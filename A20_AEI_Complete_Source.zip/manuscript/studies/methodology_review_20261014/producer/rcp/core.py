"""Joint pose/bias/map correction and a measured-cost finite-horizon controller.
No truth or face labels enter OnlineInput, registration or planning.
Left perturbations are used for pose and map orientations.
"""
from dataclasses import dataclass
from time import process_time_ns, perf_counter_ns
import itertools
import numpy as np
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation

ACTIONS=('skip','strict','tempered','converged','full')

def skew(v):
    x,y,z=v; return np.array([[0,-z,y],[z,0,-x],[-y,x,0.]])
def psd(P, floor=1e-12):
    P=(P+P.T)*.5; w,v=np.linalg.eigh(P); return (v*np.maximum(w,floor))@v.T

def exp(v): return Rotation.from_rotvec(v).as_matrix()
def log(R): return Rotation.from_matrix(R).as_rotvec()

@dataclass
class JointState:
    t: np.ndarray
    R: np.ndarray
    bias: np.ndarray
    mt: np.ndarray
    mR: np.ndarray
    P: np.ndarray
    def copy(self): return JointState(*(x.copy() for x in (self.t,self.R,self.bias,self.mt,self.mR,self.P)))
    def retract(self,d):
        s=self.copy();s.t+=d[:3];s.R=exp(d[3:6])@s.R;s.bias+=d[6:12];s.mt+=d[12:15];s.mR=exp(d[15:18])@s.mR;return s
    def delta(self,base): return np.r_[self.t-base.t,log(self.R@base.R.T),self.bias-base.bias,self.mt-base.mt,log(self.mR@base.mR.T)]

@dataclass(frozen=True)
class Dynamics:
    position_density: float=.00008
    rotation_density: float=.000002
    bias_t: float=.0015
    bias_r: float=.00015
    tau: float=125.

def left_jacobian(v):
    theta=np.linalg.norm(v);A=skew(v)
    if theta<1e-7:return np.eye(3)+.5*A+(A@A)/6.
    return np.eye(3)+(1-np.cos(theta))/theta**2*A+(theta-np.sin(theta))/theta**3*(A@A)

def left_jacobian_inverse(v):
    theta=np.linalg.norm(v);A=skew(v)
    if theta<1e-6:return np.eye(3)-.5*A+(A@A)/12.
    return np.eye(3)-.5*A+(1/theta**2-(1+np.cos(theta))/(2*theta*np.sin(theta)))*(A@A)

def transition(state,dt,velocity):
    u=(velocity[:3]-state.bias[:3])*dt;w=(velocity[3:]-state.bias[3:])*dt
    F=np.eye(18);F[:3,3:6]=-skew(state.R@u);F[:3,6:9]=-state.R*dt;F[3:6,9:12]=-state.R@left_jacobian(w)*dt
    F[6:12,6:12]*=np.exp(-dt/125.);return F

def forecast_intervals(state,velocity,lags=(0.,4.,12.,16.),step=.1):
    W=np.zeros((18,18));W[:3,:3]=np.eye(3);W[3:6,3:6]=np.eye(3)*1.5**2
    result=[];s=state.copy()
    for h in np.diff(lags):
        Facc=np.eye(18);Qacc=np.zeros((18,18));G=np.zeros((18,18));qcost=0.;N=int(np.ceil(h/step));dt=h/N
        for _ in range(N):
            F=transition(s,dt,velocity);rho=np.exp(-dt/Dynamics().tau)
            Q=np.zeros((18,18));Q[:3,:3]=np.eye(3)*Dynamics().position_density*dt;Q[3:6,3:6]=np.eye(3)*Dynamics().rotation_density*dt
            Q[6:9,6:9]=np.eye(3)*Dynamics().bias_t**2*(1-rho*rho);Q[9:12,9:12]=np.eye(3)*Dynamics().bias_r**2*(1-rho*rho)
            Facc=F@Facc;Qacc=F@Qacc@F.T+Q;G+=Facc.T@W@Facc*dt;qcost+=np.trace(W@Qacc)*dt
            s.t+=s.R@(velocity[:3]-s.bias[:3])*dt;s.R=s.R@exp((velocity[3:]-s.bias[3:])*dt);s.bias*=rho
        result.append((G,Facc,Qacc,qcost))
    return result

def propagate(s,dt,increment,dyn=Dynamics()):
    if dt<=0: return s.copy()
    F=transition(s,dt,increment/dt);o=s.copy()
    o.t+=s.R@(increment[:3]-s.bias[:3]*dt);o.R=s.R@exp(increment[3:]-s.bias[3:]*dt)
    rho=np.exp(-dt/dyn.tau);o.bias*=rho
    Q=np.zeros((18,18));Q[:3,:3]=np.eye(3)*dyn.position_density*dt;Q[3:6,3:6]=np.eye(3)*dyn.rotation_density*dt
    Q[6:9,6:9]=np.eye(3)*dyn.bias_t**2*(1-rho*rho);Q[9:12,9:12]=np.eye(3)*dyn.bias_r**2*(1-rho*rho)
    P=F@s.P@F.T+Q;o.P=(P+P.T)*.5;return o

class PriorMap:
    def __init__(self,points,normals,face_ids=None):
        self.points=np.asarray(points);self.normals=np.asarray(normals);self.tree=cKDTree(self.points)
        self.face_ids=np.asarray(face_ids) if face_ids is not None else np.full(len(points),-1)
    def pairs(self,scan,state,distance=.8):
        body=scan@state.R.T;world=body+state.t
        local=(world-state.mt)@state.mR
        d,ix=self.tree.query(local);valid=np.isfinite(d)&(d<distance)
        n=self.normals[ix[valid]]@state.mR.T
        rr=np.einsum('ij,ij->i',n,world[valid]-(self.points[ix[valid]]@state.mR.T+state.mt))
        H=np.zeros((valid.sum(),18));H[:,:3]=n;H[:,3:6]=np.cross(body[valid],n)
        H[:,12:15]=-n;H[:,15:18]=-np.cross(world[valid]-state.mt,n)
        return rr,H,ix[valid],np.flatnonzero(valid)

def thin(scan,n):
    if len(scan)<=n:return scan
    return scan[np.linspace(0,len(scan)-1,n,dtype=int)]

def register(prior_map,scan,prior,action,cpu_limit=.15):
    """One source prior, one scan, one posterior. No covariance update per iteration."""
    start=process_time_ns(); wall=perf_counter_ns();points=thin(scan,1500 if action=='full' else 96)
    precision=np.linalg.inv(prior.P);cur=prior.copy();sigma=.025;hub=.0625
    iterations=0; trials=0;converged=False;gate=False;timeout=False;selected_weight=1.
    def terms(s,weight=1.):
        r,H,ix,si=prior_map.pairs(points,s)
        w=np.minimum(1.,hub/np.maximum(np.abs(r),1e-12))*weight/sigma**2
        d=s.delta(prior);G=np.eye(18);G[3:6,3:6]=left_jacobian_inverse(d[3:6]);G[15:18,15:18]=left_jacobian_inverse(d[15:18]);N=G.T@precision@G+H.T@(H*w[:,None]);g=G.T@precision@d+H.T@(w*r)
        obj=d@precision@d+weight*(np.sum(np.where(np.abs(r)<=hub,r*r,2*hub*np.abs(r)-hub**2))+(len(points)-len(r))*(2*hub*.8-hub**2))/sigma**2
        return r,H,N,g,obj,ix,si
    initial=terms(cur)[4]; last_step=np.inf
    cap=1 if action in ('strict','tempered') else (40 if action=='full' else 25)
    for it in range(cap):
        if (process_time_ns()-start)*1e-9>cpu_limit:timeout=True;break
        r,H,N,g,obj,ix,si=terms(cur)
        if len(r)<12:break
        weights=[2.**(-i) for i in range(11)] if action=='tempered' else [1.]
        chosen=None
        for wt in weights:
            trials+=1
            tw=terms(cur,wt);step=-np.linalg.solve(tw[2],tw[3]);cand=cur.retract(step)
            within=np.linalg.norm(step[:3])<=.05 and np.linalg.norm(step[3:6])<=.01
            descent=terms(cand,wt)[4]<=tw[4]+1e-9
            if action in ('strict','tempered') and not(within and descent):continue
            if action not in ('strict','tempered') and not descent:
                for fraction in (.5,.25,.125,.0625):
                    cand=cur.retract(step*fraction)
                    if terms(cand,wt)[4]<=tw[4]+1e-9:step=step*fraction;descent=True;break
            if descent:chosen=(cand,step);selected_weight=wt;break
        iterations=it+1
        if chosen is None:break
        cur,step=chosen;gate=True;last_step=float(np.linalg.norm(step[:6]))
        if np.linalg.norm(step[:3])<.001 and np.linalg.norm(step[3:6])<.0005:converged=True;break
    r,H,N,g,obj,ix,si=terms(cur,selected_weight)
    rmse=float(np.sqrt(np.mean(np.minimum(r*r,.1**2)))) if len(r) else 1.
    inlier=float(np.mean(np.abs(r)<.10)) if len(r) else 0.
    accepted=gate and not timeout and len(r)>=12 and rmse<.065 and inlier>.6 and (action in ('strict','tempered') or converged)
    # At final accepted linearization condition original covariance exactly once.
    post=cur.copy() if accepted else prior.copy()
    if accepted:post.P=psd(np.linalg.inv(N))
    stats={'likelihood_weight':selected_weight,'action':action,'accepted':bool(accepted),'converged':bool(converged),'timeout':bool(timeout),'pairs':len(r),'iterations':iterations,'trials':trials,'residual':rmse,'inlier':inlier,'initial_objective':float(initial),'final_objective':float(obj),'step':last_step,
           'cpu_s':(process_time_ns()-start)*1e-9,'wall_s':(perf_counter_ns()-wall)*1e-9}
    return post,stats,ix,si

def observe(prior_map,scan,state,age):
    start=process_time_ns();r,H,ix,si=prior_map.pairs(thin(scan,96),state)
    J=H.T@H/.025**2
    C=np.linalg.inv(np.linalg.inv(state.P)+J)
    S=state.P-C
    eig=np.linalg.eigvalsh(J[:6,:6]);q=np.abs(r)
    features=np.array([np.log1p(age),np.log(max(np.trace(S[:3,:3]),1e-12)),np.log(max(np.trace(S[3:6,3:6]),1e-12)),np.log1p(len(r)),float(np.mean(q<.1)) if len(r) else 0.,float(np.sqrt(np.mean(q*q))) if len(r) else 1.,float(np.quantile(q,.9)) if len(r) else 1.,np.log1p(max(eig[0],0)),np.log1p(max(eig[-1],0))])
    return features,J,(process_time_ns()-start)*1e-9

@dataclass
class OnlineInput:
    stamp:float
    state:JointState
    scan:np.ndarray
    velocity:np.ndarray
    age:float
    tokens:float
    budget_rate:float

class RiskModel:
    """Positive-weight paired second moments; labels and truth stay in training files."""
    def __init__(self,path):
        z=np.load(path);self.x=z['x'];self.action=z['action'];self.outcome=z['outcome'];self.paired=z['paired'];self.cost=z['cost']
        self.mu=np.mean(self.x,axis=0);self.sd=np.maximum(np.std(self.x,axis=0),.1);self.trees={a:cKDTree((self.x[self.action==a]-self.mu)/self.sd) for a in ACTIONS[1:]};self.indices={a:np.flatnonzero(self.action==a) for a in ACTIONS[1:]}
    def predict(self,x,P,action,k=48):
        d,local=self.trees[action].query((x-self.mu)/self.sd,k=min(k,len(self.indices[action])))
        ids=self.indices[action][np.atleast_1d(local)];w=np.exp(-np.atleast_1d(d)**2/(max(np.atleast_1d(d)[-1],.1)**2));w/=w.sum()
        probs=np.array([w[self.outcome[ids]==i].sum() for i in range(3)])
        # Total mixture learned from paired whitened errors, source prior transported.
        L=np.linalg.cholesky(psd(P));u=self.paired[ids,:,:18];v=self.paired[ids,:,18:]
        # Each input contains one pair; retained axis permits extension to timed pairs.
        u=u[:,0];v=v[:,0];Mskip=L@np.einsum('n,ni,nj->ij',w,u,u)@L.T
        Mpost=L@np.einsum('n,ni,nj->ij',w,v,v)@L.T
        us=np.einsum('n,ni->i',w,u);vs=np.einsum('n,ni->i',w,v)
        cu=u-us;cv=v-vs
        Cs=psd(np.einsum('n,ni,nj->ij',w,cu,cu));Cp=psd(np.einsum('n,ni,nj->ij',w,cv,cv));Cps=np.einsum('n,ni,nj->ij',w,cv,cu)
        Aw=Cps@np.linalg.inv(Cs);bw=vs-Aw@us;Rw=psd(Cp-Aw@Cs@Aw.T)
        A=L@Aw@np.linalg.inv(L);b=L@bw;R=L@Rw@L.T
        return psd(Mskip),psd(Mpost),probs,float(np.quantile(self.cost[ids],.95)),A,b,psd(R),L@us,L@Cs@L.T


class TokenBucket:
    def __init__(self,rate,capacity=.1):self.rate=rate;self.capacity=capacity;self.tokens=capacity;self.total=0.;self.t=0.
    def advance(self,t):self.tokens=min(self.capacity,self.tokens+max(0.,t-self.t)*self.rate);self.t=t
    def charge(self,c):self.tokens-=c;self.total+=c

class Planner:
    """Receding-horizon expected-moment planning, exact search over the finite action set.
    This is a moment approximation, not a full POMDP or outcome-adaptive tree.
    Future scans are not supplied. Future geometry is raycast from commanded motion.
    """
    def __init__(self,model,policy='rcp',period=4.,fixed='full',costs=None,lam=.3,horizon=(0.,4.,12.,16.),overhead_rate=.002,decision_cost=.004):
        self.model=model;self.policy=policy;self.period=period;self.fixed=fixed;self.lam=lam;self.horizon=horizon
        self.overhead_rate=overhead_rate;self.decision_cost=decision_cost
        self.costs=costs or dict(strict=.003,tempered=.004,converged=.005,full=.01);self.last_slot=0;self.last_accept=0.
    def choose(self,inp,features,J,future_features=None):
        s=inp.state;aff=[a for a in ACTIONS[1:] if self.costs[a]<=inp.tokens]
        if not aff:return 'skip',{'reason':'tokens'}
        if self.policy in ('greedy','rcp') and inp.age>=12.:
            return ('full' if 'full' in aff else 'skip'),{'reason':'common_cadence_floor'}
        if self.policy=='periodic':
            slot=int(np.floor(inp.stamp/self.period+1e-8));due=slot>self.last_slot;self.last_slot=max(slot,self.last_slot)
            return (self.fixed if due and self.fixed in aff else 'skip'),{'reason':'periodic'}
        if self.policy=='age':return (self.fixed if inp.age>=self.period and self.fixed in aff else 'skip'),{'reason':'age'}
        if self.policy=='simple':return (self.fixed if inp.age>=self.period and features[4]>.65 and features[5]<.08 and self.fixed in aff else 'skip'),{'reason':'simple'}
        if self.policy=='geometry':
            best=max(aff,key=lambda a:np.trace(s.P[:3,:3])-np.trace(np.linalg.inv(np.linalg.inv(s.P)+J*({'strict':.5,'tempered':.6,'converged':1.,'full':1.5}[a]))[:3,:3])-self.lam*self.costs[a])
            return (best if inp.age>=1. else 'skip'),{'reason':'geometry'}
        forecasts=forecast_intervals(s,inp.velocity,self.horizon[:2] if self.policy=='greedy' else self.horizon)
        G=[v[0] for v in forecasts]
        snapshots=[]
        nodes=1 if self.policy=='greedy' else 3
        for i in range(nodes):
            xx=features if future_features is None else (future_features[i][0] if isinstance(future_features[i],tuple) else future_features[i])
            if i==0:node_P=s.P
            elif future_features is not None:node_P=future_features[i][1]
            else:
                node_P=s.P.copy()
                for _,F,Q,_ in forecasts[:i]:node_P=F@node_P@F.T+Q
            dic={}
            for a in ACTIONS[1:]:dic[a]=self.model.predict(xx,node_P,a)
            snapshots.append(dic)
        # Precompute affine transports, rather than rebuilding heads for 125 sequences.
        source_skip=snapshots[0]['full'][0]
        source_mean=snapshots[0]['full'][7];source_cov=snapshots[0]['full'][8]
        transitions=[]
        for snapshot in snapshots:
            tr={}
            for a,pred in snapshot.items():
                tr[a]=(pred[4],pred[5],pred[6],pred[2],pred[3])
            transitions.append(tr)
        seqs=np.asarray(list(itertools.product(ACTIONS,repeat=nodes)))
        C=np.repeat(source_cov[None,:,:],len(seqs),axis=0);means=np.repeat(source_mean[None,:],len(seqs),axis=0)
        tokens=np.full(len(seqs),inp.tokens);values=np.zeros(len(seqs));valid=np.ones(len(seqs),bool)
        for i in range(nodes):
            if i>0:
                can_plan=tokens>=self.decision_cost
                valid&=can_plan|(seqs[:,i]=='skip')
                tokens-=can_plan*self.decision_cost;values+=self.lam*can_plan*self.decision_cost
            for a in ACTIONS[1:]:
                take=seqs[:,i]==a
                A,b,R,pr,c=transitions[i][a];c=max(c,self.costs[a]);valid[take]&=tokens[take]>=c;tokens[take]-=c
                C[take]=A@C[take]@A.T+R;means[take]=means[take]@A.T+b;values[take]+=self.lam*c
            h=self.horizon[i+1]-self.horizon[i]
            overhead=self.overhead_rate*h
            values+=self.lam*overhead
            tokens=np.minimum(.1,tokens+(inp.budget_rate-self.overhead_rate)*h)
            valid&=tokens>=0
            values+=np.einsum('ij,nji->n',G[i],C)+np.einsum('ni,ij,nj->n',means,G[i],means)
            F,Q=forecasts[i][1:3];values+=forecasts[i][3]
            C=F@C@F.T+Q;means=means@F.T
        values[~valid]=np.inf
        if not np.any(valid):return 'skip',{'reason':'no_affordable_plan','evaluated':len(seqs)}
        index=int(np.argmin(values));best=(values[index],seqs[index]);evaluated=len(seqs)
        return best[1][0],{'reason':self.policy,'predicted_objective':float(best[0]),'sequence':list(best[1]),'evaluated':evaluated}
