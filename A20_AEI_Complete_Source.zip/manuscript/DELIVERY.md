# Complete source and original research data

Download `A20_AEI_Complete_Source.zip` and every `A20_AEI_Data_*.zip`
listed in `DELIVERY_INDEX.json` into the same directory. Extract the Source ZIP;
keep the data ZIP files unchanged. From the extracted `manuscript` directory:

```sh
python reporting/restore_data.py --archive-dir ..
python reporting/verify_package.py --source ../A20_AEI_Complete_Source.zip --data-dir .. --restored-root .
```

If the ZIP files are elsewhere, replace `..` with their directory. Restoration
verifies each archive and every payload hash, refuses unsafe paths and links,
and skips already correct files. It refuses to overwrite changed files unless
`--overwrite` is explicitly supplied. Run restoration before numerical study
reproduction or figure regeneration. Publication figure PDFs are in Source.

`MANIFEST.json` contains SHA256 hashes for every delivered research/source
payload, across Source and all data volumes. `DELIVERY_INDEX.json` maps each
payload to exactly one archive and records data archive hashes and sizes.
These generated inventory files do not hash themselves. All original files
remain unchanged in the research working tree. The archive set is complete only
when every data volume listed in the index is present; no network is used by
restoration or verification. Compiled article PDFs are supplied separately.
LaTeX intermediates, bytecode and reproducible presentation previews are
excluded under the documented packaging policy.
