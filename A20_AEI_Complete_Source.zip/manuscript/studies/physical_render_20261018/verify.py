"""Recompute all image metrics and check immutable protocol, camera and artifacts."""
from pathlib import Path
import json,hashlib,sys
import numpy as np
import pandas as pd
from PIL import Image
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT.parent/'lifecycle_20261018'))
from imaging import decode,fit,configuration,old
freeze=json.loads((ROOT/'freeze.json').read_text())
for rel,h in freeze['sha256'].items():assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==h,rel
for rel,h in freeze['external'].items():assert hashlib.sha256((ROOT.parent/rel).read_bytes()).hexdigest()==h,rel
p=json.loads((ROOT/'protocol.json').read_text());frame=pd.read_csv(ROOT/'outputs'/'metrics.csv');assert len(frame)==72
assert set(frame.seed)==set(p['held_out_seeds'])
assert set(frame.variant)==set(p['variants'])
max_projection=0.;largest_numeric=0.
for seed in p['held_out_seeds']:
 s=json.loads((ROOT/'outputs'/'test'/(str(seed)+'.json')).read_text());assert s['pilot'] is False;assert s['samples']==32;assert not s['denoising']
 for k in ('camera','rotation','translation_error','rotation_error','cad','actual','missing'):s[k]=np.asarray(s[k])
 assert np.allclose(s['rotation'].T@s['rotation'],np.eye(3));assert np.isclose(np.linalg.det(s['rotation']),1)
 error=float(np.max(np.abs(old.project(s['actual'],s['camera'],s['rotation'],s['focal'])-s['blender_projected_pixels'])));max_projection=max(max_projection,error);assert error<1e-3
 for v in p['variants']:
  path=ROOT/'outputs'/'test'/(str(seed)+'_'+v+'.png');rgb=np.asarray(Image.open(path).convert('RGB'));assert rgb.shape==(576,768,3)
  row=frame[(frame.seed==seed)&(frame.variant==v)].iloc[0];assert row.png_sha256==hashlib.sha256(path.read_bytes()).hexdigest()
  values,arrays=fit(s,configuration('baseline'),decode(rgb,18.))
  for k,x in values.items():
   error=abs(x-row[k]);largest_numeric=max(largest_numeric,error);assert np.isclose(x,row[k],rtol=1e-11,atol=1e-12),(seed,v,k,x,row[k])
  archived=np.load(ROOT/'outputs'/(str(seed)+'_'+v+'_correspondences.npz'))
  for k,x in arrays.items():assert np.allclose(x,archived[k],rtol=1e-11,atol=1e-12),(seed,v,k)
qa={'status':'PASS','sources':24,'images_reprocessed':72,'maximum_camera_projection_discrepancy_px':max_projection,'maximum_recomputed_csv_difference':largest_numeric,'source_protocol_and_external_hashes_match':True,'all_correspondence_arrays_match':True,'no_pilot_in_test':True}
(ROOT/'verification.json').write_text(json.dumps(qa,indent=2));print(json.dumps(qa,indent=2))
