"""Complete vector schematics and a plate of the five supplied simulation views.

The scene plate places unmodified originals at their original aspect ratios.
Its images provide application context, with no inferred numerical measurements.
"""
from pathlib import Path
import hashlib
import json
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import fitz
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.path import Path as MPath

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'source/figure_qa'))
from audit_panel_alignment import require_matplotlib_panel_alignment

OUT = ROOT / 'figures/r6'
QA = ROOT / 'qa'
OUT.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['DejaVu Sans'],
    'font.size': 7.2,
    'pdf.fonttype': 42,
    'svg.fonttype': 'none',
    'axes.spines.top': False,
    'axes.spines.right': False,
    'savefig.facecolor': 'white',
})

C = {
    'ink': '#203849', 'muted': '#5E6F7C', 'line': '#B7C4CE',
    'blue': '#286C91', 'blue_bg': '#EDF5F9',
    'teal': '#327C7F', 'teal_bg': '#ECF5F4',
    'violet': '#756A94', 'violet_bg': '#F1EEF6',
    'amber': '#A47936', 'amber_bg': '#F8F3E9',
    'neutral': '#F6F8FA',
}
MM = 25.4
TEXT_CONTAINMENT = []


def canvas(width, height):
    return plt.figure(figsize=(width / MM, height / MM), facecolor='white')


def panel(fig, width, height, bottom, letter, title, total_height):
    ax = fig.add_axes([2 / width, bottom / total_height,
                       (width - 4) / width, height / total_height])
    ax.set_xlim(0, width - 4)
    ax.set_ylim(0, height)
    ax.set_axis_off()
    ax.set_gid(letter)
    ax.text(0, height - 2.8, letter, fontsize=9, fontweight='bold',
            color=C['ink'], va='center')
    ax.text(5.5, height - 2.8, title, fontsize=8.6, fontweight='bold',
            color=C['ink'], va='center')
    return ax


def text(ax, x, y, value, size=7.0, color=None, weight='normal', ha='left'):
    return ax.text(x, y, value, fontsize=size, color=color or C['ink'],
                   fontweight=weight, ha=ha, va='center', linespacing=1.2)


def box(ax, x, y, w, h, title, lines=(), family='blue', title_size=7.8,
        body_size=7.0, line_gap=3.7):
    ax.add_patch(FancyBboxPatch((x, y), w, h,
                 boxstyle='round,pad=0,rounding_size=1.4',
                 linewidth=.6, edgecolor=C['line'], facecolor=C[family + '_bg']))
    ax.plot([x + 2.3, x + 2.3], [y + h - 6.6, y + h - 2.5],
            lw=1.7, color=C[family], solid_capstyle='round')
    title_artist = text(ax, x + 4, y + h - 4.5, title, title_size, weight='bold')
    TEXT_CONTAINMENT.append((ax, title_artist, x + w - 2))
    for i, line in enumerate(lines):
        artist = text(ax, x + 2.3, y + h - 9 - i * line_gap, line, body_size)
        TEXT_CONTAINMENT.append((ax, artist, x + w - 2))


def arrow(ax, points, meta=False, color=None, lw=.95):
    codes = [MPath.MOVETO] + [MPath.LINETO] * (len(points) - 1)
    patch = FancyArrowPatch(path=MPath(points, codes), arrowstyle='-|>',
                 mutation_scale=6.4, linewidth=lw,
                 linestyle=(0, (3, 2.5)) if meta else '-',
                 color=color or (C['violet'] if meta else C['blue']),
                 joinstyle='round', capstyle='round', clip_on=False)
    ax.add_patch(patch)
    return patch


def cross_arrow(fig, a, b, points_a, endpoint_b, *, meta=True, clearance_mm=3):
    points = [fig.transFigure.inverted().transform(a.transData.transform(p))
              for p in points_a]
    end = fig.transFigure.inverted().transform(b.transData.transform(endpoint_b))
    # The route stays in the outside gutter until it reaches the target row.
    points += [(points[-1][0], end[1] + clearance_mm / (fig.get_figheight() * MM)),
               (end[0], end[1] + clearance_mm / (fig.get_figheight() * MM)), end]
    patch = FancyArrowPatch(path=MPath(points, [MPath.MOVETO] +
                        [MPath.LINETO] * (len(points) - 1)),
               transform=fig.transFigure, arrowstyle='-|>', mutation_scale=6.4,
               lw=.9, linestyle=(0, (3, 2.5)) if meta else '-',
               color=C['violet'] if meta else C['blue'], clip_on=False)
    fig.add_artist(patch)


def save(fig, name, *, axes, ids, rows=None, columns=None, dpi=600):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    overflow = []
    for ax, artist, right in TEXT_CONTAINMENT:
        if ax.figure is not fig:
            continue
        actual = ax.transData.inverted().transform(artist.get_window_extent(renderer).corners())
        if actual[:, 0].max() > right + .05:
            overflow.append((artist.get_text(), round(actual[:, 0].max() - right, 2)))
    if overflow:
        raise ValueError('Text exceeds card right padding (mm): ' + str(overflow))
    alignment = require_matplotlib_panel_alignment(
        fig, axes=axes, panel_ids=ids,
        row_groups=rows, column_groups=columns,
        json_out=QA / f'r6_{name}_alignment.json',
        overlay_svg=QA / f'r6_{name}_alignment.svg',
        tolerance_pt=1.5, gutter_tolerance_pt=1.5, strict=True,
    )
    pending_pdf = OUT / f'.{name}.pending.pdf'
    pending_svg = OUT / f'.{name}.pending.svg'
    pending_png = OUT / f'.{name}.pending.png'
    pending_tiff = OUT / f'.{name}.pending.tiff'
    fig.savefig(pending_pdf)
    with fitz.open(pending_pdf) as check:
        if len(check) != 1:
            raise ValueError('The vector export must have one complete page')
    pending_pdf.replace(OUT / f'{name}.pdf')
    fig.savefig(pending_svg)
    pending_svg.replace(OUT / f'{name}.svg')
    fig.savefig(pending_png, dpi=300)
    pending_png.replace(OUT / f'{name}.png')
    fig.savefig(pending_tiff, dpi=dpi, pil_kwargs={'compression': 'tiff_lzw'})
    pending_tiff.replace(OUT / f'{name}.tiff')
    plt.close(fig)
    return alignment


def architecture():
    fig = canvas(168, 136)
    a = panel(fig, 168, 36, 98, 'a',
              'Task declarations select a policy with matching evidence', 136)
    text(a, 5.5, 28.5, 'Configured before sensing  |  Separate metadata dispatcher',
         6.8, C['muted'])
    box(a, 1, 2, 36, 22, 'Frozen models',
        ['1,120 earlier episodes', 'CART / RF forecasts', '20-policy catalogue'],
        family='violet', body_size=7.0)
    box(a, 41, 2, 37, 22, 'Risk calibration',
        ['696 independent inputs', '240 simultaneous cards', 'Event, mixture, service; U'],
        family='violet', body_size=7.0)
    box(a, 83, 2, 37, 22, 'Declared request',
        ['Profile, load, source', 'Trajectory / capture / both', 'Allowance + deadline'],
        family='amber', body_size=6.8)
    box(a, 125, 2, 38, 22, 'Compatible policy',
        ['Match all requested cards', 'Min. calibration loss + CPU', 'Empty set: REFUSED'],
        family='violet', body_size=6.8)
    arrow(a, [(37, 13), (41, 13)], meta=True)
    arrow(a, [(78, 13), (80.5, 13), (80.5, 26), (144, 26), (144, 24)], meta=True)
    arrow(a, [(120, 13), (125, 13)], meta=True)

    b = panel(fig, 168, 60, 35, 'b',
              'A retained solver publishes replaceable posterior versions', 136)
    text(b, 5.5, 52.5, 'Numerical execution on causal inputs', 6.8, C['muted'])
    box(b, 1, 15, 32, 31, 'Scan processing',
        ['Rolling LiDAR scan', 'Deskew + voxels', 'Map + source prior',
         'Sealed scan + prior'], body_size=6.9)
    box(b, 37, 15, 41, 31, 'Retained ICP state',
        ['Fixed prior; retained 18D state', 'Residual, inlier, step, spectrum',
         'Quality determines eligibility'], title_size=7.4, body_size=6.7,
        line_gap=3.5)
    text(b, 39.3, 23, 'Checkpoints', 6.7, C['muted'])
    for i, label in enumerate(['1', '2', '4', '8', '16', '25']):
        x = 39.4 + i * 6.0
        b.add_patch(FancyBboxPatch((x, 16.8), 5.2, 4.3,
              boxstyle='round,pad=0,rounding_size=.65', lw=.55,
              edgecolor=C['blue'], facecolor='white'))
        text(b, x + 2.6, 18.95, label, 6.7, ha='center')
    box(b, 82, 15, 38, 31, 'Forecast + rules',
        ['Error / event / work', 'Profile + time predicates',
         'Choose a reachable cap', 'Publish / continue / stop'],
        family='amber', title_size=7.5, body_size=6.8)
    box(b, 124, 15, 39, 31, 'Receiver installation',
        ['Posterior (x, P) + source ID', 'Replace source contribution',
         'Replay measured motion', 'Reject: restore prior + replay'],
        family='teal', title_size=7.7, body_size=6.65)
    for start, end in [(33, 37), (78, 82), (120, 124)]:
        arrow(b, [(start, 31), (end, 31)])
    arrow(b, [(101, 15), (101, 9), (57.5, 9), (57.5, 15)])
    text(b, 62, 11.8, 'Continue retained prefix', 6.6, C['blue'])
    box(b, 1, 1, 42, 7, 'Measured motion stream', family='blue', title_size=7.0)
    arrow(b, [(17, 8), (17, 15)])
    arrow(b, [(43, 4.2), (121.5, 4.2), (121.5, 23), (124, 23)], color=C['teal'])
    b.add_patch(FancyBboxPatch((124, 1), 39, 9,
            boxstyle='round,pad=0,rounding_size=1.2', lw=.7,
            edgecolor=C['teal'], facecolor=C['teal_bg']))
    text(b, 126.3, 6.6, 'Live pose + version + P', 6.8, weight='bold')
    text(b, 126.3, 3, 'Available after installed replay', 6.6, C['muted'])
    arrow(b, [(143.5, 15), (143.5, 10)], color=C['teal'])
    cross_arrow(fig, a, b, [(163, 13), (165, 13)], (104, 46))
    text(b, 126, 47.5, 'Selected policy / model', 6.6, C['violet'])

    c = panel(fig, 168, 28, 4, 'c',
              'Separate scope checking authorizes a scheduled statement', 136)
    box(c, 1, 1, 45, 20, 'Version + event card',
        ['Source / profile / event IDs', 'Policy / model / artifact hashes',
         'Queue / load / assessment time'],
        family='violet', title_size=7.2, body_size=6.8)
    box(c, 50, 1, 60, 20, 'Scope + allowance checks',
        ['Seal, active components and service match',
         'Declared mixture; requested event; U ≤ δ',
         'Finite fields; scheduled time valid'],
        family='violet', title_size=7.5, body_size=6.8)
    box(c, 116, 1, 47, 20, 'Scheduled statement',
        ['Applicable population bound(s)', 'Otherwise: provisional / refused'],
        family='teal', title_size=7.6, body_size=6.8)
    arrow(c, [(46, 10.5), (50, 10.5)], meta=True)
    arrow(c, [(110, 10.5), (116, 10.5)], meta=True)
    cross_arrow(fig, b, c, [(163, 21), (165, 21)], (23, 21), clearance_mm=1.5)
    text(c, 122, 24.8, 'Version metadata', 6.6, C['violet'])
    fig.text(.017, .011, 'Solid: numerical data and motion', fontsize=6.6, color=C['blue'])
    fig.text(.46, .011, 'Dashed: configured policy and evidence', fontsize=6.6, color=C['violet'])
    return save(fig, 'architecture', axes=[a, b, c], ids=['a', 'b', 'c'],
                columns=[['a', 'b', 'c']])


def interface():
    fig = canvas(168, 75)
    a = panel(fig, 168, 32, 41, 'a',
              'One immutable source prior defines every posterior version', 75)
    box(a, 1, 2, 31, 18, 'Source prior',
        ['Scan + prior (x, P)', 'Fixed source identity'],
        family='blue', body_size=6.8)
    box(a, 42, 2, 43, 18, 'Retained ICP state',
        ['Same objective and prior', 'Continue the retained prefix'],
        family='blue', body_size=6.9)
    arrow(a, [(32, 11), (42, 11)])
    text(a, 102, 24, 'Correlated source versions', 7.1, C['teal'], weight='bold')
    a.plot([85, 92, 92, 153.5], [11, 11, 20, 20], color=C['teal'], lw=.95)
    for i, label in enumerate(['v1', 'v2', 'v3']):
        x = 96 + i * 24
        a.add_patch(FancyBboxPatch((x, 2), 19, 12,
                  boxstyle='round,pad=0,rounding_size=1.2', lw=.7,
                  facecolor=C['teal_bg'], edgecolor=C['teal']))
        text(a, x + 9.5, 9.8, label, 8.1, weight='bold', ha='center')
        text(a, x + 9.5, 5, 'Mean + P', 6.9, ha='center')
        arrow(a, [(x + 9.5, 20), (x + 9.5, 14)], color=C['teal'])
    b = panel(fig, 168, 34, 4, 'b',
              'The receiver replaces one source contribution, then replays motion', 75)
    boxes = [
        (1, 30, 'Prior only', ['Propagate motion']),
        (36, 34, 'Install v1', ['Replay to availability']),
        (75, 34, 'Replace with v2', ['Replay to availability']),
        (114, 49, 'Rejected completion', ['Restore source prior', 'Replay measured motion']),
    ]
    for x, w, title, lines in boxes:
        box(b, x, 7, w, 19, title, lines, family='teal',
            title_size=7.5, body_size=6.8)
    for start, end in [(31, 36), (70, 75), (109, 114)]:
        arrow(b, [(start, 16.5), (end, 16.5)], color=C['teal'])
    text(b, 1, 2, 'Illustrative sequence; optimization remains tied to the source prior.',
         6.8, C['muted'])
    return save(fig, 'source_versions', axes=[a, b], ids=['a', 'b'],
                columns=[['a', 'b']])


def scene_plate():
    width, height = 168, 83
    fig = canvas(width, height)
    top_w = (164 - 2 * 3) / 3
    bottom_w = (164 - 3) / 2
    # Exact equal-size frames per row. Image aspect ratios remain unchanged;
    # small white margins fit each full original inside its frame.
    frames = [(2 + i * (top_w + 3), 50, top_w, 27.5) for i in range(3)]
    frames += [(2 + i * (bottom_w + 3), 3, bottom_w, 42) for i in range(2)]
    titles = ['Exterior approach', 'Forward underside', 'Elevated overview',
              'Landing-gear proximity', 'Under-wing / fuselage proximity']
    ids = list('abcde')
    axes, rows = [], [['a', 'b', 'c'], ['d', 'e']]
    manifest = json.loads((QA / 'r6_scene_asset_manifest.json').read_text())
    rendered = []
    for (x, y, w, h), label, title, asset in zip(frames, ids, titles, manifest['assets']):
        image_path = ROOT / asset['file']
        assert hashlib.sha256(image_path.read_bytes()).hexdigest() == asset['sha256']
        img = mpimg.imread(image_path)
        ih, iw = img.shape[:2]
        scale = min(w / iw, h / ih)
        dw, dh = iw * scale, ih * scale
        x0, y0 = (w - dw) / 2, (h - dh) / 2
        ax = fig.add_axes([x / width, y / height, w / width, h / height])
        ax.set_gid(label)
        ax.set_xlim(0, w)
        ax.set_ylim(0, h)
        ax.set_axis_off()
        ax.imshow(img, origin='upper', extent=(x0, x0 + dw, y0, y0 + dh),
                  aspect='auto', interpolation='none')
        ax.text(0, h + 2.3, label, fontsize=8.1, fontweight='bold',
                color=C['ink'], va='center', clip_on=False)
        text(ax, 4.5, h + 2.3, title, 7.2)
        axes.append(ax)
        rendered.append({'panel':label, 'source':asset['file'],
                         'display_width_mm':dw, 'display_height_mm':dh,
                         'effective_source_dpi':iw / (dw / MM),
                         'aspect_ratio_preserved':abs(dw/dh - iw/ih) < 1e-10,
                         'crop':'none', 'pixel_edits':'none'})
    (QA / 'r6_scene_render_geometry.json').write_text(json.dumps(rendered, indent=2))
    return save(fig, 'simulation_views', axes=axes, ids=ids, rows=rows,
                columns=[], dpi=600)


if __name__ == '__main__':
    for name, draw in [('architecture', architecture), ('source_versions', interface),
                       ('simulation_views', scene_plate)]:
        result = draw()
        print(json.dumps({'figure': name, 'alignment': result.get('verdict') or
                          result.get('status'), 'exported':['pdf','svg','png','tiff']}),
              flush=True)
