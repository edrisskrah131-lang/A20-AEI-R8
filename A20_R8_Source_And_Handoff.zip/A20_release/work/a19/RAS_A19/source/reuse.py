"""Exact reusable-probe policies: a probe both informs and materializes an action.

Model terminal losses exclude compute. Completed probes are paid once and their
cached registration output has zero remaining execution cost.
"""
from functools import lru_cache
import itertools,json,pickle
import numpy as np
import pandas as pd
from prospective import ROOT,PRICE,ACTIONS,MESHES
from evaluate_prospective import QUANTUM,FIDELITIES,RATIOS

class ReusePlanner:
    def __init__(self,losses,observations,costs,budget,rho=1.,mode='joint',reuse=True,price=.3):
        self.Y=np.asarray(losses);self.Z=np.asarray(observations);self.c=np.asarray(costs)
        self.budget=int(budget);self.rho=rho;self.mode=mode;self.reuse=reuse
        self.root=(-1,-1,-1);self.price=price*QUANTUM;self.unit_price=price
        self.belief=lru_cache(None)(self._belief);self.solve=lru_cache(None)(self._solve)
    def _belief(self,state):
        w=np.ones(len(self.Y))
        for q,z in enumerate(state):
            if z>=0:w*=np.where(self.Z[:,q]==z,self.rho,1-self.rho)
        return w/w.sum() if w.sum()>0 else None
    def spent(self,state):return sum(self.c[q+1] for q,z in enumerate(state) if z>=0)
    def remaining_costs(self,state):
        cc=self.c.copy()
        if self.reuse:
            for q,z in enumerate(state):
                if z>=0:cc[q+1]=0
        return cc
    def stop(self,state,belief_state=None):
        w=self.belief(state if belief_state is None else belief_state)
        cc=self.remaining_costs(state);mask=cc+self.spent(state)<=self.budget
        vals=w@self.Y+self.price*cc;vals[~mask]=np.inf
        a=int(np.argmin(vals));return float(vals[a]),a
    def _solve(self,state):
        best,a=self.stop(state);decision=('stop',a)
        w=self.belief(state);spent=self.spent(state)
        for q,z in enumerate(state):
            if z>=0 or spent+self.c[q+1]>self.budget:continue
            if self.mode=='reserve' and spent+self.c[q+1]+self.c[4]>self.budget:continue
            value=self.price*self.c[q+1]
            for bit in [0,1]:
                probability=float(w@np.where(self.Z[:,q]==bit,self.rho,1-self.rho))
                if probability==0:continue
                child=list(state);child[q]=bit;child=tuple(child)
                risk=self.stop(child)[0] if self.mode=='myopic' else self.solve(child)[0]
                value+=probability*risk
            if value<best-1e-14:best=value;decision=('query',q)
        return best,decision
    def fixed_subset(self):
        best,_=self.stop(self.root);subset=()
        for mask in range(1,8):
            qs=tuple(q for q in range(3) if mask&(1<<q))
            if sum(self.c[q+1] for q in qs)>self.budget:continue
            val=sum(self.c[q+1] for q in qs)*self.price
            for bits in itertools.product([0,1],repeat=len(qs)):
                state=[-1]*3;w=np.ones(len(self.Y))/len(self.Y)
                for q,bit in zip(qs,bits):
                    state[q]=bit;w*=np.where(self.Z[:,q]==bit,self.rho,1-self.rho)
                if w.sum()>0:val+=w.sum()*self.stop(tuple(state))[0]
            if val<best-1e-14:best=val;subset=qs
        return best,subset
    def export(self):
        table={};fallback={}
        def visit(state):
            if state in table:return
            table[state]=self.solve(state)[1]
            if table[state][0]=='query':
                q=table[state][1]
                for bit in [0,1]:
                    child=list(state);child[q]=bit;child=tuple(child)
                    if self.belief(child) is not None:visit(child)
                    else:fallback[(state,bit)]=self.stop(child,belief_state=state)[1]
        visit(self.root)
        subset=self.fixed_subset()[1] if self.mode=='fixed' else None
        fa={}
        if subset is not None:
            for bits in itertools.product([0,1],repeat=len(subset)):
                state=[-1]*3
                for q,b in zip(subset,bits):state[q]=b
                state=tuple(state);belief_state=state if self.belief(state) is not None else self.root
                fa[bits]=self.stop(state,belief_state)[1]
        return dict(table=table,fallback=fallback,subset=subset,fixed_actions=fa,
                    coarse=self.stop(self.root)[1],costs=self.c,budget=self.budget,
                    rho=self.rho,reuse=self.reuse,price=self.unit_price,model_risk=self.solve(self.root)[0])

def dispatch(model,method,probe):
    if method=='full':return 4,[]
    if method=='coarse':return int(model['coarse']),[]
    if model['subset'] is not None:
        path=list(model['subset']);bits=tuple(int(probe(q)) for q in path)
        return model['fixed_actions'][bits],path
    state=(-1,)*3;path=[]
    while True:
        kind,q=model['table'][state]
        if kind=='stop':return q,path
        bit=int(probe(q));path.append(q);child=list(state);child[q]=bit;child=tuple(child)
        if child not in model['table']:return model['fallback'][(state,bit)],path
        state=child

def realized(row,model,method):
    a,path=dispatch(model,method,lambda q:row['accepted'][q+1])
    charged=set(q+1 for q in path)
    costs=sum(row['cpu'][i] for i in charged)
    if a not in charged or not model['reuse']:costs+=row['cpu'][a]
    terminal=row['losses'][a]-PRICE*row['cpu'][a]
    return terminal+model['price']*costs,a,path,costs

def compile_models():
    rows=[json.loads(l) for l in (ROOT/'data/prospective_cases.jsonl').read_text().splitlines()]
    train=[r for r in rows if r['split']=='train'];val=[r for r in rows if r['split']=='validation']
    profile=json.loads((ROOT/'data/runtime_profile.json').read_text())
    methods=['full','coarse','fixed','myopic','reserve','joint','no_reuse']
    models={};selection=[]
    for mesh,ctx,ratio,price,method in itertools.product(MESHES,range(3),RATIOS,[.003,.03,.3],methods):
        tr=[r for r in train if r['mesh']==mesh and r['context']==ctx]
        vs=[r for r in val if r['mesh']==mesh and r['context']==ctx]
        Y=np.array([r['losses'] for r in tr])-PRICE*np.array([r['cpu'] for r in tr])
        Z=np.array([r['accepted'][1:4] for r in tr],int)
        c=np.array(profile[mesh]['execution_units']);budget=int(max(c)*ratio)
        grid=[.5] if method in ['full','coarse'] else FIDELITIES
        candidates=[]
        for rho in grid:
            p=ReusePlanner(Y,Z,c,budget,rho,mode=method,reuse=method!='no_reuse',price=price)
            model=p.export();risk=np.mean([realized(r,model,method)[0] for r in vs])
            candidates.append((risk,rho,model))
        best=min(x[0] for x in candidates);risk,rho,model=next(x for x in candidates if x[0]<=best+1e-12)
        models[(mesh,ctx,ratio,price,method)]=model
        selection.append(dict(mesh=mesh,context=ctx,ratio=ratio,price=price,method=method,rho=rho,
                              validation_loss=risk,grid_losses=[(a,b) for a,b,_ in candidates]))
    with (ROOT/'data/reuse_models.pkl').open('wb') as f:pickle.dump(models,f)
    (ROOT/'data/reuse_selection.json').write_text(json.dumps(selection,indent=2))
    print(pd.DataFrame(selection).query('ratio == 1.0 and price == .3').to_string(index=False))

if __name__=='__main__':compile_models()
