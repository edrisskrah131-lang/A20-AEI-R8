"""Redraw manuscript figures from immutable result-table snapshots.

No experiment, selection, risk allocation or numerical producer is changed.
Run with the project's Python environment; output includes PDF/SVG/PNG.
"""
from pathlib import Path
import hashlib, json, shutil
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch, Rectangle, Patch
from matplotlib.colors import ListedColormap

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'paper/figures/visual'
DATA = OUT / 'data'
DATA.mkdir(parents=True, exist_ok=True)
R8 = Path('/workspace/a20-env/study/A20_release/output/A20_AEI_R8/data/r8_final/analysis')
BLUE, TEAL, ORANGE, RED = '#245B91', '#16887B', '#D68A35', '#BF5960'
INK, MUTED, LIGHT, PURPLE = '#263746', '#73818D', '#E9EEF2', '#8A6BA5'
SERVICES = ['relaxed', 'standard', 'tight', 'contended']
PROFILES = ['nominal', 'unfitted']
POLCOL = {'Fixed2': INK, 'Fixed4': PURPLE, 'Final': RED, 'FlatCART': BLUE,
          'FlatRF': ORANGE, 'OldRAVC': TEAL, 'KG1': BLUE, 'Full': TEAL}
MARK = {'Fixed2': 's', 'Fixed4': 'D', 'Final': 'X', 'FlatCART': 'o',
        'FlatRF': '^', 'OldRAVC': 'P', 'KG1': 'o', 'Full': 'D'}
mpl.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
    'axes.titlesize': 8.5, 'axes.labelsize': 8, 'xtick.labelsize': 7,
    'ytick.labelsize': 7, 'legend.fontsize': 7, 'legend.frameon': False,
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.edgecolor': '#ABB6BF', 'axes.labelcolor': INK, 'text.color': INK,
    'xtick.color': INK, 'ytick.color': INK, 'axes.linewidth': .65,
    'lines.linewidth': 1.45, 'pdf.fonttype': 42, 'svg.fonttype': 'none',
    'savefig.facecolor': 'white', 'figure.facecolor': 'white'})
FILES = {}
QA = []

def snapshot(prefix, name, source):
    dest = DATA / f'{prefix}_{name}.csv'
    if not dest.exists(): shutil.copy2(source, dest)
    FILES[str(dest.relative_to(ROOT))] = hashlib.sha256(dest.read_bytes()).hexdigest()
    return pd.read_csv(dest)

def r8(name): return snapshot('r8', name, R8 / (name + '.csv'))
def r9(name): return snapshot('r9', name, ROOT / 'tables' / (name + '.csv'))

def panel(ax, letter, title):
    ax.set_title(title, loc='left', pad=11, fontweight='medium')
    ax.text(-.035, 1.055, letter, transform=ax.transAxes, fontweight='bold',
            fontsize=10, ha='right', va='bottom')

def clean(ax): ax.grid(axis='y', color=LIGHT, lw=.7); ax.set_axisbelow(True)

def save(fig, name):
    fig.canvas.draw()
    # Keep every text object's box inside the exported canvas.
    renderer = fig.canvas.get_renderer()
    bad = []
    hidden = set()
    for ax in fig.axes:
        if not ax.axison:
            hidden.update(id(t) for t in ax.get_xticklabels()+ax.get_yticklabels())
        else:
            for t in ax.get_xticklabels():
                if not min(ax.get_xlim()) <= t.get_position()[0] <= max(ax.get_xlim()): hidden.add(id(t))
            for t in ax.get_yticklabels():
                if not min(ax.get_ylim()) <= t.get_position()[1] <= max(ax.get_ylim()): hidden.add(id(t))
    for item in fig.findobj(mpl.text.Text):
        if not item.get_visible() or not item.get_text() or id(item) in hidden: continue
        b = item.get_window_extent(renderer)
        if b.x0 < -2 or b.y0 < -2 or b.x1 > fig.bbox.width + 2 or b.y1 > fig.bbox.height + 2:
            bad.append(item.get_text())
    QA.append({'figure': name, 'text_outside_canvas': bad})
    for ext in ['pdf', 'svg', 'png']:
        fig.savefig(OUT / f'{name}.{ext}', dpi=300)
    plt.close(fig)

def box(ax, xy, wh, title, body, color=BLUE):
    x,y=xy; w,h=wh
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.008,rounding_size=.035',
                 fc='white', ec=color, lw=1.0))
    ax.annotate(title,(x+.035,y+h),xytext=(0,-7),textcoords='offset points',
                fontsize=8.1,color=color,weight='bold',va='top')
    ax.annotate(body,(x+.035,y+h),xytext=(0,-24),textcoords='offset points',
                fontsize=7.2,va='top',linespacing=1.25)

def arrow(ax, a, b, color=MUTED):
    ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'-|>','lw':1.15,'color':color,
                'shrinkA':2,'shrinkB':2,'mutation_scale':9})


def execution():
    casepath=ROOT/'studies/change_recovery_20261013/outputs/illustrated_case.json'
    case=json.loads(casepath.read_text()); FILES[str(casepath.relative_to(ROOT))]=hashlib.sha256(casepath.read_bytes()).hexdigest()
    camera=ROOT/'studies/change_recovery_20261013/inputs/14300000_camera.npz'
    FILES[str(camera.relative_to(ROOT))]=hashlib.sha256(camera.read_bytes()).hexdigest()
    data=np.load(camera);out=case['outcome']
    fig=plt.figure(figsize=(6.9,5.25))
    a=fig.add_axes([.07,.80,.88,.11]);a.set(xlim=(-.025,.325),ylim=(-.65,1.15));a.axis('off')
    panel(a,'a','Capture-time association · FlatCART · relaxed service')
    a.plot([0,.20],[0,0],c=MUTED,lw=1.2)
    a.plot([.215,.28],[0,0],c=MUTED,lw=1.2,ls=':')
    a.text(.248,0,'//',ha='center',va='center',fontsize=8,color=MUTED,backgroundcolor='white')
    for x,title,col in [(0,'Scan + immutable prior',INK),(.1,'Install version 1',BLUE),(.2,'Install version 2 + capture',TEAL)]:
        a.plot(x,0,'o',c=col,ms=5)
        a.text(x,.32,title,ha='center',fontsize=7.5,color=col)
        a.text(x,-.40,f'{x:.1f} s',ha='center',fontsize=7.5)
    a.text(.30,.28,'Report\nat 1.5 s',ha='center',fontsize=7.3,color=MUTED)
    a.text(.15,-1.0,'Same source is replaced in order; capture uses version 2.',ha='center',fontsize=7.5)
    im=fig.add_axes([.07,.395,.41,.30]);im.axis('off')
    im.imshow(data['rgb'],extent=(-144,144,-108,108),origin='upper')
    xy=data['detected_xy'];im.scatter(xy[:,0],-xy[:,1],s=34,facecolors='none',edgecolors='white',lw=.8)
    im.set_title('b   Actual synthetic RGB + decoded centers',loc='left',pad=7,fontsize=8.2,fontweight='medium')
    im.text(0,-.10,'10 / 10 targets acquired',transform=im.transAxes,fontsize=7.5)
    m=fig.add_axes([.55,.39,.40,.31]);m.axis('off')
    m.text(0,1.02,'c   Measured outputs and eligible evidence',fontsize=8.2,fontweight='medium')
    metrics=[('GSD',f"{out['gsd_m']*1000:.2f} mm/pixel"),('Exposure blur',f"{out['blur_px']:.3f} pixel"),
             ('Reprojection',f"{out['reprojection_px']:.2f} pixels"),('Target displacement',f"{out['association_m']*1000:.1f} mm"),
             ('Full-association card','229 / 2048; U = 0.143973')]
    for i,(label,value) in enumerate(metrics):
        y=.82-i*.16;m.text(0,y,label,fontsize=7.8);m.text(1,y,value,ha='right',fontsize=7.8,color=TEAL if i==4 else INK)
    m.text(0,-.075,'This image passes full-report thresholds.\nIts population service is still uncertified.',fontsize=7.2,color=MUTED,linespacing=1.3)
    c=fig.add_axes([.07,.105,.88,.19]);c.axis('off');c.set(xlim=(0,1),ylim=(0,1))
    c.text(0,1.13,'d   Executed evidence revalidation · same policy · no new calibration',fontsize=8.2,fontweight='medium')
    box(c,(.008,.03),(.277,.94),'Relax requirement','Reprojection: 30 → 50 px\nFull association admitted\nReuse U = 0.143973',TEAL)
    box(c,(.34,.03),(.36,.94),'Decoder version changes','Full association: refused\nReadiness-only: admitted\nOptical component: refused',RED)
    box(c,(.755,.03),(.235,.94),'Restore decoder','Original full association\nAdmitted again\nSame anchor evidence',TEAL)
    arrow(c,(.289,.50),(.335,.50));arrow(c,(.706,.50),(.748,.50))
    fig.text(.07,.027,'Image attachment is post-execution. Detected history faults persist; a trusted successor can recover.',fontsize=7.3,color=MUTED)
    save(fig,'02_execution')

def platforms():
    fig,axs=plt.subplots(2,2,figsize=(6.9,4.25))
    fig.subplots_adjust(left=.025,right=.975,bottom=.035,top=.925,wspace=.035,hspace=.15)
    names=['platform_lab.jpeg','platform_side.jpeg','aircraft_field.jpeg','aircraft_field_portrait.jpeg']
    labels=['Laboratory platform','Sensor integration','Aircraft field setting','Under-fuselage setting']
    for i,(a,name,label) in enumerate(zip(axs.flat,names,labels)):
        a.imshow(plt.imread(ROOT/'paper/figures/r7/hardware_originals'/name));a.axis('off')
        a.set_title(chr(97+i)+'   '+label,loc='left',pad=5,fontsize=8.5)
    save(fig,'03_platforms')

def performance():
    s=r8('controlled_summary');c=r8('certificate_margins');inte=r8('integrated_summary');p=r8('primary_intervals')
    fig,axs=plt.subplots(2,2,figsize=(6.9,5.15))
    fig.subplots_adjust(left=.27,right=.97,bottom=.17,top=.92,wspace=.42,hspace=.62)
    for i,pr in enumerate(PROFILES):
        a=axs[0,i];panel(a,chr(97+i),pr.capitalize()+' · standard service')
        g=s.query('profile==@pr and service=="standard"')
        a.scatter(g.work_s*1000,g.loss_m2s*1000,s=13,c='#C9D2D9',zorder=1)
        cert=c.query('profile==@pr and service=="standard" and event=="union" and upper<=.15').policy
        t=g[g.policy.isin(cert)];a.scatter(t.work_s*1000,t.loss_m2s*1000,s=63,facecolors='none',edgecolors=TEAL,lw=.8)
        for method in ['Fixed2','Fixed4','Final','FlatCART','FlatRF','OldRAVC']:
            v=g[g.policy==method].iloc[0]
            a.scatter(v.work_s*1000,v.loss_m2s*1000,c=POLCOL[method],marker=MARK[method],s=34,zorder=3)
        v=inte.query('profile==@pr and service=="standard" and task=="union" and variant=="Full"').iloc[0]
        a.scatter(v.work_s*1000,v.loss_m2s*1000,c=TEAL,marker='D',s=32,zorder=4)
        a.set(xlabel='Total modeled work (ms)',ylabel='Integrated loss (10⁻³ m² s)');clean(a)
    contrasts=['Full-ValidatedFlat','KG1-FlatCART','KG1-FlatRF','KG1-Fixed2']
    labels=['Full − procedure','Contract-CART − FlatCART','Contract-CART − FlatRF','Contract-CART − Fixed2']
    for j,(metric,scale,xlabel) in enumerate([('loss_m2s',1000,'Paired loss change (10⁻³ m² s)'),('observation_failure',100,'Observation failure change (pp)')]):
        a=axs[1,j];panel(a,chr(99+j),'Paired differences · standard service')
        for i,pr in enumerate(PROFILES):
            g=p.query('profile==@pr and metric==@metric').set_index('contrast').reindex(contrasts)
            y=np.arange(4)+(i-.5)*.17;col=BLUE if i==0 else ORANGE
            a.hlines(y,g.lo_family*scale,g.hi_family*scale,color=col,lw=4,alpha=.25)
            a.hlines(y,g.lo95*scale,g.hi95*scale,color=col,lw=1.45)
            a.scatter(g['mean']*scale,y,c=col,s=15,zorder=3)
        a.axvline(0,c=MUTED,ls=':',lw=.8);a.invert_yaxis()
        a.set_yticks(range(4),labels if j==0 else []);a.tick_params(axis='y',labelsize=6.7)
        a.set_xlabel(xlabel);a.grid(axis='x',color=LIGHT,lw=.65)
    # Bottom-left labels occupy the inter-panel space only if placed outside; use inset labels.
    axs[1,0].set_yticks(range(4),['Full − procedure','Contract-CART − FlatCART','Contract-CART − FlatRF','Contract-CART − Fixed2'])
    for a in axs[1]: a.set_ylim(3.55,-.55)
    h=[Line2D([],[],c=POLCOL[m],marker=MARK[m],lw=0,label=m,ms=4) for m in ['Fixed2','Fixed4','Final','FlatCART','FlatRF','OldRAVC']]
    h += [Line2D([],[],c=TEAL,marker='D',lw=0,label='Full',ms=4),Line2D([],[],marker='o',mfc='none',mec=TEAL,c='none',label='Union admissible',ms=6)]
    fig.legend(handles=h,loc='lower center',ncol=4,bbox_to_anchor=(.53,.012),columnspacing=1.1)
    fig.text(.18,.385,'Blue: nominal     Orange: unfitted',fontsize=7.0,color=MUTED)
    save(fig,'04_performance')

def localization_diagnostics():
    d=r8('module_ablations')
    fig,axs=plt.subplots(2,2,figsize=(6.9,4.8))
    fig.subplots_adjust(left=.12,right=.97,bottom=.14,top=.90,wspace=.42,hspace=.72)
    for j,(metric,scale,label) in enumerate([('loss_delta',1000,'Loss change (10⁻³ m² s)'),('work_delta',1000,'Work change (ms)')]):
        a=axs[0,j];panel(a,chr(97+j),'Effect of the CART time predicate')
        for pr,phase,col in [('nominal','nominal_confirmation',BLUE),('unfitted','geometry_confirmation',ORANGE)]:
            g=d.query('phase==@phase and module=="Time/CART"').set_index('service').reindex(SERVICES)
            a.plot(range(4),g[metric]*scale,marker='o' if pr=='nominal' else '^',
                   ls='-' if pr=='nominal' else '--',c=col,ms=4,label=pr.capitalize())
        a.axhline(0,c=MUTED,lw=.8);a.set_xticks(range(4),['Relaxed','Standard','Tight','Contended'],rotation=20)
        a.set_ylabel(label);clean(a)
    axs[0,0].legend(loc='upper left',fontsize=7)
    a=axs[1,0];panel(a,'c','Attachment checks · 16 invalid fixtures')
    names=['None','Match','Version','History','Procedure'];vals=[16,4,2,0,0]
    a.bar(range(5),vals,color=['#BFC9D1',BLUE,ORANGE,TEAL,PURPLE],width=.58)
    for x,y in enumerate(vals):a.text(x,y+.5,str(y),ha='center',fontsize=8)
    a.set(ylim=(0,19),ylabel='Incorrect attachments');a.set_xticks(range(5),names,rotation=20);clean(a)
    a=axs[1,1];panel(a,'d','Selective invalidation · 528 stored cards')
    names=['RF forecast','Nominal assets','Union event','Standard service','Clock'];vals=[168,264,176,132,528]
    a.barh(range(5),vals,color=RED,height=.58,label='Revoked')
    a.barh(range(5),528-np.array(vals),left=vals,color=LIGHT,height=.58,label='Retained')
    for y,v in enumerate(vals):a.text(v/2,y,str(v),va='center',ha='center',color='white',fontsize=7)
    a.set_yticks(range(5),names,fontsize=7);a.set(ylim=(5.6,-.6),xlim=(0,545),xlabel='Applicable-card count');a.legend(loc='lower right',fontsize=6.8,ncol=2)
    fig.text(.12,.025,'Paired time-predicate effects and fixed attachment/dependency fixtures.',fontsize=7.5,color=MUTED)
    save(fig,'10_localization_diagnostics')

def routes():
    d=r8('route_summary');std=r8('route_std')
    fig,axs=plt.subplots(3,2,figsize=(6.9,5.5))
    fig.subplots_adjust(left=.11,right=.98,bottom=.12,top=.93,wspace=.38,hspace=.52)
    conds=['ordinary','contention','geometric_stress'];methods=['Fixed2','KG1','Full']
    for i,mesh in enumerate(['B767','C172','UnfittedAirframe']):
        g=d[d.mesh==mesh]
        for j,(metric,scale,lab) in enumerate([('rmse_cm',1,'Route RMSE (cm)'),('capture_success_rate',100,'Timely success (%)')]):
            a=axs[i,j];panel(a,chr(97+i*2+j),mesh.replace('UnfittedAirframe','Unfitted airframe'))
            for variant,h in g.groupby('variant'):
                h=h.set_index('condition').reindex(conds)
                assert h[metric].notna().all(), (mesh,variant,metric,'incomplete route conditions')
                a.plot(range(3),h[metric]*scale,c='#CDD5DC',lw=.65,alpha=.6,zorder=1)
            for method in methods:
                h=g[g.variant==method].set_index('condition').reindex(conds)
                e=std.query('mesh==@mesh and variant==@method').set_index('condition').reindex(conds)
                assert h[metric].notna().all() and e[metric].notna().all()
                a.errorbar(np.arange(3)+{'Fixed2':-.06,'KG1':0,'Full':.06}[method],h[metric]*scale,yerr=e[metric]*scale,
                    c=POLCOL[method],marker=MARK[method],ms=4,lw=1.35,capsize=2,zorder=3,label='Contract-CART' if method=='KG1' else method)
            a.set_ylabel(lab);a.set_xticks(range(3),['Ordinary','Contention','Stress']);clean(a)
            if j==1:a.set_ylim(0,106)
    fig.legend(*axs[0,0].get_legend_handles_labels(),loc='lower center',ncol=3,bbox_to_anchor=(.52,.012))
    save(fig,'06_routes')

def requests():
    d=r9('all_frozen_plans');r9('configured_support')
    fig,axs=plt.subplots(2,3,figsize=(6.9,5.6))
    fig.subplots_adjust(left=.185,right=.975,bottom=.145,top=.87,wspace=.12,hspace=.72)
    variants=['full','coarser_gsd','more_blur','partial','partial_relaxed','stricter','late_report','single_service']
    labels=['Full','Coarse GSD','More blur','Partial','Relaxed partial','Stricter','Later report','Component']
    tasks=['acquisition','association','report'];contexts=[(p,s) for p in PROFILES for s in SERVICES]
    key={(r.study,r.profile,r.service,r.task,r.variant,r.method):r.status for r in d.query('allowance==.15').itertuples()}
    counts=[]
    for row,study in enumerate(['A','B']):
        supported=extra=0
        for col,task in enumerate(tasks):
            a=axs[row,col];z=np.zeros((8,8))
            for y,v in enumerate(variants):
                for x,(p,service) in enumerate(contexts):
                    sem=key[study,p,service,task,v,'ContractCover']=='AUTHORIZED'
                    direct=key[study,p,service,task,v,'DirectRecertCached']=='AUTHORIZED'
                    assert not sem or direct
                    z[y,x]=1 if sem else (2 if direct else 0)
            supported+=int((z==1).sum());extra+=int((z==2).sum())
            a.imshow(z,cmap=ListedColormap([LIGHT,TEAL,ORANGE]),vmin=0,vmax=2,aspect='auto',interpolation='nearest')
            a.set_yticks(range(8),labels if col==0 else [],fontsize=7.5)
            a.set_xticks(range(8),['R','S','T','C']*2,fontsize=7.5)
            a.set_xticks(np.arange(-.5,8,1),minor=True);a.set_yticks(np.arange(-.5,8,1),minor=True)
            a.grid(which='minor',c='white',lw=.75);a.tick_params(which='minor',bottom=False,left=False)
            a.axvline(3.5,c='white',lw=2.5)
            a.text(1.5,-.90,'Nominal',ha='center',va='bottom',fontsize=7.5)
            a.text(5.5,-.90,'Unfitted',ha='center',va='bottom',fontsize=7.5)
            a.set_title(chr(97+row*3+col)+'   '+{'acquisition':'Acquisition','association':'Association','report':'Reporting'}[task],
                        loc='left',fontsize=8.5,pad=24,fontweight='medium')
        axs[row,0].text(-.01,1.37,'Study '+study,transform=axs[row,0].transAxes,fontsize=9,weight='bold')
        counts.append({'study':study,'semantic_cells':supported,'direct_additional_cells':extra})
    fig.text(.185,.087,'Services: R relaxed · S standard · T tight · C contended. Risk allowance: 0.15.',fontsize=7.5,color=MUTED)
    fig.legend(handles=[Patch(fc=TEAL,label='Contract coverage'),Patch(fc=ORANGE,label='Direct renewal only'),Patch(fc=LIGHT,label='Refused')],
        loc='lower center',ncol=3,bbox_to_anchor=(.55,.023),fontsize=7.2,columnspacing=1)
    (OUT/'request_matrix_counts.json').write_text(json.dumps(counts,indent=2))
    assert counts==[{'study':'A','semantic_cells':24,'direct_additional_cells':6},{'study':'B','semantic_cells':26,'direct_additional_cells':6}]
    save(fig,'07_requests')

def optics():
    fig=plt.figure(figsize=(6.9,3.95))
    for i,(x,name,title) in enumerate([(0.06,'actual_raster_0.png','a   Study A · 192 × 144'),(.53,'actual_raster_1.png','b   Study B · 288 × 216')]):
        a=fig.add_axes([x,.44,.405,.45]);a.imshow(plt.imread(OUT/name));a.axis('off')
        a.set_title(title,loc='left',fontsize=8.5,pad=7)
    a=fig.add_axes([.06,.09,.88,.23]);a.axis('off');a.set(xlim=(0,1),ylim=(0,1))
    box(a,(.02,.06),(.38,.86),'Fixed target sampling','GSD = range / (focal length × incidence)\nSame target, same optics → same GSD',BLUE)
    box(a,(.54,.06),(.45,.86),'Wider region of interest','Changes acquired target coverage\nChanges raster / decoder work\nRequires renewal of affected events',TEAL)
    a.text(.465,.57,'ROI\nedit',ha='center',fontsize=8,color=MUTED)
    arrow(a,(.405,.35),(.52,.35),TEAL)
    fig.text(.06,.035,'Archived excluded pilot 12000000; both panels use the same source and diagnostic landmarks.',fontsize=7,color=MUTED)
    save(fig,'08_optics')



def evidence_node(ax, x, y, title, body, color, fill):
    w,h=.25,.25
    ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,
        boxstyle='round,pad=.007,rounding_size=.025',fc=fill,ec=color,lw=.9,zorder=3))
    ax.text(x,y+.075,title,ha='center',va='center',fontsize=7.2,weight='bold',color=color,zorder=4)
    ax.text(x,y-.055,body,ha='center',va='center',fontsize=6.8,linespacing=1.3,zorder=4)

def relation(ax, a, b, label, loc, color, dashed=False):
    ax.annotate('',xy=b,xytext=a,arrowprops=dict(arrowstyle='-|>',lw=1,
       color=color,linestyle='--' if dashed else '-',mutation_scale=8),zorder=1)
    ax.text(*loc,label,fontsize=6.5,color=color,ha='center',va='center',
        bbox=dict(facecolor='white',edgecolor='none',pad=1.1),zorder=2)


def conformance_figure():
    path=ROOT/'studies/change_recovery_20261013/outputs/change_cases.csv'
    d=snapshot('change','cases',path)
    eligible=d[(d.method=='ContractCover') & d.before_authorized & (d.edit!='unchanged')]
    g=eligible.groupby('edit',sort=False).after_authorized.agg(['size','sum'])
    assert len(eligible)==705 and len(g)==15 and (g['size']==47).all()
    retained=g['sum'].astype(int).to_numpy();withdrawn=47-retained
    assert withdrawn.sum()==489 and retained.sum()==216 and eligible.recovered.all()
    labels={'target_plan':'Target plan','geometry_sampler':'Geometry sampler','focal_px':'Focal length',
       'exposure_s':'Exposure','motion_sampler':'Motion sampler','roi':'ROI',
       'renderer':'Renderer','detector':'Pixel decoder','pixel_noise':'Pixel noise',
       'localization':'Localization','capture_sampler':'Capture sampler','camera_clock':'Camera clock',
       'report_queue':'Report queue','roi_and_clock':'ROI + camera clock','decoder_and_clock':'Decoder + camera clock'}
    fig=plt.figure(figsize=(6.9,5.7))
    a=fig.add_axes([.215,.18,.375,.69]);panel(a,'a','Selective handling by edited provider')
    a.barh(range(len(g)),withdrawn,color=RED,height=.64,label='Withdraw')
    a.barh(range(len(g)),retained,left=withdrawn,color=TEAL,height=.64,label='Retain')
    for i,(w,r) in enumerate(zip(withdrawn,retained)):
        if w:a.text(w/2,i,str(w),ha='center',va='center',color='white',fontsize=6.8)
        if r:a.text(w+r/2,i,str(r),ha='center',va='center',color='white',fontsize=6.8)
    a.set_yticks(range(len(g)),[labels[k] for k in g.index],fontsize=6.8)
    a.set(xlim=(0,47),ylim=(len(g)-.35,-.65),xlabel='Initially admitted contexts per edit')
    a.set_xticks([0,10,20,30,40,47]);a.grid(axis='x',color=LIGHT,lw=.6);a.set_axisbelow(True)
    a.legend(loc='upper center',bbox_to_anchor=(.50,-.105),ncol=2,fontsize=7)
    b=fig.add_axes([.69,.57,.275,.30]);b.axis('off');panel(b,'b','All eligible changes')
    b.text(.5,.85,'705',ha='center',fontsize=25,weight='bold',color=INK)
    b.text(.5,.72,'47 contexts × 15 edits',ha='center',fontsize=7.2,color=MUTED)
    b.add_patch(Rectangle((0,.43),489/705,.17,fc=RED))
    b.add_patch(Rectangle((489/705,.43),216/705,.17,fc=TEAL))
    b.text((489/705)/2,.515,'489',ha='center',va='center',color='white',fontsize=10,weight='bold')
    b.text((1+489/705)/2,.515,'216',ha='center',va='center',color='white',fontsize=10,weight='bold')
    b.text(.0,.32,'WITHDRAW',color=RED,fontsize=7,weight='bold')
    b.text(1,.32,'RETAIN',ha='right',color=TEAL,fontsize=7,weight='bold')
    b.text(.5,.12,'705 / 705 restored',ha='center',color=TEAL,fontsize=9,weight='bold')
    b.text(.5,.01,'after restoring the original producers',ha='center',color=MUTED,fontsize=6.4)
    c=fig.add_axes([.725,.22,.24,.22]);panel(c,'c','Diagnostic control errors')
    c.barh([0,1,2],[489,216,0],height=.47,color=[RED,ORANGE,TEAL])
    c.set_yticks([0,1,2],['Stale plan','Whole producer','Contract'],fontsize=6.5)
    c.set(xlim=(0,570),ylim=(2.8,-.8),xlabel='Incorrect evidence decisions')
    c.set_xticks([0,250,500]);c.grid(axis='x',color=LIGHT,lw=.6);c.set_axisbelow(True)
    for y,n in enumerate([489,216,0]):c.text(n+12,y,str(n),va='center',fontsize=7.5)
    fig.text(.215,.055,'Declared dependency oracle: missed withdrawals 0 · unnecessary refusals 0 · restoration mismatches 0',fontsize=6.8,color=MUTED)
    fig.text(.215,.025,'Full matrix: 5,120 configurations per method, including unchanged controls and initial refusals.',fontsize=6.8,color=MUTED)
    save(fig,'12_conformance')




METHODSTUDY=ROOT/'studies/methodology_review_20261014/outputs'

def methodology(name):return snapshot('methodology',name,METHODSTUDY/(name+'.csv'))

def overview():
    fig=plt.figure(figsize=(6.9,5.65))
    a=fig.add_axes([.035,.74,.93,.16]);a.axis('off');a.set(xlim=(0,1),ylim=(0,1))
    a.text(0,1.15,'a   Offline calibration',fontsize=8.7,weight='bold')
    for x,title,body in [(.02,'Complete inputs','Executed policy / service\nTask-event failure labels'),(.355,'Risk-card inventory','Event + producer + population\nCounts, manifests and bound U'),(.69,'Shared risk allocation','Reserved family and β allocation\nSimultaneous event coverage')]:
        box(a,(x,.03),(.28,.93),title,body,BLUE)
    arrow(a,(.315,.5),(.34,.5),BLUE);arrow(a,(.68,.5),(.645,.5),BLUE)
    b=fig.add_axes([.035,.275,.93,.365]);b.axis('off');b.set(xlim=(0,1),ylim=(0,1))
    b.text(0,1.13,'b   Typed operating knowledge and online execution',fontsize=8.7,weight='bold')
    nodes=[(.02,.62,'Typed request R','Unit-typed intervals φ\nPopulation, service and δ',BLUE),
      (.355,.62,'Compile and match','Canonical event + $D_R$\nTyped schema $\\mathcal{K}$ / predicates $\Gamma$',TEAL),
      (.69,.62,'Evidence route','Covered anchor → reuse\nElse exact event → renewal',TEAL),
      (.02,.03,'Numerical executor','One immutable scan / prior\nRetained ICP and ordered replay',BLUE),
      (.355,.03,'Captured task output','Active version + pixels\nTask quantities and report time',BLUE),
      (.69,.03,'Receipt monitor','Card, version and history\nIssue / withdraw / restore',TEAL)]
    for x,y,title,body,col in nodes:box(b,(x,y),(.28,.30),title,body,col)
    arrow(b,(.315,.77),(.34,.77),TEAL);arrow(b,(.65,.77),(.675,.77),TEAL)
    arrow(b,(.495,.60),(.16,.35),BLUE)
    b.text(.30,.48,'committed policy',fontsize=6.2,color=BLUE,bbox=dict(fc='white',ec='none',pad=1))
    arrow(b,(.315,.18),(.34,.18),BLUE);arrow(b,(.65,.18),(.675,.18),BLUE)
    arrow(b,(.85,.61),(.85,.34),TEAL)
    b.text(.87,.475,'applicable proof',fontsize=6.2,color=TEAL)
    c=fig.add_axes([.035,.06,.93,.11]);c.axis('off');c.set(xlim=(0,1),ylim=(0,1))
    c.text(0,1.25,'c   Producer change audit',fontsize=8.7,weight='bold')
    steps=[('Candidate component','paired pipeline re-execution'),('Compare task quantities','audit declared projection'),('Evidence decision','retain proof or renew affected event')]
    for x,(title,body) in zip([0,.355,.71],steps):
        c.add_patch(Rectangle((x,.04),.28,.88,fc='#EDF4F2',ec='none'))
        c.text(x+.015,.60,title,color=TEAL,fontsize=7.4,weight='bold')
        c.text(x+.015,.24,body,fontsize=6.2)
    arrow(c,(.29,.48),(.345,.48),TEAL);arrow(c,(.645,.48),(.70,.48),TEAL)
    save(fig,'01_overview')

def mechanisms():
    d=methodology('producer_reexecution')
    edits=['roi','focal','exposure','decoder_disabled','hidden_roi_focal','hidden_decoder_readiness']
    metrics=['gsd_m','blur_px','coverage','reprojection_px','association_m','localization_ready','report_delay_s','image_age_s']
    count=np.array([[int(d.query('edit==@e and metric==@m').changed.sum()) for m in metrics] for e in edits])
    bad=np.array([[int(d.query('edit==@e and metric==@m').undeclared_change.sum()) for m in metrics] for e in edits])
    code=np.where(bad>0,2,np.where(count>0,1,0))
    fig=plt.figure(figsize=(6.9,5.35))
    a=fig.add_axes([.235,.48,.73,.40]);panel(a,'a','Measured quantity changes among five paired inputs')
    a.imshow(code,cmap=ListedColormap([LIGHT,'#D5E4F2','#F0D8DA']),vmin=0,vmax=2,aspect='auto')
    for y in range(6):
        for x in range(8):a.text(x,y,str(count[y,x]),ha='center',va='center',fontsize=8,color=RED if bad[y,x] else BLUE if count[y,x] else MUTED)
    a.set_xticks(range(8),['GSD','Blur','Coverage','Reproj.','CAD disp.','Ready','Delay','Age'],fontsize=6.9)
    a.set_yticks(range(6),['ROI','Focal length','Exposure','Decoder off','ROI → focal fault','Decoder → ready fault'],fontsize=7)
    a.set_xticks(np.arange(-.5,8,1),minor=True);a.set_yticks(np.arange(-.5,6,1),minor=True);a.grid(which='minor',c='white',lw=1.5)
    a.tick_params(which='minor',bottom=False,left=False)
    a.axhline(3.5,color='white',lw=4)
    fig.legend(handles=[Patch(fc=LIGHT,label='No measured change'),Patch(fc='#D5E4F2',label='Declared affected quantity'),Patch(fc='#F0D8DA',label='Undeclared changed quantity')],
       loc='lower center',bbox_to_anchor=(.58,.38),ncol=3,fontsize=6.5)
    fig.text(.035,.325,'b   Actual rerendered output · fixed archived source and CAD targets',fontsize=8.4,weight='bold')
    paths=[ROOT/'studies/methodology_review_20261014/inputs/archives/14300000_camera.npz',METHODSTUDY/'illustration_roi.npz',METHODSTUDY/'illustration_hidden_roi_focal.npz']
    labels=['Original ROI','Wider ROI · fixed focal length','Wider ROI · hidden focal coupling']
    g=d.query('seed==14300000 and metric=="gsd_m"').set_index('edit')
    gsds=[float(g.iloc[0].baseline),float(g.loc['roi','edited']),float(g.loc['hidden_roi_focal','edited'])]
    for i,(path,label,gsd) in enumerate(zip(paths,labels,gsds)):
        FILES[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
        im=fig.add_axes([.035+i*.322,.10,.287,.18]);im.imshow(np.load(path)['rgb']);im.axis('off')
        im.set_title(label,loc='left',fontsize=6.7,pad=5)
        im.text(0,-.14,f'Fixed-target GSD: {gsd*1000:.2f} mm/pixel',transform=im.transAxes,fontsize=6.7,color=RED if i==2 else TEAL)
    fig.text(.035,.02,'Actual geometry, raster and decoder re-execution; original primary cards and population inputs retained.',fontsize=6.8,color=MUTED)
    save(fig,'05_mechanisms')

def boundaries():
    support=methodology('hybrid_support');cost=methodology('hybrid_cost');bounds=methodology('family_bound_example')
    fig=plt.figure(figsize=(6.9,4.85))
    a=fig.add_axes([.10,.59,.38,.29]);panel(a,'a','All directly supported contexts retained')
    g=support[support.study.isin(['A','B'])].set_index('study').loc[['A','B']]
    a.bar([0,1],g.reused,color=TEAL,width=.53,label='Anchor reuse')
    a.bar([0,1],g.direct_fallback,bottom=g.reused,color=ORANGE,width=.53,label='Direct fallback')
    for i,row in enumerate(g.itertuples()):
        a.text(i,row.reused/2,str(row.reused),ha='center',va='center',color='white',fontsize=8)
        a.text(i,row.reused+row.direct_fallback/2,str(row.direct_fallback),ha='center',va='center',color='white',fontsize=8)
        a.text(i,row.supported+1,f'{row.supported}/160',ha='center',fontsize=8,weight='bold')
    a.set_xticks([0,1],['Study A','Study B']);a.set(ylim=(0,36),ylabel='Supported unique contexts');clean(a)
    a.legend(fontsize=6.5,ncol=2,loc='lower center',bbox_to_anchor=(.5,-.30))
    b=fig.add_axes([.65,.59,.315,.29]);panel(b,'b','Same 59 contexts and policies')
    g=cost.query('study=="combined"').set_index('method')
    vals=[g.loc[m,'event_record_evaluations']/1000 for m in ['Direct fixed policy','Reuse plus direct fallback']]
    b.bar([0,1],vals,color=[ORANGE,TEAL],width=.52)
    for i,v in enumerate(vals):b.text(i,v+2,f'{v*1000:,.0f}',ha='center',fontsize=8,weight='bold')
    b.set_xticks([0,1],['Exact event','Reuse + fallback']);b.set(ylim=(0,99),ylabel='Event–record evaluations (thousands)');clean(b)
    b.text(.5,92,'13.89% fewer evaluations',ha='center',color=TEAL,fontsize=8.4,weight='bold')
    c=fig.add_axes([.13,.14,.825,.22]);panel(c,'c','Example bound under alternative calibration-scope designs')
    vals=[bounds.query('design=="Primary reserved"').iloc[0].upper,
          bounds.query('design=="Canonical scope design" and method=="Direct"').iloc[0].upper,
          bounds.query('design=="Canonical scope design" and method=="Anchor"').iloc[0].upper]
    c.plot(range(3),vals,'o-',c=BLUE,ms=5)
    for i,v in enumerate(vals):c.text(i,v+.00025,f'{v:.6f}',ha='center',fontsize=7.6)
    c.set_xticks(range(3),['Reserved family\nK = 4,608','Canonical complete family\nK = 1,692','Canonical anchor family\nK = 780'])
    c.set(xlim=(-.25,2.25),ylim=(.1396,.1453),ylabel='Risk upper bound');clean(c)
    fig.text(.13,.025,'Primary allowance 0.15: scope sensitivity preserves support (anchors 24/23; exact events 30/29).',fontsize=6.8,color=MUTED)
    save(fig,'09_boundaries')

def point_scale():
    d=methodology('point_count_probe');fig,axs=plt.subplots(1,2,figsize=(6.9,2.85))
    fig.subplots_adjust(left=.12,right=.97,bottom=.25,top=.83,wspace=.4)
    for i,(metric,scale,label) in enumerate([('median_native_cpu_s',1000,'Native CPU median (ms)'),('source_position_error_m',1000,'Source position error (mm)')]):
        ax=axs[i];panel(ax,chr(97+i),'Five fixed source replays')
        for seed,g in d.groupby('seed'):
            ax.plot(g.requested_points,g[metric]*scale,'o-',ms=3,alpha=.8,label=str(seed))
        ax.set_xticks([96,192,384]);ax.set_xlabel('Requested point cap');ax.set_ylabel(label);clean(ax)
    fig.text(.12,.04,'Actual counts clip to available frontend points; three timing trials per cap on the same archived input.',fontsize=6.8,color=MUTED)
    save(fig,'11_point_count')


if __name__=='__main__':
    overview();execution();platforms();performance();mechanisms();routes();requests();optics();boundaries();localization_diagnostics();conformance_figure();point_scale()
    (OUT/'figure_provenance.json').write_text(json.dumps({'sources':FILES,'result_tables_unchanged':True,
      'figures_use_original_photos_numeric_rasters_and_vector_graphics':True,'software_fixture_counts':[16,4,2,0,0],
      'new_change_study':'studies/change_recovery_20261013/outputs/results.json',
      'route_error_bars':'sample standard deviations over four matched route inputs; not confidence intervals',
      'original_matched_support':{'contexts':47,'anchor_record_evaluations':49152,'direct_record_evaluations':61440},
      'declared_model_conformance_counts':{'edits':705,'withdrawals':489,'retentions':216},
      'routed_support':{'contexts':59,'reused':46,'direct_fallback':13,'event_record_evaluations':63488,'exact_event_evaluations':73728},
      'numerical_producer_audit':{'archived_sources':5,'interventions_per_source':6},
      'request_labels_retained':192,'unique_event_contexts_per_study':160},indent=2))
    (OUT/'figure_canvas_qa.json').write_text(json.dumps(QA,indent=2))
    print(json.dumps({'figures':len(QA),'canvas_issues':[q for q in QA if q['text_outside_canvas']]},indent=2))
