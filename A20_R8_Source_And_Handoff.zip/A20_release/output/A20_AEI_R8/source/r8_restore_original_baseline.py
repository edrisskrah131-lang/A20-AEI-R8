"""Reassemble the byte-preserved incoming source ZIP without changing old files."""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
P=ROOT/'preserved/latest_AEI_25p_baseline'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8<<20),b''):h.update(b)
    return h.hexdigest()
def main():
    metadata=json.loads((P/'ORIGINAL_BASELINE_MANIFEST.json').read_text())
    for name,r in metadata.items():
        target=P/name
        if 'parts' in r and not target.exists():
            tmp=target.with_suffix('.assembling')
            with tmp.open('wb') as output:
                for part in r['parts']:
                    p=P/part['path'];assert p.stat().st_size==part['bytes'] and sha(p)==part['sha256']
                    with p.open('rb') as f:
                        for b in iter(lambda:f.read(8<<20),b''):output.write(b)
            assert tmp.stat().st_size==r['bytes'] and sha(tmp)==r['sha256']
            tmp.replace(target)
        assert target.stat().st_size==r['bytes'] and sha(target)==r['sha256'],name
    print('Incoming 25-page main, 18-page SI, full original source and figure ZIPs verified byte-for-byte.')
if __name__=='__main__':main()
