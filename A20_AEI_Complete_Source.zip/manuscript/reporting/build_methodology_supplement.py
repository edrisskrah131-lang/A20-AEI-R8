"""Format the executed methodology diagnostics from preserved CSV outputs."""
from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'studies/methodology_review_20261014/outputs'
parts=[r'''\section{Typed metamodel, compilation and executed producer auditing}\label{supp:methodology}
The reference extension implements typed request compilation and a relation-domain checker. A request contains population, service, allowance and a conjunction of intervals. Each interval declares a metric and engineering unit, with optional lower and upper bounds. Unit conversion, interval intersection and canonical sorting produce the event identity; contradictory bounds and incompatible dimensions are rejected. All 24 declared task/variant expressions reproduce their original event identities and provider projections. Four invalid quantity specifications, a wrong relation type and an invalid source-revision order are rejected.

\begin{table}[htbp]\centering\small
\caption{Metamodel relation signatures implemented by the checker.}\label{supp:metamodel-relations}
\begin{tabular}{lll}\toprule
Relation & Domain & Range\\\midrule
requires & Request & Event\\
commits & Plan & Request\\
selects & Plan & Policy\\
bounds & Card & Event\\
supports & Card & Plan\\
derivedFrom & Card & Producer\\
produces & Producer & Quantity\\
dependsOn & Quantity & Provider\\
uses & Receipt & SourceVersion\\
records & Receipt & Plan\\
revises & SourceVersion & SourceVersion\\\bottomrule
\end{tabular}\end{table}

For example, full association compiles coverage $\ge0.50$, reprojection $\le30$ px, CAD-target displacement $\le100$ mm and readiness $\ge1$. The compiler converts $100$ mm to $0.10$ m and gathers the declared dependencies of those quantities. The dependency manifest is an explicit implemented-data-flow specification; it is not inferred by a static-analysis engine. Unit/schema checks validate its use, while paired numerical re-execution audits its consequences.

The five sources are the previously sealed reproduction inputs: A/nominal 13,200,000 and 13,201,023; A/unfitted 13,300,000; B/nominal 14,200,000; and B/unfitted 14,300,000. For each, original CAD addresses, geometry perturbation, motion, capture time and installed FlatCART/relaxed state are retained. The renderer, pixel decoder and task scorer run on these fixed inputs. Baseline RGB arrays agree byte-for-byte with their archives and task quantities agree within $10^{-10}$. Four interventions widen ROI by 96 by 72 pixels, set focal length to 2,400 px, set exposure to 9 ms, or disable the decoder. Two fault fixtures additionally make focal length depend on ROI width, or make capture readiness depend on the decoder's finite outputs, without declaring that coupling. The fixed virtual reporting clock is retained to isolate producer-function changes.

Measured quantity changes are computed from output values, independently of the dependency checker. A declared affected quantity may show no change on a finite input; this is not evidence of global invariance. An undeclared measured change falsifies the transfer premise for that tested producer/input. The replay audit flags all five pairs in each injected coupling class. These fixtures test the specified faults and do not estimate arbitrary hidden-coupling detection rates.
''']

def table(df,caption):
    cols=list(df.columns);s='\\begin{table}[htbp]\\centering\\small\n\\caption{'+caption+'}\n'
    s+='\\begin{tabular}{@{}'+'l'*len(cols)+'@{}}\\toprule\n'+' & '.join(cols)+'\\\\\\midrule\n'
    for row in df.itertuples(index=False,name=None):s+=' & '.join(str(x).replace('_',r'\_') for x in row)+r'\\'+'\n'
    return s+r'\bottomrule\end{tabular}\end{table}'+'\n'

f=pd.read_csv(OUT/'producer_audit_summary.csv')
df=f[['edit','paired_sources','undeclared_quantity_changes','flagged_source_pairs']].copy()
df.columns=['Intervention','Pairs','Undeclared changes','Flagged pairs']
parts.append(table(df,'Actual producer re-execution. Counts refer to five paired archived inputs per intervention.'))
parts.append(r'\subsection{Reuse-first routing and calibration-scope sensitivity}'+'\n')
parts.append('The routed evidence analysis uses all 320 unique primary contexts. It fixes the originally selected direct-renewal policy, selects a compatible covering anchor when available and otherwise retains an exact-event card. All applicable invariant evidence pools are available to both routes. Selected proofs are deduplicated by event, producer, population and calibration-source manifest; repeated service labels do not add distinct proofs. The catalogue counts measure selected proof-construction requirements, excluding acquisition, producer execution, policy-catalogue search, native timing and human effort.\n')
f=pd.read_csv(OUT/'hybrid_cost.csv')
df=f.copy();df['method']=df['method'].replace({'Direct fixed policy':'Exact event','Reuse plus direct fallback':'Reuse + fallback'})
df.columns=['Study','Route','Contexts','Proof cards','Record evaluations']
parts.append(table(df,'Selected proof preparation on identical supported contexts and fixed numerical policies.'))
parts.append('Canonical calibration scopes use the same four signatures and do not merge tests using observed numerical coincidence. The anchor family contains 780 canonical tests; the complete stored family contains 1,692. Each sensitivity design separately allocates total confidence error 0.05. A combined routed catalogue requires one allocation over its tested union. The original primary cards continue to use 0.05/4,608. The canonical designs tighten the example bound without changing support at allowance 0.15.\n')
f=pd.read_csv(OUT/'family_bound_example.csv')
df=f[['design','method','K','upper']].copy();df['upper']=df['upper'].map(lambda x:f'{x:.6f}');df.columns=['Scope design','Method','Family size','Upper bound']
parts.append(table(df,'Archived-count scope sensitivity for the full-association example, with 229 failures among 2,048 calibration inputs.'))
parts.append(r'\subsection{Registration point-count probes}'+'\n')
parts.append('The unchanged source solver is run on the existing frontend cloud at requested caps 96, 192 and 384. Actual sample count clips to available points. Each run uses the original immutable prior; no forecast model is retrained. Native Linux CPU is the median of three repeated executions, including solver construction. The error column describes the final candidate before acceptance; rejected candidates remain visible. These finite probes use no primary budget wrapper or larger-point risk certificate.\n')
f=pd.read_csv(OUT/'point_count_probe.csv')
df=pd.DataFrame({'Source':f.seed,'Cap':f.requested_points,'Used':f.used_points,'Iterations':f.iterations,
 'Accepted':f.accepted.map({True:'yes',False:'no'}),'Error (mm)':f.source_position_error_m.map(lambda x:f'{x*1000:.2f}'),
 'CPU (ms)':f.median_native_cpu_s.map(lambda x:f'{x*1000:.2f}')})
parts.append(table(df,'Paired point-count diagnostic on the five archived inputs. Timing repeats do not increase the source count.'))
parts.append(r'''\begin{figure}[p]\centering\includegraphics[width=\linewidth]{visual/11_point_count.pdf}
\caption{Executed point-count probes. Every trace is one fixed archived source. Candidate error is nonmonotonic in requested point count; timing medians describe this Linux diagnostic.}\end{figure}
\begin{figure}[p]\centering\includegraphics[width=\linewidth]{visual/12_conformance.pdf}
\caption{Original declared-model change/recovery conformance matrix, retained as implementation verification. The oracle shares the declaration specification; these counts do not test the correctness of an undeclared physical dependency.}\end{figure}
\FloatBarrier
''')
(ROOT/'paper/sections/methodology_extension.tex').write_text('\n'.join(parts))
print('Built executed methodology supplement.')
