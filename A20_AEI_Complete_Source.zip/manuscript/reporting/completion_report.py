"""Build the current article from the executed lifecycle and surface challenge.

Earlier integrated figures remain reproducible as supplementary evidence.
This module keeps each plotted source in an explicit checksum ledger.
"""
from pathlib import Path
import argparse
import hashlib
import json
import sys

import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import FancyBboxPatch, Patch
from PIL import Image

import visual_revision as style

ROOT = Path(__file__).resolve().parents[1]
SEC = ROOT / 'paper/sections'
FIG = ROOT / 'paper/figures/visual'
CAM = ROOT / 'studies/lifecycle_campaign_20261018'
CHALLENGE = ROOT / 'studies/inspection_challenge_20261018'
BLUE, TEAL, ORANGE, RED, INK, MUTED, LIGHT = (
    style.BLUE, style.TEAL, style.ORANGE, style.RED,
    style.INK, style.MUTED, style.LIGHT)
SOURCES = {}
VARIANTS = ['baseline', 'focal', 'exposure', 'wide_roi', 'lighting',
            'decoder', 'exposure_light_decoder', 'camera_focal_roi']
V_NAMES = ['Baseline', 'Focal length +15%', 'Exposure +50%',
           'Expanded image region', 'Illumination ×0.45', 'Decoder update',
           'Exposure + light + decoder', 'Focal length + image region']
REQUESTS = ['optical', 'optical_relaxed', 'acquisition',
            'acquisition_relaxed', 'association', 'association_relaxed',
            'complete', 'complete_relaxed']
R_NAMES = ['Optical', 'Optical+', 'Acquisition', 'Acquisition+',
           'Association', 'Association+', 'Complete', 'Complete+']
METHODS = ['Whole renewal', 'DAG exact + registry',
           'Containment + repair', 'Rules + registry']
M_NAMES = ['Whole', 'DAG + exact', 'Containment', 'Rules']
COLORS = [ORANGE, BLUE, TEAL, INK]
STEP_NAMES = ['Initial', 'Relax', 'Exposure', 'Tighten', 'Light', 'Decoder',
              'Combined', 'Camera', 'Stale output', 'Bad revision',
              'Repair', 'Replay', 'Rollback', 'Population', 'Late output',
              'Repair']


def track(path):
    path = Path(path)
    SOURCES[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return path


def read_csv(path):
    return pd.read_csv(track(path))


def read_json(path):
    return json.loads(track(path).read_text())


def write(name, content):
    (SEC / (name + '.tex')).write_text(content.strip() + '\n')


def risk_figure():
    cards = read_csv(CAM / 'outputs/exact_risk_cards.csv')
    assert len(cards) == 64 and cards.n.eq(256).all()
    assert cards.alpha.eq(.05 / 64).all()
    values = cards.pivot(index='variant', columns='request', values='upper').loc[VARIANTS, REQUESTS].to_numpy()
    admitted = values <= .15
    fig, ax = plt.subplots(figsize=(6.9, 3.65))
    fig.subplots_adjust(left=.275, right=.985, bottom=.23, top=.87)
    ax.imshow(admitted, cmap=ListedColormap(['#F4DDDE', '#D9EDE8']), vmin=0, vmax=1, aspect='auto')
    for i in range(8):
        for j in range(8):
            ax.text(j, i, f'{values[i,j]:.3f}', ha='center', va='center',
                    fontsize=8.1, color=INK if admitted[i,j] else '#9C343F')
    ax.set_xticks(range(8), R_NAMES, rotation=32, ha='right', fontsize=7.7)
    ax.set_yticks(range(8), V_NAMES, fontsize=7.7)
    ax.set_xticks(np.arange(-.5,8,1), minor=True)
    ax.set_yticks(np.arange(-.5,8,1), minor=True)
    ax.grid(which='minor', color='white', linewidth=1.3)
    ax.tick_params(which='both', length=0)
    for s in ax.spines.values():
        s.set_visible(False)
    fig.text(.275, .96, 'Quality-event risk upper bounds', fontsize=9)
    fig.text(.275, .91, '256 calibration scenes · 64 fixed events · 95% simultaneous confidence',
             fontsize=7.8, color=MUTED)
    fig.text(.275, .025, f'{int(admitted.sum())} / 64 supported contexts at allowance 0.15; + denotes a relaxed request.',
             fontsize=7.7, color=MUTED)
    style.save(fig, '38_campaign_support')
    return cards


def case_figure(cards):
    """Show processed controlled images and their population-level event bounds."""
    seed = 202630100  # Fixed first test source; no outcome-dependent selection.
    arrays = []
    for variant in ['baseline', 'exposure']:
        path = track(CAM / f'outputs/representative_campaigns/{seed}_four-layout_{variant}.npz')
        with np.load(path) as z:
            arrays.append({k:z[k].copy() for k in z.files})
    records = [json.loads(str(z['metadata']))['record'] for z in arrays]
    bounds = cards.set_index(['variant','request']).upper
    values = [bounds.loc['baseline','complete'], bounds.loc['exposure','complete'],
              bounds.loc['exposure','complete_relaxed']]
    fig = plt.figure(figsize=(6.9, 4.15))
    for j, (z, rec, name) in enumerate(zip(arrays, records, ['Baseline', 'Exposure +50%'])):
        ax = fig.add_axes([.025 + j*.50, .41, .45, .51])
        rgb = z['rgb']; h,w = rgb.shape[:2]
        ax.imshow(rgb, extent=(-w/2,w/2,h/2,-h/2))
        ax.scatter(z['matched_centers'][:,0], z['matched_centers'][:,1],
                   s=15, facecolors='none', edgecolors='#EDAA4F', lw=.6)
        ax.axis('off')
        ax.set_title(f'{chr(97+j)}   {name}', loc='left', fontsize=8.7)
        ax.text(0,-.075, f"{rec['matched_targets']} / {rec['planned_targets']} matches · "
                f"{rec['blur_px']:.3f} px blur · {1000*rec['association_m']:.3f} mm mapping",
                transform=ax.transAxes, fontsize=7.1, color=MUTED)
    ax=fig.add_axes([.025,.04,.95,.29]); ax.set(xlim=(0,1),ylim=(0,1)); ax.axis('off')
    for j,(title,u,body,col) in enumerate(zip(
        ['BASELINE COMPLETE','UPDATED COMPLETE','UPDATED COMPLETE+'], values,
        ['Admit', 'Refuse', 'Exact fallback: admit'], [BLUE,RED,TEAL])):
        x=.01+j*.337
        ax.add_patch(FancyBboxPatch((x,.12),.30,.64,boxstyle='round,pad=.008,rounding_size=.025',
                                   fc='white',ec=col,lw=1.1))
        ax.text(x+.015,.65,title,color=col,fontsize=7.3,weight='bold')
        ax.text(x+.015,.41,f'Population risk bound  U = {u:.3f}',fontsize=7.5)
        ax.text(x+.015,.23,body,fontsize=8.1,weight='bold',color=col)
        if j<2: style.arrow(ax,(x+.307,.43),(x+.333,.43))
    fig.text(.025,.015,'Both individual images satisfy the strict event. Service admission uses the independent calibration population.',
             fontsize=7.1,color=MUTED)
    style.save(fig,'36_campaign_journey')
    b,e=records
    write('completion_case',f'''The first held-out observation illustrates this distinction (Fig.~\\ref{{fig:journey}}).
Its sampling scale remains {1000*b['gsd_m']:.3f}~mm/pixel after the exposure update, while blur increases from {b['blur_px']:.3f} to {e['blur_px']:.3f} pixels.
Both individual outputs satisfy the strict complete-service predicate.
The independently calibrated upper bound nevertheless changes from {values[0]:.3f} to {values[1]:.3f}, above the allowance 0.15.
The relaxed complete event has upper bound {values[2]:.3f} and remains supported.
The workflow therefore continues the relaxed service while withholding the strict one; the output's current producer and binding determine which statement accompanies it.''')


def request_table():
    sys.path.insert(0, str(ROOT/'studies/lifecycle_20261018'))
    from evidence import REQUESTS as definitions
    rows = [r'\begin{table}[!htbp]\centering\small',
            r'\caption{Capture-to-CAD requirements. GSD is in mm/pixel; blur and residual are in pixels; coverage is in percent; mapping error is in mm. A dash leaves the quantity unconstrained; + identifies a relaxed request.}\label{tab:requests}',
            r'\begin{tabular}{@{}lrrrrr@{}}\toprule Request & GSD $\le$ & Blur $\le$ & Coverage $\ge$ & Residual $\le$ & Mapping $\le$\\\midrule']
    for name, label in zip(REQUESTS, R_NAMES):
        spec = definitions[name]
        cells = []
        for key in ['gsd_m', 'blur_px', 'coverage', 'reprojection_px', 'association_m']:
            value = spec.get(key, [None,None])[0 if key=='coverage' else 1]
            scale = 1000 if key.endswith('_m') else 100 if key=='coverage' else 1
            cells.append('---' if value is None else f'{value*scale:g}')
        rows.append(label+' & '+' & '.join(cells)+r'\\')
    rows.append(r'\bottomrule\end{tabular}\end{table}')
    write('completion_requests', '\n'.join(rows))


def campaign_figures():
    summary=read_json(CAM/'outputs/summary.json')
    full=read_csv(CAM/'outputs/family_method_summary.csv').set_index('method').loc[METHODS]
    sparse=read_csv(CAM/'outputs/method_summary.csv').set_index('method').loc[METHODS]
    fig,axs=plt.subplots(1,3,figsize=(6.9,3.15))
    fig.subplots_adjust(left=.075,right=.985,bottom=.25,top=.85,wspace=.48)
    settings=[('a   Full evidence catalogue',full.record_evaluations,'Record evaluations',19000),
              ('b   Sequential requests',sparse.evidence_record_evaluations,'Record evaluations',2850),
              ('c   Numerical workflow',sparse.event_cpu_s,'Process CPU (s)',235)]
    for ax,(title,values,ylabel,ymax) in zip(axs,settings):
        scale=1000 if ylabel=='Record evaluations' else 1
        ax.bar(range(4),values.to_numpy()/scale,color=COLORS,width=.61)
        for j,v in enumerate(values):
            ax.text(j,(v+ymax*.025)/scale,f'{v:,.0f}' if ylabel=='Record evaluations' else f'{v:.1f}',
                    ha='center',fontsize=7.5)
        ax.set_xticks(range(4),M_NAMES,rotation=35,ha='right',fontsize=7.5)
        ax.set(ylabel='Records (thousands)' if scale==1000 else ylabel,ylim=(0,ymax/scale));ax.set_title(title,loc='left',fontsize=8)
        style.clean(ax)
    fig.text(.075,.025,'Evidence catalogues are each built once. The 64-source numerical workflow shares the same DAG across incremental methods.',
             fontsize=6.7,color=MUTED)
    style.save(fig,'39_campaign_work')

    events=read_csv(CAM/'outputs/event_summary.csv')
    events=events[events.method=='Containment + repair'].sort_values('index')
    plans=read_csv(CAM/'outputs/catalogue_events.csv')
    plans=plans[plans.method=='Containment + repair'].sort_values('index')
    x=np.arange(16)
    fig=plt.figure(figsize=(6.9,4.6))
    ax=fig.add_axes([.16,.60,.81,.28])
    upper=plans.upper.to_numpy()
    ax.plot(x,upper,c=MUTED,lw=1,zorder=1)
    for i,r in enumerate(events.itertuples()):
        if i==13:
            ax.text(i,.055,'No\ncard',ha='center',va='center',fontsize=6.8,color=ORANGE)
        else:
            color=TEAL if r.issued else RED if i==3 else ORANGE
            ax.scatter(i,upper[i],s=38,c=color,marker='o' if r.issued else 'X',zorder=3)
    ax.axhline(.15,c=RED,ls=':',lw=1)
    ax.text(15.4,.154,'0.15',ha='right',va='bottom',color=RED,fontsize=7)
    ax.set(xlim=(-.6,15.6),ylim=(0,.35),ylabel='Selected card bound',xticks=[])
    ax.set_title('a   Admissible evidence and current output binding',loc='left',fontsize=8.5)
    style.clean(ax)
    ax.legend(handles=[mpl.lines.Line2D([],[],color=TEAL,marker='o',ls='',label='Issued'),
                       mpl.lines.Line2D([],[],color=RED,marker='X',ls='',label='Risk refusal'),
                       mpl.lines.Line2D([],[],color=ORANGE,marker='X',ls='',label='Binding / population refusal')],
              loc='upper left',bbox_to_anchor=(-.005,1.34),ncol=3,fontsize=7)
    stagekeys=['geometry','radiance','sensor','decode','pose','optics']
    stage=np.array([events['calls_'+k].to_numpy()/64 for k in stagekeys])
    assert np.isin(stage,[0,1]).all()
    ax=fig.add_axes([.16,.26,.81,.25])
    ax.imshow(stage,cmap=ListedColormap(['#EDF1F4',BLUE]),vmin=0,vmax=1,aspect='auto')
    ax.set_yticks(range(6),['Geometry','Radiance','Sensor','Extraction','Pose','Optics'],fontsize=7.3)
    ax.set_xticks(range(16),[f'{i+1:02d}  {name}' for i,name in enumerate(STEP_NAMES)],
                  rotation=55,ha='right',fontsize=6.9)
    ax.set_xticks(np.arange(-.5,16,1),minor=True);ax.set_yticks(np.arange(-.5,6,1),minor=True)
    ax.grid(which='minor',color='white',lw=1.2);ax.tick_params(which='both',length=0)
    for s in ax.spines.values():s.set_visible(False)
    ax.set_title('b   Stages actually executed per source',loc='left',fontsize=8.5,pad=9)
    fig.text(.16,.025,'Blue: stage executes. Gray: cached output or registry operation. Same schedule for all 64 sources.',
             fontsize=6.8,color=MUTED)
    style.save(fig,'40_campaign_sequence')
    return summary,full,sparse


def design_text():
    p=read_json(CAM/'protocol.json')
    r=read_json(CHALLENGE/'rendering/protocol.json')
    assert p['family_K']==64 and p['calibration_scene_count']==256
    assert len(r['test_sources'])==64 and len(r['development_sources'])==8
    write('completion_design',r'''
\subsection{Scene population and calibrated requirements}
The lifecycle experiment samples 256 independent calibration scenes and 64 independent test scenes from a controlled image population. Each scene draws its own surface curvature, camera pose, material appearance and physical-to-CAD displacements. Four fastener layouts are represented: parallel rows, curved rows, staggered sites and an access-panel perimeter. The layouts contain 28--36 sites, with fastener radii of 2.0--3.4~mm and typical spacing of 28--40~mm. Shared and local displacement standard deviations are 0.4 and 0.15~mm; site missingness is 0.025 and edge occlusion occupies 0--10\% of the image.

Baseline images have $768\times576$ pixels, focal length 1,200--1,600 pixels, camera distance 0.70--1.15~m, exposure 3--7~ms and surface-relative motion 0.06--0.18~m/s. The family contains the baseline and five component updates: focal length $\times1.15$, exposure $\times1.5$, image region $896\times672$, illumination $\times0.45$ and extraction contrast threshold $18\to10$. Two combined producers apply exposure/illumination/extraction together and focal length/image region together. Named configurations are complete settings; only the two explicitly combined producers apply simultaneous changes.

All eight producers execute on every calibration scene, yielding 2,048 outputs. The eight requests in Table~\ref{tab:requests} give the fixed family $K=8\times8=64$, with $\beta=0.05$, $\alpha=0.05/64$ and primary allowance $\delta=0.15$. The allowance concerns violation of the capture-to-CAD quality conjunction by a complete scene. Calibration selects the plans before the test inputs are processed. The six producers visited by the sequential campaign execute on all 64 test scenes; evaluation scores all eight requests for each of these producers, giving 48 observed producer/request contexts.
\input{sections/completion_requests}

Local dark contrast and connected components of 5--240 pixels supply candidate centers. A 30-pixel prior gate constrains CAD assignment; six or more matches trigger pose refinement with scales of 0.5 pixel, 3~mm and 0.001 rad. The implementation uses SciPy's trust-region reflective least-squares solver \cite{virtanen2020scipy} with the specified Huber loss. The numerical dependency graph separates geometry, radiance, sensor formation, extraction, pose and optical quantities.

\subsection{One continuing change campaign and matched methods}
Each test source follows 16 operations: initial service, request relaxation, exposure update, request tightening, illumination update, extraction update, combined exposure/illumination/extraction update, combined camera update, stale attachment, out-of-order repair, valid repair, repair replay, numerical rollback, population mismatch, late old-version delivery and valid rollback repair. The illumination step requests the optical event; other ordinary steps request strict or relaxed complete service. The population-mismatch step executes a paired stress input with 0.14 missingness, 0--35\% occlusion and larger CAD displacements. Its registered population differs from the calibrated population.

Whole renewal recomputes the complete numerical packet and constructs exact-event evidence. The primary baseline uses a persistent dependency graph, exact-event cards and the authoritative registry. It reuses an exact card only when the event and its producer projection match; containment additionally permits a stronger event to cover a weaker request. Containment with repair uses the same graph and registry with stronger-event reuse and exact fallback. Independent rules implement the same event and binding conditions. All methods receive identical inputs, trusted outputs and calibration records. Stale delivery and repair operate on the actual stored numerical packets, including their image and correspondence hashes. The independent checker reconstructs the required revision, binding and admission for every operation.

A complementary component-registration experiment uses 64 additional independent scenes. It compares clean updates with three conditional hidden couplings: image region to focal length, illumination to exposure, and extraction to focal length. Every pair re-executes the affected numerical producer; changes beyond $10^{-10}$ absolute/relative tolerance veto a declared invariance. This experiment tests the dependency interface before the sequential campaign applies the registered configurations.

Evidence preparation has two demand schedules: all 64 fixed contexts and the requests visited by the 16-step campaign. Each schedule builds one population-level catalogue per method, shared by all test sources. We measure its constructed cards, calibration-record evaluations and process CPU. Numerical workflow timing separately measures the 64 paired trajectories, with method order rotated across sources. The complete packet is requested at each numerical step; stage caching and evidence reuse therefore have distinct work counters. All unsuccessful cards and refused requests remain in the measurements.

The experiment runs on a shared Linux AMD EPYC 9V74 host, Python 3.12, with two workers and one numerical thread per worker. Process CPU and elapsed time include executed numerical stages, geometric quality scoring, payload hashing and registry/consistency checks. Initial nominal-scene sampling, process creation and file export are excluded; the stress-input draw is included in its population-change step. Catalogue preparation is timed separately. A 10,000-replicate paired bootstrap resamples the 64 complete sources for the workflow CPU comparison. The Supplementary Material records the environment, all event outcomes and the earlier single-update and repair studies.

\subsection{Surface-structure and imaging challenge}
The geometric challenge uses Blender 4.3.2 Cycles to evaluate light transport through explicit geometry, materials and illumination \cite{kajiya1986rendering}. Its four structural families are a longitudinal lap joint, rounded access hatch, doubly curved diagonal joint and raised repair doubler. Individual scenes sample part dimensions, joint or panel contours, fastener positions, curvature, materials and camera pose. Geometric sealant, shallow fastener heads, painted and metallic surfaces, abrasion and three area emitters produce the image. Figure~\ref{fig:challenge-inputs} shows fixed-source examples of the processed images.
\input{sections/completion_gallery}

Eight development scenes cover the first two families. The test set has 16 independent scenes per family, giving 64 scenes and 256 images under nominal, raking-light, oblique-view and foreground-occlusion conditions. The latter two families are held out from image-provider selection. Conditions change actual emitters, camera pose or foreground hose/tool geometry. Resolution is $768\times576$, with at most 32 samples per pixel, adaptive threshold 0.02 and no denoising. Camera projection and skin-mesh ray intersection are checked independently before scoring.

The original contrast extractor is compared with a locally normalized extractor. For grayscale intensity $I$ on the 0--255 scale, the alternative uses contrast $c=G_3*I-I$ and local scale $s=[\max\{G_8*I^2-(G_8*I)^2,0\}]^{1/2}$, where $G_\sigma$ is a Gaussian filter. A candidate pixel satisfies both $c>a$ and $c>z\max(s,1)$. Development selects one of the six predefined pairs $z\in\{1.0,1.6,2.2\}$ and $a\in\{4,8\}$, minimizing quality failures and then maximizing coverage across equally weighted family/condition cells. Both providers use the same component filters, assignment and pose estimator. Test scoring begins after this selection is fixed.

The challenge applies the Association thresholds in Table~\ref{tab:requests}: correct-address coverage $\ge0.8$, maximum fitted residual $\le8$ pixels and maximum all-site mapping error $\le8$~mm. Correct-address scoring additionally requires a visible, nonmissing target with the assigned CAD identity and image error below 8 pixels. Missing and occluded sites remain in the denominator; failed surface intersections remain as infinite mapping errors. The observable screen instead checks matched-site fraction $\ge0.8$ and fitted residual $\le8$ pixels. The two fixed providers produce 512 evaluated outputs. We report quality failures, screen acceptance and accepted-but-failed outputs for every family and condition. A paired bootstrap with 4,000 replicates resamples scenes within each family, retaining all repeated conditions and both providers. These images define a separate evaluated population with their own recorded quality outcomes.
''')


def challenge_gallery():
    seeds=[202640000,202641000,202642000,202643000]
    names=['Longitudinal lap joint','Rounded access hatch',
           'Doubly curved diagonal joint','Raised repair doubler']
    paths=[CHALLENGE/f'rendering/test/{s}_nominal.png' for s in seeds]
    if not all(p.exists() for p in paths):
        return False
    fig,axs=plt.subplots(2,2,figsize=(6.9,5.65))
    fig.subplots_adjust(left=.02,right=.99,bottom=.055,top=.94,wspace=.045,hspace=.19)
    for i,(ax,path,name) in enumerate(zip(axs.flat,paths,names)):
        rgb=np.asarray(Image.open(track(path)).convert('RGB'))
        ax.imshow(rgb); ax.axis('off')
        ax.set_title(f'{chr(97+i)}   {name}',loc='left',fontsize=8.3)
    fig.text(.02,.015,'Original 768 × 576 rendered inputs; the first test source from each independently sampled structural family.',
             fontsize=7.1,color=MUTED)
    style.save(fig,'37_structural_inputs')
    write('completion_gallery',r'''\begin{figure}[!htbp]\centering\includegraphics[width=\linewidth]{visual/37_structural_inputs.pdf}
\caption{Actual nominal inputs from the surface challenge. Mesh topology changes across the four families, and dimensions, fastener layouts, surface appearance and camera pose vary within each family. The first test source from each family is shown without image retouching. Diagonal-joint and repair-doubler structures are held out from image-provider selection.}\label{fig:challenge-inputs}\end{figure}''')
    return True


def campaign_results(cards, summary, full, sparse):
    held=read_csv(CAM/'outputs/heldout_request_scores.csv')
    obs=read_csv(CAM/'outputs/campaign_observations.csv')
    baseline=obs[(obs.method=='Containment + repair')&(obs['index']==0)]
    assert len(baseline)==64 and baseline.seed.nunique()==64
    supported=held[held.authorized]
    bounds=cards.set_index(['variant','request']).upper
    saving=100*(1-full.loc[METHODS[2],'record_evaluations']/full.loc[METHODS[1],'record_evaluations'])
    ci=summary['dag_paired_source_bootstrap_ci']
    regression=read_csv(ROOT/'studies/lifecycle_20261018/outputs/regression.csv')
    assert len(regression)==192 and regression.seed.nunique()==64
    assert regression.active.sum()==86 and regression.veto.sum()==86 and regression.clean_veto.sum()==0
    content=[r'\subsection{The supported service changes with the requirement}',
        f'''Calibration supports {int(cards.authorized.sum())} of the 64 producer/request contexts (Fig.~\\ref{{fig:campaign-support}}).
        All four complete methods retain this same set. Under the fixed catalogue order, containment supplies 29 contexts from existing stronger cards; exact construction supports 25 further contexts and refuses ten.
        The exposure update raises the strict complete-event bound to {bounds.loc['exposure','complete']:.3f}, while its relaxed event remains at {bounds.loc['exposure','complete_relaxed']:.3f}.
        The combined exposure, illumination and extraction update similarly supports relaxed complete service at {bounds.loc['exposure_light_decoder','complete_relaxed']:.3f} while refusing strict complete service at {bounds.loc['exposure_light_decoder','complete']:.3f}.
        Under reduced illumination, the optical event remains supported at {bounds.loc['lighting','optical']:.3f}; complete association requirements determine the additional refusals.''',
        f'''The six producers used in the sequential test yield 48 observed contexts, of which {len(supported)} were admitted by calibration.
        Among these {len(supported)} calibration-admitted contexts, test failures range from {int(supported.test_failures.min())} to {int(supported.test_failures.max())} per 64 scenes.
        At baseline, mean correct-address coverage is {baseline.coverage.mean()*100:.2f}\\%, median fitted residual is {baseline.reprojection_px.median():.3f} pixel, and median mapping error is {1000*baseline.association_m.median():.3f}~mm.
        Median prior translation error decreases from {1000*baseline.prior_translation_error_m.median():.3f} to {1000*baseline.posterior_translation_error_m.median():.3f}~mm after fitting.
        All test outcomes, including the refused programs and individual quality failures, are retained in the Supplementary Material.''',
        r'''\begin{figure}[!htbp]\centering\includegraphics[width=\linewidth]{visual/38_campaign_support.pdf}
        \caption{Exact-event calibration bounds for the 64 fixed contexts. Green cells meet the 0.15 scene-level allowance. The 256 calibration scenes are independent of the 64 campaign test sources. The three incremental methods and whole renewal support the same 54 contexts.}\label{fig:campaign-support}\end{figure}''',
        f'''In the separate 64-source component-registration experiment (Supplementary Material), paired numerical re-execution detects all {int(regression.active.sum())} activated hidden couplings, with no veto among its {len(regression)} clean update pairs.
        These checks exercise numerical effects of a violated dependency declaration. The sequential experiment then examines the evidence and output history of the registered updates.''',
        r'\subsection{Continuing service through repair and rollback}',
        '''The campaign distinguishes three causes of refusal within the same output history (Fig.~\\ref{fig:sequence}).
        Tightening the exposure-updated request fails its risk allowance despite a current authenticated binding.
        Stale delivery and an out-of-order repair encounter an admissible event but fail the binding rules.
        The stress input has a different registered population, so its quality statement is unavailable before any attachment decision.
        These decisions follow from the event, producer and output records supplied to each method.''',
        '''All four methods make the same 704 issuance decisions among 1,024 operations per implementation.
        No stale, wrong-origin or invalid-revision binding is issued.
        Both authorized repairs succeed for each of the 64 sources, restoring all 128 eligible recovery checkpoints.
        A replayed repair is rejected while the already repaired output remains available.
        Numerical rollback restores the cached baseline output at registry revision 9, advancing from revision 8; the incremental methods execute no numerical provider for that operation.
        A late delivery carrying the earlier revision is still refused, and the final repair restores service for all 64 sources.
        Thus reuse of numerical data and reuse of control authority follow different revision rules.''',
        r'''\begin{figure}[!htbp]\centering\includegraphics[width=\linewidth]{visual/40_campaign_sequence.pdf}
        \caption{The 16-operation lifecycle. (a) The selected evidence bound and actual issuance decision. Reused stronger cards can have a higher bound than the request's exact card. A statistically supported service can still be withheld for a stale binding; a population mismatch has no applicable card. (b) Actual dependency-stage execution. Valid repair and numerical rollback use retained outputs. The independent registry and rule implementations reproduce these decisions and stage counts.}\label{fig:sequence}\end{figure}''',
        r'\subsection{Evidence work and numerical computation}',
        f'''For the complete family, whole renewal constructs 64 cards, exact dependency caching constructs {int(full.loc[METHODS[1],'constructed_cards'])}, and containment with fallback constructs {int(full.loc[METHODS[2],'constructed_cards'])}.
        The corresponding record evaluations are {int(full.loc[METHODS[0],'record_evaluations']):,}, {int(full.loc[METHODS[1],'record_evaluations']):,} and {int(full.loc[METHODS[2],'record_evaluations']):,}.
        Containment reduces this work by {saving:.2f}\\% relative to exact caching while preserving all 54 supported contexts.
        The independent rules give the same construction and support counts.
        For the requests actually visited in the 16-step campaign, exact caching constructs eight cards and containment constructs six: 2,048 versus 1,536 record evaluations, a 25\\% reduction.
        Each catalogue is prepared once and shared by all 64 sources.''',
        f'''Figure~\\ref{{fig:work}} separates this evidence work from numerical execution.
        Whole renewal consumes {sparse.loc[METHODS[0],'event_cpu_s']:.3f}~s of process CPU across the 64 trajectories, compared with {sparse.loc[METHODS[1],'event_cpu_s']:.3f}~s for the DAG baseline.
        The shared dependency cache reduces workflow CPU by {summary['dag_event_cpu_saving_vs_whole_percent']:.2f}\\%, with a paired 95\\% bootstrap interval of {ci[0]:.2f}--{ci[1]:.2f}\\%.
        Containment and rules consume {sparse.loc[METHODS[2],'event_cpu_s']:.3f} and {sparse.loc[METHODS[3],'event_cpu_s']:.3f}~s, with identical numerical outputs and stage counts.
        A separate cold full-catalogue preparation takes {1000*full.loc[METHODS[1],'cpu_s']:.3f}~ms for exact caching and {1000*full.loc[METHODS[2],'cpu_s']:.3f}~ms for containment.
        The principal operational result is selective continuation and recovery with explicit evidence applicability; the additional containment saving concerns this small preparation task.''',
        r'''\begin{figure}[!htbp]\centering\includegraphics[width=\linewidth]{visual/39_campaign_work.pdf}
        \caption{Attribution of computational work. The complete family and the sequential demand each build one shared evidence catalogue. Event containment reduces record evaluations relative to exact caching. The larger workflow CPU saving comes from the ordinary dependency graph shared by the three incremental methods.}\label{fig:work}\end{figure}''']
    write('completion_campaign_results','\n\n'.join(content))
    return dict(saving=saving,baseline_coverage=baseline.coverage.mean(),supported_test_contexts=len(supported),
                max_test_failures=int(supported.test_failures.max()))


def challenge_figures():
    folder=CHALLENGE/'analysis/outputs/test'
    summary=read_json(folder/'summary.json')
    freeze=read_json(CHALLENGE/'analysis/freeze.json')
    metrics=read_csv(folder/'metrics.csv')
    conditions=read_csv(folder/'conditions.csv')
    strata=read_csv(folder/'strata.csv')
    assert summary['scene_count']==64 and summary['image_count']==256 and len(metrics)==512
    fronts=[freeze['baseline']['name'],freeze['selected']['name']]
    names=['Fixed contrast','Normalized contrast']
    conds=['nominal','raking_light','oblique_view','occlusion']
    labels=['Nominal','Raking light','Oblique view','Occlusion']
    fig,axs=plt.subplots(2,2,figsize=(6.9,5.7))
    fig.subplots_adjust(left=.10,right=.98,bottom=.12,top=.88,wspace=.36,hspace=.68)
    x=np.arange(4)
    for ax,key,title in zip(axs[0],['quality_failures','observable_screen_acceptances'],
                            ['a   Association-event failures','b   Observable-screen acceptance']):
        for j,(front,col) in enumerate(zip(fronts,[BLUE,TEAL])):
            g=conditions[conditions.frontend==front].set_index('condition').loc[conds]
            vals=g[key].to_numpy()
            ax.bar(x+(j-.5)*.34,vals,width=.31,color=col,label=names[j])
            for xx,v in zip(x+(j-.5)*.34,vals):
                ax.text(xx,v+.8,str(int(v)),ha='center',fontsize=7.2)
        ax.set_xticks(x,labels,rotation=20,ha='right',fontsize=7.2)
        maximum=conditions[key].max()
        ax.set(ylabel='Outputs / 64 scenes',ylim=(0,max(8,maximum*1.20+2)))
        ax.set_title(title,loc='left',fontsize=8.1);style.clean(ax)
    handles,legend=axs[0,0].get_legend_handles_labels()
    fig.legend(handles,legend,loc='upper center',ncol=2,bbox_to_anchor=(.55,.98),fontsize=8)
    ax=axs[1,0]
    matrix=strata[strata.frontend==fronts[1]].pivot(index='family',columns='condition',values='quality_failures').loc[range(4),conds].to_numpy()
    ax.imshow(matrix,cmap='YlOrRd',vmin=0,vmax=16,aspect='auto')
    for i in range(4):
        for j in range(4):
            ax.text(j,i,f'{int(matrix[i,j])}/16',ha='center',va='center',fontsize=7.2,
                    color='white' if matrix[i,j]>10 else INK)
    ax.set_xticks(range(4),labels,rotation=20,ha='right',fontsize=7.2)
    ax.set_yticks(range(4),['Lap','Hatch','Diagonal*','Doubler*'],fontsize=7.2)
    ax.tick_params(which='both',length=0)
    ax.set_title('c   Normalized provider by structure',loc='left',fontsize=8.1)
    for spine in ax.spines.values():spine.set_visible(False)
    ax=axs[1,1]
    comparison={p['condition']:p for p in summary['provider_comparisons'] if p['metric']=='coverage'}
    mean=np.array([comparison[c]['alternative_minus_frozen_mean'] for c in conds])*100
    interval=np.array([comparison[c]['scene_cluster_percentile_95'] for c in conds])*100
    ax.axvline(0,color=MUTED,lw=.9,ls=':')
    ax.errorbar(mean,range(4),xerr=[mean-interval[:,0],interval[:,1]-mean],fmt='o',c=TEAL,
                ecolor=TEAL,capsize=3,ms=4.5)
    ax.set_yticks(range(4),labels,fontsize=7.2);ax.invert_yaxis()
    ax.set_xlabel('Coverage difference (percentage points)',fontsize=7.3)
    ax.set_title('d   Normalized minus fixed contrast',loc='left',fontsize=8.1)
    ax.grid(axis='x',color=LIGHT,lw=.7);ax.set_axisbelow(True)
    fig.text(.10,.025,'* Structure held out from provider selection. Intervals resample paired scenes within each structural family.',
             fontsize=7,color=MUTED)
    style.save(fig,'41_challenge_outcomes')
    correspondence_figure(metrics,fronts[1])
    return summary,freeze,metrics,conditions


def correspondence_figure(metrics,frontend):
    folder=CHALLENGE/'analysis/outputs/test'
    seed=202643000
    fig,axs=plt.subplots(1,2,figsize=(6.9,3.45))
    fig.subplots_adjust(left=.02,right=.99,bottom=.20,top=.85,wspace=.065)
    for j,(ax,condition) in enumerate(zip(axs,['nominal','occlusion'])):
        row=metrics[(metrics.seed==seed)&(metrics.condition==condition)&(metrics.frontend==frontend)].iloc[0]
        rgb=np.asarray(Image.open(track(CHALLENGE/row.image_path)).convert('RGB'));h,w=rgb.shape[:2]
        z=np.load(track(folder/f'{seed}_{condition}_{frontend}.npz'))
        ax.imshow(rgb,extent=(-w/2,w/2,h/2,-h/2))
        ax.scatter(z['predicted'][:,0],z['predicted'][:,1],s=15,marker='+',color='#2386C6',lw=.65)
        ax.scatter(z['matched_centers'][:,0],z['matched_centers'][:,1],s=20,facecolors='none',edgecolors='#E7A23B',lw=.7)
        ax.axis('off');ax.set_title(f'{chr(97+j)}   '+('Nominal' if j==0 else 'Foreground occlusion'),loc='left',fontsize=8.5)
        ax.text(0,-.09,f'Correct matches  {int(row.correct_matches)} / {int(row.planned_targets)}',
                transform=ax.transAxes,fontsize=7.5)
        ax.text(1,-.09,'Quality fails' if row.quality_failure else 'Quality passes',
                transform=ax.transAxes,ha='right',fontsize=7.2,color=RED if row.quality_failure else TEAL)
        ax.text(0,-.18,f'Residual  {row.reprojection_px:.2f} px  ·  mapping  {1000*row.association_m:.2f} mm',
                transform=ax.transAxes,fontsize=7.3,color=MUTED)
    fig.legend(handles=[mpl.lines.Line2D([],[],color='#2386C6',marker='+',ls='',label='Fitted CAD projection'),
                        mpl.lines.Line2D([],[],color='#E7A23B',marker='o',mfc='none',ls='',label='Pixel-derived center')],
               loc='upper center',bbox_to_anchor=(.5,.995),ncol=2,fontsize=7.5)
    fig.text(.02,.025,'Fixed first repair-doubler source; identical planned sites in both conditions. All extracted correspondences enter fitting.',
             fontsize=6.8,color=MUTED)
    style.save(fig,'42_actual_correspondences')


def challenge_results(summary,freeze,metrics,conditions):
    fronts=[freeze['baseline']['name'],freeze['selected']['name']]
    conds=['nominal','raking_light','oblique_view','occlusion']
    table=conditions.set_index(['frontend','condition'])
    fixed=table.loc[fronts[0]].loc[conds]
    normalized=table.loc[fronts[1]].loc[conds]
    changes={p['condition']:p for p in summary['paired_condition_changes'] if p['frontend']==fronts[1]}
    occ=changes['occlusion']
    hold=metrics[(metrics.frontend==fronts[1])&(metrics.family.isin([2,3]))]
    ordinary=metrics[(metrics.frontend==fronts[1])&(metrics.family.isin([0,1]))]
    example=metrics[(metrics.frontend==fronts[1])&(metrics.seed==202643000)].set_index('condition')
    nominal,occluded=example.loc['nominal'],example.loc['occlusion']
    stats=dict(baseline_false_accepts=int(fixed.accepted_but_failed.sum()),
               normalized_false_accepts=int(normalized.accepted_but_failed.sum()),
               baseline_failures=int(fixed.quality_failures.sum()),
               normalized_failures=int(normalized.quality_failures.sum()))
    text=[r'\subsection{Quality under structural and imaging changes}',
        f'''Development selects the normalized extractor with $z={freeze['selected']['z']:g}$ and $a={freeze['selected']['absolute']:g}$.
        Figure~\\ref{{fig:challenge-results}} retains all 256 test images and compares this fixed choice with the original extractor.
        In nominal, raking-light, oblique-view and occluded conditions, the original extractor fails the association event on {', '.join(str(int(v)) for v in fixed.quality_failures)} of 64 scenes, respectively.
        The normalized extractor gives {', '.join(str(int(v)) for v in normalized.quality_failures)} failures under the same conditions.
        Its mean correct-address coverage is {', '.join(f'{v*100:.1f}' for v in normalized.coverage_mean)}\\%, respectively.
        The paired coverage differences and their scene-bootstrap intervals show the effect of replacing this component under each condition.
        Across all conditions, the development-selected extractor has {stats['normalized_failures']} event failures, compared with {stats['baseline_failures']} for the original extractor.
        Under nominal imaging, mean coverage increases from {fixed.loc['nominal','coverage_mean']*100:.2f}\\% to {normalized.loc['nominal','coverage_mean']*100:.2f}\\%, while residual violations increase from {int(fixed.loc['nominal','residual_failures'])} to {int(normalized.loc['nominal','residual_failures'])} of 64 scenes.
        The coverage gain is accompanied by more residual failures, making the complete quality event relevant to component replacement.''',
        f'''The two structurally held-out families contribute 32 independent scenes and 128 condition images.
        The normalized extractor has {int(hold.quality_failure.sum())} quality failures among these images, compared with {int(ordinary.quality_failure.sum())} among the 128 images from familiar structural families.
        Within the paired occlusion intervention, {occ['pass_to_failure']} scenes change from a nominal pass to failure and {occ['failure_to_pass']} change from failure to pass.
        Mean coverage changes by {100*occ['mean_coverage_change']:+.2f} percentage points, with a paired 95\\% interval of {100*occ['coverage_change_scene_cluster_95'][0]:+.2f} to {100*occ['coverage_change_scene_cluster_95'][1]:+.2f}.
        Planned targets remain unchanged across each pair, so occluded or missing sites still contribute to the requested coverage.''',
        r'''\begin{figure}[!htbp]\centering\includegraphics[width=\linewidth]{visual/41_challenge_outcomes.pdf}
        \caption{Complete test outcomes on 64 independent scenes under four conditions. (a) Violation of coverage, fitted-residual or mapping requirements. (b) Outputs accepted by the observable count/residual screen; none of these accepted outputs fails the independently scored association event. (c) Failures of the development-selected provider within each structural family. (d) Paired mean coverage differences with descriptive 95\% bootstrap intervals, resampling scenes within families.}\label{fig:challenge-results}\end{figure}''',
        f'''The observable matched-count/residual screen accepts {int(fixed.observable_screen_acceptances.sum())} of 256 outputs from the original extractor and {int(normalized.observable_screen_acceptances.sum())} from the normalized extractor.
        Of these, {stats['baseline_false_accepts']} and {stats['normalized_false_accepts']} outputs, respectively, fail the independently scored quality event.
        Figure~\\ref{{fig:challenge-correspondences}} shows the first repair-doubler source before and after foreground occlusion, with fitted CAD projections and pixel-derived centers.
        Correct matches decrease from {int(nominal.correct_matches)} to {int(occluded.correct_matches)} of {int(nominal.planned_targets)} planned sites.
        The occluded output retains {int(occluded.matched_targets-occluded.correct_matches)} incorrect assignments; its maximum residual rises from {nominal.reprojection_px:.2f} to {occluded.reprojection_px:.2f} pixels, crossing the 8-pixel requirement, while mapping error remains below 8~mm.
        These measurements distinguish a current, authenticated numerical result from the geometric quality of the result.
        The challenge outcomes remain associated with this renderer and image provider when the evidence interface evaluates applicability.''',
        r'''\begin{figure}[!htbp]\centering\includegraphics[width=\linewidth]{visual/42_actual_correspondences.pdf}
        \caption{Actual correspondence outputs for a fixed test pair, using the development-selected normalized extractor. Both frames are unretouched renderer outputs. Overlays show all fitted CAD locations and the assigned pixel centers; the scoring denominator contains the same planned sites in both conditions. This source was selected by its position in the fixed test list.}\label{fig:challenge-correspondences}\end{figure}''']
    write('completion_challenge_results','\n\n'.join(text))
    return stats


def article_summary(campaign, full, sparse, challenge, stats):
    """Use executed outcomes for the abstract, conclusion and headline ledger."""
    saving=100*(1-full.loc[METHODS[2],'record_evaluations']/full.loc[METHODS[1],'record_evaluations'])
    if stats['baseline_false_accepts']+stats['normalized_false_accepts']:
        screen_abstract=(f"The original and development-selected extractors yield {stats['baseline_false_accepts']} and "
                         f"{stats['normalized_false_accepts']} outputs, respectively, that pass observable screening but fail the association event.")
        screen_conclusion=('The geometric image challenge exposes quality failures that remain hidden from matched-count and residual screening, '
                           'linking the event definition to actual correspondence and mapping outcomes.')
    else:
        screen_abstract=(f"The original and development-selected extractors violate the association event on {stats['baseline_failures']} and "
                         f"{stats['normalized_failures']} images; the observable screen rejects every observed quality failure.")
        screen_conclusion=('The geometric image challenge quantifies the effects of surface structure, view and occlusion on association quality, '
                           'linking service requirements to actual correspondence and mapping outcomes.')
    write('completion_abstract',f'''An inspection quality statement can become inapplicable when a camera, image-processing component or engineering requirement changes, even though part of the numerical result remains usable.
We present an executable evidence interface for maintaining CAD-guided inspection services through such changes.
Typed requests compile to scene-level quality events, and calibrated bounds transfer through event containment and compatible producer functions.
Exact-event fallback preserves the services admitted by direct renewal, while versioned repair transactions restore the association between evidence and the current authenticated output.
A sequential experiment uses 256 calibration scenes and 64 independent test scenes, with each test scene undergoing 16 operations including combined updates, stale delivery, repair and numerical rollback.
Full-family comparisons support the same {campaign['admitted_family_contexts']} of 64 calibrated contexts.
Containment reduces full-catalogue record evaluations from {int(full.loc[METHODS[1],'record_evaluations']):,} to {int(full.loc[METHODS[2],'record_evaluations']):,} ({saving:.2f}\\%).
All complete implementations restore their 128 eligible repair checkpoints without issuing an invalid binding.
Dependency caching separately reduces measured workflow CPU by {campaign['dag_event_cpu_saving_vs_whole_percent']:.2f}\\%.
A complementary light-transport challenge evaluates {challenge['image_count']} images from 64 independent surface scenes spanning four structural families and four imaging conditions.
{screen_abstract}
The results connect evidence renewal and output recovery to explicit inspection requirements, while distinguishing numerical reuse, statistical applicability and geometric quality.''')
    write('completion_conclusion',f'''This study develops an executable interface for carrying quantitative inspection evidence through changes in requirements, numerical producers and output versions.
Event containment reuses a stronger quality statement; exact fallback preserves the support of the complete calibrated catalogue.
An authenticated repair transaction then restores the output that can carry the statement, with numerical rollback and registry revision treated separately.

Complete-family evaluation retains all {campaign['admitted_family_contexts']} calibrated producer/request contexts while reducing full-catalogue evidence evaluations by {saving:.2f}\\% relative to exact dependency caching.
The separate sequential-demand catalogue reduces evaluations by 25\\%.
All complete implementations restore their 128 eligible repair checkpoints, with no invalid binding issued across the 1,024 operations of each implementation.
{screen_conclusion}
Together, these results establish a reproducible decision process for retaining applicable evidence, renewing affected statements and resuming an inspection service on the correct output.''')
    write('completion_results',r'''\input{sections/completion_campaign_results}
\input{sections/completion_challenge_results}''')
    claims=[]
    def add(key,value,formatted=None,locations=('main','supplement')):
        claims.append(dict(key=key,value=float(value) if isinstance(value,np.floating) else int(value) if isinstance(value,np.integer) else value,
                           formatted=str(value) if formatted is None else formatted,locations=list(locations)))
    add('campaign.independent_calibration_sources',256,'256')
    add('campaign.independent_test_sources',64,'64')
    add('campaign.calibration_outputs',2048,'2,048')
    add('campaign.admitted_contexts',campaign['admitted_family_contexts'],'54')
    add('campaign.decisions_per_method',campaign['decisions_per_method'],'1,024')
    add('campaign.issued_per_method',int(sparse.loc[METHODS[2],'issued']),'704')
    add('campaign.catalogue_exact_evaluations',int(full.loc[METHODS[1],'record_evaluations']),'13,824')
    add('campaign.catalogue_reuse_evaluations',int(full.loc[METHODS[2],'record_evaluations']),'8,960')
    add('campaign.catalogue_reduction_percent',saving,f'{saving:.2f}%')
    add('campaign.sparse_evaluations_exact',int(sparse.loc[METHODS[1],'evidence_record_evaluations']),'2,048')
    add('campaign.sparse_evaluations_reuse',int(sparse.loc[METHODS[2],'evidence_record_evaluations']),'1,536')
    add('campaign.dag_cpu_savings_percent',campaign['dag_event_cpu_saving_vs_whole_percent'],f"{campaign['dag_event_cpu_saving_vs_whole_percent']:.2f}%")
    add('campaign.whole_event_cpu_s',float(sparse.loc[METHODS[0],'event_cpu_s']),f"{sparse.loc[METHODS[0],'event_cpu_s']:.3f}")
    add('campaign.dag_event_cpu_s',float(sparse.loc[METHODS[1],'event_cpu_s']),f"{sparse.loc[METHODS[1],'event_cpu_s']:.3f}")
    add('campaign.repairs',128,'128')
    add('challenge.independent_test_scenes',challenge['scene_count'],'64')
    add('challenge.images',challenge['image_count'],'256')
    add('challenge.evaluations',challenge['frontend_evaluations'],'512')
    (FIG/'completion_claims.json').write_text(json.dumps(dict(claims=claims),indent=2)+'\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--partial', action='store_true', help='Build completed campaign artifacts and available raw-image gallery only.')
    args = parser.parse_args()
    style.QA.clear()
    cards=risk_figure()
    case_figure(cards)
    request_table()
    summary,full,sparse=campaign_figures()
    design_text()
    challenge_gallery()
    campaign_results(cards,summary,full,sparse)
    if not args.partial:
        challenge,freeze,metrics,conditions=challenge_figures()
        stats=challenge_results(challenge,freeze,metrics,conditions)
        article_summary(summary,full,sparse,challenge,stats)
    elif (CHALLENGE/'analysis/fixed_example_preview.json').exists():
        preview=read_json(CHALLENGE/'analysis/fixed_example_preview.json')
        freeze=read_json(CHALLENGE/'analysis/freeze.json')
        correspondence_figure(pd.DataFrame(preview['rows']),freeze['selected']['name'])
    (FIG/'completion_canvas_qa.json').write_text(json.dumps(style.QA, indent=2)+'\n')
    (FIG/'completion_figure_provenance.json').write_text(json.dumps(dict(sources=SOURCES), indent=2)+'\n')
    print(json.dumps(dict(figures=len(style.QA), source_files=len(SOURCES))))


if __name__ == '__main__':
    main()
