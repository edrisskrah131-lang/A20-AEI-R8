"""Live integrated executions on independent, prescribed complete routes.

Native online CPU is timed around computation/coordination, excluding sensor
raycasting and truth scoring. Availability follows the frozen operation clock.
Episode cards are never authorized for this different route population.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import argparse,json,time
import numpy as np,pandas as pd
import checkpoint
from rcp.core import JointState,exp,log,propagate
from rcp.sensor import Mesh
from train import initial_cov
from r4_sensor import raw_scan,frontend
from r8_collect import CountedICP,thin_sensor
from r8_geometry import geometry,route
from r8_protocol import ROOT,D,PROTOCOL,sha,digest
from r8_policy import policies,decide,predict_count,prediction_work,solver_work,stage_reservation
from r8_contracts import Registry,dispatch,procedural_dispatch,events_for,Transaction,source_from_arrays,prepare_payload,payload_seal,Precommit,procedural_version_check
from r8_evaluate import assert_freeze,runtime_bindings,relevant_bindings
from r8_service import load_models

VARIANTS=['KG1','Fixed2','Fixed4','Final','FlatCART','FlatRF','ContractRF','OldRAVC','CART_Time','KG1_Held','Full','TaskAwareFlatValidated']

def inputs(mesh,condition,rep):
    design=PROTOCOL['route_design'];gi=design['geometries'].index(mesh);ci=design['conditions'].index(condition)
    seed=design['base']+gi*10000+ci*1000+rep;folder=D/'routes'/f'{mesh}_{condition}_{rep}';folder.mkdir(exist_ok=True)
    output=folder/'inputs.npz'
    if output.exists():return folder
    rng=np.random.default_rng(seed);level=3 if condition=='geometric_stress' else rep%3
    world=Mesh(geometry(mesh,level));path=np.load(route(mesh))['pose'];n=6000
    # Continuous source path; no cyclic join between unequal endpoints.
    idx=np.arange(n)*(len(path)-1)/(n-1);lo=np.minimum(idx.astype(int),len(path)-2);hi=lo+1;a=idx-lo
    truth=path[lo]*(1-a[:,None])+path[hi]*a[:,None]
    truth[:,5]=path[lo,5]+a*np.angle(np.exp(1j*(path[hi,5]-path[lo,5])))
    inc=np.zeros((n,6))
    for i in range(1,n):inc[i]=np.r_[(truth[i,:3]-truth[i-1,:3])@exp(truth[i-1,3:]),log(exp(truth[i-1,3:]).T@exp(truth[i,3:]))]
    density=np.r_[np.full(3,.004),np.full(3,.0004)];scale=np.r_[np.full(3,.0015),np.full(3,.00015)]
    bias=np.zeros((n,6));bias[0]=rng.normal(0,scale)
    for i in range(1,n):bias[i]=np.exp(-.1/125)*bias[i-1]+rng.normal(0,scale)*np.sqrt(1-np.exp(-.2/125))
    observed=inc+bias*.1+rng.normal(0,np.sqrt(.1)*density,(n,6))
    mt=rng.normal(0,.025,3);mR=exp(rng.normal(0,.001,3));sd=.08 if condition=='geometric_stress' else .03
    prior=JointState(truth[0,:3]+rng.normal(0,sd,3),exp(rng.normal(0,.006,3))@exp(truth[0,3:]),np.zeros(6),np.zeros(3),np.eye(3),initial_cov(sd))
    raws=[];relative=[];offset=[0];frames=[]
    for i in range(20,n,20):
        raw,dt,ring=raw_scan(world,truth[i],inc[min(i+1,n-1)]/.1,seed*100000+i,i*.1,mt,mR,2. if condition=='geometric_stress' or rep>0 else 1.)
        profile='occlusion' if condition=='geometric_stress' and 120<=i*.1<240 else 'degeneracy' if condition=='geometric_stress' and 240<=i*.1<360 else 'nominal'
        raw,dt,ring=thin_sensor(raw,dt,ring,profile,np.random.default_rng(seed+i))
        raws.append(raw);relative.append(dt);offset.append(offset[-1]+len(raw));frames.append(i)
    np.savez_compressed(output,truth=truth,increment=observed,map_t=mt,map_R=mR,raw=np.concatenate(raws),raw_dt=np.concatenate(relative),raw_offsets=offset,frames=frames,
        **{'prior_'+k:getattr(prior,k) for k in ['t','R','bias','mt','mR','P']})
    (folder/'inputs_manifest.json').write_text(json.dumps({'seed':seed,'mesh':mesh,'condition':condition,'rep':rep,'level':level,
        'input_sha256':sha(output),'generator_sha256':sha(__file__),'route_template_sha256':sha(route(mesh)),
        'world_sha256':sha(geometry(mesh,level)),'source':'synthetic rolling raycast on licensed/procedural geometry; stochastic measured increment odometry; prescribed route'},indent=2))
    print('R8_ROUTE_INPUT',mesh,condition,rep,flush=True);return folder

def service_at(condition,source):
    if condition=='ordinary':return PROTOCOL['services'][1]
    # Frozen exogenous load/deadline schedule; no estimator feedback.
    return PROTOCOL['services'][[1,2,3][int(source*.1//60)%3]]

def error(state,truth,mt,mR):return float(np.linalg.norm((state.t-state.mt)@state.mR-(truth[:3]-mt)@mR))

def register_source(prior_map,raw,dt,past,prior,mesh,noise,p,models,clock,service,profile,source_id,binding,commit=None):
    start=time.process_time_ns();cloud,front_cpu=frontend(raw,dt,past);source=source_from_arrays(source_id,cloud,prior)
    if commit is not None:commit.bind_source(source);commit.verify(commit.plan);commit.verify_execution(p['id'],profile,service['id'])
    tx=Transaction(source,p['id'],profile,service['id'],service['deadline_s'],service['budget_s'],binding,commit.identity if commit else None)
    bytes_=cloud.nbytes+sum(getattr(prior,k).nbytes for k in ['t','R','bias','mt','mR','P'])
    front_work=clock['frontend_nlogn_s']*max(1,len(raw)*np.log2(1+len(raw)))
    seal_work=clock['seal_byte_s']*bytes_;fixed_work=front_work+seal_work;dec_work=0.;dec_cpu=0.;pubs=[];trace=[];seq=0;budget=False
    first=stage_reservation(0,1,p['model'],clock)
    if seal_work+clock['solver_init_s']+clock['query_s']+first>service['budget_s']:
        return [],tx,{'cpu_s':(time.process_time_ns()-start)*1e-9,'front_cpu_s':front_cpu,'decision_cpu_s':0.,'sender_work_s':seal_work,
            'sender_total_work_s':fixed_work,'iterations':0,'budget_stop':1,'trace':[]}
    solver=CountedICP(prior_map,cloud,prior,int(mesh=='C172'));last=None;previous=0
    context={'mesh':mesh,'noise':noise,'seed':int(source_id.split('/')[-1])}
    for cap in [1,2,4,8,16,25]:
        current=solver_work(last,clock) if last is not None else clock['solver_init_s']+clock['query_s']
        reserve=stage_reservation(previous,cap,p['model'],clock)
        if seal_work+current+dec_work+reserve>service['budget_s']+1e-12:
            budget=True
            if last is not None and last['eligible'] and not (last['done'] and not last['accepted']) and not any(x[2]==last['iteration'] for x in pubs):
                if seal_work+current+dec_work+clock['publication_s']<=service['budget_s']+1e-12:
                    seq+=1;dec_work+=clock['publication_s'];tx.register_payload(seq,last['iteration'],post);pubs.append((post.copy(),fixed_work+current+dec_work,last['iteration'],seq))
            break
        post,stats,feature=solver.advance();last=dict(**stats,feature=feature.tolist(),query_calls=solver.query_calls,checkpoint_calls=solver.checkpoint_calls)
        t=time.process_time_ns()
        pred,visits=predict_count(models[p['model']],feature if p['model']=='old' else np.r_[feature[:10],noise]) if p['model'] else (None,0)
        pub,halt,detail=decide(context,last,pred,p,clock,service,fixed_work+solver_work(last,clock)+dec_work+prediction_work(p['model'],visits,clock))
        dec_cpu+=(time.process_time_ns()-t)*1e-9
        dec_work+=prediction_work(p['model'],visits,clock)+clock['decision_s'];previous=last['iteration']
        paid=fixed_work+solver_work(last,clock)+dec_work
        if pub:seq+=1;dec_work+=clock['publication_s'];paid+=clock['publication_s'];tx.register_payload(seq,last['iteration'],post);pubs.append((post.copy(),paid,last['iteration'],seq))
        trace.append({'iteration':last['iteration'],'publish':bool(pub),'halt':bool(halt),'sender_work_s':paid-front_work,**detail})
        if halt or solver.done:break
    paid=fixed_work+solver_work(last,clock)+dec_work if last else fixed_work
    if last and last['done'] and not last['accepted'] and pubs:
        seq+=1;dec_work+=clock['publication_s'];paid+=clock['publication_s'];tx.register_payload(seq,0,prior);pubs.append((prior.copy(),paid,0,seq))
    assert paid-front_work<=service['budget_s']+1e-12
    return pubs,tx,{'cpu_s':(time.process_time_ns()-start)*1e-9,'front_cpu_s':front_cpu,'decision_cpu_s':dec_cpu,
        'sender_work_s':paid-front_work,'sender_total_work_s':paid,'front_work_s':front_work,'iterations':solver.it,'budget_stop':int(budget),'trace':trace}

def run(folder,mesh,condition,rep,variant,models,prior_map,clock,registry,table,ps):
    out=folder/f'{variant}.json'
    if out.exists():return json.loads(out.read_text())['result']
    z=np.load(folder/'inputs.npz');state=JointState(*(z['prior_'+k].copy() for k in ['t','R','bias','mt','mR','P']))
    truth=z['truth'];increments=z['increment'];cs={int(f):j for j,f in enumerate(z['frames'])}
    pending=None;trace=[];jobs=[];captures=[];publications=[];online=prop_cpu=receiver_cpu=correction_cpu=dispatch_cpu=0.;work=0.;dropped=0;scope_refusals=0
    last_policy=None;switches=0;noise=2. if condition=='geometric_stress' or rep>0 else 1.
    for i in range(len(truth)):
        online_start=time.process_time_ns()
        if i:
            t=time.process_time_ns();state=propagate(state,.1,increments[i]);prop_cpu+=(time.process_time_ns()-t)*1e-9;work+=clock['propagation_step_s']
        if pending is not None:
            while pending['versions'] and pending['versions'][0]['arrival']<=i:
                v=pending['versions'].pop(0);elapsed=(i-pending['source'])*.1;t=time.process_time_ns()
                packet={'source':pending['tx'].source.identity,'prior':pending['tx'].source.prior_seal,'data':pending['tx'].source.data_seal,
                    'sequence':v['sequence'],'iteration':v['iteration'],'rollback':v['iteration']==0,'policy':pending['policy'],
                    'profile':pending['profile'],'service':pending['service']['id'],'bindings':pending['bindings'],
                    'replay_to':i-pending['source'],'sender_work_s':v['prefix']-pending['front_work'],'payload':pending['tx'].payloads[v['sequence']],'commit_id':pending['tx'].commit_id}
                checkreq={'event':'trajectory','assessment_s':4.,'active_bindings':pending['bindings'],'received_payload_seal':payload_seal(v['state'])}
                if variant=='TaskAwareFlatValidated':
                    tx=pending['tx'];ok=procedural_version_check(tx.source,tx.policy,tx.profile,tx.service,tx.deadline,tx.budget,tx.bindings,packet,elapsed,i-pending['source'],tx.last_sequence,tx.last_iteration,tx.rollback,checkreq,tx.expected_versions)
                    ok=ok and packet['commit_id']==tx.commit_id
                    check={'valid':ok,'reasons':[] if ok else ['procedural_validation']}
                else:check=pending['tx'].assess(packet,elapsed,i-pending['source'],checkreq)
                if check['valid']:
                    cur=v['state'].copy()
                    for k in range(pending['source']+1,i+1):cur=propagate(cur,.1,increments[k])
                    state=cur;pending['tx'].install(packet,i-pending['source']);pending['active']=v['iteration']
                    publications.append([pending['source'],i,v['iteration'],v['sequence']])
                receiver_cpu+=(time.process_time_ns()-t)*1e-9
                work+=clock['receiver_base_s']+(i-pending['source'])*clock['propagation_step_s']
            assessment=i==pending['source']+int(round(pending['service']['deadline_s']/.1))
            if assessment:
                # Save the state for scoring after the online timer closes.
                assess_info=(pending['source'],pending['active']>0,state.copy(),pending['policy'],pending['service']['id'])
            else:assess_info=None
            if i>=pending['end'] and not pending['versions'] and i>=pending['source']+int(round(pending['service']['deadline_s']/.1)):pending=None
        else:assess_info=None
        if i in cs:
            if pending is not None:dropped+=1;drop_info=(i,state.copy())
            else:
                drop_info=None;j=cs[i];service=service_at(condition,i);task=PROTOCOL['request_types'][(i//20-1)%4]
                profile='route/'+condition+'/'+mesh;proxy='unfitted' if mesh=='UnfittedAirframe' else 'nominal';pid=variant
                request={'profile':profile,'service':service['id'],'task':task,'events':events_for(task),'allowance':.15,'declared_population':True,'elapsed_s':0.}
                d0=time.process_time_ns()
                if variant in ['Full','TaskAwareFlatValidated']:
                    admission=dispatch(registry,table,request,list(ps)) if variant=='Full' else procedural_dispatch(registry.cards,table,request,list(ps),registry.runtime)
                    assert admission['status']=='REFUSED';scope_refusals+=1
                    # Empirical recommendation is explicitly provisional and
                    # cannot transfer any episode bound to this route request.
                    proxyreq=dict(request,profile=proxy)
                    recommendation=dispatch(registry,table,proxyreq,list(ps)) if variant=='Full' else procedural_dispatch(registry.cards,table,proxyreq,list(ps),registry.runtime)
                    pid=recommendation['policy'] or 'KG1'
                elif variant=='KG1_Held':pid='KG1'
                provisional_plan={'status':'PROVISIONAL','policy':pid,'witness':dict(profile=profile,service=service['id'],task=task,allowance=.15,cards=[],bounds={})}
                commit=Precommit(request,provisional_plan)
                dispatch_cpu+=(time.process_time_ns()-d0)*1e-9
                if last_policy is not None and pid!=last_policy:switches+=1
                last_policy=pid;p=ps[pid];binding=relevant_bindings(registry.runtime,proxy,service,p)
                raw=z['raw'][z['raw_offsets'][j]:z['raw_offsets'][j+1]];dt=z['raw_dt'][z['raw_offsets'][j]:z['raw_offsets'][j+1]]
                pubs,tx,stats=register_source(prior_map,raw,dt,increments[max(1,i-4):i+1],state,mesh,noise,p,models,clock,service,profile,'route-scan/'+str(i),binding,commit)
                correction_cpu+=stats['cpu_s'];work+=stats['sender_total_work_s'];paid=stats['sender_total_work_s']
                if variant=='KG1_Held' and pubs:
                    post,_,it,seq=pubs[-1];pubs=[(post,paid,it,seq)]
                versions=[];replay_work=0.;lastarrival=i
                for post,c,it,seq in pubs:
                    denominator=.1-service['load']*clock['propagation_step_s']
                    relative=max(1,int(np.ceil((.05+service['load']*(c+replay_work+clock['receiver_base_s']))/denominator))) if denominator>0 else len(truth)
                    versions.append({'arrival':i+relative,'state':post,'iteration':it,'sequence':seq,'prefix':c})
                    replay_work+=clock['receiver_base_s']+relative*clock['propagation_step_s'];lastarrival=i+relative
                end=max(lastarrival,i+max(1,int(np.ceil((.05+service['load']*(paid+replay_work))/.1))))
                pending={'source':i,'versions':versions,'active':0,'end':end,'tx':tx,'policy':pid,'profile':profile,'service':service,'bindings':binding,'front_work':stats.get('front_work_s',stats['sender_total_work_s']-stats['sender_work_s'])}
                jobs.append({'source':i,'task':task,'policy':pid,'service':service['id'],'status':'PROVISIONAL','requested_route_population':profile,**stats})
        else:drop_info=None
        online+=(time.process_time_ns()-online_start)*1e-9
        if assess_info is not None:
            source,ready,assess_state,pid,sid=assess_info;e=error(assess_state,truth[i],z['map_t'],z['map_R']);captures.append([source,int(ready),int(ready and e<=.1),e])
        if drop_info is not None:captures.append([i,0,0,error(drop_info[1],truth[i],z['map_t'],z['map_R'])])
        e=error(state,truth[i],z['map_t'],z['map_R']);trace.append([i*.1,e,*state.t,pending['active'] if pending else 0])
    arr=np.asarray(trace);e=arr[:,1];cap=np.asarray(captures)
    result={'mesh':mesh,'condition':condition,'rep':rep,'variant':variant,'duration_s':600.,'calls':len(jobs),'dropped':dropped,
        'opportunities':len(cs),'capture_ready':int(cap[:,1].sum()),'capture_success':int(cap[:,2].sum()),
        'rmse_cm':float(np.sqrt(np.mean(e**2))*100),'p95_cm':float(np.quantile(e,.95)*100),'p99_cm':float(np.quantile(e,.99)*100),'max_cm':float(e.max()*100),
        'fail_samples':int((e[50:]>.1).sum()),'event_after_5s':int(np.any(e[50:]>.1)),'loss_m2s':float(np.sum(e**2)*.1),
        'direct_online_cpu_s':online,'prop_cpu_s':prop_cpu,'receiver_cpu_s':receiver_cpu,'correction_cpu_s':correction_cpu,'dispatch_cpu_s':dispatch_cpu,
        'coordinator_cpu_s':online-prop_cpu-receiver_cpu-correction_cpu-dispatch_cpu,'work_equivalent_s':work,
        'front_cpu_s':sum(x['front_cpu_s'] for x in jobs),'decision_cpu_s':sum(x['decision_cpu_s'] for x in jobs),
        'policy_switches':switches,'mean_iterations':float(np.mean([x['iterations'] for x in jobs])),
        'scope_refusals':scope_refusals,'authorized_episode_cards':0,'certificate_scope':'route population differs; descriptive outcomes only'}
    assert result['coordinator_cpu_s']>=-1e-7
    np.savez_compressed(folder/f'{variant}.npz',trace=arr,captures=cap)
    out.write_text(json.dumps({'result':result,'jobs':jobs,'publications':publications,'executor_sha256':sha(__file__)},indent=2,allow_nan=False))
    print('R8_ROUTE',mesh,condition,rep,variant,'rmse',round(result['rmse_cm'],3),'success',result['capture_success'],'CPU',round(online,3),flush=True)
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--collect',action='store_true');ap.add_argument('--pilot',action='store_true');a=ap.parse_args()
    if not a.pilot:
        assert_freeze();f=json.loads((D/'selection_freeze.json').read_text())
        for p,h in f['files'].items():assert sha(D/p)==h
    design=PROTOCOL['route_design']
    if a.collect:
        for m in design['geometries']:
            for c in design['conditions']:
                for rep in range(4):inputs(m,c,rep)
        return
    models=load_models();clock=json.loads((D/'clock_profile.json').read_text());ps={p['id']:p for p in policies()}
    registry=Registry(json.loads((D/'event_cards.json').read_text()),runtime_bindings());cf=pd.read_csv(D/'calibration.csv')
    table={(r.profile,r.service,r.policy):r.score_m2s for r in cf[cf.event=='trajectory'].itertuples()}
    maps={m:Mesh(geometry(m)).prior for m in design['geometries']}
    tasks=[(m,c,r,v) for m in design['geometries'] for c in design['conditions'] for r in range(4) for v in VARIANTS]
    np.random.default_rng(PROTOCOL['statistics']['seed']).shuffle(tasks);results=[]
    for m,c,r,v in tasks:
        folder=D/'routes'/f'{m}_{c}_{r}';results.append(run(folder,m,c,r,v,models,maps[m],clock,registry,table,ps))
        pd.DataFrame(results).sort_values(['mesh','condition','rep','variant']).to_csv(D/'route_results.csv',index=False)
    print('R8_ROUTES_COMPLETE',len(results),flush=True)

if __name__=='__main__':main()
