"""Event-driven dispatch over the unchanged R4 calibrated policy catalogue.

This is secondary analysis of frozen records, not a new prospective experiment.
A request selects one constant policy for its declared population/context. It
does not select using individual scan quality, labels, or confirmation results.
"""
import os
os.environ['OPENBLAS_NUM_THREADS'] = '1'
from pathlib import Path
import copy
import json
import time
import numpy as np
import pandas as pd
from r4_protocol import ROOT, D, PROTOCOL, sha
from r4_contracts import check, digest, EVENTS, frontend_hash

OUT = ROOT / 'data/r5_dispatch'
TASKS = {'trajectory': ['trajectory'], 'capture': ['capture'],
         'both_marginals': ['trajectory', 'capture']}


def finite_number(x):
    return type(x) in (int, float) and np.isfinite(x)


def runtime_bindings(fingerprint=sha, active_service=None):
    """Construct trusted runtime identity from the installed frozen source."""
    frozen = json.loads((D / 'freeze.json').read_text())
    manifest = json.loads((D / 'evaluation_manifest.json').read_text())
    paths = {ROOT/'source/r4_policy.py': frozen['policy_sha256'],
             ROOT/'source/checkpoint.py': frozen['solver_sha256'],
             ROOT/'data/checkpoint_model.npz': frozen['old_model_sha256'],
             D/'protocol.json': frozen['protocol_sha256'],
             ROOT/'source/r4_evaluate.py': manifest['numeric_executor_sha256']}
    paths.update({D/f'{model}_forecast.npz': frozen['forecasts'][model]['sha256']
                  for model in ['cart','rf']})
    for path, expected in paths.items():
        if fingerprint(path) != expected:
            raise ValueError('runtime component mismatch: ' + str(path.relative_to(ROOT)))
    if json.loads((D/'protocol.json').read_text()) != PROTOCOL:
        raise ValueError('active protocol differs from the frozen protocol')
    # Active configuration comes from the frozen executor/protocol, not from
    # the event card being checked. This verifies this source/configuration
    # snapshot, not device timing or complete executable-environment identity.
    service = {'queue_s': PROTOCOL['queue_s'], 'dt_s': PROTOCOL['dt_s'],
               'primitive_cpu_s': manifest['step_cpu_s'],
               'installation_latency': manifest['installation_latency'],
               'receiver_replay': 'all prior versions charged; replay through installation tick',
               'numeric_executor_sha256': fingerprint(ROOT/'source/r4_evaluate.py')}
    if active_service is not None:
        service = active_service
    bindings = {}
    for spec in frozen['policies']:
        model = spec['model']
        forecast = (frozen['old_model_sha256'] if model == 'old' else
                    frozen['forecasts'][model]['sha256'] if model else 'none')
        bindings[spec['id']] = {
            'policy_hash': digest({'spec': spec, 'implementation': frozen['policy_sha256']}),
            'forecast_hash': forecast}
    return {'policies': bindings, 'frontend_hash': frontend_hash(),
            'service_hash': digest(service), 'service_parameters': service,
            'installation_model': 'queue plus scaled sender work and cumulative causal receiver replay, quantized 0.1s',
            'verified_component_hashes': {str(p.relative_to(ROOT)): expected for p,expected in paths.items()}}


class Dispatcher:
    def __init__(self, cards, calibration, runtime):
        assert len(cards) == 240 and len(calibration) == 120
        assert len({c['id'] for c in cards}) == 240
        self.cards = cards
        self.calibration = calibration
        self.runtime = runtime
        self.profiles = {c['profile_id'] for c in cards}
        self.card_index = {(c['policy_id'],c['profile_id'],c['load'],c['kind']): c for c in cards}
        self.objective_index = {(r.phase,float(r.load),r.policy): float(r.loss_m2s+r.cpu_s)
                                for r in calibration.itertuples()}
        assert len(self.card_index) == 240 and len(self.objective_index) == 120

    def dispatch(self, request, source):
        """Return a selected policy and vector of marginal bounds, or refusal."""
        reasons = []
        if not isinstance(request, dict) or not isinstance(source, dict):
            return {'status': 'REFUSED', 'reasons': ['invalid_record'], 'policy': None}
        events = request.get('events')
        if (not isinstance(events, dict) or not events or
                any(e not in EVENTS for e in events)):
            reasons.append('invalid_events')
        else:
            for e, spec in events.items():
                if not isinstance(spec, dict):
                    reasons.append('invalid_event_specification')
                    continue
                allowance = spec.get('allowance')
                if not finite_number(allowance) or not 0 <= allowance <= .15:
                    reasons.append('invalid_allowance')
                if spec.get('event_hash') != digest(EVENTS[e]):
                    reasons.append('event_definition')
        for key in ['load', 'queue_s']:
            if not finite_number(request.get(key)):
                reasons.append('invalid_' + key)
        if not isinstance(request.get('profile_id'), str) or request['profile_id'] not in self.profiles:
            reasons.append('unknown_profile')
        for key in ['source_id', 'source_prior_seal']:
            if (not isinstance(source.get(key), str) or not source[key] or
                    request.get(key) != source[key]):
                reasons.append('source_lineage')
        if reasons:
            return {'status': 'REFUSED', 'reasons': sorted(set(reasons)), 'policy': None}

        candidates = []
        for pid, binding in self.runtime['policies'].items():
            bounds = {}
            applicable = True
            for event, spec in events.items():
                c = self.card_index.get((pid,request['profile_id'],request['load'],event))
                if c is None:
                    applicable = False
                    break
                # The runtime supplies the selected implementation identity;
                # request metadata cannot manufacture it from a matching card.
                req = dict(request, kind=event, policy_id=pid,
                           policy_hash=binding['policy_hash'],
                           forecast_hash=binding['forecast_hash'],
                           event_hash=spec['event_hash'],
                           risk_allowance=spec['allowance'])
                for key in ['frontend_hash', 'service_hash', 'installation_model']:
                    if c[key] != self.runtime[key]:
                        applicable = False
                if not check(c, req, source)['authorized']:
                    applicable = False
                bounds[event] = c['risk_upper']
            if applicable:
                context = c['id'].split('/')[0]
                candidates.append({'policy': pid, 'score': self.objective_index[(context,request['load'],pid)],
                                   'bounds': bounds})
        candidates.sort(key=lambda c: (c['score'], c['policy']))
        if not candidates:
            return {'status': 'REFUSED', 'reasons': ['no_applicable_policy'],
                    'policy': None, 'eligible_policies': []}
        best = candidates[0]
        return {'status': 'SELECTED', 'reasons': [], **best,
                'eligible_policies': [c['policy'] for c in candidates],
                'statement': 'separate population marginal bounds',
                'union_bound': min(1., sum(best['bounds'].values()))}


def request_for(cards, context, load, task):
    c = next(c for c in cards if c['id'].startswith(context + '/') and c['load'] == load)
    source = {'source_id': 'scan/illustrative-101',
              'source_prior_seal': digest({'t': [0, 0, 0], 'P': 'immutable'})}
    req = {k: c[k] for k in ['profile_id', 'load', 'queue_s', 'frontend_hash',
                              'installation_model', 'service_hash']}
    req.update(source)
    req.update(mesh_hash=next(iter(c['mesh_hashes'].values())),
               declared_profile_assumption=True, assessment_s=.3, elapsed_s=0.,
               events={e: {'allowance': .15, 'event_hash': digest(EVENTS[e])}
                       for e in TASKS[task]})
    return req, source


def audit(dispatcher):
    """Exercise successful requests, semantic refusals and numeric bypasses."""
    cards = dispatcher.cards
    req, source = request_for(cards, 'nominal_calibration', 20., 'both_marginals')
    rows = []

    def test(name, request, seal=source, expected=False, server=dispatcher):
        result = server.dispatch(request, seal)
        admitted = result['status'] == 'SELECTED'
        assert admitted == expected, (name, result)
        rows.append({'case': name, 'expected_selected': expected, **result})

    test('valid_both_marginals', req, expected=True)
    for value in [None, {}, [], {'joint_union': {'allowance': .15}},
                  {'capture': None}]:
        test('invalid_events_' + str(value), dict(req, events=value))
    for value in [None, float('nan'), float('inf'), -.01, True, False, .15001, 1.]:
        r = copy.deepcopy(req); r['events']['capture']['allowance'] = value
        test('invalid_allowance_' + str(value), r)
    r = copy.deepcopy(req); r['events']['capture']['allowance'] = .08
    test('stricter_capture_allowance', r)
    r = copy.deepcopy(req); r['events']['capture']['event_hash'] = digest(EVENTS['trajectory'])
    test('trajectory_hash_for_capture', r)
    for key in ['profile_id', 'mesh_hash', 'frontend_hash', 'service_hash',
                'installation_model', 'source_id', 'source_prior_seal', 'queue_s']:
        test('mismatch_' + key, dict(req, **{key: 'incompatible'}))
    for key in ['load', 'queue_s', 'elapsed_s', 'assessment_s']:
        for value in [None, float('nan'), float('inf'), True, False, -1.]:
            test('invalid_' + key + '_' + str(value), dict(req, **{key: value}))
    for load in [40., 60.]:
        test('uncalibrated_load_' + str(load), dict(req, load=load))
    test('expired_capture', dict(req, elapsed_s=.4))
    test('wrong_capture_instant', dict(req, assessment_s=.2))
    for value in [None, 'true', 1, False]:
        test('invalid_profile_assumption_' + str(value), dict(req, declared_profile_assumption=value))
    for profile in ['complete_route', 'difficult_prior', 'shifted_noise']:
        test('uncovered_' + profile, dict(req, profile_id=profile))
    for value in [[], {}, None, True]:
        test('invalid_profile_id_' + str(value), dict(req, profile_id=value))
    for key in ['source_id', 'source_prior_seal']:
        test('empty_source_' + key, dict(req, **{key: ''}), dict(source, **{key: ''}))
    for key in ['policy_hash', 'forecast_hash']:
        bad = copy.deepcopy(dispatcher.runtime)
        for binding in bad['policies'].values():
            binding[key] = 'changed-installed-implementation'
        test('changed_runtime_' + key, req,
             server=Dispatcher(cards, dispatcher.calibration, bad))
    for relative in dispatcher.runtime['verified_component_hashes']:
        def altered(path, relative=relative):
            return 'changed-component' if str(path.relative_to(ROOT)) == relative else sha(path)
        try:
            runtime_bindings(fingerprint=altered)
        except ValueError:
            rows.append({'case':'startup_changed_' + relative, 'expected_selected':False,
                         'status':'REFUSED_AT_STARTUP','policy':None})
        else:
            raise AssertionError('changed runtime component was not rejected: ' + relative)
    for key, value in [('queue_s',.1), ('dt_s',.2), ('primitive_cpu_s',.001),
                       ('installation_latency','different'), ('receiver_replay','none')]:
        service = dict(dispatcher.runtime['service_parameters'], **{key:value})
        test('changed_active_service_' + key, req,
             server=Dispatcher(cards,dispatcher.calibration,runtime_bindings(active_service=service)))
    for context in ['nominal_calibration', 'geometry_calibration']:
        for load in [1., 10., 20.]:
            for task in TASKS:
                r, s = request_for(cards, context, load, task)
                test(f'{context}/load{load:g}/{task}', r, s,
                     expected=not (context == 'geometry_calibration' and task == 'both_marginals'))
    pd.DataFrame(rows).to_csv(OUT / 'dispatch_audit.csv', index=False)
    return {'checks': len(rows), 'unexpected_selections': 0,
            'scope': 'deterministic metadata requests with illustrative source seals'}


def benchmark(dispatcher):
    """Indexed metadata dispatch CPU; exclude startup hashing and transport."""
    requests = [request_for(dispatcher.cards,context,load,task)
                for context in ['nominal_calibration','geometry_calibration']
                for load in [1.,10.,20.] for task in TASKS]
    for request,source in requests:
        dispatcher.dispatch(request,source)
    costs = []
    for i in range(2400):
        request,source = requests[i % len(requests)]
        begin = time.process_time_ns()
        dispatcher.dispatch(request,source)
        costs.append((time.process_time_ns()-begin)/1000.)
    result = {'calls':len(costs),'request_configurations':len(requests),
              'median_us':float(np.median(costs)), 'p95_us':float(np.quantile(costs,.95)),
              'metric':'single-process process_time_ns; indexed in-process dispatch',
              'scope':'includes candidate filtering and calibration-score selection; excludes startup/component hashing, transport and scan hashing',
              'ledger':'separate metadata prototype; not added to the frozen numerical CPU/installation service',
              'source_sha256':sha(ROOT/'source/r5_dispatch.py')}
    (OUT/'dispatch_cost.json').write_text(json.dumps(result,indent=2))
    return result


def paired_effect(a, b, metric, rng):
    aa = a[metric].to_numpy(dtype=float); bb = b[metric].to_numpy(dtype=float)
    diffs = []; ratios = []
    for _ in range(40):
        ix = rng.integers(0, len(aa), (250, len(aa)))
        am = aa[ix].mean(axis=1); bm = bb[ix].mean(axis=1)
        diffs.extend(am - bm)
        ratios.extend(am / bm - 1)
    return {'metric': metric, 'n': len(aa), 'difference': float((aa-bb).mean()),
            'difference_ci': np.quantile(diffs, [.025, .975]).tolist(),
            'relative_change': float(aa.mean()/bb.mean()-1),
            'relative_change_ci': np.quantile(ratios, [.025, .975]).tolist()}


def main():
    OUT.mkdir(exist_ok=True)
    cards = json.loads((D / 'event_cards.json').read_text())
    cf = pd.read_csv(D / 'calibration.csv')
    dispatcher = Dispatcher(cards, cf, runtime_bindings())
    decisions = []
    for context in ['nominal_calibration', 'geometry_calibration']:
        for load in [1., 10., 20.]:
            req, source = request_for(cards, context, load, 'trajectory')
            generic = dispatcher.dispatch(req, source)
            assert generic['status'] == 'SELECTED'
            for task in TASKS:
                req, source = request_for(cards, context, load, task)
                decision = dispatcher.dispatch(req, source)
                cardmap = {c['kind']: c for c in cards if c['policy_id'] == generic['policy'] and
                           c['profile_id'] == req['profile_id'] and c['load'] == load}
                generic_applicable = all(cardmap[e]['certified'] and
                                         cardmap[e]['risk_upper'] <= .15 for e in TASKS[task])
                decisions.append({'context': context, 'load': load, 'task': task,
                                  'trajectory_choice': generic['policy'],
                                  'trajectory_choice_applicable': generic_applicable,
                                  **decision})
    # The freeze precedes this script's reading of confirmation records, but the
    # R5 question was formulated after R4 inspection. It is explicitly secondary.
    manifest = {'analysis': 'A20-R5-event-dispatch-secondary',
                'status': 'post-primary secondary frozen-record analysis; not prospective confirmation',
                'selector': 'min calibration mean(loss_m2s) + 1 * mean(cpu_s), tie by policy ID',
                'policy_unit': 'one fixed policy per declared mixture/load/event request',
                'risk': 'each requested marginal <= allowance <= 0.15; no joint 0.15 certificate',
                'events': TASKS, 'catalogue_family_size': 240, 'new_risk_cards': 0,
                'independent_confirmation_inputs': 1120, 'new_geometric_inputs': 0,
                'sha256': {str(p.relative_to(ROOT)): sha(p) for p in
                           [D/'freeze.json', D/'calibration.csv', D/'event_cards.json',
                            ROOT/'source/r4_policy.py', ROOT/'source/r5_dispatch.py']},
                'decisions': decisions}
    (OUT / 'selector_freeze.json').write_text(json.dumps(manifest, indent=2, allow_nan=False))
    qa = audit(dispatcher)
    dispatch_cost = benchmark(dispatcher)
    outcomes = pd.read_csv(D / 'policy_results.csv')
    summaries = []; effects = []; rng = np.random.default_rng(202610119)
    for d in decisions:
        phase = d['context'].replace('calibration', 'confirmation')
        selected = d['policy']
        if selected is None:
            continue
        q = outcomes[(outcomes.phase == phase) & (outcomes.load == d['load'])]
        a = q[q.policy == selected].set_index('seed').sort_index()
        b = q[q.policy == d['trajectory_choice']].set_index('seed').loc[a.index]
        expected_n = 640 if phase.startswith('nominal') else 480
        assert len(a) == expected_n and a.index.is_unique
        r = {k: d[k] for k in ['context', 'load', 'task', 'policy', 'trajectory_choice']}
        r.update(n=len(a), cpu_ms=float(a.cpu_s.mean()*1000),
                 loss_m2s=float(a.loss_m2s.mean()), rmse_cm=float(a.rmse_m.mean()*100),
                 trajectory_failures=int(a.failure.sum()), capture_ready=int(a.capture_ready.sum()),
                 capture_success=int(a.capture_success.sum()),
                 comparator_capture_success=int(b.capture_success.sum()),
                 comparator_cpu_ms=float(b.cpu_s.mean()*1000),
                 comparator_loss_m2s=float(b.loss_m2s.mean()))
        summaries.append(r)
        if selected != d['trajectory_choice']:
            for metric in ['capture_success', 'cpu_s', 'loss_m2s', 'failure']:
                effects.append({**{k: r[k] for k in ['context', 'load', 'task', 'policy', 'trajectory_choice']},
                                **paired_effect(a, b, metric, rng)})
    pd.DataFrame(summaries).to_csv(OUT / 'confirmation_summary.csv', index=False)
    (OUT / 'paired_effects.json').write_text(json.dumps(effects, indent=2))
    report = {'request_configurations': len(decisions),
              'policy_level_admission': 18,
              'policy_level_inapplicable_assignments': sum(not d['trajectory_choice_applicable'] for d in decisions),
              'checked_trajectory_admission': sum(d['trajectory_choice_applicable'] for d in decisions),
              'event_dispatch_admission': sum(d['status'] == 'SELECTED' for d in decisions),
              'both_geometry_refusals': sum(d['status'] == 'REFUSED' for d in decisions),
              'audit': qa, 'dispatch_cost':dispatch_cost, 'bootstrap_resamples': 10000,
              'bootstrap_unit': 'paired independent episode seed',
              'comparators': 'constructed policy-level admission and checked trajectory-choice diagnostics',
              'interpretation': 'catalogue coverage, not a random sample of field requests or individual-scan risk'}
    assert report['request_configurations'] == 18
    assert report['policy_level_inapplicable_assignments'] == 6
    assert report['checked_trajectory_admission'] == 12
    assert report['event_dispatch_admission'] == 15
    (OUT / 'analysis_report.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
