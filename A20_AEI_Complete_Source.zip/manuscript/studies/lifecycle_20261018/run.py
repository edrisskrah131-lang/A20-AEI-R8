import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import json,hashlib,argparse,time,platform
import numpy as np,pandas as pd
from scipy.stats import beta
from imaging import *
from evidence import *
ROOT=Path(__file__).parent;OUT=ROOT/'outputs';OUT.mkdir(exist_ok=True);SPEC=json.loads((ROOT/'protocol.json').read_text());VERIFY=False

def emit(rows,name,ignore=()):
 frame=rows if isinstance(rows,pd.DataFrame) else pd.DataFrame(rows);p=OUT/name
 if VERIFY:
  old=pd.read_csv(p);pd.testing.assert_frame_equal(frame.drop(columns=list(ignore)).reset_index(drop=True),old.drop(columns=list(ignore)).reset_index(drop=True),check_dtype=False,check_exact=False,atol=1e-9,rtol=1e-10)
 else:frame.to_csv(p,index=False)

def observe(job):
 phase,seed=job;s=draw(seed,phase=='stress');p=Pipeline(s);rows=[];variants=VARIANTS if phase!='stress' else ('baseline',)
 for v in variants:
  c=configuration(v);begin=time.process_time_ns();values=p.evaluate(c);cpu=(time.process_time_ns()-begin)*1e-9
  rows.append(dict(phase=phase,seed=seed,layout=s['layout'],family=s['family'],variant=v,**values,cpu_s=cpu))
  if seed in (SPEC['test_seed_start'],SPEC['test_seed_start']+1,SPEC['test_seed_start']+2,SPEC['test_seed_start']+3) and v in ('baseline','decoder','lighting'):
   data=p.image(c);path=OUT/f'example_{seed}_{v}.npz'
   if VERIFY:
    oldz=np.load(path)
    for k in data:assert np.allclose(data[k],oldz[k],atol=1e-9),k
   else:np.savez_compressed(path,**data)
 config=dict(phase=phase,seed=seed,layout=s['layout'],family=s['family'],targets=len(s['cad']),missing=int(s['missing'].sum()),occlusion=s['occlusion'],painted=s['painted'],roughness=s['roughness'],noise=s['noise'],max_cad_discrepancy_m=float(np.linalg.norm(s['actual']-s['cad'],axis=1).max()))
 return rows,config

def populations(workers):
 jobs=[(phase,SPEC[phase+'_seed_start']+i) for phase in ('calibration','test','stress') for i in range(SPEC[phase+'_inputs'])];rows=[];configs=[]
 with ProcessPoolExecutor(workers) as pool:
  for n,(r,c) in enumerate(pool.map(observe,jobs,chunksize=1)):
   rows+=r;configs.append(c)
   if (n+1)%32==0:print('POPULATION',n+1,len(jobs),flush=True)
 emit(rows,'observations.csv',ignore=('cpu_s',));emit(configs,'configurations.csv')

def analysis():
 frame=pd.read_csv(OUT/'observations.csv');groups={v:g.sort_values('seed') for v,g in frame.query('phase=="calibration"').groupby('variant')};cards=[];plans=[];cost=[];timing=[]
 for method in METHODS:
  trials=[]
  for _ in range(11):
   t=time.process_time_ns();row,answer,constructed=construct(groups,method);trials.append((time.process_time_ns()-t)*1e-9)
  cost.append(row);plans.extend(dict(method=method,**a) for a in answer);timing.append(dict(method=method,median_cpu_s=float(np.median(trials)),trials=11))
  if method=='Whole renewal':
   for a in constructed:
    test=frame.query('phase=="test" and variant==@a["variant"]') if False else frame[(frame.phase=='test')&(frame.variant==a['variant'])]
    cards.append({k:v for k,v in a.items() if k!='projection'}|dict(test_failures=int(failures(test,a['request']).sum()),test_n=len(test),authorized=a['upper']<=.15))
 pp=pd.DataFrame(plans);piv=pp.pivot(index=['variant','request'],columns='method',values='authorized');assert piv.eq(piv['Whole renewal'],axis=0).all().all()
 emit(cost,'catalogue_cost.csv');emit(plans,'plans.csv');emit(cards,'risk_cards.csv')
 if not VERIFY:emit(timing,'catalogue_timing.csv')
 quality=[]
 for (phase,v),g in frame.groupby(['phase','variant']):
  quality.append(dict(phase=phase,variant=v,n=len(g),coverage_mean=g.coverage.mean(),residual_median=g.reprojection_px.median(),mapping_median_mm=g.association_m.median()*1000,mapping_p95_mm=g.association_m.quantile(.95)*1000,prior_median_mm=g.prior_translation_error_m.median()*1000,pose_median_mm=g.posterior_translation_error_m.median()*1000))
 emit(quality,'quality_summary.csv')
 stress=frame.query('phase=="stress"');base=frame.query('phase=="test" and variant=="baseline"')
 emit([dict(request=q,nominal_failures=int(failures(base,q).sum()),nominal_n=len(base),stress_failures=int(failures(stress,q).sum()),stress_n=len(stress)) for q in REQUESTS],'stress_summary.csv')
 return cost

def timings(workers):
 # Timing each update/request uses a fresh copy of the same baseline stage cache.
 # Actual method work is executed; time is never inferred from logical call counts.
 jobs=list(range(SPEC['timing_seed_start'],SPEC['timing_seed_start']+SPEC['timing_inputs']));rows=[]
 with ProcessPoolExecutor(workers) as pool:
  for n,r in enumerate(pool.map(time_one,jobs,chunksize=1)):rows+=r;print('TIMING_INPUT',n+1,len(jobs),flush=True)
 if not VERIFY:emit(rows,'pipeline_timing.csv')
 else:
  prior=pd.read_csv(OUT/'pipeline_timing.csv');now=pd.DataFrame(rows);cols=['seed','variant','request','method']+['calls_'+s for s in STAGES];pd.testing.assert_frame_equal(now[cols],prior[cols],check_dtype=False)

def time_one(seed):
 s=draw(seed);baseline=Pipeline(s);base=configuration('baseline');bv=baseline.evaluate(base);rows=[]
 for vi,v in enumerate(VARIANTS[1:]):
  for qi,q in enumerate(REQUESTS):
   rotate=(seed+vi+qi)%len(METHODS);order=METHODS[rotate:]+METHODS[:rotate]
   for method in order:
    p=Pipeline(s)
    if method!='Whole renewal':p.cache=baseline.cache.copy()
    t=time.perf_counter_ns();cpu=time.process_time_ns();c=configuration(v)
    value=p.evaluate(c,None if method=='Whole renewal' else REQUESTS[q])
    # A scalar event check is included; batch cardinality and inversion are measured separately.
    fail=any(not np.isfinite(value[m]) or (lo is not None and value[m]<lo) or (hi is not None and value[m]>hi) for m,(lo,hi) in REQUESTS[q].items())
    ct=(time.process_time_ns()-cpu)*1e-9;wall=(time.perf_counter_ns()-t)*1e-9
    if method=='Whole renewal':reference={m:value[m] for m in REQUESTS[q]}
    rows.append(dict(seed=seed,variant=v,request=q,method=method,cpu_s=ct,wall_s=wall,event_failure=fail,**{'calls_'+k:n for k,n in p.calls.items()},**{m:value[m] for m in REQUESTS[q]}))
   block=rows[-4:]
   for metric in REQUESTS[q]:assert np.allclose([a[metric] for a in block],block[0][metric],rtol=1e-10,atol=1e-9,equal_nan=True)
 return rows

def regression(workers):
 jobs=list(range(SPEC['regression_seed_start'],SPEC['regression_seed_start']+SPEC['regression_inputs']));rows=[]
 with ProcessPoolExecutor(workers) as pool:
  for n,r in enumerate(pool.map(regress_one,jobs,chunksize=1)):rows+=r
 emit(rows,'regression.csv')

def regress_one(seed):
 s=draw(seed);p=Pipeline(s);base=configuration('baseline');b=p.evaluate(base);rows=[]
 for variant,fault,active in [('wide_roi','roi_focal',s['camera'][0]>0),('lighting','light_exposure',s['painted']),('decoder','decoder_focal',s['family']==2)]:
  c=configuration(variant);clean=p.evaluate(c);changed=c.copy()
  if active:
   if fault=='light_exposure':changed['exposure']*=1.8
   else:changed['focal']*=1.08
  dirty=p.evaluate(changed)
  permitted=CHANGES[variant];undeclared=[m for m in QUANTITIES if not (QDEPS[m]&permitted) and not np.isclose(dirty[m],b[m],atol=1e-10,rtol=1e-10)]
  clean_bad=[m for m in QUANTITIES if not (QDEPS[m]&permitted) and not np.isclose(clean[m],b[m],atol=1e-10,rtol=1e-10)]
  rows.append(dict(seed=seed,fault=fault,active=bool(active),veto=bool(undeclared),clean_veto=bool(clean_bad),undeclared=';'.join(undeclared),mapping_before_mm=b['association_m']*1000,mapping_after_mm=dirty['association_m']*1000,residual_after_px=dirty['reprojection_px']))
 return rows

def lifecycle():
 frame=pd.read_csv(OUT/'observations.csv').query('phase=="test"');plans=pd.read_csv(OUT/'plans.csv');rows=[]
 lookup={(r.method,r.variant,r.request):r._asdict() for r in plans.itertuples(index=False)}
 payloads={(r.seed,r.variant):dict(coverage=r.coverage,reprojection_px=r.reprojection_px,association_m=r.association_m) for r in frame.itertuples()}
 for seed in sorted(frame.seed.unique()):
  for q in REQUESTS:
   for mode in ['contract','snapshot','stateless','no_integrity']:
    gate=ReceiptGate();source=f'{seed}/{q}';base=payloads[seed,'baseline'];gate.register(source,1,base)
    for event,v,version,payload in [('baseline','baseline',1,base),('producer_change','exposure',2,payloads[seed,'exposure']),('restoration','baseline',3,base)]:
     if version>1:gate.register(source,version,payload)
     plan=lookup['Contract + fallback',v,q];valid=gate.issue(source,version,payload,v,plan,mode if mode!='contract' else False)
     rows.append(dict(seed=seed,request=q,mode=mode,event=event,issued=valid,expected=bool(plan['authorized'])))
    plan=lookup['Contract + fallback','baseline',q]
    # Separate fault scopes prevent one latch from masking a later ablation.
    for fault in ['stale_version','altered_payload','wrong_producer']:
     scope=source+'/'+fault;gate.register(scope,1,base);gate.register(scope,2,base)
     version=1 if fault=='stale_version' else 2
     payload=dict(base,association_m=base['association_m']+.001) if fault=='altered_payload' else base
     producer='exposure' if fault=='wrong_producer' else 'baseline'
     valid=gate.issue(scope,version,payload,producer,plan,mode if mode!='contract' else False)
     rows.append(dict(seed=seed,request=q,mode=mode,event=fault,issued=valid,expected=False))
     valid=gate.issue(scope,2,base,'baseline',plan,mode if mode!='contract' else False)
     rows.append(dict(seed=seed,request=q,mode=mode,event=fault+'_retry',issued=valid,expected=False))
    successor=source+'/new';gate.register(successor,1,base);valid=gate.issue(successor,1,base,'baseline',plan,mode if mode!='contract' else False)
    rows.append(dict(seed=seed,request=q,mode=mode,event='independent_successor',issued=valid,expected=bool(plan['authorized'])))
 emit(rows,'lifecycle.csv')

if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--verify',action='store_true');a.add_argument('--workers',type=int,default=2);a.add_argument('--stage',choices=['all','population','analysis','timing','regression','lifecycle'],default='all');args=a.parse_args();VERIFY=args.verify
 frozen=json.loads((ROOT/'freeze.json').read_text())
 for name,h in frozen['files'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h,name
 if args.stage in ('all','population'):populations(args.workers)
 if args.stage in ('all','analysis'):print(json.dumps(analysis(),indent=2),flush=True)
 if args.stage in ('all','timing'):timings(args.workers)
 if args.stage in ('all','regression'):regression(args.workers)
 if args.stage in ('all','lifecycle'):lifecycle()
