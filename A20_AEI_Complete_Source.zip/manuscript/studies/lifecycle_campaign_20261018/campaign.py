"""Fixed campaign configuration and evidence planning; no image generation here."""
from functools import lru_cache
from pathlib import Path
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'lifecycle_20261018'))
from imaging import configuration as old_configuration,QDEPS,STAGES,Pipeline,draw
from evidence import REQUESTS,covers

CONFIGS=('baseline','focal','exposure','wide_roi','lighting','decoder',
         'exposure_light_decoder','camera_focal_roi')
METHODS=('Whole renewal','DAG exact + registry','Containment + repair','Rules + registry')
POPULATION='four-layout skin mixture v1'
OTHER_POPULATION='stress mixture v1'
EVENTS=(
 dict(name='baseline',kind='numerical',variant='baseline',request='complete'),
 dict(name='requirement_relax',kind='request',variant='baseline',request='complete_relaxed'),
 dict(name='exposure_update',kind='numerical',variant='exposure',request='complete_relaxed'),
 dict(name='requirement_tighten',kind='request',variant='exposure',request='complete'),
 dict(name='lighting_update',kind='numerical',variant='lighting',request='optical'),
 dict(name='decoder_update',kind='numerical',variant='decoder',request='complete_relaxed'),
 dict(name='combined_update',kind='numerical',variant='exposure_light_decoder',request='complete_relaxed'),
 dict(name='camera_update',kind='numerical',variant='camera_focal_roi',request='complete_relaxed'),
 dict(name='stale_attachment',kind='stale',variant='camera_focal_roi',request='complete_relaxed'),
 dict(name='out_of_order_repair',kind='invalid_repair',variant='camera_focal_roi',request='complete_relaxed'),
 dict(name='validated_repair',kind='repair',variant='camera_focal_roi',request='complete_relaxed'),
 dict(name='repair_replay',kind='replay',variant='camera_focal_roi',request='complete_relaxed'),
 dict(name='numeric_rollback',kind='rollback',variant='baseline',request='complete_relaxed'),
 dict(name='population_mismatch',kind='population',variant='baseline',request='complete_relaxed'),
 dict(name='late_version_delivery',kind='late',variant='baseline',request='complete_relaxed'),
 dict(name='validated_rollback_repair',kind='repair',variant='baseline',request='complete_relaxed'),
)

def configuration(variant):
    if variant=='exposure_light_decoder':
        return dict(old_configuration('baseline'),exposure=1.5,lighting=.45,decoder=10.)
    if variant=='camera_focal_roi':
        return dict(old_configuration('baseline'),focal=1.15,roi=(896,672))
    return old_configuration(variant)

def stable_hash(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

@lru_cache(maxsize=None)
def projection(variant,request):
    c=configuration(variant)
    deps=set().union(*(QDEPS[m] for m in REQUESTS[request]))
    return tuple((k,str(c[k])) for k in sorted(deps))

def numerical_failure(values,request):
    import math
    for metric,(lower,upper) in REQUESTS[request].items():
        value=values[metric]
        if not math.isfinite(value) or (lower is not None and value<lower) or (upper is not None and value>upper):
            return True
    return False

def equivalent_rule(card,variant,request):
    """Independent interval/provider-fact implementation of containment."""
    if card['upper']>.15:return False
    old,new=REQUESTS[card['request']],REQUESTS[request]
    for metric,(lower,upper) in new.items():
        if metric not in old:return False
        lo,hi=old[metric]
        if lower is not None and (lo is None or lo<lower):return False
        if upper is not None and (hi is None or hi>upper):return False
        a,b=configuration(card['variant']),configuration(variant)
        for producer in QDEPS[metric]:
            if a[producer]!=b[producer]:return False
    return True

class Planner:
    """Measured card construction on calibrated records, with persistent cache."""
    def __init__(self,method,groups,alpha=.05/64):
        self.method,self.groups,self.alpha=method,groups,alpha
        self.cards=[];self.evaluations=0;self.cp_calls=0

    def exact(self,variant,request):
        if self.method!='Whole renewal':
            sig=projection(variant,request)
            for card in self.cards:
                if card['request']==request and projection(card['variant'],request)==sig:return card
        from scipy.stats import beta
        rows=self.groups[variant];k=sum(numerical_failure(r,request) for r in rows);n=len(rows)
        upper=1. if k==n else float(beta.isf(self.alpha,k+1,n-k))
        card=dict(variant=variant,request=request,population=POPULATION,n=n,k=k,alpha=self.alpha,upper=upper,
                  projection=projection(variant,request))
        card['identity']=stable_hash(card)
        self.cards.append(card);self.evaluations+=n;self.cp_calls+=1
        return card

    def plan(self,variant,request):
        matches=[]
        if self.method=='Containment + repair':
            matches=[c for c in self.cards if c['upper']<=.15 and covers(c['request'],request)
                     and projection(c['variant'],request)==projection(variant,request)]
        elif self.method=='Rules + registry':
            matches=[c for c in self.cards if equivalent_rule(c,variant,request)]
        if matches:
            selected=min(matches,key=lambda c:(c['upper'],c['variant'],c['request']));route='containment'
        else:
            before=self.cp_calls;selected=self.exact(variant,request)
            route='exact_new' if self.cp_calls>before else 'exact_cached'
        return dict(identity=selected['identity'],authorized=selected['upper']<=.15,
                    upper=selected['upper'],proof_variant=selected['variant'],
                    proof_request=selected['request'],route=route)
