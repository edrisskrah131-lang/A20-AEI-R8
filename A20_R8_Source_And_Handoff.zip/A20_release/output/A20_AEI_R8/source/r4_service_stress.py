"""Additional workload analysis on unchanged confirmation inputs.

Loads 40/60 are outside the calibrated service family. No calibration card is
reused, and these paired observations are descriptive service stress results.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import json,time
import numpy as np,pandas as pd
from r4_protocol import ROOT,D,sha
from r4_policy import Forecast
from checkpoint import CompactTree
from r4_evaluate import predict_cache,evaluate
def main():
 frozen=json.loads((D/'freeze.json').read_text());models={'cart':Forecast(D/'cart_forecast.npz'),'rf':Forecast(D/'rf_forecast.npz'),'old':CompactTree(ROOT/'data/checkpoint_model.npz')}
 manifest=json.loads((D/'evaluation_manifest.json').read_text());step=manifest['step_cpu_s']
 policies=[p for p in frozen['policies']+frozen['ablations'] if p['id'] in ['KG1','KG1_no_deadline','KG1_no_profile','FlatCART','FlatRF','ContractRF','Fixed2','Fixed4','Final']]
 rows=[json.loads(x) for x in (D/'episodes.jsonl').read_text().splitlines() if json.loads(x)['phase'].endswith('confirmation')];records=[]
 for r in rows:
  cache=predict_cache(r,models)
  for load in [40.,60.]:
   for p in policies:records.append(evaluate(r,p,models,cache,load,step))
 f=pd.DataFrame(records);f.to_csv(D/'service_stress_results.csv',index=False)
 summary=[]
 for (phase,load,p),g in f.groupby(['phase','load','policy']):summary.append({'phase':phase,'load':load,'policy':p,'n':len(g),'cpu_ms':g.cpu_s.mean()*1000,'loss':g.loss_m2s.mean(),'events':int(g.failure.sum()),'ready':int(g.capture_ready.sum()),'success':int(g.capture_success.sum())})
 pd.DataFrame(summary).to_csv(D/'service_stress_summary.csv',index=False)
 (D/'service_stress_manifest.json').write_text(json.dumps({'source_sha256':sha(__file__),'paired_input_sha256':sha(D/'episodes.jsonl'),'frozen_policy_sha256':sha(D/'freeze.json'),'loads':[40,60],'events':'same 0.3-s observation-pose event','independent_units':1960,'new_geometric_inputs':0,'rows':len(f),'calibration':'outside calibrated loads; no attached confidence card','analysis':'additional descriptive workload analysis; not used for forecast fitting or family selection'},indent=2))
 print('SERVICE_STRESS_COMPLETE',len(f),flush=True)
if __name__=='__main__':main()
