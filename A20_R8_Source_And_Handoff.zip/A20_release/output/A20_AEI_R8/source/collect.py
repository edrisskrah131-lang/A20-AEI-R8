"""Fresh paired source episodes for checkpoint-policy fitting and confirmation."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json,time,hashlib
import numpy as np
from checkpoint import ROOT,WORK,CheckpointICP
from rcp.core import JointState,exp,log,propagate,register
from rcp.sensor import Mesh,scan
from train import initial_cov
from prospective import rel_error

A19=WORK/'work/a19/RAS_A19';OUT=ROOT/'data';OUT.mkdir(exist_ok=True)
INPUT=OUT/'episode_inputs';INPUT.mkdir(exist_ok=True)
protocol=dict(version='R3-checkpoint-episodes-1',phases={'train':480,'validation':120,'calibration':160,'confirmation':240,'stress':120},
 phase_bases={'train':910000,'validation':920000,'calibration':930000,'confirmation':940000,'stress':950000},
 training_prior_sd=[.015,.03,.06,.14],target_prior_sd=[.015,.03,.06],stress_prior_sd=[.07,.14],
 meshes=['B767','C172'],shape_levels=[0,1,2],target_noise=[1.,2.],stress_noise=[3.,4.],
 horizon_s=4.,motion_dt=.1,risk_eval_start_s=.5,position_alert_m=.1,
 checkpoint_iterations=[1,2,4,8,16,25],runtime_scenarios=[1.,10.],queue_s=.05,
 selection_family_size=20,selection_family_error=.05,main_risk_limit=.15,
 sensor_model='16 rings, rolling 0.1 s; deskew from preceding five noisy increments',
 source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 solver_sha256=hashlib.sha256((ROOT/'source/checkpoint.py').read_bytes()).hexdigest())
f=ROOT/'protocol_episodes.json'
if f.exists():
    # Preserve the original generation hashes when resuming stored inputs.
    # Compatibility checks use scientific settings; export/QA-only code fixes
    # are recorded separately rather than rewriting the generation provenance.
    old=json.loads(f.read_text())
    assert {k:v for k,v in old.items() if not k.endswith('sha256')}=={k:v for k,v in protocol.items() if not k.endswith('sha256')}
else:f.write_text(json.dumps(protocol,indent=2))

def trajectories(states,future,increments,map_t,map_R):
    errors=[];rot=[];costs=[]
    for s in states:
        s=s.copy();pe=[];re=[];t=time.process_time_ns()
        for j in range(41):
            if j:s=propagate(s,.1,increments[j-1])
            p,r=rel_error(s,future[j],map_t,map_R);pe.append(float(np.linalg.norm(p)));re.append(float(np.linalg.norm(r)))
        costs.append((time.process_time_ns()-t)*1e-9);errors.append(pe);rot.append(re)
    return np.array(errors),np.array(rot),costs

meshes={(m,l):Mesh(A19/f'meshes/{m}/world_discrepancy_{l}.npz') for m in protocol['meshes'] for l in [0,1,2]}
routes={m:np.load(A19/f'meshes/{m}/route.npz')['pose'] for m in protocol['meshes']}
out=OUT/'episodes.jsonl';done={r['seed'] for r in map(json.loads,out.read_text().splitlines())} if out.exists() else set()
start=time.perf_counter();count=0
with out.open('a') as file:
 for phase,n in protocol['phases'].items():
  for i in range(n):
   seed=protocol['phase_bases'][phase]+i
   if seed in done:continue
   rng=np.random.default_rng(seed);mesh=str(rng.choice(protocol['meshes']));mi=protocol['meshes'].index(mesh)
   level=int(rng.choice([0,1,2]));noise=float(rng.choice(protocol['stress_noise'] if phase=='stress' else protocol['target_noise']))
   sd=float(rng.choice(protocol['training_prior_sd'] if phase=='train' else protocol['stress_prior_sd'] if phase=='stress' else protocol['target_prior_sd']))
   route=routes[mesh];frame=int(rng.integers(100,len(route)-100));truth=route[frame]
   mt=rng.normal(0,.025,3);mR=exp(rng.normal(0,.001,3))
   def increment(j):return np.r_[(route[j+1,:3]-route[j,:3])@exp(route[j,3:]),log(exp(route[j,3:]).T@exp(route[j+1,3:]))]
   bias=rng.normal(0,np.r_[np.full(3,.0015),np.full(3,.00015)])
   dens=np.r_[np.full(3,.004),np.full(3,.0004)]
   measured_past=np.array([increment(j)+bias*.1+rng.normal(0,np.sqrt(.1)*dens) for j in range(frame-5,frame)])
   cloud=scan(meshes[(mesh,level)],truth,increment(frame)/.1,seed*100,frame*.1,1024,mt,mR,deskew_velocity=measured_past.mean(0)/.1)['xyz'].astype(float)
   if noise>1:cloud+=rng.normal(0,.025*np.sqrt(noise**2-1),cloud.shape)
   prior=JointState(truth[:3]+rng.normal(0,sd,3),exp(rng.normal(0,.006,3))@exp(truth[3:]),np.zeros(6),np.zeros(3),np.eye(3),initial_cov(sd))
   future=route[frame:frame+41]
   inc=np.array([increment(j)+bias*.1+rng.normal(0,np.sqrt(.1)*dens) for j in range(frame,frame+40)])
   cpu0=time.process_time_ns();wall0=time.perf_counter_ns()
   solver=CheckpointICP(meshes[(mesh,0)].prior,cloud,prior,mi);states=[prior.copy()];trace=[]
   while not solver.done:
    post,stats,feature=solver.advance();states.append(post.copy())
    trace.append(dict(**stats,feature=feature.tolist(),cpu_total_s=(time.process_time_ns()-cpu0)*1e-9,wall_total_s=(time.perf_counter_ns()-wall0)*1e-9))
   solver_cpu=(time.process_time_ns()-cpu0)*1e-9
   final=states[-1] if trace[-1]['accepted'] else prior
   # Final-only equivalence check uses the independently implemented old solver.
   ref,rs,_,_=register(meshes[(mesh,0)].prior,cloud,prior,'converged',cpu_limit=1.)
   delta=float(np.max(np.abs(final.delta(ref))));covdelta=float(np.max(np.abs(final.P-ref.P)))
   assert delta<1e-8 and covdelta<1e-8
   states.append(final.copy())
   errors,rot,prop_cost=trajectories(states,future,inc,mt,mR)
   row=dict(phase=phase,seed=seed,mesh=mesh,level=level,noise=noise,sd=sd,frame=frame,npoints=len(cloud),
    trace=trace,cpu_s=solver_cpu,reference_cpu_s=rs['cpu_s'],state_delta=delta,covariance_delta=covdelta,
    error=errors.tolist(),rotation_error=rot.tolist(),propagation_primitive_cpu_s=prop_cost[0],
    provenance='NEW_GEOMETRIC_SIMULATION')
   np.savez_compressed(INPUT/f'{seed}.npz',cloud=cloud,future_truth=future,increment=inc,map_t=mt,map_R=mR,
      prior_t=prior.t,prior_R=prior.R,prior_bias=prior.bias,prior_mt=prior.mt,prior_mR=prior.mR,prior_P=prior.P)
   file.write(json.dumps(row)+'\n');file.flush();count+=1
   if count%40==0:print('COLLECT',phase,count,'elapsed',round(time.perf_counter()-start,1),flush=True)
print('COLLECTION COMPLETE',flush=True)
