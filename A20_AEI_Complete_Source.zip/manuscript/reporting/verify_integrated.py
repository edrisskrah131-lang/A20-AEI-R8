"""Independent quantitative and document checks for the integrated manuscript."""
from pathlib import Path
import json,hashlib,re
import numpy as np,pandas as pd,fitz
from scipy.stats import beta
ROOT=Path(__file__).resolve().parents[1]
CASE=ROOT/'studies/decision_case_20261018';REC=ROOT/'studies/validated_recovery_20261018';REN=ROOT/'studies/physical_render_20261018'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ev=pd.read_csv(CASE/'event_validation.csv');assert len(ev)==48
computed=beta.isf(.05/48,ev.test_failures+1,256-ev.test_failures)
assert np.allclose(computed,ev.test_upper,atol=1e-12,rtol=1e-12)
selected=ev[ev.calibration_admitted_at_015]
assert len(selected)==41 and selected.test_failures.max()==7
assert abs(selected.test_upper.max()-.07456822403265874)<1e-12
sens=pd.read_csv(CASE/'sensitivity.csv')
assert sens.groupby('allowance').supported.nunique().eq(1).all()
assert sens.groupby('allowance').supported.first().tolist()==[0,18,40,41,43]
case=json.loads((CASE/'case.json').read_text());assert case['selection']['seed']==202619100
b=case['variants']['baseline']['values_in_report_units'];e=case['variants']['exposure']['values_in_report_units']
assert b['gsd_mm_per_pixel']==e['gsd_mm_per_pixel'] and np.isclose(e['blur_px']/b['blur_px'],1.5)
assert not case['exposure_change']['optical_card_retained']
summary=json.loads((REC/'outputs/summary.json').read_text());rm=pd.read_csv(REC/'outputs/repair_metrics.csv').set_index('method')
assert summary['unique_source_request_contexts']==2048 and summary['fault_scopes']==4096
assert summary['valid_repairs']==4096 and summary['rejected_repair_commands']==24576
for name in ['quarantine_repair','authoritative_snapshot','event_sourced']:
    r=rm.loc[name];assert r.recovered_scopes==3072 and r.incorrect_numerical_origin_issuances==0 and r.repaired_unique_source_request_contexts==1536
assert rm.loc['permanent_latch','recovered_scopes']==0
assert rm.loc['metadata_only_ablation','incorrect_numerical_origin_issuances']==3072
verify=json.loads((REC/'outputs/verification.json').read_text());assert verify['status']=='PASS' and verify['check_groups']>=12
assert json.loads((CASE/'independent_check.json').read_text())['status']=='PASS'
rv=json.loads((REN/'verification.json').read_text());assert rv['status']=='PASS' and rv['images_reprocessed']==72
met=pd.read_csv(REN/'outputs/metrics.csv');rs=json.loads((REN/'outputs/summary.json').read_text())
assert len(met)==72 and met.seed.nunique()==24
assert met.groupby('seed').variant.nunique().eq(3).all()
for name,g in met.groupby('variant'):
    s=rs['variants'][name]
    assert np.isclose(g.coverage.mean(),s['coverage_mean'])
    fail=(g.coverage<.8)|(g.reprojection_px>8)|(g.association_m>.008)
    assert fail.sum()==s['inherited_association_failures']
    assert np.isclose(g.association_m.median(),s['association_m'])
fig=ROOT/'paper/figures/visual';qa=json.loads((fig/'integrated_canvas_qa.json').read_text())
assert len(qa)==6 and all(not x['text_outside_canvas'] for x in qa)
provenance=json.loads((fig/'integrated_figure_provenance.json').read_text())
for rel,h in provenance['sources'].items():assert sha(ROOT/rel)==h,rel
assert provenance['controlled_gallery_seed']==202619100
for kind,paint in [('metal',False),('paint',True)]:
    expected=int(met[(met.variant=='baseline')&(met.painted==paint)].seed.min())
    assert provenance[kind+'_gallery_seed']==expected
main=fitz.open(ROOT/'paper/main.pdf');supp=fitz.open(ROOT/'paper/supplement.pdf')
text=' '.join(p.get_text() for p in main);flat=re.sub(r'\s+',' ',text)
for required in ['0.07457','0.272','0.080','1,536','3,072','24,576','0.02','Validity of calibration-selected services','authenticated repair','1.3 stops','72 images']:
    assert required in flat,required
assert re.findall(r'Figure (\d+):',text)==[str(i) for i in range(1,9)]
all_supp=' '.join(p.get_text() for p in supp)
assert 'Independent risk checks, validated repair and geometric rendering' in all_supp
assert '0.074568224' in all_supp and '53,248' in all_supp
assert 'Evidence scope, data provenance and declarations' in all_supp
for name in ['main','supplement']:
    log=(ROOT/'paper'/f'{name}.log').read_text()
    assert not any(x in log for x in ['undefined references','Citation','Overfull','LaTeX Error','multiply defined']),name
result=dict(status='PASS',main_pages=len(main),supplement_pages=len(supp),main_figures=8,heldout_programs=48,admitted_programs=41,heldout_upper_max=float(selected.test_upper.max()),recovered_unique_source_request_pairs=1536,rendered_transfer_scenes=24,rendered_images=72,independent_recovery_check_groups=verify['check_groups'],provenance_files=len(provenance['sources']),canvas='PASS')
(ROOT/'audits/integrated_qa.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
