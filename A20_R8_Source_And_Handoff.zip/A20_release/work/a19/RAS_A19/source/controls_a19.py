"""Audit controls fixed before their trajectory outcomes are generated.

No refitting of the A18 controller. Includes every constituent action, two
deterministic cascades, slower Full scheduling, and a fixed-policy cache removal.
"""
from pathlib import Path
import json,pickle,hashlib,itertools
from time import process_time_ns,perf_counter_ns
import numpy as np
import pandas as pd
from scipy.spatial.transform import Rotation
from prospective import ROOT,ACTIONS,PRICE,context,Mesh,JointState,propagate,exp
from rcp.core import register
from reuse import dispatch,realized

def freeze():
    cases=json.loads((ROOT/'protocol_missions.json').read_text())['cases']
    tasks=[]
    for c in cases:
        modes=['always_tempered','cascade_cf','full_4s','joint_nocache']
        modes+=['always_strict'] if c['mesh']=='B767' else ['always_converged']
        for mode in modes:tasks.append(dict(case=c,mode=mode))
    d=dict(purpose='Strong constituent controls and fixed-policy reuse attribution after A18 review',
        retrospective_status='Control families specified after reading A18; no A18 model is refit.',
        primary_price=.3,budget_ratio=1.,tasks=tasks,execution_order_seed=191017,
        geometric_aliases={'B767/always_converged':'A18 Coarse always dispatches Converged',
            'C172/always_strict':'A18 Coarse always dispatches Strict',
            'C172/cascade_sc':'A18 Reuse-DP exactly follows Strict acceptance then Converged',
            'B767/joint':'A18 Reuse-DP always dispatches Converged'},
        model_sha256=hashlib.sha256((ROOT/'data/reuse_models.pkl').read_bytes()).hexdigest(),
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        costs='Measured process CPU, same single-thread numerical backend. Cache removal retains the trained policy but reruns selected cached action.',
        feasibility='cascades and cache removal are mechanism/work controls; total reservation exceedances reported explicitly.')
    p=ROOT/'protocol_controls_A19.json'
    if p.exists():assert json.loads(p.read_text())==d
    else:p.write_text(json.dumps(d,indent=2))
    return d

def snapshots():
    rows=[json.loads(l) for l in (ROOT/'data/confirmation_cases.jsonl').read_text().splitlines()]
    models=pickle.load(open(ROOT/'data/reuse_models.pkl','rb'));records=[]
    for row in rows:
        m=models[(row['mesh'],row['context'],1.,.3,'joint')]
        _,ja,jpath,jcpu=realized(row,m,'joint')
        choices=[('always_'+ACTIONS[a],a,[],float(row['cpu'][a])) for a in range(5)]
        choices+=[('cascade_sc',1 if row['accepted'][1] else 3,[0],row['cpu'][1]+(0 if row['accepted'][1] else row['cpu'][3])),
                  ('cascade_cf',3 if row['accepted'][3] else 4,[2],row['cpu'][3]+(0 if row['accepted'][3] else row['cpu'][4])),
                  ('joint_nocache',ja,jpath,jcpu+(row['cpu'][ja] if ja-1 in jpath else 0))]
        for method,a,path,cpu in choices:
            L=row['losses'][a]-PRICE*row['cpu'][a]
            charges=sum(m['costs'][q+1] for q in path)
            if a-1 not in path or method=='joint_nocache':charges+=m['costs'][a]
            records.append(dict(mesh=row['mesh'],seed=row['seed'],level=row['level'],noise=row['noise'],context=row['context'],
                method=method,action=a,pose_loss=L,cpu_ms=cpu*1000,loss=L+.3*cpu,
                nominal_feasible=charges<=m['budget'],probes=len(path)))
    df=pd.DataFrame(records);df.to_csv(ROOT/'data/control_snapshots.csv',index=False)
    print(df.groupby(['mesh','method'])[['pose_loss','cpu_ms','loss','nominal_feasible']].mean().to_string(),flush=True)

def run(c,mode,models):
    inp=ROOT/'data/missions'/f"{c['mesh']}_mission{c['replicate']}"
    out=ROOT/'data/controls'/inp.name;out.mkdir(parents=True,exist_ok=True)
    file=out/(mode+'.json')
    if file.exists():return json.loads(file.read_text())['result']
    z=np.load(inp/'inputs.npz');truth=z['truth'];increments=z['increment'];mt=z['map_t'];mR=exp(z['map_rot'])
    clouds={int(frame):z['xyz'][z['offsets'][i]:z['offsets'][i+1]] for i,frame in enumerate(z['frames'])}
    init=np.load(inp/'initial.npz');s=JointState(*(init[k] for k in ['t','R','bias','mt','mR','P']))
    mesh=Mesh(ROOT/f"meshes/{c['mesh']}/airframe_mesh.npz")
    xyz=[];rp=[];rr=[];jobs=[];pending=None;pcpu=wcpu=rcpu=0.;accepted=0
    for frame in range(len(truth)):
        if frame:
            t=process_time_ns();s=propagate(s,.1,increments[frame]);pcpu+=(process_time_ns()-t)*1e-9
        if pending is not None and frame>=pending['delivery']:
            if pending['accepted']:
                t=process_time_ns();post=pending['post']
                for j in range(pending['source']+1,frame+1):post=propagate(post,.1,increments[j])
                s=post;rcpu+=(process_time_ns()-t)*1e-9;accepted+=1
            pending=None
        if frame in clouds and frame>0 and pending is None and (mode!='full_4s' or frame%40==0):
            model=models[(c['mesh'],context(s),1.,.3,'joint')];source=s.copy();cache={}
            begin=process_time_ns();wall=perf_counter_ns()
            def probe(q):
                a=q+1;post,stats,_,_=register(mesh.prior,clouds[frame],source,ACTIONS[a]);cache[a]=(post,stats)
                return stats['accepted']
            if mode.startswith('always_'):action=ACTIONS.index(mode[7:]);path=[]
            elif mode=='full_4s':action=4;path=[]
            elif mode=='cascade_cf':action=3 if probe(2) else 4;path=[2]
            elif mode=='joint_nocache':action,path=dispatch(model,'joint',probe)
            else:raise ValueError(mode)
            rerun=mode=='joint_nocache' and action in cache
            if action==0:post=source;ok=False
            elif action in cache and not rerun:post,stats=cache[action];ok=stats['accepted']
            else:post,stats,_,_=register(mesh.prior,clouds[frame],source,ACTIONS[action]);ok=stats['accepted']
            cpu=(process_time_ns()-begin)*1e-9;wall_s=(perf_counter_ns()-wall)*1e-9;wcpu+=cpu
            delay=max(1,int(np.ceil(wall_s/.1)))
            reserved=sum(model['costs'][q+1] for q in path)+(model['costs'][action] if action not in cache or rerun else 0)
            pending=dict(post=post,accepted=ok,source=frame,delivery=frame+delay)
            jobs.append(dict(frame=frame,action=action,path=path,accepted=bool(ok),cpu_s=cpu,wall_s=wall_s,
                budget_s=model['budget']*1e-5,reserved_s=float(reserved)*1e-5,nominal_feasible=reserved<=model['budget'],
                overrun=cpu>model['budget']*1e-5,delivery_frame=frame+delay,cache_hit=action in cache and not rerun,
                recomputed=rerun,context=context(source)))
        xyz.append(s.t.copy());rp.append((s.t-s.mt)@s.mR);rr.append(s.mR.T@s.R)
    # Vectorized evaluation is outside every estimator CPU ledger.
    pp=(truth[:,:3]-mt)@mR;truthR=np.einsum('ij,njk->nik',mR.T,Rotation.from_rotvec(truth[:,3:]).as_matrix())
    pe=np.linalg.norm(np.asarray(rp)-pp,axis=1)
    re=np.linalg.norm(Rotation.from_matrix(np.einsum('nij,nkj->nik',np.asarray(rr),truthR)).as_rotvec(),axis=1)
    trace=np.c_[np.arange(len(truth))*.1,np.asarray(xyz),pe,re]
    result=dict(mesh=c['mesh'],replicate=c['replicate'],level=c['level'],method=mode,duration_s=len(truth)*.1,
        rmse_m=float(np.sqrt(np.mean(pe**2))),p95_m=float(np.quantile(pe,.95)),max_m=float(pe.max()),
        rotation_rmse_deg=float(np.rad2deg(np.sqrt(np.mean(re**2)))),cpu_s=pcpu+wcpu+rcpu,
        correction_cpu_s=wcpu,propagation_cpu_s=pcpu,replay_cpu_s=rcpu,initial_cpu_s=float(init['cpu']),
        probes=sum(len(j['path']) for j in jobs),cache_hits=sum(j['cache_hit'] for j in jobs),
        calls=len(jobs),accepted=accepted,overruns=sum(j['overrun'] for j in jobs),
        infeasible_reservations=sum(not j['nominal_feasible'] for j in jobs))
    if mode=='joint_nocache':
        original=json.loads((inp/'joint_r1.json').read_text());original_trace=np.load(inp/'joint_r1.npz')['trace']
        result['same_decision_paths']=all((a['frame'],a['action'],a['path'])==(b['frame'],b['action'],b['path']) for a,b in zip(jobs,original['jobs'])) and len(jobs)==len(original['jobs'])
        result['max_trace_error_difference']=float(np.max(np.abs(trace[:,4:]-original_trace[:,4:])))
    np.savez_compressed(file.with_suffix('.npz'),trace=trace)
    file.write_text(json.dumps(dict(result=result,jobs=jobs),indent=2,default=lambda v:v.item() if isinstance(v,np.generic) else str(v)))
    print('CONTROL',c['mesh'],c['replicate'],mode,'RMSE',round(result['rmse_m'],6),'CPU',round(result['cpu_s'],3),flush=True)
    return result

def main():
    p=freeze();snapshots();models=pickle.load(open(ROOT/'data/reuse_models.pkl','rb'))
    tasks=p['tasks'];np.random.default_rng(p['execution_order_seed']).shuffle(tasks);results=[]
    for t in tasks:
        results.append(run(t['case'],t['mode'],models));pd.DataFrame(results).to_csv(ROOT/'data/control_missions.csv',index=False)
    print('CONTROLS COMPLETE',len(results),flush=True)

if __name__=='__main__':main()
