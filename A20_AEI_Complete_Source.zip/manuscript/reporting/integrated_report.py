"""Generate the integrated article from executed, separately identified studies."""
from pathlib import Path
import json, sys, hashlib
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
SEC=ROOT/'paper/sections'; FIG=ROOT/'paper/figures/visual'
LIFE=ROOT/'studies/lifecycle_20261018'; OUT=LIFE/'outputs'
CASE=ROOT/'studies/decision_case_20261018'
REPAIR=ROOT/'studies/validated_recovery_20261018'
RENDER=ROOT/'studies/physical_render_20261018'
import visual_revision as style
style.QA.clear(); save=style.save
BLUE,TEAL,ORANGE,RED,INK,MUTED,LIGHT=style.BLUE,style.TEAL,style.ORANGE,style.RED,style.INK,style.MUTED,style.LIGHT
sys.path.insert(0,str(LIFE))
from imaging import Pipeline,draw,configuration
from evidence import REQUESTS,METHODS
case=json.loads((CASE/'case.json').read_text())
validation=json.loads((CASE/'validation_summary.json').read_text())
rec=json.loads((REPAIR/'outputs/summary.json').read_text())
render=json.loads((RENDER/'outputs/summary.json').read_text())
protocol=json.loads((RENDER/'protocol.json').read_text())
assert render['sources']==24 and render['rendered_images']==72
metrics=pd.read_csv(RENDER/'outputs/metrics.csv')
assert metrics.groupby('seed').size().eq(3).all()
cost=pd.read_csv(OUT/'catalogue_cost.csv').set_index('method')
timing=pd.read_csv(OUT/'catalogue_timing.csv').set_index('method')
runtime=pd.read_csv(OUT/'pipeline_timing.csv')
quality=pd.read_csv(OUT/'quality_summary.csv').set_index(['phase','variant'])
oldsummary=json.loads((OUT/'summary.json').read_text())
recovery=pd.read_csv(REPAIR/'outputs/repair_metrics.csv').set_index('method')
sensitivity=pd.read_csv(CASE/'sensitivity.csv')
ev=pd.read_csv(CASE/'event_validation.csv')
sources={}
def track(path):
    sources[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
    return path
for directory in [OUT,CASE,REPAIR/'outputs',RENDER/'outputs']:
    for p in directory.glob('*'):
        if p.is_file() and p.suffix in ('.json','.csv'):track(p)
def write(name,text): (SEC/(name+'.tex')).write_text(text+'\n')
base=case['variants']['baseline']; exp=case['variants']['exposure']
bval=base['values_in_report_units']; evals=exp['values_in_report_units']
bu=base['requests']['complete']['exact_event_evidence']['calibration_upper']
eu=exp['requests']['complete']['exact_event_evidence']['calibration_upper']
ru=exp['requests']['complete_relaxed']['exact_event_evidence']['calibration_upper']

# Numerical example: the source is fixed by ascending held-out seed, not outcome.
write('integrated_case',f'''For the first held-out source, geometric sampling remains {bval['gsd_mm_per_pixel']:.3f}~mm/pixel after a 50\\% exposure increase, while blur changes from {bval['blur_px']:.3f} to {evals['blur_px']:.3f} pixels. This particular image satisfies the complete quality predicate in both configurations. Across the calibration population, however, the strict complete-service upper bound changes from {bu:.3f} to {eu:.3f}, exceeding the allowance of 0.15. The relaxed exact event has upper bound {ru:.3f} and remains admissible. Thus a good individual output and support for a producer over its operating population answer different engineering questions.''')
fig=plt.figure(figsize=(6.9,3.9)); ax=fig.add_axes([.025,.04,.95,.90]);ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
def card(x,y,w,h,title,body,color):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.008,rounding_size=.015',fc='white',ec=color,lw=1.1))
    ax.text(x+.018,y+h-.04,title,color=color,weight='bold',fontsize=7.5,va='top')
    ax.text(x+.018,y+h-.125,body,color=INK,fontsize=7.1,va='top',linespacing=1.4)
ax.text(.01,.97,'a   One source, three evidence decisions',fontsize=8.6,weight='bold',va='top')
card(.02,.52,.27,.34,'BASELINE',f'Sampling  {bval["gsd_mm_per_pixel"]:.3f} mm/px\nBlur  {bval["blur_px"]:.3f} px\nComplete  U = {bu:.3f}  ·  admit',BLUE)
card(.365,.52,.27,.34,'EXPOSURE +50%',f'Sampling  {evals["gsd_mm_per_pixel"]:.3f} mm/px\nBlur  {evals["blur_px"]:.3f} px\nComplete  U = {eu:.3f}  ·  refuse',ORANGE)
card(.71,.52,.27,.34,'RELAXED REQUIREMENT',f'Same updated producer\nExact-event fallback\nComplete+  U = {ru:.3f}  ·  admit',TEAL)
style.arrow(ax,(.30,.69),(.35,.69));style.arrow(ax,(.645,.69),(.70,.69))
ax.text(.01,.41,'b   Output provenance governs attachment and recovery',fontsize=8.6,weight='bold')
states=[('Current output','Version 1',BLUE),('Stale attachment','Quarantine',RED),('Validated repair','Revision 2',TEAL),('Service resumes','History retained',TEAL)]
for j,(title,body,col) in enumerate(states):
    x=.025+j*.25;card(x,.095,.20,.22,title,body,col)
    if j<3:style.arrow(ax,(x+.21,.20),(x+.24,.20))
ax.text(.025,.005,'Selected image passes both predicates; population admission uses the 256-scene calibration records.',fontsize=6.8,color=MUTED)
save(fig,'30_inspection_journey')

# Full request thresholds in main text.
rows=[r'\begin{table}[!htbp]\centering\small',r'\caption{Predefined capture-to-CAD requests. GSD is in mm/pixel, blur and residual in pixels, coverage in percent and mapping in mm. A dash denotes an unconstrained quantity.}\label{tab:requests}',r'\begin{tabular}{@{}lrrrrr@{}}\toprule Request & GSD $\le$ & Blur $\le$ & Coverage $\ge$ & Residual $\le$ & Mapping $\le$\\\midrule']
for name,spec in REQUESTS.items():
    vals=[]
    for key in ['gsd_m','blur_px','coverage','reprojection_px','association_m']:
        value=spec.get(key,[None,None])[0 if key=='coverage' else 1]
        scale=1000 if key.endswith('_m') else 100 if key=='coverage' else 1
        vals.append('---' if value is None else f'{value*scale:g}')
    rows.append(name.replace('_relaxed','+').capitalize()+' & '+' & '.join(vals)+r'\\')
rows.append(r'\bottomrule\end{tabular}\end{table}');write('integrated_requests','\n'.join(rows))

write('integrated_render_design',r'''A separate Blender 4.3.2 Cycles study generates 24 independently seeded panels, each with baseline, exposure-gain and reduced-illumination configurations. Curved panel meshes, overlapping joints, shallow three-dimensional fastener heads and countersink rings form the surface. Painted and metallic materials use sampled roughness and surface variation; three area lights provide diffuse and reflected illumination. Four development seeds establish rendering settings before the held-out sources are generated.

The renderer produces $768\times576$ images with at most 32 samples per pixel, adaptive sampling threshold 0.01 and no denoising. The gain update adds 1.3 stops; the illumination update scales light and world radiance by 0.1. The camera is static, so this gain intervention changes brightness without a shutter-motion model. All 72 images pass through the unchanged contrast detector and pose estimator. An independent Blender camera projection is checked against the numerical projector. Physical sites enter evaluation after matching and fitting. This renderer defines a separate transfer population; its quality outcomes are evaluated directly.''')

# Show original controlled pixels and path-traced pixels, with unaltered color values.
seed=int(case['selection']['seed']);pipe=Pipeline(draw(seed))
controlled=[]
for variant in ['baseline','exposure']:
    pipe.evaluate(configuration(variant));controlled.append(pipe.image(configuration(variant)))
metal=int(metrics.query('variant=="baseline" and not painted').seed.min())
paint=int(metrics.query('variant=="baseline" and painted').seed.min())
examples=[('Controlled raster',controlled[0]['rgb'],None),('Geometric metal panel',np.asarray(Image.open(track(RENDER/f'outputs/test/{metal}_baseline.png'))),metal),('Geometric painted panel',np.asarray(Image.open(track(RENDER/f'outputs/test/{paint}_baseline.png'))),paint)]
fig,axs=plt.subplots(2,3,figsize=(6.9,4.1));fig.subplots_adjust(left=.025,right=.99,bottom=.07,top=.93,wspace=.06,hspace=.21)
for j,(title,rgb,rseed) in enumerate(examples):
    a=axs[0,j];a.imshow(rgb);a.axis('off');a.set_title(chr(97+j)+'   '+title,loc='left',fontsize=7.6)
    if rseed is None:
        z=controlled[0];pred=z['predicted'];idx=z['matched_indices'];centers=z['matched_centers'];height,width=rgb.shape[:2]
    else:
        z=np.load(track(RENDER/f'outputs/{rseed}_baseline_correspondences.npz'));pred=z['predicted'];idx=z['matched_indices'];centers=z['matched_centers'];height,width=rgb.shape[:2]
    assert len(idx)>0
    k=int(np.argmin(np.linalg.norm(pred[idx],axis=1)));loc=pred[idx[k]]+[width/2,height/2];decoded=centers[k]+[width/2,height/2]
    a=axs[1,j];a.imshow(rgb,extent=(0,width,height,0),interpolation='nearest');a.set(xlim=(loc[0]-23,loc[0]+23),ylim=(loc[1]+23,loc[1]-23));a.scatter(*loc,s=55,c=BLUE,marker='+',lw=1.2);a.scatter(*decoded,s=60,facecolors='none',edgecolors=ORANGE,lw=1.1);a.axis('off');a.set_title(chr(100+j)+'   Pixel / CAD correspondence',loc='left',fontsize=7.3)
    a.plot([loc[0]-18,loc[0]-10],[loc[1]+17]*2,c='white',lw=1.4);a.text(loc[0]-14,loc[1]+14,'8 px',ha='center',fontsize=6.8,color='white')
fig.text(.025,.015,'Blue: prior CAD projection. Orange: extracted image center. Full images and geometry are archived.',fontsize=6.8,color=MUTED);save(fig,'31_actual_inputs')

# Make cost attribution a single figure instead of several small counting plots.
fig,axs=plt.subplots(1,2,figsize=(6.9,2.9));fig.subplots_adjust(left=.10,right=.98,bottom=.22,top=.86,wspace=.38)
labels=['Whole','DAG','Contract','Rules'];cols=[ORANGE,BLUE,TEAL,INK];methods=list(METHODS)
a=axs[0];vv=cost.loc[methods,'record_evaluations'].to_numpy();a.bar(range(4),vv,color=cols,width=.58)
for j,v in enumerate(vv):a.text(j,v+200,f'{v:,}',ha='center',fontsize=7.2)
a.set_xticks(range(4),labels);a.set(ylabel='Calibration record evaluations',ylim=(0,14300));a.set_title('a   Evidence construction',loc='left');style.clean(a)
cpu=runtime.groupby('method').cpu_s.sum();a=axs[1];vv=cpu.reindex(methods).to_numpy();a.bar(range(4),vv,color=cols,width=.58)
for j,v in enumerate(vv):a.text(j,v+2.8,f'{v:.1f}',ha='center',fontsize=7.2)
a.set_xticks(range(4),labels);a.set(ylabel='Measured source-renewal CPU (s)',ylim=(0,219));a.set_title('b   Numerical stage execution',loc='left');style.clean(a)
fig.text(.10,.035,'All complete routes admit 41 / 48 contexts. Numerical stage reuse is shared by the three DAG-based methods.',fontsize=6.6,color=MUTED);save(fig,'32_renewal_work')

# Recoverability expressed as a state trajectory and independently counted outcomes.
trace=json.loads((REPAIR/'outputs/example_trace.json').read_text())['examples']['complete_relaxed/stale_producer_output']['trace']
selected=['baseline_registered','exposure_registered','wrong_attachment','correct_retry_without_repair','repair_wrong_hash','repair_valid','repair_duplicate_after_commit','post_repair_request']
positions={x['step']:x for x in trace}
fig,axs=plt.subplots(1,2,figsize=(6.9,3.45),gridspec_kw={'width_ratios':[1.2,1]});fig.subplots_adjust(left=.085,right=.98,bottom=.34,top=.86,wspace=.65)
a=axs[0];xx=np.arange(len(selected));v=[int(positions[s]['quarantine_repair']) for s in selected];old=[int(positions[s]['permanent_latch']) for s in selected]
a.step(xx,v,where='mid',c=TEAL,lw=1.8,label='Validated repair');a.plot(xx,v,'o',c=TEAL,ms=4);a.plot(xx,old,'x--',c=ORANGE,ms=5,label='Permanent latch')
a.set_xticks(xx,['Initial','Update','Mismatch','Retry','Bad digest','Repair','Duplicate','Resume'],rotation=42,ha='right',fontsize=8);a.set_yticks([0,1],['Refuse','Issue']);a.set_ylim(-.18,1.35);a.legend(loc='upper center',fontsize=7.5);a.set_title('a   Same source, corrected binding',loc='left');style.clean(a)
a=axs[1];rows=['permanent_latch','authoritative_snapshot','quarantine_repair','event_sourced'];rv=recovery.loc[rows,'recovered_scopes'].to_numpy();a.barh(range(4),rv,color=[ORANGE,BLUE,TEAL,INK],height=.55)
for j,v in enumerate(rv):a.text(v+45,j,f'{int(v):,}',va='center',fontsize=8)
a.set_yticks(range(4),['Permanent latch','Registry snapshot','Validated repair','Event log'],fontsize=8);a.invert_yaxis();a.set(xlim=(0,3700),xlabel='Recovered / 3,072 eligible scenarios');a.set_title('b   Eligible service recovery',loc='left');a.grid(axis='x',color=LIGHT,lw=.7);a.set_axisbelow(True)
fig.text(.07,.025,'1,536 source/request pairs × two faults. Recovery implementations reject wrong numerical origins.',fontsize=7.5,color=MUTED);save(fig,'33_validated_recovery')

# All independently rendered scenes, including failures, remain visible.
variants=['baseline','exposure','lighting'];vnames=['Baseline','Gain +1.3 stops','Light ×0.1'];colors=[BLUE,ORANGE,TEAL]
fig,axs=plt.subplots(1,2,figsize=(6.9,3.1));fig.subplots_adjust(left=.10,right=.98,bottom=.24,top=.86,wspace=.43)
for j,v in enumerate(variants):
    g=metrics.query('variant==@v').sort_values('seed');x=j+np.linspace(-.15,.15,len(g))
    axs[0].scatter(x,100*g.coverage,s=16,c=colors[j],alpha=.7,edgecolor='none')
    axs[1].scatter(x,1000*g.association_m,s=16,c=colors[j],alpha=.7,edgecolor='none')
    for ax,vals in [(axs[0],100*g.coverage),(axs[1],1000*g.association_m)]:ax.plot([j-.20,j+.20],[np.median(vals)]*2,c=INK,lw=1.5)
for a in axs:a.set_xticks(range(3),vnames,rotation=12,fontsize=7);style.clean(a)
axs[0].axhline(80,c=MUTED,ls=':',lw=.8);axs[0].set(ylabel='Correct-address coverage (%)',ylim=(-3,104));axs[0].set_title('a   Pixel extraction under material changes',loc='left')
axs[1].axhline(8,c=MUTED,ls=':',lw=.8);axs[1].set(ylabel='Maximum mapping error (mm)');axs[1].set_title('b   CAD mapping on physical geometry',loc='left')
fig.text(.10,.025,'24 independent panels × three configurations. Each point is one rendered scene; horizontal lines show medians.',fontsize=6.7,color=MUTED);save(fig,'34_render_transfer')

fig,axs=plt.subplots(1,2,figsize=(6.9,2.9));fig.subplots_adjust(left=.10,right=.98,bottom=.22,top=.86,wspace=.38)
for m,col,mark in zip(['Whole renewal','DAG exact cache','Contract + fallback'],[ORANGE,BLUE,TEAL],['s','^','o']):
    g=sensitivity.query('method==@m').sort_values('allowance');axs[1].plot(g.allowance,g.record_evaluations,marker=mark,c=col,label=m.replace(' renewal','').replace(' cache',''))
g=sensitivity.query('method=="Contract + fallback"').sort_values('allowance');axs[0].plot(g.allowance,g.supported,'o-',c=TEAL)
for r in g.itertuples():axs[0].annotate(str(r.supported),(r.allowance,r.supported),xytext=(0,5),textcoords='offset points',ha='center',fontsize=7)
axs[0].set(ylabel='Supported contexts / 48',ylim=(0,49));axs[0].set_title('a   Identical support for complete methods',loc='left')
axs[1].set(ylabel='Calibration record evaluations');axs[1].set_title('b   Evidence work across allowances',loc='left');axs[1].legend(fontsize=6.4)
for a in axs:a.set_xlabel('Scene-level risk allowance');style.clean(a)
save(fig,'35_allowance_sensitivity')

write('integrated_recovery_design',r'''The recovery study replays the 256 held-out image sources under eight requests and two binding faults, yielding 2,048 distinct source/request contexts and 4,096 fault scenarios. One fault attaches a stored baseline output after the exposure update; the other attaches another source's stored output. All substituted records differ numerically from the intended output. The authenticated payload contains the archive locator, fitted residual and matched/planned counts. Physical mapping and coverage labels are reserved for independent scoring.

Each scenario follows 13 steps: baseline and updated registration, wrong attachment, retry, unregistered alias, five malformed repair attempts, valid repair, duplicate repair and resumed request. Repair evidence checks the expected revision, active producer, source, payload digest and calibration identity. The comparator derives numerical origin from the immutable archive records. Permanent latch, authoritative snapshot, validated repair, independent event-log replay and a metadata-only ablation receive the same records. Recovery availability counts only requests admitted for the updated producer.''')

q=quality.loc['test','baseline'];hard=quality.loc['stress','baseline'];rbase=render['variants']['baseline'];rgain=render['variants']['exposure'];rlight=render['variants']['lighting']
parts=[r'\subsection{Calibrated services and independent held-out risk}',
f'''The controlled held-out images have mean correct-address coverage {q.coverage_mean*100:.2f}\\%. Refinement reduces median prior translation error from {q.prior_median_mm:.3f} to {q.pose_median_mm:.3f}~mm. Median fitted residual is {q.residual_median:.3f} pixel, and median and 95th-percentile mapping errors are {q.mapping_median_mm:.3f} and {q.mapping_p95_mm:.3f}~mm.''',
'''At allowance 0.15, calibration admits 41 of 48 producer/request contexts (Fig.~\\ref{fig:support}). Exposure removes strict acquisition and complete-service support; lower light additionally affects association. All complete methods give the same decisions. Anchor-only routing admits 38 contexts. Exact fallback restores relaxed acquisition and complete service after exposure, and relaxed acquisition under lower light.''',
f'''The separate held-out check evaluates all 48 fixed programs on all 256 test scenes. Among the 41 calibration-admitted services, the largest test failure count is {validation['selected_max_test_failures']}/256. Their simultaneous one-sided test bounds are all at most {validation['selected_test_upper_max']:.5f}, using a separate 95\\% family statement with allocation $0.05/48$. These checks use the complete test population and leave the selected plans unchanged.''',
'''The allowance sweep admits 0, 18, 40, 41 and 43 contexts at 0.02, 0.05, 0.10, 0.15 and 0.20, respectively. Every complete method preserves this support. The Supplementary Material reports the corresponding construction work and all held-out bounds.''',
r'''\begin{figure}[!htbp]\centering\includegraphics[width=\linewidth]{visual/21_lifecycle_support.pdf}
\caption{Calibrated event bounds for the controlled population. Green cells satisfy the primary allowance 0.15. The independent held-out check evaluates the same fixed programs after plan selection.}\label{fig:support}\end{figure}''',
r'\subsection{Renewal work and its attribution}',
'''Whole renewal constructs 48 cards; exact dependency caching constructs 42; containment with fallback and the independent rule implementation each construct 26. Their record evaluations are 12,288, 10,752 and 6,656, respectively. Containment reduces this work by 38.10\\% relative to exact caching while preserving all 41 supported contexts. Catalogue CPU is 4.419~ms for whole renewal, 4.290~ms for DAG exact, 2.725~ms for the compiled contract and 4.777~ms for the interpreted rules. The contract's absolute preparation saving over exact caching is 1.565~ms at this scale.''',
f'''The 640 paired source-renewal cases consume {cpu['Whole renewal']:.3f}~s of process CPU under whole renewal and {cpu['DAG exact cache']:.3f}~s under dependency caching, a {oldsummary['dag_cpu_saving_percent']:.2f}\\% reduction. A paired bootstrap over the 16 timing inputs gives a 95\\% interval of {oldsummary['dag_cpu_saving_paired_bootstrap_ci'][0]:.2f}--{oldsummary['dag_cpu_saving_paired_bootstrap_ci'][1]:.2f}\\%. Contract and rule paths consume {cpu['Contract + fallback']:.3f} and {cpu['Rules + containment']:.3f}~s. Their numerical outputs and stage counts agree with the DAG baseline. Figure~\\ref{{fig:renewal}} separates this shared numerical benefit from evidence preparation.''',
r'''\begin{figure}[!htbp]\centering\includegraphics[width=\linewidth]{visual/32_renewal_work.pdf}
\caption{Two measured renewal costs. (a) Evidence construction on stored calibration records. (b) Actual numerical execution over 640 paired cases per method. Containment changes evidence work; the three dependency-based paths share numerical stage reuse.}\label{fig:renewal}\end{figure}''',
r'\subsection{Recoverable output attachment}',
'''Validated repair restores all 3,072 eligible fault scenarios, covering 1,536 distinct source/request contexts across the 256 images. The permanent latch restores none. The authoritative-snapshot and event-log implementations reproduce the validated-repair decisions exactly (Table~\\ref{tab:recovery}). The source observation is retained throughout; the repair commits the trusted updated output at a newer revision.''',
'''The three recovery implementations issue no output with an incorrect numerical origin. The metadata-only ablation issues 3,072 such outputs, identifying the role of payload and provenance validation. Across all requests, 4,096 valid repairs commit and 24,576 malformed repair commands are rejected. A successfully repaired binding remains valid when a duplicate transaction is rejected. Strict complete service under exposure remains statistically inadmissible after repair; provenance recovery does not change its event bound.''',
r'''\begin{table}[!htbp]\centering\small\caption{Output recovery on the same stored observations. Recovery denominator: 3,072 eligible scenarios. Wrong origin is checked against the archived source and producer record.}\label{tab:recovery}
\begin{tabular}{@{}lrr@{}}\toprule Method & Recovered & Wrong-origin issuances\\\midrule''']
for key,label in [('permanent_latch','Permanent latch'),('authoritative_snapshot','Authoritative snapshot'),('quarantine_repair','Validated repair'),('event_sourced','Event-log replay'),('metadata_only_ablation','Metadata-only ablation')]:
    r=recovery.loc[key];parts.append(f'{label} & {int(r.recovered_scopes):,} & {int(r.incorrect_numerical_origin_issuances):,}'+r'\\')
parts += [r'\bottomrule\end{tabular}\end{table}',r'''\begin{figure}[!htbp]\centering\includegraphics[width=\linewidth]{visual/33_validated_recovery.pdf}
\caption{Recovery changes service availability while retaining the rejected attempt. (a) The first held-out source's relaxed complete-service workflow. (b) Recoverable scenarios under matched trusted-registry information. Numerical-origin checks and protocol traces use the same stored image outputs.}\label{fig:recovery}\end{figure}''',
r'\subsection{Transfer to geometric surface rendering}',
f'''The unchanged image front end processes all 72 path-traced images. Baseline panels have mean correct-address coverage {rbase['coverage_mean']*100:.2f}\\% and median maximum mapping error {rbase['association_m']*1000:.3f}~mm. At gain +1.3 stops, mean coverage is {rgain['coverage_mean']*100:.2f}\\%; at one-tenth illumination it is {rlight['coverage_mean']*100:.2f}\\%. The inherited association predicate fails on {rbase['inherited_association_failures']}/24 baseline, {rgain['inherited_association_failures']}/24 gain and {rlight['inherited_association_failures']}/24 lower-light panels (Fig.~\\ref{{fig:render-transfer}}). Full scene-level outcomes retain every rendered input.''',
f'''Blender's independently computed camera projections agree with the numerical projector within ${render['max_independent_camera_projection_difference_px']*1e5:.1f}\\times10^{{-5}}$ pixel. The resulting comparison separates appearance-driven extraction behavior from a camera-coordinate mismatch. These transfer outcomes are scored within their own renderer population; the earlier 48-event calibration remains attached to its original producer and population.''',
r'''\begin{figure}[!htbp]\centering\includegraphics[width=\linewidth]{visual/34_render_transfer.pdf}
\caption{Image-to-CAD transfer across 24 independently rendered panels. Every scene is processed in all three configurations. The unchanged detector receives image pixels; physical CAD locations enter subsequent scoring. Dashed lines show inherited association thresholds.}\label{fig:render-transfer}\end{figure}''',
r'\subsection{Component regression and operating conditions}',
'''Conditional hidden couplings activate in 86 of 192 update/input pairs across the 64 regression inputs. Re-execution detects all 86 changes in quantities declared unaffected; all 192 clean pairs pass. The three fault classes activate on 24, 36 and 26 inputs. These checks test the declared dependency interface at component registration.''',
f'''Stronger controlled disturbances lower mean coverage to {hard.coverage_mean*100:.2f}\\% and raise the 95th-percentile mapping error to {hard.mapping_p95_mm:.3f}~mm. Strict complete-service failures rise from 4/256 nominal test scenes to 77/128 stress scenes (Fig.~\\ref{{fig:stress}}). Optical sampling remains acceptable, while occlusion, missing correspondences and CAD discrepancy affect the image-to-model task. This result identifies an operating-distribution change that requires its own evidence population.''',
r'''\begin{figure}[!htbp]\centering\includegraphics[width=\linewidth]{visual/26_lifecycle_stress.pdf}
\caption{Controlled nominal and stress populations. Each point represents one independently sampled complete scene. Stress changes missingness, occlusion, CAD discrepancy and prior error; the resulting failures are reported separately from nominal calibration.}\label{fig:stress}\end{figure}''']
write('integrated_results','\n\n'.join(parts))
write('integrated_abstract',r'''Inspection evidence must remain aligned with the requirement, computation and output it supports. We develop an executable evidence interface for CAD-guided aircraft inspection that combines typed quality requests, producer dependencies, calibrated event bounds and authenticated output recovery. Event containment reuses stronger evidence, while exact-event fallback preserves the support of direct renewal. A provenance-bound repair transaction restores a corrected output without erasing its audit history. A controlled aircraft-skin study executes 3,072 outputs from 512 independently sampled scenes. All complete methods admit 41 of 48 service contexts; independent held-out simultaneous risk bounds for these services remain below 0.075. Containment reduces evidence-record evaluations by 38.10\% relative to exact dependency caching. Measured stage caching reduces source-renewal CPU by 56.26\%, shared by the matched dependency-based implementations. Validated repair restores 1,536 distinct eligible source/request contexts that an irreversible latch blocks. A separate 72-image path-traced study tests the unchanged front end on geometric fasteners and reflective surfaces. These experiments establish an explicit workflow for retaining, renewing and recovering engineering evidence through component and output changes.''')
write('integrated_conclusion',r'''Executable evidence management connects a quality requirement to the calibrated producer and authenticated output that support it. Containment with exact fallback preserves direct-renewal support, while validated repair restores a corrected binding and retains its audit history. The controlled image study supports 41 service contexts, independently checks their held-out risks and reduces evidence-record evaluations by 38.10\%. Matched implementations separate this evidence benefit from conventional numerical caching and reproduce recovery across 1,536 eligible source/request contexts. The geometric-rendering and stress studies expose the role of appearance and operating-population changes. The resulting interface provides a concrete specification for selective renewal and recoverable evidence attachment in CAD-guided inspection.''')

(FIG/'integrated_canvas_qa.json').write_text(json.dumps(style.QA,indent=2)+'\n')
(FIG/'integrated_figure_provenance.json').write_text(json.dumps(dict(sources=sources,controlled_gallery_seed=seed,metal_gallery_seed=metal,paint_gallery_seed=paint,gallery_selection='first held-out source for each declared material category'),indent=2)+'\n')
assert len(style.QA)==6 and all(not q['text_outside_canvas'] for q in style.QA),style.QA
print(json.dumps(dict(status='PASS',figures=len(style.QA),rendered_images=len(metrics),supported=41,heldout_upper_max=validation['selected_test_upper_max']),indent=2))
