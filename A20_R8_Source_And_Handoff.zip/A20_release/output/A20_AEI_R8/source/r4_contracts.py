"""Statistical event cards and executable source/configuration applicability checks.

Checking a profile ID cannot establish distributional equality on a physical robot.
That equality is a deployment assumption recorded on, rather than inferred by, the card.
"""
import json,hashlib,copy
import numpy as np,pandas as pd
from r4_protocol import ROOT,D,PROTOCOL,sha
from checkpoint import WORK
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def frontend_hash():return digest({'collector':sha(ROOT/'source/r4_collect.py'),'sensor_frontend':sha(ROOT/'source/r4_sensor.py'),'native_sensor':sha(WORK/'work/a19/RAS_A19/source/rcp/sensor.py')})
EVENTS={'trajectory':{'threshold_m':.1,'times_s':[round(.5+.1*i,10) for i in range(36)],'failure':'any position error > threshold'},'capture':{'deadline_s':.3,'threshold_m':.1,'failure':'no positive scan-source version active at deadline after all installations and rollbacks OR position error > threshold at deadline','service':'includes receiver replay'}}
def profiles():
 out={}
 for context,meshes in [('nominal_calibration',['B767','C172']),('geometry_calibration',['ProceduralAirframe'])]:
  mesh_hashes={}
  for m in meshes:
   p=D/'geometry/world_discrepancy_0.npz' if m=='ProceduralAirframe' else WORK/f'work/a19/RAS_A19/meshes/{m}/world_discrepancy_0.npz'
   mesh_hashes[m]=sha(p)
  record={'meshes':meshes,'mesh_hashes':mesh_hashes,'prior_sd':PROTOCOL['nominal_prior_sd'],'noise':PROTOCOL['nominal_noise'],'shape_levels':[0,1,2],'generator_sha256':sha(ROOT/'source/r4_collect.py'),'sampling':'declared random mixture, not arbitrary distributions inside parameter ranges','distributional_equality':'assumed deployment-to-calibration equality; not proven by metadata'}
  record['frontend_implementation_hash']=frontend_hash()
  out[context]={'record':record,'id':digest(record)}
 return out
def check(card,request,source):
 reasons=[]
 for key in ['kind','policy_id','policy_hash','forecast_hash','event_hash','profile_id','load','queue_s','frontend_hash','installation_model','service_hash']:
  if request.get(key)!=card.get(key):reasons.append(key)
 if request.get('mesh_hash') not in card['mesh_hashes'].values():reasons.append('mesh_hash')
 if request.get('source_id')!=source['source_id'] or request.get('source_prior_seal')!=source['source_prior_seal']:reasons.append('source_lineage')
 if request.get('declared_profile_assumption') is not True:reasons.append('profile_assumption')
 if not card['certified']:reasons.append('risk_infeasible')
 allowance=request.get('risk_allowance')
 if type(allowance) not in (int,float) or not np.isfinite(allowance) or not 0<=allowance<=1:reasons.append('invalid_allowance')
 elif card['risk_upper']>allowance:reasons.append('requested_allowance')
 if card['kind']=='capture':
  assessment=request.get('assessment_s')
  if type(assessment) not in (int,float) or not np.isfinite(assessment) or abs(assessment-card['event']['deadline_s'])>1e-12:reasons.append('assessment_instant')
  elapsed=request.get('elapsed_s')
  if type(elapsed) not in (int,float) or not np.isfinite(elapsed) or elapsed<0:reasons.append('invalid_elapsed')
  elif elapsed>.3+1e-12:reasons.append('expired')
 return {'authorized':not reasons,'reasons':reasons,'risk_upper':card['risk_upper'] if not reasons else None,'status':'BOUND_VALID' if not reasons else 'PROVISIONAL_OR_REFUSED'}
def build():
 cf=pd.read_csv(D/'calibration.csv');freeze=json.loads((D/'freeze.json').read_text());ps=profiles();cards=[]
 manifest=json.loads((D/'evaluation_manifest.json').read_text())
 service={'queue_s':PROTOCOL['queue_s'],'dt_s':PROTOCOL['dt_s'],'primitive_cpu_s':manifest['step_cpu_s'],'installation_latency':manifest['installation_latency'],'receiver_replay':'all prior versions charged; replay through installation tick','numeric_executor_sha256':manifest['numeric_executor_sha256']}
 for _,r in cf.iterrows():
  p=next(p for p in freeze['policies'] if p['id']==r.policy);mh=freeze['old_model_sha256'] if p['model']=='old' else freeze['forecasts'][p['model']]['sha256'] if p['model'] else 'none'
  for event in ['trajectory','capture']:
   upper=float(r.upper_risk if event=='trajectory' else r.task_upper_risk)
   c={'id':f'{r.phase}/{r.policy}/load{r.load:g}/{event}','kind':event,'policy_id':r.policy,'policy_hash':digest({'spec':p,'implementation':freeze['policy_sha256']}),'forecast_hash':mh,'event_hash':digest(EVENTS[event]),'event':EVENTS[event],'profile_id':ps[r.phase]['id'],'profile':ps[r.phase]['record'],'mesh_hashes':ps[r.phase]['record']['mesh_hashes'],'load':float(r.load),'queue_s':.05,'frontend_hash':frontend_hash(),'installation_model':'queue plus scaled sender work and cumulative causal receiver replay, quantized 0.1s','risk_upper':upper,'allowance':.15,'n':int(r.n),'k':int(r.k if event=='trajectory' else r.task_k),'family_error':.05,'joint_family_size':240,'certified':upper<=.15}
   c.update(service_parameters=service,service_hash=digest(service))
   cards.append(c)
 (D/'event_cards.json').write_text(json.dumps(cards,indent=2))
 audit=[]
 for c in cards:
  source={'source_id':'scan/101','source_prior_seal':digest({'t':[0,0,0],'P':'immutable'})}
  req={k:c[k] for k in ['policy_id','policy_hash','forecast_hash','event_hash','profile_id','load','queue_s','frontend_hash','installation_model','service_hash']};req.update(source);req.update(mesh_hash=next(iter(c['mesh_hashes'].values())),declared_profile_assumption=True,kind=c['kind'],elapsed_s=.3,assessment_s=.3,risk_allowance=.15)
  expected=c['certified'];result=check(c,req,source);assert result['authorized']==expected
  audit.append({'card':c['id'],'case':'exact_request','expected':expected,**result})
  for key in ['kind','policy_hash','forecast_hash','event_hash','profile_id','mesh_hash','frontend_hash','installation_model','service_hash','source_prior_seal','source_id','queue_s','load']:
   bad=copy.deepcopy(req);bad[key]='incompatible';result=check(c,bad,source);assert not result['authorized'];audit.append({'card':c['id'],'case':'mismatch_'+key,'expected':False,**result})
  for name,update in [('undeclared_distribution',{'declared_profile_assumption':False}),('complete_route_profile',{'profile_id':'complete-route-distribution'}),('changed_noise_profile',{'profile_id':'noise-3-to-4'}),('changed_prior_mixture',{'profile_id':'prior-0.04-0.10'})]:
   bad=dict(req,**update);result=check(c,bad,source);assert not result['authorized'];audit.append({'card':c['id'],'case':name,'expected':False,**result})
  if c['kind']=='capture':
   for value in [None,float('nan'),.1,.2,.4,True]:
    result=check(c,dict(req,assessment_s=value),source);assert not result['authorized'];audit.append({'card':c['id'],'case':'assessment_instant','expected':False,**result})
   result=check(c,dict(req,elapsed_s=.4),source);assert not result['authorized'];audit.append({'card':c['id'],'case':'expired','expected':False,**result})
   for value in [None,float('nan'),float('inf'),-.1,True,False]:
    result=check(c,dict(req,elapsed_s=value),source);assert not result['authorized'];audit.append({'card':c['id'],'case':'invalid_elapsed','expected':False,**result})
   for kind in ['trajectory',None]:
    result=check(c,dict(req,elapsed_s=.4,kind=kind),source);assert not result['authorized'];audit.append({'card':c['id'],'case':'expired_kind_bypass','expected':False,**result})
  result=check(c,dict(req,risk_allowance=max(0.,c['risk_upper']*.5)),source);assert not result['authorized'];audit.append({'card':c['id'],'case':'stricter_allowance','expected':False,**result})
  for value in [None,float('nan'),float('inf'),-.1,True,False]:
   result=check(c,dict(req,risk_allowance=value),source);assert not result['authorized'];audit.append({'card':c['id'],'case':'invalid_allowance','expected':False,**result})
  for value in [None,'false',1,float('nan'),False]:
   result=check(c,dict(req,declared_profile_assumption=value),source);assert not result['authorized'];audit.append({'card':c['id'],'case':'invalid_profile_declaration','expected':False,**result})
 pd.DataFrame(audit).to_csv(D/'contract_audit.csv',index=False)
 report={'cards':len(cards),'certified_cards':sum(c['certified'] for c in cards),'checks':len(audit),'unexpected_authorizations':0,'checker_sha256':sha(__file__),'audit_scope':'separate metadata service, deterministic requests with illustrative source seals; not an online experiment authorization log or field reliability trial','authorization_target':'attachment of a population policy-event statement at the scheduled assessment instant, not observation execution NOW or scan-conditional risk','profile_equality':'metadata consistency and declared distribution assumptions; unknown shifts are not detected automatically'}
 (D/'contract_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
if __name__=='__main__':build()
