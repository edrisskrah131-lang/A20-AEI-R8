"""Restore the licensed, byte-preserved native dependency before running R4."""
from pathlib import Path
import ctypes,io,zipfile,subprocess,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
WORK=ROOT.parents[1]
def safe_extract(z,target):
    target=target.resolve()
    for info in z.infolist():
        dest=(target/info.filename).resolve()
        if not dest.is_relative_to(target):raise ValueError('unsafe archive member')
    z.extractall(target)
def main():
    a19=WORK/'work/a19/RAS_A19'
    if not (a19/'source/rcp/core.py').is_file():
        original=ROOT/'preserved/A20_RAS_complete.zip'
        with zipfile.ZipFile(original) as z:
            nested=z.read('A20_release/output/A20_R3_complete/preserved/A19_source_and_results.zip')
        target=WORK/'work/a19';target.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(io.BytesIO(nested)) as z:safe_extract(z,target)
    native=a19/'source/rcp/libbvh.so'
    rebuild=not native.is_file()
    if not rebuild:
        try:ctypes.CDLL(str(native))
        except OSError:rebuild=True
    if rebuild:
        subprocess.run(['g++','-O3','-std=c++17','-shared','-fPIC',
            str(a19/'source/rcp/bvh.cpp'),'-o',str(native)],check=True)
    print(json.dumps({'native_dependency':str(a19),'compiled_on_this_host':rebuild,
         'core_sha256':hashlib.sha256((a19/'source/rcp/core.py').read_bytes()).hexdigest()}))
if __name__=='__main__':main()
