"""Paired numerical producer audit and evidence-routing reanalysis.

Original cards, population observations and policy commitments are immutable.
The five source replays and point-count probes are finite implementation
diagnostics, not additional calibration/confirmation population inputs.
"""
from pathlib import Path
from collections import defaultdict
from types import SimpleNamespace
import sys, json, hashlib, time, platform
import numpy as np
import pandas as pd
from scipy.stats import beta

ROOT=Path(__file__).resolve().parent
PACKAGE=ROOT.parents[1]
OUT=ROOT/'outputs';OUT.mkdir(exist_ok=True)
SPEC=json.loads((ROOT/'protocol.json').read_text())
SHA=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(ROOT/'producer'))
from rcp.core import JointState,PriorMap,exp,propagate
from portable_mesh import PortableMesh
from camera_renderer import render,detect_fiducials
from target_metrics import target_geometry,score_image,score_association
from checkpoint import CheckpointICP
PortableMesh.library_path=(PACKAGE/'native/bvh_windows.dll' if platform.system()=='Windows' else ROOT/'producer/rcp/libbvh.so')
PortableMesh.prior_map_class=PriorMap
sys.path.insert(0,str(PACKAGE/'studies/change_recovery_20261013'))
import validate as evidence
from knowledge_compiler import verify_compiler
METRICS=tuple(evidence.tr.DEPENDENCIES)
TOL=SPEC['tolerance']
SIG=('event_id','producer_id','population_id','calibration_manifest')
VERIFY='--verify' in sys.argv

def emit(frame,name):
    if not isinstance(frame,pd.DataFrame):frame=pd.DataFrame(frame)
    if VERIFY:
        old=pd.read_csv(OUT/name)
        ignored=[c for c in ['cpu_s','wall_s','median_native_cpu_s'] if c in frame]
        pd.testing.assert_frame_equal(frame.drop(columns=ignored).reset_index(drop=True),old.drop(columns=ignored).reset_index(drop=True),check_dtype=False,check_exact=False,rtol=1e-12,atol=TOL)
    else:frame.to_csv(OUT/name,index=False)

def verify_inputs():
    for name,value in json.loads((ROOT/'freeze.json').read_text())['files'].items():
        if SHA(ROOT/name)!=value:raise ValueError('Changed frozen diagnostic input '+name)

def numeric_changed(a,b):
    if np.isfinite(a)!=np.isfinite(b):return True
    return bool(np.isfinite(a) and abs(a-b)>TOL)

def audit_transfer(before,after,changed_fields):
    observed={metric for metric in METRICS if numeric_changed(before[metric],after[metric])}
    declared={metric for metric in METRICS if set(changed_fields)&set(evidence.tr.DEPENDENCIES[metric])}
    omitted=observed-declared
    return {'status':'VETO' if omitted else 'CONSISTENT_ON_TESTED_INPUT','undeclared_quantities':sorted(omitted)}

def source_case(desc,meshes):
    seed=desc['seed'];folder=ROOT/'inputs/archives'
    meta=json.loads((folder/f'{seed}.json').read_text());z=np.load(folder/f'{seed}.npz');cam=np.load(folder/f'{seed}_camera.npz')
    m=meta['source']['mesh'];level=meta['source']['level']
    for lev in {0,level}:
        key=(m,lev)
        if key not in meshes:meshes[key]=PortableMesh(ROOT/f'inputs/meshes/{m}_{lev}.npz')
    actual=next(q for q in meta['outcomes'] if q['policy']==SPEC['fixed_policy'] and q['service']==SPEC['fixed_service'])
    active=actual['active_index'];tick=meta['capture_tick']
    state=JointState(*(z['states_'+k][active].copy() for k in ['t','R','bias','mt','mR','P']))
    for i in range(tick):state=propagate(state,.1,z['increment'][i])
    targets={'faces':cam['target_faces'],'bary':cam['target_bary'],'cad_points':cam['target_cad']}
    return meta,z,cam,meshes[m,level],meshes[m,0],state,targets,actual

def execute_camera(desc,case,edit):
    meta,z,cam,mesh,prior_mesh,state,targets,actual=case
    seed=desc['seed'];w0,h0=cam['rgb'].shape[1],cam['rgb'].shape[0]
    width,height=w0,h0;focal,exposure=1800.,.006
    fields={'unchanged':(), 'roi':('roi',),'focal':('focal_px',),'exposure':('exposure_s',),
      'decoder_disabled':('detector',),'hidden_roi_focal':('roi',),'hidden_decoder_readiness':('detector',)}[edit]
    if edit in ['roi','hidden_roi_focal']:width+=96;height+=72
    if edit=='focal':focal=2400.
    if edit=='exposure':exposure=.009
    if edit=='hidden_roi_focal':focal=1800.*width/w0
    tick=meta['capture_tick'];pose=z['future_truth'][tick];speed=meta['speed_m_s'];gimbal=cam['gimbal_R']
    geom=target_geometry(mesh,targets,pose,z['map_t'],z['map_R'],exp,focal,speed,exposure,gimbal)
    frame=render(mesh,pose,z['map_t'],z['map_R'],np.random.default_rng(seed+60000000),exp,
       width,height,focal,exposure,speed,gimbal,geom)
    detected,_=detect_fiducials(frame['rgb'],len(targets['faces']))
    if edit in ['decoder_disabled','hidden_decoder_readiness']:detected[:]=np.nan
    image=score_image(frame,geom,width,height,detected)
    association=score_association(state,targets,geom,exp,width,height,focal,gimbal,detected)
    ready=float(actual['active_index']>0)
    if edit=='hidden_decoder_readiness':ready*=float(np.isfinite(detected).any())
    clock=.0625 if desc['study']=='A' else .125
    report=max(actual['first_delivery_s'],tick*.1+.05+10*clock)
    values={**{k:image[k] for k in ['gsd_m','blur_px','coverage']},**association,
       'localization_ready':ready,'report_delay_s':report,'image_age_s':report-tick*.1}
    return values,fields,frame

def replay_audit():
    rows=[];baselines=[];scales=[];meshes={}
    for desc in SPEC['sources']:
        seed=desc['seed'];case=source_case(desc,meshes)
        meta,z,cam,mesh,prior_mesh,state,targets,actual=case
        base,_,frame=execute_camera(desc,case,'unchanged')
        for metric,value in base.items():
            old=actual[metric];old=np.inf if old is None else old
            if numeric_changed(value,old):raise AssertionError(('Archived baseline differs',seed,metric,value,old))
        assert np.array_equal(frame['rgb'],cam['rgb']),seed
        baselines.append({'seed':seed,'rgb_equal':True,'metrics_match_archive':True,
           'raw_points':len(z['raw']),'frontend_points':len(z['cloud'])})
        for edit in SPEC['interventions']:
            values,fields,after=execute_camera(desc,case,edit)
            gate=audit_transfer(base,values,fields)
            if edit.startswith('hidden_'):assert gate['status']=='VETO'
            else:assert gate['status']=='CONSISTENT_ON_TESTED_INPUT'
            for metric in METRICS:
                changed=numeric_changed(base[metric],values[metric])
                declared=bool(set(fields)&set(evidence.tr.DEPENDENCIES[metric]))
                rows.append({'seed':seed,'study':desc['study'],'edit':edit,'metric':metric,
                  'baseline':base[metric],'edited':values[metric], 'changed':changed,
                  'declared_affected':declared,'undeclared_change':changed and not declared,
                  'cpu_s':after['cpu_s'],'wall_s':after['wall_s']})
            if seed==14300000 and edit in ['roi','hidden_roi_focal','decoder_disabled']:
                if VERIFY:
                    assert np.array_equal(np.load(OUT/f'illustration_{edit}.npz')['rgb'],after['rgb'])
                else:np.savez_compressed(OUT/f'illustration_{edit}.npz',rgb=after['rgb'])
        prior=JointState(*(z['states_'+k][0].copy() for k in ['t','R','bias','mt','mR','P']))
        for requested in SPEC['registration_point_requests']:
            trial=[]
            for repeat in range(3):
                begin=time.process_time_ns()
                solver=CheckpointICP(prior_mesh.prior,z['cloud'],prior,int(meta['source']['mesh']=='C172'),points=requested)
                while not solver.done:post,stats,_=solver.advance()
                trial.append((time.process_time_ns()-begin)*1e-9)
            true=z['map_R'].T@(z['future_truth'][0,:3]-z['map_t'])
            predicted=post.mR.T@(post.t-post.mt)
            scales.append({'seed':seed,'requested_points':requested,'used_points':len(solver.points),
                'iterations':stats['iteration'],'accepted':stats['accepted'],
                'source_position_error_m':float(np.linalg.norm(predicted-true)),
                'median_native_cpu_s':float(np.median(trial)),'trials':len(trial)})
        print('NUMERICAL_PRODUCER_AUDIT',seed,flush=True)
    for m in meshes.values():m.close()
    emit(rows,'producer_reexecution.csv')
    emit(scales,'point_count_probe.csv')
    f=pd.DataFrame(rows);summary=[]
    for edit,g in f.groupby('edit',sort=False):
        summary.append({'edit':edit,'paired_sources':g.seed.nunique(),
           'undeclared_quantity_changes':int(g.undeclared_change.sum()),
           'flagged_source_pairs':int(g.groupby('seed').undeclared_change.any().sum())})
    emit(summary,'producer_audit_summary.csv')
    return {'archived_baselines':baselines,'producer_audit':summary,'point_count_probes':len(scales)}

def unique_cards(ids):
    return {tuple(c[k] for k in SIG):c for c in evidence.CARDS if c['id'] in ids}

def route_evidence():
    rows=[];seen=set()
    for q in evidence.PLANS:
        key=(q['study'],q['profile'],q['service'],q['event_id'])
        if q['method']!='DirectRecertCached' or q['allowance']!=.15 or key in seen:continue
        seen.add(key)
        base={k:q[k] for k in ['study','profile','service','task','variant','event_id','policy','status']}
        if q['status']!='AUTHORIZED':rows.append({**base,'route':'refused','direct_card':None,'hybrid_card':None});continue
        event=evidence.tr.requirement(q['task'],q['variant'])
        context=next(c['context'] for c in evidence.CARDS if c['id']==q['card'])
        direct=evidence.engine(q['study'],q['profile'],q['service'],q['policy'],event,context,'DirectRecertCached')
        anchor=evidence.engine(q['study'],q['profile'],q['service'],q['policy'],event,context,'ContractCover')
        assert direct['status']=='AUTHORIZED'
        use=anchor if anchor['status']=='AUTHORIZED' else direct
        rows.append({**base,'route':'reuse' if use is anchor else 'direct',
           'direct_card':direct['card'],'hybrid_card':use['card'],'hybrid_upper':use['upper']})
    f=pd.DataFrame(rows);assert len(f)==320 and (f.status=='AUTHORIZED').sum()==59
    emit(rows,'hybrid_plans.csv')
    support=[];costs=[]
    for study in ['A','B','combined']:
        g=f if study=='combined' else f[f.study==study];yes=g[g.status=='AUTHORIZED']
        support.append({'study':study,'contexts':len(g),'supported':len(yes),
           'reused':int((yes.route=='reuse').sum()),'direct_fallback':int((yes.route=='direct').sum())})
        for method,col in [('Direct fixed policy','direct_card'),('Reuse plus direct fallback','hybrid_card')]:
            cards=unique_cards(set(yes[col]));costs.append({'study':study,'method':method,
               'supported_contexts':len(yes),'proof_cards':len(cards),
               'event_record_evaluations':sum(c['n'] for c in cards.values())})
    emit(support,'hybrid_support.csv')
    emit(costs,'hybrid_cost.csv')
    return {'hybrid_support':support,'hybrid_cost':costs}

def family_sensitivity():
    all_groups=unique_cards({c['id'] for c in evidence.CARDS})
    anchor_ids={c['id'] for c in evidence.CARDS if c['variant'] in evidence.tr.ANCHORS}
    anchor_groups=unique_cards(anchor_ids)
    families=[('Primary reserved',4608,4608),('Canonical scope design',len(anchor_groups),len(all_groups))]
    queries=[];seen=set()
    for q in evidence.PLANS:
        key=(q['study'],q['profile'],q['service'],q['event_id'])
        if q['method']=='ContractCover' and q['allowance']==.15 and key not in seen:queries.append(q);seen.add(key)
    rows=[];boundrows=[]
    for design,k_anchor,k_direct in families:
        bounds={}
        for method,K in [('Anchor',k_anchor),('Direct',k_direct)]:
            bounds[method]={c['id']:1. if c['k']==c['n'] else float(beta.isf(.05/K,c['k']+1,c['n']-c['k'])) for c in evidence.CARDS}
            for study in ['A','B']:
                accepted=0
                for q in queries:
                    if q['study']!=study:continue
                    ev=evidence.tr.requirement(q['task'],q['variant']);okay=False
                    for c in evidence.CARDS:
                        if c['profile']!=q['profile'] or c['service']!=q['service'] or (study=='A' and c['study']!='A'):continue
                        if bounds[method][c['id']]>.15:continue
                        if method=='Anchor':
                            if c['variant'] not in evidence.tr.ANCHORS or evidence.containment(c['_event'],ev) is None:continue
                        elif c['event_id']!=ev.identity:continue
                        ctx=next(x['context'] for x in evidence.CARDS if x['study']==study and x['profile']==q['profile'] and x['service']==q['service'] and x['policy']==c['policy'])
                        if evidence.tr.event_capsule(ev,ctx)!=evidence.tr.event_capsule(ev,c['context']):continue
                        okay=True;break
                    accepted+=okay
                rows.append({'design':design,'method':method,'family_K':K,'study':study,'supported_contexts':accepted,'contexts':160})
            focal=next(c for c in evidence.CARDS if c['id']=='B/unfitted/relaxed/FlatCART/association/full')
            boundrows.append({'design':design,'method':method,'K':K,'n':focal['n'],'k':focal['k'],'upper':bounds[method][focal['id']]})
    primary={(x['method'],x['study']):x['supported_contexts'] for x in rows if x['design']=='Primary reserved'}
    assert primary=={('Anchor','A'):24,('Anchor','B'):23,('Direct','A'):30,('Direct','B'):29},primary
    emit(rows,'family_sensitivity.csv')
    emit(boundrows,'family_bound_example.csv')
    return {'canonical_anchor_tests':len(anchor_groups),'canonical_all_tests':len(all_groups),'family_sensitivity':rows}

def main():
    verify_inputs()
    result={'status':'PASS','new_population_inputs':0,'new_calibration_cards':0,
      'scope':'Finite paired producer re-execution, point-count probes, fixed-policy evidence routing and archived-count sensitivity',
      **replay_audit(),**route_evidence(),**family_sensitivity(),
      'compiler':verify_compiler(evidence.tr)}
    if VERIFY:
        assert result==json.loads((OUT/'results.json').read_text())
    else:(OUT/'results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':main()
