"""Rolling 16-beam simulation with archived consumed samples.
Airframes are FlightGear visual meshes; they are not metrology CAD.
The odometry port is a stochastic increment simulator, not FAST-LIO2.
"""
from pathlib import Path
import ctypes
import hashlib,json
import numpy as np
from scipy.spatial.transform import Rotation
from .core import PriorMap,exp

class Mesh:
    def __init__(self,mesh_path,map_points=80000):
        z=np.load(mesh_path,allow_pickle=True);self.v=np.ascontiguousarray(z['vertices'],dtype=float);self.f=np.ascontiguousarray(z['faces'],dtype=np.int32);self.n=z['normals'];self.area=z['area'];self.names=z['names']
        self.lib=ctypes.CDLL(str(Path(__file__).with_name('libbvh.so')))
        ptr=ctypes.c_void_p; self.lib.build_mesh.restype=ptr;self.lib.build_mesh.argtypes=[ptr,ptr,ctypes.c_int]
        self.lib.cast_rolling.argtypes=[ptr,ptr,ptr,ctypes.c_int,ptr,ptr];self.lib.free_mesh.argtypes=[ptr]
        self.handle=self.lib.build_mesh(self.v.ctypes.data,self.f.ctypes.data,len(self.f))
        rng=np.random.default_rng(7093);faces=rng.choice(len(self.f),size=map_points,p=self.area/self.area.sum())
        u=rng.random(map_points);v=rng.random(map_points);flip=u+v>1;u[flip]=1-u[flip];v[flip]=1-v[flip]
        t=self.v[self.f[faces]];points=t[:,0]+u[:,None]*(t[:,1]-t[:,0])+v[:,None]*(t[:,2]-t[:,0]);self.prior=PriorMap(points,self.n[faces],faces)
    def cast(self,origins,directions):
        origins=np.ascontiguousarray(origins,dtype=np.float64);directions=np.ascontiguousarray(directions,dtype=np.float64)
        ranges=np.empty(len(directions));faces=np.empty(len(directions),dtype=np.int32)
        self.lib.cast_rolling(self.handle,origins.ctypes.data,directions.ctypes.data,len(directions),ranges.ctypes.data,faces.ctypes.data)
        return ranges,faces
    def __del__(self):
        if hasattr(self,'handle'): self.lib.free_mesh(self.handle)

def directions(columns=1024):
    # firing order: 16 rings per column; timestamp is relative to end of sweep
    az=np.repeat(np.arange(columns)*2*np.pi/columns,16);el=np.tile(np.deg2rad(np.arange(-15,16,2)),columns)
    return np.c_[np.cos(el)*np.cos(az),np.cos(el)*np.sin(az),np.sin(el)],np.repeat(np.linspace(-.1,0,columns,endpoint=False),16),np.tile(np.arange(16),columns)

def scan(mesh,pose,velocity,seed,stamp,columns=1024,map_t=None,map_R=None,deskew_velocity=None):
    rng=np.random.default_rng(seed);dirs,rel,ring=directions(columns)
    map_t=np.zeros(3) if map_t is None else map_t;map_R=np.eye(3) if map_R is None else map_R
    R=exp(pose[3:]);delta=Rotation.from_rotvec(rel[:,None]*velocity[3:]).as_matrix()
    Rs=np.einsum('ij,njk->nik',R,delta);ts=pose[:3]+rel[:,None]*(R@velocity[:3])[None,:]
    # fixed measured extrinsic, each ray fired at its own pose
    origins=ts+np.einsum('nij,j->ni',Rs,np.array([.15,0,.75]));worlddirs=np.einsum('nij,nj->ni',Rs,dirs)
    localorigins=(origins-map_t)@map_R;localdirs=worlddirs@map_R
    ranges,faces=mesh.cast(localorigins,localdirs);valid=np.isfinite(ranges)&(ranges>.3)&(faces>=0)
    ids=np.flatnonzero(valid)
    if len(ids)==0:return {k:np.empty((0,3),np.float32) if k in ('xyz_raw','xyz') else np.empty(0,np.float32) for k in ('xyz_raw','xyz','face','dt','ring','dynamic')}
    incidence=np.abs(np.einsum('ij,ij->i',mesh.n[faces[ids]],localdirs[ids]))
    # dropout rises at grazing incidence; metal/glass use distinct noise levels
    glass=np.array(['glass' in str(x).lower() for x in mesh.names[faces[ids]]]);sd=.015+.02*(1-incidence)+.03*glass
    keep=rng.random(len(ids))>(.025+.08*(1-incidence)+.15*glass);ids=ids[keep];sd=sd[keep]
    measured=ranges[ids]+rng.normal(0,sd)
    raw=dirs[ids]*measured[:,None]+np.array([.15,0,.75])
    # deterministic sectors emulate dynamic foreground and can occlude rays
    az=np.arctan2(dirs[ids,1],dirs[ids,0]);sector=(np.abs(np.angle(np.exp(1j*(az-.7*np.sin(stamp*.025)))))<.06)&(stamp%45<8)
    measured[sector]=np.minimum(measured[sector],3.+.2*np.sin(stamp*.2));raw[sector]=dirs[ids[sector]]*measured[sector,None]+[.15,0,.75]
    # Common front-end deskew uses measured motion from causal measured increments;
    # all consumed output coordinates and acquisition times are archived.
    vw=velocity if deskew_velocity is None else deskew_velocity
    dr=Rotation.from_rotvec(rel[ids,None]*vw[3:]).as_matrix()
    deskew=np.einsum('nij,nj->ni',dr,raw)+rel[ids,None]*vw[:3]
    # bounded return count follows the existing requested .4m voxel front-end setting
    cells=np.floor(deskew/.4).astype(np.int32);_,take=np.unique(cells,axis=0,return_index=True);take=np.sort(take)
    if len(take)>1500:take=take[np.linspace(0,len(take)-1,1500,dtype=int)]
    return {'xyz_raw':raw[take].astype(np.float32),'xyz':deskew[take].astype(np.float32),'face':faces[ids[take]],'dt':rel[ids[take]].astype(np.float32),'ring':ring[ids[take]].astype(np.uint8),'dynamic':sector[take].astype(np.uint8)}

def forecast_scan(mesh,state):
    """Clean structural-prior raycast; no sensor-noise or dynamic-object oracle."""
    dirs,_,_=directions(128);origin=state.t+state.R@np.array([.15,0,.75]);worlddirs=dirs@state.R.T
    origins=np.repeat(((origin-state.mt)@state.mR)[None,:],len(dirs),axis=0)
    ranges,faces=mesh.cast(origins,worlddirs@state.mR);keep=np.isfinite(ranges)&(ranges>.3)&(faces>=0)
    return dirs[keep]*ranges[keep,None]+[.15,0,.75]

def forecast_state(s,velocity,lag):
    from .core import propagate
    state=s.copy();n=int(np.ceil(lag/.1));dt=lag/n
    for _ in range(n):state=propagate(state,dt,velocity*dt)
    return state

def generate(mesh_path,route_path,out,duration=180.,offset=0.,seed=1001,columns=1024):
    import time
    out=Path(out);out.mkdir(parents=True,exist_ok=True);mesh=Mesh(mesh_path);route=np.load(route_path)['pose'];dt=.02;n=int(duration/dt)
    time50=np.arange(n)*dt;idx=(time50+offset)/.1;lo=np.minimum(idx.astype(int),len(route)-2);a=idx-lo
    truth=route[lo]*(1-a[:,None])+route[lo+1]*a[:,None]
    # Local motion follows the source route, yaw is interpolated in its unwrapped form.
    truth[:,5]=np.interp(time50+offset,np.arange(len(route))*.1,np.unwrap(route[:,5]))
    inc=np.zeros((n,6));inc[1:,:3]=np.einsum('nij,nj->ni',Rotation.from_rotvec(truth[:-1,3:]).as_matrix().transpose(0,2,1),np.diff(truth[:,:3],axis=0));inc[1:,3:]=np.diff(truth[:,3:],axis=0)
    rng=np.random.default_rng(seed);bias=np.empty((n,6));bias[0]=rng.normal(0,np.r_[np.full(3,.0015),np.full(3,.00015)])
    for i in range(1,n):bias[i]=np.exp(-dt/125)*bias[i-1]+rng.normal(0,np.r_[np.full(3,.0015),np.full(3,.00015)])*np.sqrt(1-np.exp(-2*dt/125))
    measured=inc+bias*dt+rng.normal(0,np.sqrt(dt)*np.r_[np.full(3,.004),np.full(3,.0004)],size=(n,6))
    map_t=rng.normal(0,.025,3);map_rot=rng.normal(0,.001,3);map_R=exp(map_rot)
    # 200Hz IMU record is supplied for ROS adaptation; the evaluation port consumes
    # measured increment odometry. These IMU values are not claimed to produce it.
    ti=np.arange(int(duration*200))/200;vel=np.gradient(truth[:,:3],dt,axis=0);acc=np.gradient(vel,dt,axis=0)
    Ri=Rotation.from_rotvec(np.column_stack([np.interp(ti,time50,truth[:,j]) for j in range(3,6)])).as_matrix()
    aw=np.column_stack([np.interp(ti,time50,acc[:,j]) for j in range(3)])-[0,0,-9.80665]
    gyro=np.column_stack([np.interp(ti,time50,np.gradient(truth[:,j],dt)) for j in range(3,6)])
    imu=np.c_[ti,np.einsum('nij,nj->ni',Ri.transpose(0,2,1),aw)+rng.normal(0,.025,(len(ti),3)),gyro+rng.normal(0,.0008,(len(ti),3))]
    np.savez_compressed(out/'motion.npz',stamp=time50,truth=truth,increment=measured,bias=bias,map_t=map_t,map_rot=map_rot,imu=imu)
    allhash=[];tick=[];xyz=[];raw=[];face=[];ring=[];rel=[];dynamic=[];offsets=[0]
    begin=time.perf_counter()
    for frame in range(0,n,5):
        vv=inc[min(frame+1,n-1)]/dt
        causal=np.mean(measured[max(1,frame-4):frame+1],axis=0)/dt if frame else measured[0]/dt
        cloud=scan(mesh,truth[frame],vv,seed*100000+frame,time50[frame],columns,map_t,map_R,deskew_velocity=causal)
        tick.append(frame);xyz.append(cloud['xyz']);raw.append(cloud['xyz_raw']);face.append(cloud['face']);ring.append(cloud['ring']);rel.append(cloud['dt']);dynamic.append(cloud['dynamic']);offsets.append(offsets[-1]+len(cloud['xyz']))
        if len(tick)>=300 or frame>=n-5:
            name=f'scans_{tick[0]:06d}.npz';path=out/name
            np.savez_compressed(path,tick=np.array(tick),offsets=np.array(offsets),xyz=np.concatenate(xyz),xyz_raw=np.concatenate(raw),face=np.concatenate(face),ring=np.concatenate(ring),dt=np.concatenate(rel),dynamic=np.concatenate(dynamic))
            allhash.append({'file':name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()});tick=[];xyz=[];raw=[];face=[];ring=[];rel=[];dynamic=[];offsets=[0]
    manifest={'version':'A9-rolling-causal-v3','generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'seed':seed,'duration_s':duration,'route_offset_s':offset,'rings':16,'columns':columns,'scan_hz':10,'odom_hz':50,'imu_hz':200,'map_t':map_t.tolist(),'map_rot':map_rot.tolist(),'mesh_sha256':hashlib.sha256(Path(mesh_path).read_bytes()).hexdigest(),'route_sha256':hashlib.sha256(Path(route_path).read_bytes()).hexdigest(),'motion_sha256':hashlib.sha256((out/'motion.npz').read_bytes()).hexdigest(),'chunks':allhash,'generation_wall_s':time.perf_counter()-begin,'front_end':'stochastic measured-increment odometry; no LIO algorithm executed','imu_use':'archived ROS adaptation input, not fused by evaluated increment port','truth_access':'offline labels only'}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2));print(out,len(allhash),round(manifest['generation_wall_s'],2),flush=True)

def load_scans(folder):
    for p in sorted(Path(folder).glob('scans_*.npz')):
        with np.load(p) as z:
            data={k:z[k] for k in z.files}
        for i,frame in enumerate(data['tick']):
            sl=slice(data['offsets'][i],data['offsets'][i+1]);yield int(frame),{k:data[k][sl] for k in ['xyz','xyz_raw','face','ring','dt','dynamic']}
