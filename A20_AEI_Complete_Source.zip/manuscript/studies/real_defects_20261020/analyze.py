"""Reconstruct grouped calibration, held-out quality and scope-aware renewal."""
from pathlib import Path
from collections import defaultdict
from copy import deepcopy
import csv,hashlib,json,sys
import numpy as np
from scipy.stats import beta
from interface import POPULATION,SERVICE,compile_defect,event_covers,decision,diagnostics
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'validated_recovery_20261018'))
from model import Registry,QuarantineGate,event_sourced_issue,metadata_only_issue,digest as binding_digest

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):Path(p).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def dump_csv(p,rows):
    with Path(p).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def upper(k,n,alpha):return 1. if n==0 or k==n else float(beta.isf(alpha,k+1,n-k))
def failure(row,request):return bool(compile_defect(request).event.failure(dict(defect_group_recall=row['recall'],defect_fp_per_image=row['fp_per_image'])))
def covers(a,b):return event_covers(a,b)

def aggregate(scores):
    groups=defaultdict(list)
    for r in scores:groups[(r['producer'],r['split'],r['group'])].append(r)
    result=[]
    for (p,split,g),rows in sorted(groups.items()):
        tp=sum(r['tp'] for r in rows);gt=sum(r['gt'] for r in rows);fp=sum(r['fp'] for r in rows)
        result.append(dict(producer=p,split=split,group=g,images=len(rows),gt=gt,tp=tp,fp=fp,fn=gt-tp,
                           recall=tp/gt if gt else 1.,fp_per_image=fp/len(rows),precision=tp/(tp+fp) if tp+fp else 0.))
    return result

def catalogue(cards,spec,allowance):
    requests={r['name']:r for r in spec['requests']};built=[];plans=[]
    for producer in [p['name'] for p in spec['producers']]:
        for name in ['coverage','review','triage','strict']:
            anchors=[c for c in built if c['producer']==producer and c['upper']<=allowance and covers(requests[c['request']],requests[name])]
            exact=next(c for c in cards if c['producer']==producer and c['request']==name)
            if anchors:
                proof=min(anchors,key=lambda c:(c['upper'],c['request']));route='containment'
            else:proof=exact;built.append(proof);route='exact'
            assert (proof['upper']<=allowance)==(exact['upper']<=allowance)
            if 'producer_signature_sha256' in proof:
                authorization=decision(proof,requests[name],exact['producer_signature_sha256'],allowance=allowance)
                assert (authorization['status']=='AUTHORIZED')==(exact['upper']<=allowance)
            plans.append(dict(producer=producer,request=name,route=route,proof_request=proof['request'],upper=proof['upper'],exact_upper=exact['upper'],authorized=proof['upper']<=allowance,card_identity=proof['identity']))
    return plans,built

def lifecycle(plans,scores,spec,metadata):
    by_plan={(p['producer'],p['request']):p for p in plans}
    grouped=defaultdict(list)
    for row in scores:
        if row['split']=='test':grouped[row['group']].append(row)
    rows=[]
    for group,source_rows in sorted(grouped.items()):
        payloads={}
        for p in [x['name'] for x in spec['producers']]:
            selected=sorted((r for r in source_rows if r['producer']==p),key=lambda r:r['uid'])
            lookup={r['uid']:r for r in metadata[p]['images']}
            payloads[p]=dict(source_group=group,producer_sha256=metadata[p]['signature_sha256'],
                observations=[dict(uid=r['uid'],input_sha256=lookup[r['uid']]['input_image_sha256'],pixels_sha256=lookup[r['uid']]['transformed_pixels_sha256'],prediction_sha256=r['prediction_sha256']) for r in selected])
        initial='triage'
        cards={p:dict(identity=by_plan[p,initial]['card_identity'],authorized=by_plan[p,initial]['authorized']) for p in payloads}
        registry=Registry('defect-report:'+group,group,payloads,cards);gate=QuarantineGate();saved_final=None;old_repair=None
        steps=[('initial','early','triage'),('model_update','final','triage'),('requirement_tighten','final','review'),
               ('stale_report','final','review'),('repair','final','review'),('dark_update','dark','review'),
               ('requirement_relax','dark','triage'),('bright_update','bright','triage'),('rollback','final','triage'),
               ('late_version','final','triage'),('repair','final','triage'),('repair_replay','final','triage')]
        for index,(kind,p,request) in enumerate(steps):
            plan=by_plan[p,request]
            cards[p]=dict(identity=plan['card_identity'],authorized=plan['authorized']);registry.cards=deepcopy(cards)
            accepted=None
            if kind in ['initial','model_update','requirement_tighten','dark_update','requirement_relax','bright_update','rollback']:
                registry.register(p);envelope=registry.envelope()
                if kind=='model_update':saved_final=deepcopy(envelope)
            elif kind in ['stale_report','late_version']:
                envelope=deepcopy(saved_final);registry.validate_attachment(envelope)
            elif kind=='repair':
                cert=registry.issue_certificate();envelope=registry.envelope(revision=registry.record['revision']+1)
                accepted=registry.repair(envelope,cert);assert accepted
                old_repair=(deepcopy(envelope),deepcopy(cert))
            else:
                rejected_envelope,cert=old_repair
                accepted=registry.repair(rejected_envelope,cert);assert not accepted
                envelope=registry.envelope()
            snapshot=registry.snapshot();issued=gate.issue(envelope,snapshot)
            independent=event_sourced_issue(envelope,registry.log,registry.cards)
            assert issued==independent
            valid=all(envelope[k]==snapshot['record'][k] for k in ['binding','capture','revision','producer','calibration']) and binding_digest(envelope['payload'])==snapshot['record']['payload_digest']
            assert not issued or (valid and plan['authorized'])
            rows.append(dict(group=group,index=index,event=kind,producer=p,request=request,revision=registry.record['revision'],state=registry.status,
                authorized=plan['authorized'],issued=issued,binding_valid=valid,metadata_only_issued=bool(metadata_only_issue(envelope,snapshot)),repair_accepted=accepted,
                payload_digest=binding_digest(payloads[p]),evidence_upper=plan['upper']))
    return rows

def main():
    spec=json.loads((ROOT/'resolved_protocol.json').read_text());out=ROOT/'outputs'
    scores=json.loads((out/'image_scores.json').read_text());manifest=json.loads((ROOT/'manifest.json').read_text())
    expected={r['uid'] for r in manifest['records'] if r['split']!='train'}
    producers=[p['name'] for p in spec['producers']]
    metadata={p:json.loads((out/(p+'_metadata.json')).read_text()) for p in producers}
    for row in scores:assert row['producer_sha256']==metadata[row['producer']]['signature_sha256']
    assert len(scores)==len(expected)*len(producers)
    for p in producers:assert {r['uid'] for r in scores if r['producer']==p}==expected
    groups=aggregate(scores);dump_csv(out/'group_scores.csv',groups)
    alpha=spec['calibration']['confidence_error']/16;allowance=spec['calibration']['primary_group_failure_allowance']
    cards=[];comparison=[];requests={r['name']:r for r in spec['requests']}
    for producer in producers:
        cal=[r for r in groups if r['producer']==producer and r['split']=='calibration']
        test=[r for r in groups if r['producer']==producer and r['split']=='test']
        image_cal=[r for r in scores if r['producer']==producer and r['split']=='calibration']
        for name,request in requests.items():
            k=sum(failure(r,request) for r in cal);n=len(cal);u=upper(k,n,alpha)
            card=dict(producer=producer,request=name,failures=k,groups=n,alpha=alpha,upper=u,
                population=POPULATION,service=SERVICE,event=request,event_identity=compile_defect(request).event.identity,
                quantity_dependencies=list(compile_defect(request).dependencies),
                producer_signature_sha256=metadata[producer]['signature_sha256'],source_manifest_sha256=sha(ROOT/'manifest.json'),
                metric_definition=dict(class_aware_matching_iou=spec['detector']['matching_iou'],matching='confidence-ordered best-unused target',duplicates='false positive',unit='complete source group',empty_annotation_recall=1.),
                metric_implementation_sha256=sha(ROOT/'evaluate.py'),
                calibration_lineage_sha256=hashlib.sha256(json.dumps(image_cal,sort_keys=True,separators=(',',':')).encode()).hexdigest())
            card['identity']=hashlib.sha256(json.dumps(card,sort_keys=True).encode()).hexdigest();cards.append(card)
            image_k=sum(r['recall']<request['group_recall_min'] or r['fp']>request['false_positives_per_image_max'] for r in image_cal)
            image_u=upper(image_k,len(image_cal),alpha)
            comparison.append(dict(producer=producer,request=name,calibration_groups=n,group_failures=k,group_frequency=k/n,group_upper=u,
                image_records=len(image_cal),image_failures=image_k,image_upper=image_u,group_authorized=u<=allowance,
                empirical_group_authorized=k/n<=allowance,image_analysis_authorized=image_u<=allowance,
                test_groups=len(test),test_group_failures=sum(failure(r,request) for r in test),test_group_failure_rate=sum(failure(r,request) for r in test)/len(test)))
    assert len(cards)==16
    save(out/'typed_interface_checks.json',diagnostics(cards,requests))
    from shared_checks import check as check_shared
    save(out/'shared_interface_checks.json',check_shared())
    save(out/'compiled_requests.json',{name:dict(event_identity=compile_defect(r).event.identity,dependencies=list(compile_defect(r).dependencies)) for name,r in requests.items()})
    save(out/'cards.json',cards);dump_csv(out/'calibration_comparison.csv',comparison)
    plans,built=catalogue(cards,spec,allowance);save(out/'plans.json',plans)
    # A requested threshold outside the fixed family can use inclusion, never an unallocated exact inversion.
    unreserved=[]
    for p in producers:
        eligible=[c for c in cards if c['producer']==p and c['upper']<=allowance and covers(c['event'],spec['unreserved_request'])]
        unreserved.append(dict(producer=p,route='containment' if eligible else 'refuse_unreserved',authorized=bool(eligible),exact_evaluations=0))
    save(out/'unreserved_requests.json',unreserved)
    rng=np.random.default_rng(spec['seed']+1);repetitions=[]
    cal_ids=sorted({r['group'] for r in groups if r['split']=='calibration'})
    for repetition in range(100):
        chosen=set(rng.choice(cal_ids,size=max(1,int(.75*len(cal_ids))),replace=False))
        sampled=[]
        for card in cards:
            group=[r for r in groups if r['split']=='calibration' and r['group'] in chosen and r['producer']==card['producer']]
            k=sum(failure(r,card['event']) for r in group)
            sample=dict(card,failures=k,groups=len(group),upper=upper(k,len(group),alpha),subsample_groups=sorted(chosen))
            sample['calibration_lineage_sha256']=hashlib.sha256(json.dumps(dict(base=card['calibration_lineage_sha256'],groups=sorted(chosen)),sort_keys=True).encode()).hexdigest()
            sample.pop('identity');sample['identity']=hashlib.sha256(json.dumps(sample,sort_keys=True).encode()).hexdigest();sampled.append(sample)
        sample_plans,sample_built=catalogue(sampled,spec,allowance)
        repetitions.append(dict(repetition=repetition,group_ids='|'.join(sorted(chosen)),calibration_groups=len(chosen),supported=sum(p['authorized'] for p in sample_plans),exact_cards=len(sampled),reuse_cards=len(sample_built),support_preserved=True))
    dump_csv(out/'calibration_subsamples.csv',repetitions)
    workflow=lifecycle(plans,scores,spec,metadata);dump_csv(out/'workflow.csv',workflow)
    class_rows=[]
    for p in producers:
        for split in ['calibration','test']:
            rows=[r for r in scores if r['producer']==p and r['split']==split]
            for c,name in enumerate(spec['classes']):
                gt=sum(r['by_class'][c]['gt'] for r in rows);tp=sum(r['by_class'][c]['tp'] for r in rows);fp=sum(r['by_class'][c]['fp'] for r in rows)
                positive_groups=len({r['group'] for r in rows if r['by_class'][c]['gt']>0})
                class_rows.append(dict(producer=p,split=split,category=name,gt=gt,tp=tp,fp=fp,recall=tp/gt if gt else None,
                    precision=tp/(tp+fp) if tp+fp else None,positive_source_groups=positive_groups,
                    best_possible_unadjusted_zero_failure_bound=upper(0,positive_groups,.05),class_specific_event_reserved=False))
    save(out/'class_diagnostics.json',class_rows)
    sensitivity=[]
    for delta in [.1,.25,.4]:
        pp,bb=catalogue(cards,spec,delta);sensitivity.append(dict(allowance=delta,supported=sum(p['authorized'] for p in pp),exact_cards=16,containment_cards=len(bb),record_evaluations_exact=16*len(cal_ids),record_evaluations_reuse=len(bb)*len(cal_ids)))
    test_performance=[]
    for p in producers:
        rows=[r for r in scores if r['producer']==p and r['split']=='test'];tp=sum(r['tp'] for r in rows);gt=sum(r['gt'] for r in rows);fp=sum(r['fp'] for r in rows)
        test_performance.append(dict(producer=p,images=len(rows),groups=len({r['group'] for r in rows}),gt=gt,tp=tp,fp=fp,recall=tp/gt,precision=tp/(tp+fp) if tp+fp else 0.))
    summary=dict(status='COMPLETE',source_groups=manifest['retained_groups'],canonical_images=len(manifest['records']),splits=manifest['statistics'],
        image_producer_outputs=len(scores),family_size=16,calibration_group_count=len(cal_ids),test_group_count=len({r['group'] for r in groups if r['split']=='test'}),
        primary_allowance=allowance,supported_contexts=sum(p['authorized'] for p in plans),constructed_exact_cards=16,constructed_reuse_cards=len(built),
        record_evaluations_exact=16*len(cal_ids),record_evaluations_reuse=len(built)*len(cal_ids),support_preserved=True,
        unreserved_requests=unreserved,sensitivity=sensitivity,test_performance=test_performance,
        empirical_authorizations=sum(r['empirical_group_authorized'] for r in comparison),unclustered_image_authorizations=sum(r['image_analysis_authorized'] for r in comparison),
        workflow_rows=len(workflow),workflow_groups=len({r['group'] for r in workflow}),issued=sum(r['issued'] for r in workflow),invalid_bindings_issued=sum(r['issued'] and not r['binding_valid'] for r in workflow),
        metadata_only_invalid_issuances=sum(r['metadata_only_issued'] and not r['binding_valid'] for r in workflow),valid_repairs=sum(r['repair_accepted'] is True for r in workflow),
        restored_eligible_checkpoints=sum(r['repair_accepted'] is True and r['issued'] for r in workflow),
        analysis_code_sha256=sha(__file__),protocol_sha256=sha(ROOT/'resolved_protocol.json'),model_freeze_sha256=sha(ROOT/'model_freeze.json'),prediction_scores_sha256=sha(out/'image_scores.json'))
    save(out/'summary.json',summary);print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
