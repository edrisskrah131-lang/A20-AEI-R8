"""Process rendered PNGs with the unchanged pixel detector and CAD pose estimator.
Ground truth enters scoring only; segmentation receives pixels only.
"""
from pathlib import Path
import argparse,json,sys,hashlib
import numpy as np
import pandas as pd
from PIL import Image
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT.parent/'lifecycle_20261018'))
from imaging import decode,fit,configuration,old
P=argparse.ArgumentParser();P.add_argument('--input',type=Path,default=ROOT/'outputs'/'test');P.add_argument('--out',type=Path,default=ROOT/'outputs');P.add_argument('--pilot',action='store_true');args=P.parse_args();args.out.mkdir(parents=True,exist_ok=True)
rows=[];projection_errors=[]
for path in sorted(args.input.glob('*.json')):
 s=json.loads(path.read_text())
 if 'cad' not in s:continue
 for key in ('camera','rotation','translation_error','rotation_error','cad','actual','missing'):s[key]=np.asarray(s[key])
 if 'blender_projected_pixels' in s:projection_errors.append(float(np.max(np.abs(old.project(s['actual'],s['camera'],s['rotation'],s['focal'])-np.asarray(s['blender_projected_pixels'])))))
 for variant,cfg in s['variants'].items():
  rgb=np.asarray(Image.open(args.input/cfg['filename']).convert('RGB'));decoded=decode(rgb,18.);values,artifacts=fit(s,configuration('baseline'),decoded)
  row=dict(seed=s['seed'],variant=variant,layout=s['layout'],painted=s['painted'],candidates=len(decoded),**values,mean_gray=float(rgb.mean()),saturated_pixel_fraction=float(np.mean(np.max(rgb,axis=2)>=250)),render_elapsed_s=cfg['elapsed_s'],png_sha256=hashlib.sha256((args.input/cfg['filename']).read_bytes()).hexdigest());rows.append(row)
  np.savez_compressed(args.out/(str(s['seed'])+'_'+variant+'_correspondences.npz'),**artifacts)
frame=pd.DataFrame(rows);frame.to_csv(args.out/('pilot_metrics.csv' if args.pilot else 'metrics.csv'),index=False)
summary={'scope':'separate Cycles renderer-transfer challenge; no pooled risk calibration','sources':len(set(frame.seed)),'rendered_images':len(frame),'decoder_threshold':18.,'max_independent_camera_projection_difference_px':max(projection_errors) if projection_errors else None,'variants':{}}
for name,g in frame.groupby('variant'):
 summary['variants'][name]={k:float(g[k].median()) for k in ['coverage','reprojection_px','association_m','prior_translation_error_m','posterior_translation_error_m','mean_gray','saturated_pixel_fraction']}
 summary['variants'][name].update({'coverage_mean':float(g.coverage.mean()),'mapping_p95_m':float(g.association_m.quantile(.95)),'inherited_association_failures':int(((g.reprojection_px>8)|(g.association_m>.008)|(g.coverage<.8)).sum()),'inherited_acquisition_failures':int((g.coverage<.8).sum()),'n':len(g)})
(args.out/('pilot_summary.json' if args.pilot else 'summary.json')).write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
