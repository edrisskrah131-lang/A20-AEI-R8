"""A18 prospective geometric queries and paired, independently seeded registration.

All labels are obtained by executing the archived geometric solvers. Query code
accepts only the map, received cloud and estimated state. It never sees truth.
"""
from pathlib import Path
from time import process_time_ns, perf_counter
import json, hashlib, argparse
import numpy as np
import pandas as pd
from rcp.core import JointState, exp, log, propagate, register, thin
from rcp.sensor import Mesh, scan
from train import initial_cov

ROOT=Path(__file__).resolve().parents[1]
ACTIONS=['skip','strict','tempered','converged','full']
MESHES=['B767','C172']
LEVELS=[0,1,2]
SCALES=[.03,.07,.14]
HORIZON=4.0
PRICE=.003

def query(prior, cloud, state, q):
    """Four independently callable geometric diagnostics, each at most 96 points."""
    start=process_time_ns()
    # Interlaced subclouds avoid paying for all correspondences before the query.
    points=thin(cloud[q::4],96)
    r,H,_,_=prior.pairs(points,state)
    if len(r)<6:
        value=[-30.,1.,1.,0.][q]
    elif q==0:
        # Geometry in scaled translation/rotation coordinates.
        A=H[:,:6]*np.r_[np.ones(3),np.full(3,1/1.5)]
        value=float(np.log(max(np.linalg.eigvalsh(A.T@A/len(r))[0],1e-12)))
    elif q==1:
        value=float(np.quantile(np.abs(r),.9))
    elif q==2:
        w=np.minimum(1.,.0625/np.maximum(np.abs(r),1e-12))/.025**2
        step=np.linalg.solve(np.linalg.inv(state.P)+H.T@(H*w[:,None]),H.T@(w*r))
        value=float(np.linalg.norm(step[:3]))
    else:
        value=float(np.sum(np.abs(r)<.1)/max(len(points),1))
    return value,(process_time_ns()-start)*1e-9

def rel_error(state,truth,map_t,map_R):
    p=(state.t-state.mt)@state.mR-(truth[:3]-map_t)@map_R
    R=state.mR.T@state.R@(map_R.T@exp(truth[3:])).T
    return p,log(R)

def context(state):
    sd=np.sqrt(np.trace(state.P[:3,:3])/3)
    return int(np.argmin(np.abs(np.log(sd/np.asarray(SCALES)))))

def dataset_design():
    rows=[]
    # Training and validation contain matched meshes. Test crosses declared
    # shape discrepancies and doubled return noise with entirely fresh seeds.
    for split,base,n in [('train',210000,80),('validation',310000,40)]:
        for mi,mesh in enumerate(MESHES):
            for si,sd in enumerate(SCALES):
                for i in range(n):
                    rows.append(dict(split=split,mesh=mesh,level=0,noise=1.,sd=sd,
                                     seed=base+mi*10000+si*1000+i))
    for mi,mesh in enumerate(MESHES):
        for level in LEVELS:
            for noise in [1.,2.]:
                for i in range(40):
                    rows.append(dict(split='test',mesh=mesh,level=level,noise=noise,
                                     sd=SCALES[i%3],seed=410000+mi*10000+level*1000+int(noise)*100+i))
    return rows

def freeze():
    path=ROOT/'protocol_A18.json'
    protocol=dict(version='A18',source_cases=dataset_design(),
        query_definition=['minimum scaled pose-Hessian eigenvalue','90th-percentile absolute residual',
                          'regularized one-step translation magnitude','inlier fraction'],
        query_point_limit=96,query_partitions='interlaced q::4',
        budget_ratios=[1.,1.25,1.5],fidelity_grid=[.5,.65,.8,.95,1.],
        policy_classes=['full','coarse','fixed','myopic','reserve','joint'],
        action_names=ACTIONS,horizon_s=HORIZON,price_per_cpu_second=PRICE,
        timing='measured process CPU; reservations fixed from training 99th percentiles times 1.5',
        source_model='FlightGear visual meshes; rolling 16-beam raycast and stochastic measured-increment input',
        split_rule='Independent seed families; shape and return-noise shifts only in test',
        outcome='Four-second paired continuation with no subsequent registration; query charges added by policy',
        registration_sha256=hashlib.sha256((ROOT/'source/rcp/core.py').read_bytes()).hexdigest(),
        generator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    if path.exists():
        assert json.loads(path.read_text())==protocol,'Frozen protocol differs'
    else:path.write_text(json.dumps(protocol,indent=2))
    return protocol

def make_case(c, meshes, routes):
    rng=np.random.default_rng(c['seed']);mesh=c['mesh'];route=routes[mesh]
    frame=int(rng.integers(100,len(route)-100));truth=route[frame]
    world=meshes[(mesh,c['level'])];prior=meshes[(mesh,0)].prior
    map_t=rng.normal(0,.025,3);map_R=exp(rng.normal(0,.001,3))
    v=np.r_[(route[frame+1,:3]-truth[:3])@exp(truth[3:])/.1,
            log(exp(truth[3:]).T@exp(route[frame+1,3:]))/.1]
    cloud=scan(world,truth,v,c['seed']*100,frame*.1,1024,map_t,map_R,deskew_velocity=v)['xyz'].astype(float)
    if c['noise']>1:
        cloud+=rng.normal(0,.025*np.sqrt(c['noise']**2-1),cloud.shape)
    s=JointState(truth[:3]+rng.normal(0,c['sd'],3),exp(rng.normal(0,.006,3))@exp(truth[3:]),
                 np.zeros(6),np.zeros(3),np.eye(3),initial_cov(c['sd']))
    qs=[query(prior,cloud,s,q) for q in range(4)]
    # A shared future motion realization is used for all five counterfactuals.
    future=route[frame:frame+41]
    increments=[]
    bias=rng.normal(0,np.r_[np.full(3,.0015),np.full(3,.00015)])
    for j in range(40):
        inc=np.r_[(future[j+1,:3]-future[j,:3])@exp(future[j,3:]),
                  log(exp(future[j,3:]).T@exp(future[j+1,3:]))]
        inc+=bias*.1+rng.normal(0,np.sqrt(.1)*np.r_[np.full(3,.004),np.full(3,.0004)])
        increments.append(inc)
    losses=[];cpus=[];accepted=[];instant=[]
    for action in ACTIONS:
        if action=='skip':post=s.copy();cpu=0.;ok=False
        else:
            t=process_time_ns();post,stats,_,_=register(prior,cloud,s,action)
            cpu=(process_time_ns()-t)*1e-9;ok=stats['accepted']
        pe,re=rel_error(post,truth,map_t,map_R);instant.append(float(np.linalg.norm(pe)))
        loss=0.;ss=post
        for j,inc in enumerate(increments):
            ss=propagate(ss,.1,inc);p,r=rel_error(ss,future[j+1],map_t,map_R)
            loss+=(p@p+2.25*(r@r))*.1
        losses.append(loss+PRICE*cpu);cpus.append(cpu);accepted.append(ok)
    return dict(**c,frame=frame,npoints=len(cloud),context=context(s),
                scores=[q[0] for q in qs],query_cpu=[q[1] for q in qs],
                losses=losses,cpu=cpus,accepted=accepted,instant=instant)

def collect():
    p=freeze();meshes={};routes={}
    out=ROOT/'data/prospective_cases.jsonl'
    done={json.loads(line)['seed'] for line in out.read_text().splitlines()} if out.exists() else set()
    for mesh in MESHES:
        routes[mesh]=np.load(ROOT/f'meshes/{mesh}/route.npz')['pose']
        for level in LEVELS: meshes[(mesh,level)]=Mesh(ROOT/f'meshes/{mesh}/world_discrepancy_{level}.npz')
    start=perf_counter()
    with out.open('a') as f:
        for i,c in enumerate(p['source_cases']):
            if c['seed'] in done:continue
            item=make_case(c,meshes,routes);f.write(json.dumps(item)+'\n');f.flush()
            if (i+1)%40==0: print('COLLECT',i+1,'/',len(p['source_cases']),c['split'],c['mesh'],round(perf_counter()-start,1),'s',flush=True)
    print('COLLECTION COMPLETE',flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['freeze','collect'])
    args=parser.parse_args();freeze() if args.stage=='freeze' else collect()
