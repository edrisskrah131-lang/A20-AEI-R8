"""Execute actual providers and identify their numerical and pixel outputs."""
import hashlib
import json
import math
import time
import numpy as np
from campaign import STAGES,configuration,stable_hash,POPULATION


def clean(value):
    if isinstance(value,(float,np.floating)):
        return float(value) if math.isfinite(value) else str(float(value))
    if isinstance(value,(int,np.integer)):return int(value)
    if isinstance(value,dict):return {k:clean(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [clean(v) for v in value]
    return value

def array_hash(array):
    a=np.ascontiguousarray(array)
    h=hashlib.sha256();h.update(str(a.dtype).encode());h.update(str(a.shape).encode());h.update(a.tobytes())
    return h.hexdigest()

def execute(pipeline,variant,population=POPULATION):
    config=configuration(variant)
    old_calls=pipeline.calls.copy();old_cpu=pipeline.cpu.copy()
    started=time.perf_counter_ns();cpu=time.process_time_ns()
    values=pipeline.evaluate(config)
    images=pipeline.image(config)
    payload=dict(source_seed=int(pipeline.s['seed']),population=population,
                 configuration_sha256=stable_hash(config),
                 rgb_sha256=array_hash(images['rgb']),decoded_sha256=array_hash(images['decoded']),
                 predicted_sha256=array_hash(images['predicted']),
                 reprojection_px=clean(values['reprojection_px']),
                 matched_targets=int(values['matched_targets']),planned_targets=int(values['planned_targets']))
    numerical_digest=stable_hash(clean(values))
    duration_cpu=(time.process_time_ns()-cpu)*1e-9;duration_wall=(time.perf_counter_ns()-started)*1e-9
    row=dict(seed=int(pipeline.s['seed']),variant=variant,population=population,**values,
             pixel_sha256=payload['rgb_sha256'],observable_sha256=stable_hash(payload),
             numerical_sha256=numerical_digest,cpu_s=duration_cpu,wall_s=duration_wall,
             **{'calls_'+s:pipeline.calls[s]-old_calls[s] for s in STAGES},
             **{'provider_cpu_'+s:pipeline.cpu[s]-old_cpu[s] for s in STAGES})
    return row,payload,images

def archive_image(path,images,record,payload):
    path.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(path,**images,metadata=np.array(json.dumps(dict(
        record=clean(record),runtime_observable_payload=payload,
        note='true_pixels are offline scoring labels and never used for runtime admission'))))
