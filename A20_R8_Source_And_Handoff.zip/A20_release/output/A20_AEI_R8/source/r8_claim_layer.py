"""Post-F0 source-scoped statistical attachment monitor.

This layer observes frozen receiver checks and leaves their return values,
installations, numerical state, deterministic work clock and event labels
unchanged. Candidate descriptors inside the F0 journal are not issued claims.
Only receipts emitted here constitute guarded public attachments. A rejected
version attempt permanently removes attachment for that source execution.
This detects the monitored invalid attempts, not unobserved packet loss or OOD.
Scoped injection is single-threaded and is always restored on exit.
"""
import copy,time
from contextlib import contextmanager
import r8_service as base
from r8_contracts import authorize_statement,procedural_statement_check
from r8_protocol import digest

_Transaction=base.Transaction
_procedural_version_check=base.procedural_version_check

class ClaimLedger:
    def __init__(self,registry,plan,execution_id,procedural=False):
        self.registry=registry;self.plan=plan;self.execution_id=execution_id
        self.procedural=procedural;self.receipts=[];self.checks=[]
        self.faulted=False;self.node=None;self.source=None;self.extra_cpu_s=0.
        self.claim_plan=copy.deepcopy(plan);self.manual_history_valid=True
    def bind(self,tx):
        t=time.process_time_ns();src=tx.source
        scope=digest({'execution':self.execution_id,'source':src.identity,
            'prior':src.prior_seal,'data':src.data_seal,'witness':self.plan.get('witness')})
        if self.source is not None and self.source!=scope:raise ValueError('claim scope changed')
        self.source=scope
        if self.procedural:
            if not hasattr(self.registry,'procedural_claim_scopes'):self.registry.procedural_claim_scopes={}
            self.scope_state=self.registry.procedural_claim_scopes.setdefault(scope,{'valid':True,'receipts':[]})
            self.manual_history_valid=self.scope_state['valid'];self.faulted=not self.manual_history_valid
        else:
            if not hasattr(self.registry,'graph_claim_receipts'):self.registry.graph_claim_receipts={}
            self.scope_receipts=self.registry.graph_claim_receipts.setdefault(scope,[])
        if not self.procedural and self.node is None:
            self.node='source-claim/'+scope;self.claim_plan['node']=self.node
            self.registry.graph.bind(self.node,scope,[self.plan['node']])
            self.faulted=self.node in self.registry.graph.revoked
        # Construction is outside the F0 monitor's timer; charge it explicitly.
        self.extra_cpu_s+=(time.process_time_ns()-t)*1e-9
    def observe(self,valid,version,reasons):
        self.checks.append({'sequence':version.get('sequence'),'valid':bool(valid),'reasons':list(reasons)})
        if valid:return
        # Fault the trusted execution context, never the untrusted packet source.
        self.faulted=True
        if self.procedural:
            self.manual_history_valid=False;self.scope_state['valid']=False
        else:self.registry.graph.invalidate(self.node)
        for receipt in self.scope_state['receipts'] if self.procedural else self.scope_receipts:
            receipt['authorized']=False;receipt['upper']=None
            receipt['status']='PROVISIONAL';receipt['revoked_by_history']=True
    def issue(self,tx,version,tick):
        for event in self.plan.get('witness',{}).get('bounds',{}):
            c=self.registry.cards[(tx.profile,tx.service,tx.policy,event)]
            req={'event':event,'card_seal':c['seal'],'receiver_tick':tick,
                 'assessment_s':tx.deadline if event!='trajectory' else 4.}
            if self.procedural:
                original=procedural_statement_check(self.registry,self.plan,tx,version,req,tick*.1)
                ok=bool(original and self.manual_history_valid)
            else:
                a=authorize_statement(self.registry,self.claim_plan,tx,version,req,tick*.1)
                ok=bool(a['authorized'])
            receipt={'source_scope':self.source,'source':tx.source.identity,
                'sequence':version['sequence'],'iteration':version['iteration'],'tick':tick,
                'event':event,'card_seal':c['seal'],'authorized':ok,
                'upper':c['upper'] if ok else None,'status':'ATTACHED' if ok else 'PROVISIONAL',
                'revoked_by_history':self.faulted,
                'meaning':'unconditional frozen policy/population event bound; no scan-conditional confidence'}
            self.receipts.append(receipt)
            (self.scope_state['receipts'] if self.procedural else self.scope_receipts).append(receipt)
    def output(self):
        out={'scope':self.source,'faulted':self.faulted,'receiver_checks':self.checks,
            'receipts':self.receipts,'status':'PROVISIONAL' if self.faulted else self.plan['status']}
        return out

@contextmanager
def receiver_observer(ledger,fault=None):
    """Optional faults are declared software tests, never stochastic episodes."""
    if base.Transaction is not _Transaction or base.procedural_version_check is not _procedural_version_check:
        raise RuntimeError('receiver observer cannot overlap another scoped execution')
    injected=False;active=None
    def bad_packet(v):
        nonlocal injected
        if fault is None or injected:return None
        injected=True;bad=copy.deepcopy(v);bad.update(fault);return bad
    class ObservedTransaction(_Transaction):
        def __init__(self,*args,**kwargs):
            nonlocal active
            super().__init__(*args,**kwargs);active=self;ledger.bind(self)
        def assess(self,version,elapsed,tick,request,layer='full'):
            bad=bad_packet(version)
            if bad is not None:
                check=super().assess(bad,elapsed,tick,request,layer)
                ledger.observe(check['valid'],bad,check['reasons'])
            check=super().assess(version,elapsed,tick,request,layer)
            ledger.observe(check['valid'],version,check['reasons']);return check
        def install(self,version,tick):
            super().install(version,tick);ledger.issue(self,version,tick)
    def procedural_observer(*args,**kwargs):
        values=list(args);version=values[7];bad=bad_packet(version)
        if bad is not None:
            values[7]=bad;ok=_procedural_version_check(*values,**kwargs)
            # F0 checks the precommit identity in the caller as well.
            ok=ok and (active.commit_id is None or bad.get('commit_id')==active.commit_id)
            ledger.observe(ok,bad,[] if ok else ['procedural_validation'])
        ok=_procedural_version_check(*args,**kwargs)
        actual=ok and (active.commit_id is None or version.get('commit_id')==active.commit_id)
        ledger.observe(actual,version,[] if actual else ['procedural_validation'])
        return ok
    base.Transaction=ObservedTransaction;base.procedural_version_check=procedural_observer
    ledger.control_start_ns=time.process_time_ns()
    try:yield
    finally:
        ledger.control_end_ns=time.process_time_ns()
        base.Transaction=_Transaction;base.procedural_version_check=_procedural_version_check

def execute_with_claims(r,z,policy,cache,clock,service,bindings,plan,registry,procedural=False,execution_id=None,fault=None):
    start=time.process_time_ns()
    ledger=ClaimLedger(registry,plan,execution_id or f"{r['seed']}/{service['id']}/{plan.get('witness',{}).get('task')}",procedural)
    with receiver_observer(ledger,fault):
        result=base.controlled(r,z,policy,cache,clock,service,bindings,plan,registry,procedural)
    claim=ledger.output();result['source_claims']=claim
    result['frozen_component_cpu_s']=result['native_charged_cpu_s']
    result['executed_replay_including_scoring_cpu_s']=(time.process_time_ns()-start)*1e-9
    # Whole replay includes online bookkeeping AND offline truth assertions /
    # scoring. It is an inclusive software execution ledger, not pure online
    # service CPU. The original component ledger plus measured unaccounted
    # claim bookkeeping is retained separately; complete routes time online CPU.
    forecasts=0.
    if policy['model'] and plan.get('status')!='REFUSED':
        forecasts=sum(cache[policy['model']][i][2] for i,s in enumerate(r['trace'])
            if s['iteration']<=result['stop_iteration'])
    result['forecast_charged_cpu_s']=forecasts
    result['inclusive_replay_charged_cpu_s']=(result['front_cpu_s']+result['solver_cpu_s']+
        result['stream_cpu_s']+forecasts+result['executed_replay_including_scoring_cpu_s'])
    outside=((ledger.control_start_ns-start)+(time.process_time_ns()-ledger.control_end_ns))*1e-9
    result['claim_unaccounted_cpu_s']=ledger.extra_cpu_s+outside
    result['native_charged_cpu_s']=result['frozen_component_cpu_s']+result['claim_unaccounted_cpu_s']
    return result
