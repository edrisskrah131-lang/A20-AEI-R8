#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
PYTHON_BIN="${A20_PYTHON:-python}"
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
"$PYTHON_BIN" studies/change_recovery_20261013/validate.py
"$PYTHON_BIN" studies/methodology_review_20261014/run.py --verify
"$PYTHON_BIN" studies/change_campaign_20261014/run.py --verify
"$PYTHON_BIN" studies/cad_surface_20261014/run.py --verify --workers 2
"$PYTHON_BIN" studies/cad_surface_20261014/catalogue.py --verify
"$PYTHON_BIN" studies/cad_surface_20261014/partial_producer.py
"$PYTHON_BIN" studies/lifecycle_20261018/run.py --verify --workers 2
"$PYTHON_BIN" studies/lifecycle_20261018/cold_check.py
"$PYTHON_BIN" studies/validated_recovery_20261018/run.py --verify
"$PYTHON_BIN" studies/validated_recovery_20261018/verify.py
"$PYTHON_BIN" studies/decision_case_20261018/scriptrun.py
"$PYTHON_BIN" studies/decision_case_20261018/independent_check.py
"$PYTHON_BIN" studies/physical_render_20261018/verify.py
"$PYTHON_BIN" reporting/build_complete_supplement.py
"$PYTHON_BIN" reporting/build_methodology_supplement.py
"$PYTHON_BIN" reporting/build_change_campaign.py
"$PYTHON_BIN" reporting/visual_revision.py
"$PYTHON_BIN" reporting/cad_surface_report.py
"$PYTHON_BIN" reporting/build_surface_supplement.py
"$PYTHON_BIN" reporting/lifecycle_report.py
"$PYTHON_BIN" reporting/lifecycle_supplement.py
"$PYTHON_BIN" reporting/integrated_report.py
"$PYTHON_BIN" reporting/integrated_supplement.py
bash build.sh
"$PYTHON_BIN" reporting/verify_lifecycle.py
"$PYTHON_BIN" reporting/verify_visual_revision.py
"$PYTHON_BIN" reporting/verify_integrated.py
"$PYTHON_BIN" reporting/verify_citations.py
