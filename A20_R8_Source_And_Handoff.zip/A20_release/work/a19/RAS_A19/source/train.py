"""Development-only action calibration. All four solvers see each sampled input."""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.spatial.transform import Rotation
from rcp.core import *
from rcp.sensor import Mesh,load_scans

def error(state,truth,bias,map_t,map_rot):
    return np.r_[state.t-truth[:3],log(state.R@exp(truth[3:]).T),state.bias-bias,state.mt-map_t,log(state.mR@exp(map_rot).T)]
def relative_error(state,truth,map_t,map_rot):
    est=(state.t-state.mt)@state.mR
    actual=(truth[:3]-map_t)@exp(map_rot)
    return np.linalg.norm(est-actual),np.linalg.norm(log((state.mR.T@state.R)@(exp(map_rot).T@exp(truth[3:])).T))

def initial_cov(position=.045):
    return np.diag(np.r_[np.full(3,position**2),np.full(3,.006**2),np.full(3,.0015**2),np.full(3,.00015**2),np.full(3,.025**2),np.full(3,.001**2)])

def train(cases,meshes,out):
    x=[];actions=[];outcomes=[];paired=[];cost=[];rows=[];rng=np.random.default_rng(98321)
    for case in cases:
        mesh=Mesh(meshes[case['mesh']]);m=np.load(Path(case['folder'])/'motion.npz')
        scans=list(load_scans(case['folder']));inds=np.linspace(0,len(scans)-1,40,dtype=int)
        for no in inds:
            frame,cloud=scans[no];truth=m['truth'][frame];bias=m['bias'][frame]
            spread=rng.choice([.025,.045,.08,.14]);P=initial_cov(spread)
            # Orthogonal development perturbations test capture and gating regimes.
            ee=rng.normal(size=18)*np.sqrt(np.diag(P));s=JointState(truth[:3]+ee[:3],exp(ee[3:6])@exp(truth[3:]),ee[6:12],np.zeros(3),np.eye(3),P)
            f,J,_=observe(mesh.prior,cloud['xyz'],s,float(rng.choice([1,4,8,12,20])))
            e0=error(s,truth,bias,m['map_t'],m['map_rot']);L=np.linalg.cholesky(P)
            for action in ACTIONS[1:]:
                post,stats,ix,si=register(mesh.prior,cloud['xyz'],s,action)
                ee=error(post,truth,bias,m['map_t'],m['map_rot']);pe,re=relative_error(post,truth,m['map_t'],m['map_rot'])
                label=0 if not stats['accepted'] else (1 if pe<=.10 and re<=.03 else 2)
                x.append(f);actions.append(action);outcomes.append(label);paired.append(np.r_[np.linalg.solve(L,e0),np.linalg.solve(L,ee)][None,:]);cost.append(stats['cpu_s'])
                rows.append({'case':case['name'],'frame':frame,'action':action,'outcome':label,'position_relative_m':float(pe),'rotation_relative_rad':float(re),**stats})
    import csv
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(out/'risk_model.npz',x=np.array(x),action=np.array(actions),outcome=np.array(outcomes),paired=np.array(paired),cost=np.array(cost))
    with open(out/'calibration_jobs.csv','w') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    summary={a:{'n':int(np.sum(np.array(actions)==a)),'rejected':int(np.sum((np.array(actions)==a)&(np.array(outcomes)==0))),'alias':int(np.sum((np.array(actions)==a)&(np.array(outcomes)==2))),'cpu_p95_s':float(np.quantile(np.array(cost)[np.array(actions)==a],.95))} for a in ACTIONS[1:]}
    (out/'calibration_summary.json').write_text(json.dumps(summary,indent=2));print(summary,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('protocol');a=p.parse_args();q=json.loads(Path(a.protocol).read_text());train(q['development'],q['meshes'],q['data_dir'])
