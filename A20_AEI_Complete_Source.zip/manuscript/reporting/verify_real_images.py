"""Check the current article's real-image claims and archived study provenance."""
from pathlib import Path
import hashlib,json,re
import fitz
ROOT=Path(__file__).resolve().parents[1];S=ROOT/'studies/real_defects_20261020';P=ROOT/'paper'
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def expand(p):return re.sub(r'\\input\{([^}]+)\}',lambda m:expand(P/(m[1]+'.tex')),p.read_text())
summary=read(S/'outputs/summary.json');verify=read(S/'outputs/verification.json');prediction=read(S/'outputs/prediction_verification.json')
assert verify['status']==prediction['status']=='PASS'
for rel,h in read(S/'artifact_manifest.json')['files'].items():assert sha(S/rel)==h,rel
provenance=read(P/'figures/visual/real_image_figure_provenance.json')
for rel,h in provenance['sources'].items():assert sha(ROOT/rel)==h,rel
assert any(k.endswith('/final.npz') for k in provenance['sources'])
assert sum(k.endswith('.jpg') for k in provenance['sources'])==5
manifest=read(S/'manifest.json');test={r['uid']:r for r in manifest['records'] if r['split']=='test'};seen=set()
for category,row in enumerate(read(P/'figures/visual/real_image_gallery.json')):
    choices=sorted((r for r in test.values() if any(int(t[0])==category for t in r['targets']) and r['uid'] not in seen),key=lambda r:r['uid'])
    assert choices and row['uid']==choices[0]['uid'];seen.add(row['uid'])
main=fitz.open(P/'main.pdf');supp=fitz.open(P/'supplement.pdf');text=re.sub(r'\s+',' ',' '.join(p.get_text() for p in main));stext=re.sub(r'\s+',' ',' '.join(p.get_text() for p in supp))
for phrase in ['Executable Evidence Management for Aircraft Inspection','Real-image defect detection and report updates','1,339','222','479','33','34','16','Actual held-out defect images','inferred source groups','pixels only']:
    assert phrase.lower() in text.lower(),('missing main evidence',phrase)
for phrase in ['Real-image source audit and detection experiment','0.95','digital producer perturbations','100 subsets of 24','accepted repairs']:
    assert phrase.lower() in stext.lower(),('missing supplementary evidence',phrase)
final=next(r for r in summary['test_performance'] if r['producer']=='final')
for n in [final['tp'],final['gt'],final['fp'],summary['workflow_rows'],summary['valid_repairs']]:assert str(n) in text
source=expand(P/'main.tex');assert 'visual/43_real_image_evidence.pdf' in source and 'visual/44_real_defect_predictions.pdf' in source
assert 'visual/41_challenge_outcomes.pdf' not in source and 'visual/42_actual_correspondences.pdf' not in source
assert 'Declaration of generative AI' not in source and 'pre-confirmation' not in source
if summary['supported_contexts']==0:assert 'None of the 16' in text and 'all quality statements are withheld' in text
for name in ['main','supplement']:
    log=(P/(name+'.log')).read_text();assert not any(x in log for x in ['Overfull','undefined references','LaTeX Error','multiply defined','Label(s) may have changed'])
result=dict(status='PASS',real_image_outputs=verify['detector_outputs_independently_scored'],grouped_events=verify['calibrated_events_recounted'],
    source_groups=222,representative_images=1339,test_images=479,admitted_contexts=summary['supported_contexts'],report_operations=summary['workflow_rows'],valid_repairs=summary['valid_repairs'],
    main_pages=len(main),supplement_pages=len(supp),main_figures=len(re.findall(r'Figure (\d+):',' '.join(p.get_text() for p in main))),
    figure_sources_checked=len(provenance['sources']),model_reinference=prediction,all_original_failed_detections_retained=True)
(ROOT/'audits/real_image_qa.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
