"""Pre-freeze correctness checks on 48 EXCLUDED pilot inputs.

Schema fixtures below contain illustrative integer fields and are used only
for deterministic software tests. They are never research calibration data.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import copy,json,time
import numpy as np
from scipy.stats import beta
import checkpoint
from rcp.core import register
from rcp.sensor import Mesh
from r8_protocol import ROOT,D,PROTOCOL,sha,digest
from r8_contracts import *
from r8_service import load_models,prediction_cache,controlled,state_from
from r8_evaluate import runtime_bindings,relevant_bindings
from r8_policy import policies
from r8_routes import register_source
from r8_geometry import geometry

def fixtures(runtime):
    result=[]
    for profile in ['nominal','unfitted']:
        for s in PROTOCOL['services']:
            for p in policies():
                for e in PROTOCOL['events']:
                    result.append(seal_card(dict(id='/'.join([profile,s['id'],p['id'],e]),profile=profile,service=s['id'],policy=p['id'],event=e,
                        n=4096,k=0,upper=float(beta.ppf(1-.05/528,1,4096)),K=528,family_error=.05,
                        bindings=relevant_bindings(runtime,profile,s,p,e),test_fixture=True)))
    return result

def verify():
    rows=[json.loads(x) for x in (D/'pilot/episodes.jsonl').read_text().splitlines()];clock=json.loads((D/'clock_profile.json').read_text())
    runtime=runtime_bindings();cards=fixtures(runtime);reg=Registry(cards,runtime);models=load_models();ps={p['id']:p for p in policies()}
    maps={m:Mesh(geometry(m)) for m in ['B767','C172','UnfittedAirframe']}
    cold=[];live=[];identical=[];fault=[];maxbudget=0.
    for j,r in enumerate(rows):
        z=np.load(D/'pilot'/f"{r['seed']}.npz");prior=state_from(z,0);cache=prediction_cache(r,models)
        if j<12:
            snapshot=payload_seal(prior);post,stats,_,_=register(maps[r['mesh']].prior,z['cloud'],prior,'converged',cpu_limit=1.)
            reference_index=-1 if r['trace'][-1]['accepted'] else 0
            delta=max(float(np.max(np.abs(getattr(post,k)-z['states_'+k][reference_index]))) for k in ['t','R','bias','mt','mR','P'])
            assert delta<2e-10 and snapshot==payload_seal(prior);cold.append({'seed':r['seed'],'accepted':bool(stats['accepted']),'maximum_state_and_covariance_difference':delta})
        for s in PROTOCOL['services']:
            for pid in ['KG1','FlatCART','CART_Time','FlatRF','ContractRF','Fixed2','Fixed4','Final']:
                p=ps[pid];binding=relevant_bindings(runtime,'nominal',s,p)
                out=controlled(r,z,p,cache,clock,s,binding);maxbudget=max(maxbudget,out['sender_work_s']-s['budget_s'])
                assert out['sender_work_s']<=s['budget_s']+1e-12
                if j<12:
                    pubs,tx,st=register_source(maps[r['mesh']].prior,z['raw'],z['raw_dt'],z['measured_past'],prior,r['mesh'],r['noise'],p,models,clock,s,'nominal','pilot-scan/'+str(r['seed']),binding)
                    journal=json.loads(out['trace']);livecaps=[x[2] for x in pubs]
                    controlledcaps=[x['active_iteration'] for x in journal['installations']]
                    # No pilot publication arrives beyond the four-second horizon.
                    assert livecaps==controlledcaps,(r['seed'],pid,s['id'],livecaps,controlledcaps)
                    assert st['iterations']==out['stop_iteration'] and abs(st['sender_work_s']-out['sender_work_s'])<1e-12
                    live.append({'seed':r['seed'],'policy':pid,'service':s['id'],'publications':livecaps,'work_difference_s':st['sender_work_s']-out['sender_work_s']})
        s=PROTOCOL['services'][1];p=ps['KG1'];b=relevant_bindings(runtime,'nominal',s,p)
        req=dict(profile='nominal',service='standard',task='both_marginals',events=['trajectory','observation'],allowance=.15,elapsed_s=0.,declared_population=True)
        table={('nominal','standard','KG1'):0.};plan=dispatch(reg,table,req,['KG1']);commit=Precommit(req,plan)
        src=source_from_arrays('test/'+str(r['seed']),z['cloud'],prior);commit.bind_source(src)
        try:commit.replace_request(dict(req,task='union'));raise AssertionError('late request accepted')
        except ValueError:pass
        commit.verify(plan)
        full=controlled(r,z,p,cache,clock,s,b,plan,reg);flat=controlled(r,z,p,cache,clock,s,b,plan,reg,procedural=True)
        fields=['work_s','loss_m2s','trajectory_failure','observation_failure','union_failure','stop_iteration','capture_ready']
        assert all(full[k]==flat[k] for k in fields);identical.append({'seed':r['seed'],'fields_identical':fields})
        assert json.loads(full['trace'])['installations']==json.loads(flat['trace'])['installations']
        refusal=controlled(r,z,p,cache,clock,s,b,{'status':'REFUSED'},reg)
        assert refusal['policy']=='REFUSED_PRIOR' and refusal['publications']==0 and refusal['solver_cpu_s']==0. and refusal['observation_failure']==1
        tx=Transaction(src,'KG1','nominal','standard',.3,.012,b);v=dict(source=src.identity,prior=src.prior_seal,data=src.data_seal,sequence=1,iteration=2,rollback=False,
            policy='KG1',profile='nominal',service='standard',bindings=copy.deepcopy(b),replay_to=2,sender_work_s=.002,payload=payload_seal(prior))
        tx.register_payload(1,2,prior)
        checkreq={'event':'observation','assessment_s':.3,'active_bindings':b,'received_payload_seal':payload_seal(prior)}
        cases={'valid':{},'wrong_policy':{'policy':'Fixed2'},'wrong_profile':{'profile':'unfitted'},'wrong_service':{'service':'tight'},
            'wrong_source':{'source':'other'},'wrong_prior':{'prior':'0'*64},'wrong_data':{'data':'0'*64},'stale_version':{'sequence':0},
            'future_replay':{'replay_to':3},'wrong_payload':{'payload':'0'*64},'negative_work':{'sender_work_s':-1.},'budget_overrun':{'sender_work_s':.013},
            'nan_work':{'sender_work_s':float('nan')},'invalid_rollback':{'rollback':True},'hidden_rollback':{'iteration':0},
            'string_rollback':{'rollback':'false'},'missing_rollback':{'rollback':None}}
        for name,changes in cases.items():
            vv=dict(v,**changes);a=tx.assess(vv,.2,2,checkreq)['valid'];bb=procedural_version_check(src,'KG1','nominal','standard',.3,.012,b,vv,.2,2,0,0,False,checkreq,tx.expected_versions)
            assert a==bb==(name=='valid');fault.append({'seed':r['seed'],'kind':'packet','case':name,'accepted':a})
        for name,changes,t in [('wrong_event',{'event':'unknown'},.2),('wrong_assessment',{'assessment_s':.4},.2),('expired',{},.4),('wrong_clock',{},.1),('changed_model',{'active_bindings':dict(b,clock='changed')},.2)]:
            rr=dict(checkreq,**changes);assert not tx.assess(v,t,2,rr)['valid'];fault.append({'seed':r['seed'],'kind':'packet','case':name,'accepted':False})
        altered=prior.copy();altered.t[0]+=.123;forged=payload_seal(altered)
        assert not tx.assess(dict(v,payload=forged),.2,2,dict(checkreq,received_payload_seal=forged))['valid']
        fault.append({'seed':r['seed'],'kind':'packet','case':'joint_payload_and_checksum_rewrite','accepted':False})
        tx.install(v,2);statement=dict(event='observation',card_seal=reg.cards[('nominal','standard','KG1','observation')]['seal'],receiver_tick=2,assessment_s=.3)
        for name,vv,rr,t in [('valid',v,statement,.2),('wrong_event',v,dict(statement,event='union'),.2),('wrong_evidence',v,dict(statement,card_seal='0'*64),.2),
            ('expired',v,statement,.4),('stale_version',dict(v,sequence=0),statement,.2),('wrong_policy',dict(v,policy='FlatCART'),statement,.2),
            ('wrong_source',dict(v,source='other'),statement,.2),('future_replay',dict(v,replay_to=3),statement,.2),('wrong_payload',dict(v,payload='0'*64),statement,.2)]:
            a=authorize_statement(reg,plan,tx,vv,rr,t)['authorized'];bb=procedural_statement_check(reg,plan,tx,vv,rr,t)
            assert a==bb==(name=='valid');fault.append({'seed':r['seed'],'kind':'statement','case':name,'accepted':a})
        atD=dict(v,replay_to=3);atDrequest=dict(statement,receiver_tick=3);tx.install(atD,3)
        assert authorize_statement(reg,plan,tx,atD,atDrequest,3*.1)['authorized']
        assert procedural_statement_check(reg,plan,tx,atD,atDrequest,3*.1)
        fresh=Transaction(src,'KG1','nominal','standard',.3,.012,b)
        fresh.register_payload(1,2,prior)
        assert fresh.assess(atD,3*.1,3,checkreq)['valid']
        fault.append({'seed':r['seed'],'kind':'statement','case':'exact_deadline_tick','accepted':True})
        rollback=dict(v,sequence=2,iteration=0,rollback=True);tx.register_payload(2,0,prior);tx.install(rollback,2)
        resurrection=dict(v,sequence=3);assert not tx.assess(resurrection,.2,2,checkreq)['valid'];fault.append({'seed':r['seed'],'kind':'packet','case':'rollback_resurrection','accepted':False})
        z.close()
    schema=[]
    for key,val in [('upper',float('nan')),('upper',float('inf')),('upper',-.1),('upper',1.1),('n',0),('n',2.5),('n',True),('k',-1),('k',4097),('k',True),('K',240),('family_error',.1)]:
        cc=copy.deepcopy(cards[0]);cc[key]=val
        try:cc=seal_card({k:v for k,v in cc.items() if k!='seal'})
        except ValueError:pass
        assert card_schema(cc);schema.append({'field':key,'value':str(val),'rejected':True})
    invalidate=[]
    for key,expected in [('forecast:rf',168),('artifacts:nominal',264),('event:union',176),('service:standard',132),('clock',528)]:
        rr=Registry(cards,runtime);affected=rr.change(key,'new-version');n=sum(x.startswith('card/') for x in affected);assert n==expected
        invalidate.append({'changed_dependency':key,'revoked_cards':n,'total_cards':528})
    result={'scope':'pre-freeze deterministic tests on excluded pilot inputs; schema fixtures are not calibration observations',
        'cold_native_equivalence':cold,'live_executor_comparisons':live,'full_and_procedural_trace_equivalence':identical,'fault_tests':fault,
        'schema_tests':schema,'dependency_invalidation':invalidate,'maximum_budget_excess_s':maxbudget,'status':'PASS',
        'method_sha256':{p.name:sha(p) for p in sorted((ROOT/'source').glob('r8_*.py'))}}
    target=ROOT/'qa/r8';target.mkdir(exist_ok=True);(target/'preflight.json').write_text(json.dumps(result,indent=2,allow_nan=False))
    print('R8_PREFLIGHT_PASS',len(cold),'cold',len(live),'live',len(identical),'fair traces',len(fault),'faults',flush=True)

if __name__=='__main__':verify()
