"""Fresh rolling scans, immutable priors and actual retained solver prefixes."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import json,time,argparse
import numpy as np
from checkpoint import CheckpointICP
from rcp.core import JointState,exp,log,propagate,register
from train import initial_cov
from prospective import rel_error
from r4_sensor import raw_scan,frontend
from rcp.sensor import Mesh
from r8_protocol import ROOT,D,PROTOCOL,sha
from r8_geometry import build,geometry,route

class CountedICP(CheckpointICP):
    def __init__(self,*args,**kwargs):
        self.query_calls=0;self.checkpoint_calls=0
        super().__init__(*args,**kwargs)
    def terms(self,s):
        self.query_calls+=1
        return super().terms(s)
    def advance(self):
        result=super().advance();self.checkpoint_calls+=1
        return result

def thin_sensor(raw,dt,ring,profile,rng):
    if profile not in ['occlusion','degeneracy']:return raw,dt,ring
    az=np.arctan2(raw[:,1],raw[:,0])
    if profile=='occlusion':
        center=float(rng.uniform(-np.pi,np.pi));keep=np.abs(np.angle(np.exp(1j*(az-center))))>1.1
    else:
        center=float(np.median(az)) if len(az) else 0.;keep=np.abs(np.angle(np.exp(1j*(az-center))))<.25
    return raw[keep],dt[keep],ring[keep]

def generate(seed,phase,profile,meshes,routes,out):
    rng=np.random.default_rng(seed)
    m='UnfittedAirframe' if profile=='unfitted' else str(rng.choice(['B767','C172']))
    level=3 if profile=='map_shift' else int(rng.integers(3))
    noise=float(rng.choice([1.,2.]));sd=float(rng.choice([.08,.12]) if profile=='prior_shift' else rng.choice([.015,.03,.06]))
    path=routes[m];frame=int(rng.integers(100,len(path)-100));truth=path[frame]
    mt=rng.normal(0,.025,3);mR=exp(rng.normal(0,.001,3))
    def inc(j):return np.r_[(path[j+1,:3]-path[j,:3])@exp(path[j,3:]),log(exp(path[j,3:]).T@exp(path[j+1,3:]))]
    bias=rng.normal(0,np.r_[np.full(3,.0015),np.full(3,.00015)]);dens=np.r_[np.full(3,.004),np.full(3,.0004)]
    past=np.array([inc(j)+bias*.1+rng.normal(0,np.sqrt(.1)*dens) for j in range(frame-5,frame)])
    raw,dt,ring=raw_scan(meshes[m,level],truth,inc(frame)/.1,seed*100,frame*.1,mt,mR,noise)
    raw,dt,ring=thin_sensor(raw,dt,ring,profile,rng);cloud,front=frontend(raw,dt,past)
    prior=JointState(truth[:3]+rng.normal(0,sd,3),exp(rng.normal(0,.006,3))@exp(truth[3:]),np.zeros(6),np.zeros(3),np.eye(3),initial_cov(sd))
    future=path[frame:frame+41];observed=np.array([inc(j)+bias*.1+rng.normal(0,np.sqrt(.1)*dens) for j in range(frame,frame+40)])
    start=time.process_time_ns();solver=CountedICP(meshes[m,0].prior,cloud,prior,int(m=='C172'))
    states=[prior.copy()];trace=[]
    while not solver.done:
        post,stats,feature=solver.advance();states.append(post.copy())
        trace.append(dict(**stats,feature=feature.tolist(),cpu_total_s=(time.process_time_ns()-start)*1e-9,
            query_calls=solver.query_calls,checkpoint_calls=solver.checkpoint_calls))
    errors=[];stream_cpu=0.
    for ix,state in enumerate(states):
        state=state.copy();e=[]
        for j in range(41):
            if j:
                t=time.process_time_ns();state=propagate(state,.1,observed[j-1])
                if ix==0:stream_cpu+=(time.process_time_ns()-t)*1e-9
            p,_=rel_error(state,future[j],mt,mR);e.append(float(np.linalg.norm(p)))
        errors.append(e)
    # Every returned source state is retained, enabling actual causal replay.
    arrays={key:np.stack([getattr(s,key) for s in states]) for key in ['t','R','bias','mt','mR','P']}
    target=out/f'{seed}.npz'
    np.savez_compressed(target,cloud=cloud,raw=raw,raw_dt=dt,raw_ring=ring,measured_past=past,
        future_truth=future,increment=observed,map_t=mt,map_R=mR,**{f'states_{k}':v for k,v in arrays.items()})
    return {'phase':phase,'profile':profile,'seed':seed,'mesh':m,'level':level,'noise':noise,'sd':sd,'frame':frame,
        'nraw':len(raw),'npoints':len(cloud),'front_cpu_s':front,'stream_cpu_s':stream_cpu,
        'trace':trace,'error':errors,'input_sha256':sha(target),'provenance':'R8_FRESH_GEOMETRIC_SENSOR_AND_NATIVE_ICP'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');ap.add_argument('--block');args=ap.parse_args()
    if not args.pilot:
        freeze=json.loads((D/'freeze.json').read_text())
        assert freeze['protocol_sha256']==sha(D/'protocol.json')
        assert freeze['collector_sha256']==sha(__file__)
        for p,h in freeze['components'].items():assert sha(ROOT/p)==h,(p,'changed after freeze')
        requested=list(PROTOCOL['blocks']) if not args.block else [args.block]
        if any(not p.endswith('calibration') for p in requested):
            plan=json.loads((D/'selection_freeze.json').read_text())
            for p,h in plan['files'].items():assert sha(D/p)==h,(p,'changed after selection freeze')
    build();meshes={};routes={}
    for m in ['B767','C172','UnfittedAirframe']:
        for level in range(4):meshes[m,level]=Mesh(geometry(m,level))
        routes[m]=np.load(route(m))['pose']
    blocks={'pilot':dict(PROTOCOL['pilot'],profile='nominal')} if args.pilot else PROTOCOL['blocks']
    if args.block:blocks={args.block:blocks[args.block]}
    folder=D/('pilot' if args.pilot else 'episode_inputs');folder.mkdir(exist_ok=True)
    log=D/('pilot/episodes.jsonl' if args.pilot else 'episodes.jsonl')
    done={json.loads(x)['seed'] for x in log.read_text().splitlines()} if log.exists() else set()
    start=time.perf_counter();count=0
    with log.open('a') as f:
        for phase,b in blocks.items():
            for i in range(b['n']):
                seed=b['base']+i
                if seed in done:continue
                r=generate(seed,phase,b['profile'],meshes,routes,folder)
                f.write(json.dumps(r,allow_nan=False,separators=(',',':'))+'\n');f.flush();count+=1
                if count%128==0 or args.pilot:print('R8_COLLECT',phase,i+1,round(time.perf_counter()-start,1),flush=True)
    print('R8_COLLECT_DONE',count,round(time.perf_counter()-start,1),flush=True)

if __name__=='__main__':main()
