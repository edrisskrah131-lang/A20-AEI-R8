# Geometry and condition challenge: image processing and evaluation

This directory owns image processing and numerical analysis. The sibling
`rendering/` directory owns the Blender scene generator, raw PNGs, scene metadata,
exterior-surface meshes and fresh-render checks. Earlier studies are read-only
inputs. This challenge is a separate rendering population; the older statistical
risk cards do not apply to it.

## Executed results

Eight development scenes provide 32 images; 64 independent test scenes provide
256 images and 512 provider evaluations. Development selects `normalized_z1_a8`
from the six declared alternatives. Every test output is retained.

| Test condition | Frozen provider quality failures /64 | Selected normalized provider failures /64 |
|---|---:|---:|
| Nominal | 9 | 22 |
| Raking light | 27 | 26 |
| Oblique view | 11 | 18 |
| Occlusion | 35 | 38 |

The selected provider improves nominal coverage by 1.267 percentage points but
has more complete-quality failures: 104/256 versus 82/256 overall. It is not a
general improvement over the frozen provider. All observed screen acceptances
pass the independently scored quality event (174 and 152 acceptances for the
frozen and normalized providers). The study therefore does not demonstrate
hidden failures accepted by this particular screen. The full paired confidence
intervals and structural-family counts are in `outputs/test/summary.json`.

Independent verification reprocesses all 256 images and exactly reproduces all
512 estimation arrays. A separate plane/barycentric intersection check agrees
with the scoring implementation to 5.56e-16 m on 32 fixed verification cases;
all 256 true-pose mesh checks agree within 7.94e-16 m. No test image has a missed
surface intersection. Image and source hashes, development selection and all
failed cases are verified in `verification.json`.

## Design

The protocol fixes four manufactured structures and four conditions. Development
images contain only longitudinal lap joints and access covers (families 0 and 1).
Test images have new independent scenes from those families and two held-out
structure families: oblique compound-curved joints and asymmetric repair
doublers (families 2 and 3). Every source is rendered under nominal illumination,
raking illumination, an oblique camera view and physical equipment occlusion.
Conditions are paired observations of a source, not independent samples.

The frozen earlier local-dark-contrast decoder is retained as the baseline. One
alternative local-normalized-contrast provider is selected from six declared
settings using development images only. Each family/condition receives equal
weight. Selection minimizes complete-quality failure, then maximizes target
coverage, with lexical ordering as a deterministic final tie-break. All
development settings and all test outcomes are retained; test results never
select a setting or exclude an image. The alternative is a replaceable image
provider comparison, not a claimed new vision algorithm.

`estimate()` receives only CAD points, the initial camera pose, focal length and
image-derived candidate coordinates. Its Hungarian assignment and regularized
Huber pose fit reproduce the earlier implementation. `check_legacy.py` compares
all 72 earlier physical-render images and requires identical candidate,
assignment and fitted-projection arrays. Ground truth and visibility enter only
the later scoring function.

## Outcomes

Coverage counts correct, visible physical targets divided by **all planned CAD
targets**, including missing or occluded targets. Correctness requires the same
target identity and a pixel distance below 8 pixels. A distractor close to an
occluded target therefore cannot count as a correct observation. Visibility is
computed by the renderer and is not available to detection or pose fitting.

All-site mapping error projects every true surface target into the true camera,
casts that pixel's ray from the estimated camera, and intersects the known
exterior CAD skin mesh. The largest distance to the physical target is reported.
This uses the known CAD surface, including raised covers and overlapping sheets;
it is not an unknown-shape reconstruction test. Failed rays remain infinite and
count as mapping failures. A true-pose identity check independently tests that
surface target locations and the exported mesh agree.

The complete-quality diagnostic fails when coverage is below 0.8, the largest
matched residual exceeds 8 pixels, or the maximum all-site mapping error exceeds
8 mm. The **observable screen** uses only matched/planned count at least 0.8 and
the largest matched residual at most 8 pixels. It is a comparator for local
output screening, not population-risk authorization. `accepted_but_failed`
counts cases passing that screen but failing the independently scored quality
event. No result is called risk certified in this challenge.

`summarize.py` reports every family/condition and provider separately. Paired
changes retain the same source. Descriptive bootstrap intervals resample source
scenes within each fixed geometry family and retain all conditions/providers
together. They are not simultaneous certification intervals or estimates for an
unrestricted natural aircraft population. Mapping quantiles use all images,
including infinite failed-ray values; an infinite quantile is serialized as
`null` with its corresponding `unbounded` flag.

## Reproduction

Use one analysis worker with `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1`.
From this directory, with the repository analysis Python environment:

```bash
python check_legacy.py
python unit_checks.py
python summarize.py
python verify.py
```

These commands preserve archived image-processing timings. `verify.py` actually
reprocesses every test image and checks its archived results; it writes only a
verification record. `summarize.py` rebuilds descriptive summaries from the
archived per-image measurements.

To repeat parameter selection and record **new** processing timings, first make
a separate copy of the manuscript source tree, then run in that copy:

```bash
python run.py select --input ../rendering/development
python run.py process --input ../rendering/test --split test
python summarize.py
python verify.py
```

Selection writes `freeze.json`, hashes the analysis/provider code and protocol,
and records every development image used. Test processing refuses a changed
analysis/provider hash and archives raw matched coordinates and fitted camera
poses for both providers. `verify.py` reprocesses all test pixels, independently
recounts identity/visibility/quality, checks image and source hashes, and compares
a separate plane/barycentric ray-intersection implementation on the first scene
of every family. Those verification scenes are selected by seed, never by score.
