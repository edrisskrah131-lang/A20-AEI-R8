"""Redraw manuscript figures from immutable result-table snapshots.

No experiment, selection, risk allocation or numerical producer is changed.
Run with the project's Python environment; output includes PDF/SVG/PNG.
"""
from pathlib import Path
import hashlib, json, shutil
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch, Rectangle, Patch
from matplotlib.colors import ListedColormap

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'paper/figures/visual'
DATA = OUT / 'data'
DATA.mkdir(parents=True, exist_ok=True)
R8 = Path('/workspace/a20-env/study/A20_release/output/A20_AEI_R8/data/r8_final/analysis')
BLUE, TEAL, ORANGE, RED = '#245B91', '#16887B', '#D68A35', '#BF5960'
INK, MUTED, LIGHT, PURPLE = '#263746', '#73818D', '#E9EEF2', '#8A6BA5'
SERVICES = ['relaxed', 'standard', 'tight', 'contended']
PROFILES = ['nominal', 'unfitted']
POLCOL = {'Fixed2': INK, 'Fixed4': PURPLE, 'Final': RED, 'FlatCART': BLUE,
          'FlatRF': ORANGE, 'OldRAVC': TEAL, 'KG1': BLUE, 'Full': TEAL}
MARK = {'Fixed2': 's', 'Fixed4': 'D', 'Final': 'X', 'FlatCART': 'o',
        'FlatRF': '^', 'OldRAVC': 'P', 'KG1': 'o', 'Full': 'D'}
mpl.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
    'axes.titlesize': 8.5, 'axes.labelsize': 8, 'xtick.labelsize': 7,
    'ytick.labelsize': 7, 'legend.fontsize': 7, 'legend.frameon': False,
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.edgecolor': '#ABB6BF', 'axes.labelcolor': INK, 'text.color': INK,
    'xtick.color': INK, 'ytick.color': INK, 'axes.linewidth': .65,
    'lines.linewidth': 1.45, 'pdf.fonttype': 42, 'svg.fonttype': 'none',
    'savefig.facecolor': 'white', 'figure.facecolor': 'white'})
FILES = {}
QA = []

def snapshot(prefix, name, source):
    dest = DATA / f'{prefix}_{name}.csv'
    if not dest.exists(): shutil.copy2(source, dest)
    FILES[str(dest.relative_to(ROOT))] = hashlib.sha256(dest.read_bytes()).hexdigest()
    return pd.read_csv(dest)

def r8(name): return snapshot('r8', name, R8 / (name + '.csv'))
def r9(name): return snapshot('r9', name, ROOT / 'tables' / (name + '.csv'))

def panel(ax, letter, title):
    ax.set_title(title, loc='left', pad=11, fontweight='medium')
    ax.text(-.035, 1.055, letter, transform=ax.transAxes, fontweight='bold',
            fontsize=10, ha='right', va='bottom')

def clean(ax): ax.grid(axis='y', color=LIGHT, lw=.7); ax.set_axisbelow(True)

def save(fig, name):
    fig.canvas.draw()
    # Keep every text object's box inside the exported canvas.
    renderer = fig.canvas.get_renderer()
    bad = []
    hidden = set()
    for ax in fig.axes:
        if not ax.axison:
            hidden.update(id(t) for t in ax.get_xticklabels()+ax.get_yticklabels())
        else:
            for t in ax.get_xticklabels():
                if not min(ax.get_xlim()) <= t.get_position()[0] <= max(ax.get_xlim()): hidden.add(id(t))
            for t in ax.get_yticklabels():
                if not min(ax.get_ylim()) <= t.get_position()[1] <= max(ax.get_ylim()): hidden.add(id(t))
    for item in fig.findobj(mpl.text.Text):
        if not item.get_visible() or not item.get_text() or id(item) in hidden: continue
        b = item.get_window_extent(renderer)
        if b.x0 < -2 or b.y0 < -2 or b.x1 > fig.bbox.width + 2 or b.y1 > fig.bbox.height + 2:
            bad.append(item.get_text())
    QA.append({'figure': name, 'text_outside_canvas': bad})
    for ext in ['pdf', 'svg', 'png']:
        fig.savefig(OUT / f'{name}.{ext}', dpi=300)
    plt.close(fig)

def box(ax, xy, wh, title, body, color=BLUE):
    x,y=xy; w,h=wh
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.008,rounding_size=.035',
                 fc='white', ec=color, lw=1.0))
    ax.annotate(title,(x+.035,y+h),xytext=(0,-7),textcoords='offset points',
                fontsize=8.1,color=color,weight='bold',va='top')
    ax.annotate(body,(x+.035,y+h),xytext=(0,-24),textcoords='offset points',
                fontsize=7.2,va='top',linespacing=1.25)

def arrow(ax, a, b, color=MUTED):
    ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'-|>','lw':1.15,'color':color,
                'shrinkA':2,'shrinkB':2,'mutation_scale':9})


def execution():
    casepath=ROOT/'studies/change_recovery_20261013/outputs/illustrated_case.json'
    case=json.loads(casepath.read_text()); FILES[str(casepath.relative_to(ROOT))]=hashlib.sha256(casepath.read_bytes()).hexdigest()
    camera=ROOT/'studies/change_recovery_20261013/inputs/14300000_camera.npz'
    FILES[str(camera.relative_to(ROOT))]=hashlib.sha256(camera.read_bytes()).hexdigest()
    data=np.load(camera);out=case['outcome']
    fig=plt.figure(figsize=(6.9,5.25))
    a=fig.add_axes([.07,.80,.88,.11]);a.set(xlim=(-.025,.325),ylim=(-.65,1.15));a.axis('off')
    panel(a,'a','Archived source 14300000 · FlatCART · relaxed service')
    a.plot([0,.20],[0,0],c=MUTED,lw=1.2)
    a.plot([.215,.28],[0,0],c=MUTED,lw=1.2,ls=':')
    a.text(.248,0,'//',ha='center',va='center',fontsize=8,color=MUTED,backgroundcolor='white')
    for x,title,col in [(0,'Scan + immutable prior',INK),(.1,'Install version 1',BLUE),(.2,'Install version 2 + capture',TEAL)]:
        a.plot(x,0,'o',c=col,ms=5)
        a.text(x,.32,title,ha='center',fontsize=7.5,color=col)
        a.text(x,-.40,f'{x:.1f} s',ha='center',fontsize=7.5)
    a.text(.30,.28,'Report\nat 1.5 s',ha='center',fontsize=7.3,color=MUTED)
    a.text(.15,-1.0,'Same source is replaced in order; capture uses version 2.',ha='center',fontsize=7.5)
    im=fig.add_axes([.07,.395,.41,.30]);im.axis('off')
    im.imshow(data['rgb'],extent=(-144,144,-108,108),origin='upper')
    xy=data['detected_xy'];im.scatter(xy[:,0],-xy[:,1],s=34,facecolors='none',edgecolors='white',lw=.8)
    im.set_title('b   Actual synthetic RGB + decoded centers',loc='left',pad=7,fontsize=8.2,fontweight='medium')
    im.text(0,-.10,'10 / 10 targets acquired',transform=im.transAxes,fontsize=7.5)
    m=fig.add_axes([.55,.39,.40,.31]);m.axis('off')
    m.text(0,1.02,'c   Measured outputs and eligible evidence',fontsize=8.2,fontweight='medium')
    metrics=[('GSD',f"{out['gsd_m']*1000:.2f} mm/pixel"),('Exposure blur',f"{out['blur_px']:.3f} pixel"),
             ('Reprojection',f"{out['reprojection_px']:.2f} pixels"),('Target displacement',f"{out['association_m']*1000:.1f} mm"),
             ('Full-association card','229 / 2048; U = 0.143973')]
    for i,(label,value) in enumerate(metrics):
        y=.82-i*.16;m.text(0,y,label,fontsize=7.8);m.text(1,y,value,ha='right',fontsize=7.8,color=TEAL if i==4 else INK)
    m.text(0,-.075,'This image passes full-report thresholds.\nIts population service is still uncertified.',fontsize=7.2,color=MUTED,linespacing=1.3)
    c=fig.add_axes([.07,.105,.88,.19]);c.axis('off');c.set(xlim=(0,1),ylim=(0,1))
    c.text(0,1.13,'d   Executed evidence revalidation · same policy · no new calibration',fontsize=8.2,fontweight='medium')
    box(c,(.008,.03),(.277,.94),'Relax requirement','Reprojection: 30 → 50 px\nFull association admitted\nReuse U = 0.143973',TEAL)
    box(c,(.34,.03),(.36,.94),'Decoder version changes','Full association: refused\nReadiness-only: admitted\nOptical component: refused',RED)
    box(c,(.755,.03),(.235,.94),'Restore decoder','Original full association\nAdmitted again\nSame anchor evidence',TEAL)
    arrow(c,(.289,.50),(.335,.50));arrow(c,(.706,.50),(.748,.50))
    fig.text(.07,.027,'Image attachment is post-execution. Detected history faults persist; a trusted successor can recover.',fontsize=7.3,color=MUTED)
    save(fig,'02_execution')

def platforms():
    fig,axs=plt.subplots(2,2,figsize=(6.9,4.25))
    fig.subplots_adjust(left=.025,right=.975,bottom=.035,top=.925,wspace=.035,hspace=.15)
    names=['platform_lab.jpeg','platform_side.jpeg','aircraft_field.jpeg','aircraft_field_portrait.jpeg']
    labels=['Laboratory platform','Sensor integration','Aircraft field setting','Under-fuselage setting']
    for i,(a,name,label) in enumerate(zip(axs.flat,names,labels)):
        a.imshow(plt.imread(ROOT/'paper/figures/r7/hardware_originals'/name));a.axis('off')
        a.set_title(chr(97+i)+'   '+label,loc='left',pad=5,fontsize=8.5)
    save(fig,'03_platforms')

def performance():
    s=r8('controlled_summary');c=r8('certificate_margins');inte=r8('integrated_summary');p=r8('primary_intervals')
    fig,axs=plt.subplots(2,2,figsize=(6.9,5.15))
    fig.subplots_adjust(left=.16,right=.97,bottom=.17,top=.92,wspace=.42,hspace=.62)
    for i,pr in enumerate(PROFILES):
        a=axs[0,i];panel(a,chr(97+i),pr.capitalize()+' · standard service')
        g=s.query('profile==@pr and service=="standard"')
        a.scatter(g.work_s*1000,g.loss_m2s*1000,s=13,c='#C9D2D9',zorder=1)
        cert=c.query('profile==@pr and service=="standard" and event=="union" and upper<=.15').policy
        t=g[g.policy.isin(cert)];a.scatter(t.work_s*1000,t.loss_m2s*1000,s=63,facecolors='none',edgecolors=TEAL,lw=.8)
        for method in ['Fixed2','Fixed4','Final','FlatCART','FlatRF','OldRAVC']:
            v=g[g.policy==method].iloc[0]
            a.scatter(v.work_s*1000,v.loss_m2s*1000,c=POLCOL[method],marker=MARK[method],s=34,zorder=3)
        v=inte.query('profile==@pr and service=="standard" and task=="union" and variant=="Full"').iloc[0]
        a.scatter(v.work_s*1000,v.loss_m2s*1000,c=TEAL,marker='D',s=32,zorder=4)
        a.set(xlabel='Total modeled work (ms)',ylabel='Integrated loss (10⁻³ m² s)');clean(a)
    contrasts=['Full-ValidatedFlat','KG1-FlatCART','KG1-FlatRF','KG1-Fixed2']
    labels=['Full − procedure','Contract-CART − FlatCART','Contract-CART − FlatRF','Contract-CART − Fixed2']
    for j,(metric,scale,xlabel) in enumerate([('loss_m2s',1000,'Paired loss change (10⁻³ m² s)'),('observation_failure',100,'Observation failure change (pp)')]):
        a=axs[1,j];panel(a,chr(99+j),'Paired differences · standard service')
        for i,pr in enumerate(PROFILES):
            g=p.query('profile==@pr and metric==@metric').set_index('contrast').reindex(contrasts)
            y=np.arange(4)+(i-.5)*.17;col=BLUE if i==0 else ORANGE
            a.hlines(y,g.lo_family*scale,g.hi_family*scale,color=col,lw=4,alpha=.25)
            a.hlines(y,g.lo95*scale,g.hi95*scale,color=col,lw=1.45)
            a.scatter(g['mean']*scale,y,c=col,s=15,zorder=3)
        a.axvline(0,c=MUTED,ls=':',lw=.8);a.invert_yaxis()
        a.set_yticks(range(4),labels if j==0 else []);a.tick_params(axis='y',labelsize=6.7)
        a.set_xlabel(xlabel);a.grid(axis='x',color=LIGHT,lw=.65)
    # Bottom-left labels occupy the inter-panel space only if placed outside; use inset labels.
    axs[1,0].set_yticks(range(4),['Full − procedure','KG1 − FlatCART','KG1 − FlatRF','KG1 − Fixed2'])
    for a in axs[1]: a.set_ylim(3.55,-.55)
    h=[Line2D([],[],c=POLCOL[m],marker=MARK[m],lw=0,label=m,ms=4) for m in ['Fixed2','Fixed4','Final','FlatCART','FlatRF','OldRAVC']]
    h += [Line2D([],[],c=TEAL,marker='D',lw=0,label='Full',ms=4),Line2D([],[],marker='o',mfc='none',mec=TEAL,c='none',label='Union admissible',ms=6)]
    fig.legend(handles=h,loc='lower center',ncol=4,bbox_to_anchor=(.53,.012),columnspacing=1.1)
    fig.text(.18,.385,'Blue: nominal     Orange: unfitted',fontsize=7.0,color=MUTED)
    save(fig,'04_performance')

def localization_diagnostics():
    d=r8('module_ablations')
    fig,axs=plt.subplots(2,2,figsize=(6.9,4.8))
    fig.subplots_adjust(left=.12,right=.97,bottom=.14,top=.90,wspace=.42,hspace=.72)
    for j,(metric,scale,label) in enumerate([('loss_delta',1000,'Loss change (10⁻³ m² s)'),('work_delta',1000,'Work change (ms)')]):
        a=axs[0,j];panel(a,chr(97+j),'Effect of the CART time predicate')
        for pr,phase,col in [('nominal','nominal_confirmation',BLUE),('unfitted','geometry_confirmation',ORANGE)]:
            g=d.query('phase==@phase and module=="Time/CART"').set_index('service').reindex(SERVICES)
            a.plot(range(4),g[metric]*scale,marker='o' if pr=='nominal' else '^',
                   ls='-' if pr=='nominal' else '--',c=col,ms=4,label=pr.capitalize())
        a.axhline(0,c=MUTED,lw=.8);a.set_xticks(range(4),['Relaxed','Standard','Tight','Contended'],rotation=20)
        a.set_ylabel(label);clean(a)
    axs[0,0].legend(loc='upper left',fontsize=7)
    a=axs[1,0];panel(a,'c','Attachment checks · 16 invalid fixtures')
    names=['None','Match','Version','History','Procedure'];vals=[16,4,2,0,0]
    a.bar(range(5),vals,color=['#BFC9D1',BLUE,ORANGE,TEAL,PURPLE],width=.58)
    for x,y in enumerate(vals):a.text(x,y+.5,str(y),ha='center',fontsize=8)
    a.set(ylim=(0,19),ylabel='Incorrect attachments');a.set_xticks(range(5),names,rotation=20);clean(a)
    a=axs[1,1];panel(a,'d','Selective invalidation · 528 stored cards')
    names=['RF forecast','Nominal assets','Union event','Standard service','Clock'];vals=[168,264,176,132,528]
    a.barh(range(5),vals,color=RED,height=.58,label='Revoked')
    a.barh(range(5),528-np.array(vals),left=vals,color=LIGHT,height=.58,label='Retained')
    for y,v in enumerate(vals):a.text(v/2,y,str(v),va='center',ha='center',color='white',fontsize=7)
    a.set_yticks(range(5),names,fontsize=7);a.set(ylim=(5.6,-.6),xlim=(0,545),xlabel='Applicable-card count');a.legend(loc='lower right',fontsize=6.8,ncol=2)
    fig.text(.12,.025,'Paired time-predicate effects and fixed attachment/dependency fixtures.',fontsize=7.5,color=MUTED)
    save(fig,'10_localization_diagnostics')

def routes():
    d=r8('route_summary');std=r8('route_std')
    fig,axs=plt.subplots(3,2,figsize=(6.9,5.5))
    fig.subplots_adjust(left=.11,right=.98,bottom=.12,top=.93,wspace=.38,hspace=.52)
    conds=['ordinary','contention','geometric_stress'];methods=['Fixed2','KG1','Full']
    for i,mesh in enumerate(['B767','C172','UnfittedAirframe']):
        g=d[d.mesh==mesh]
        for j,(metric,scale,lab) in enumerate([('rmse_cm',1,'Route RMSE (cm)'),('capture_success_rate',100,'Timely success (%)')]):
            a=axs[i,j];panel(a,chr(97+i*2+j),mesh.replace('UnfittedAirframe','Unfitted airframe'))
            for variant,h in g.groupby('variant'):
                h=h.set_index('condition').reindex(conds)
                assert h[metric].notna().all(), (mesh,variant,metric,'incomplete route conditions')
                a.plot(range(3),h[metric]*scale,c='#CDD5DC',lw=.65,alpha=.6,zorder=1)
            for method in methods:
                h=g[g.variant==method].set_index('condition').reindex(conds)
                e=std.query('mesh==@mesh and variant==@method').set_index('condition').reindex(conds)
                assert h[metric].notna().all() and e[metric].notna().all()
                a.errorbar(np.arange(3)+{'Fixed2':-.06,'KG1':0,'Full':.06}[method],h[metric]*scale,yerr=e[metric]*scale,
                    c=POLCOL[method],marker=MARK[method],ms=4,lw=1.35,capsize=2,zorder=3,label=method)
            a.set_ylabel(lab);a.set_xticks(range(3),['Ordinary','Contention','Stress']);clean(a)
            if j==1:a.set_ylim(0,106)
    fig.legend(*axs[0,0].get_legend_handles_labels(),loc='lower center',ncol=3,bbox_to_anchor=(.52,.012))
    save(fig,'06_routes')

def requests():
    d=r9('all_frozen_plans');r9('configured_support')
    fig,axs=plt.subplots(2,3,figsize=(6.9,5.6))
    fig.subplots_adjust(left=.185,right=.975,bottom=.145,top=.87,wspace=.12,hspace=.72)
    variants=['full','coarser_gsd','more_blur','partial','partial_relaxed','stricter','late_report','single_service']
    labels=['Full','Coarse GSD','More blur','Partial','Relaxed partial','Stricter','Later report','Component']
    tasks=['acquisition','association','report'];contexts=[(p,s) for p in PROFILES for s in SERVICES]
    key={(r.study,r.profile,r.service,r.task,r.variant,r.method):r.status for r in d.query('allowance==.15').itertuples()}
    counts=[]
    for row,study in enumerate(['A','B']):
        supported=extra=0
        for col,task in enumerate(tasks):
            a=axs[row,col];z=np.zeros((8,8))
            for y,v in enumerate(variants):
                for x,(p,service) in enumerate(contexts):
                    sem=key[study,p,service,task,v,'ContractCover']=='AUTHORIZED'
                    direct=key[study,p,service,task,v,'DirectRecertCached']=='AUTHORIZED'
                    assert not sem or direct
                    z[y,x]=1 if sem else (2 if direct else 0)
            supported+=int((z==1).sum());extra+=int((z==2).sum())
            a.imshow(z,cmap=ListedColormap([LIGHT,TEAL,ORANGE]),vmin=0,vmax=2,aspect='auto',interpolation='nearest')
            a.set_yticks(range(8),labels if col==0 else [],fontsize=7.5)
            a.set_xticks(range(8),['R','S','T','C']*2,fontsize=7.5)
            a.set_xticks(np.arange(-.5,8,1),minor=True);a.set_yticks(np.arange(-.5,8,1),minor=True)
            a.grid(which='minor',c='white',lw=.75);a.tick_params(which='minor',bottom=False,left=False)
            a.axvline(3.5,c='white',lw=2.5)
            a.text(1.5,-.90,'Nominal',ha='center',va='bottom',fontsize=7.5)
            a.text(5.5,-.90,'Unfitted',ha='center',va='bottom',fontsize=7.5)
            a.set_title(chr(97+row*3+col)+'   '+{'acquisition':'Acquisition','association':'Association','report':'Reporting'}[task],
                        loc='left',fontsize=8.5,pad=24,fontweight='medium')
        axs[row,0].text(-.01,1.37,'Study '+study,transform=axs[row,0].transAxes,fontsize=9,weight='bold')
        counts.append({'study':study,'semantic_cells':supported,'direct_additional_cells':extra})
    fig.text(.185,.087,'Services: R relaxed · S standard · T tight · C contended. Risk allowance: 0.15.',fontsize=7.5,color=MUTED)
    fig.legend(handles=[Patch(fc=TEAL,label='Contract coverage'),Patch(fc=ORANGE,label='Direct renewal only'),Patch(fc=LIGHT,label='Refused')],
        loc='lower center',ncol=3,bbox_to_anchor=(.55,.023),fontsize=7.2,columnspacing=1)
    (OUT/'request_matrix_counts.json').write_text(json.dumps(counts,indent=2))
    assert counts==[{'study':'A','semantic_cells':24,'direct_additional_cells':6},{'study':'B','semantic_cells':26,'direct_additional_cells':6}]
    save(fig,'07_requests')

def optics():
    fig=plt.figure(figsize=(6.9,3.95))
    for i,(x,name,title) in enumerate([(0.06,'actual_raster_0.png','a   Study A · 192 × 144'),(.53,'actual_raster_1.png','b   Study B · 288 × 216')]):
        a=fig.add_axes([x,.44,.405,.45]);a.imshow(plt.imread(OUT/name));a.axis('off')
        a.set_title(title,loc='left',fontsize=8.5,pad=7)
    a=fig.add_axes([.06,.09,.88,.23]);a.axis('off');a.set(xlim=(0,1),ylim=(0,1))
    box(a,(.02,.06),(.38,.86),'Fixed target sampling','GSD = range / (focal length × incidence)\nSame target, same optics → same GSD',BLUE)
    box(a,(.54,.06),(.45,.86),'Wider region of interest','Changes acquired target coverage\nChanges raster / decoder work\nRequires renewal of affected events',TEAL)
    a.text(.465,.57,'ROI\nedit',ha='center',fontsize=8,color=MUTED)
    arrow(a,(.405,.35),(.52,.35),TEAL)
    fig.text(.06,.035,'Archived excluded pilot 12000000; both panels use the same source and diagnostic landmarks.',fontsize=7,color=MUTED)
    save(fig,'08_optics')



def evidence_node(ax, x, y, title, body, color, fill):
    w,h=.25,.25
    ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,
        boxstyle='round,pad=.007,rounding_size=.025',fc=fill,ec=color,lw=.9,zorder=3))
    ax.text(x,y+.075,title,ha='center',va='center',fontsize=7.2,weight='bold',color=color,zorder=4)
    ax.text(x,y-.055,body,ha='center',va='center',fontsize=6.8,linespacing=1.3,zorder=4)

def relation(ax, a, b, label, loc, color, dashed=False):
    ax.annotate('',xy=b,xytext=a,arrowprops=dict(arrowstyle='-|>',lw=1,
       color=color,linestyle='--' if dashed else '-',mutation_scale=8),zorder=1)
    ax.text(*loc,label,fontsize=6.5,color=color,ha='center',va='center',
        bbox=dict(facecolor='white',edgecolor='none',pad=1.1),zorder=2)

def overview():
    fig=plt.figure(figsize=(6.9,5.15))
    a=fig.add_axes([.035,.715,.28,.23]);a.axis('off')
    a.imshow(plt.imread(OUT/'inspection_concept.png'))
    a.set_title('a   Aircraft-inspection context',loc='left',fontsize=8.1,pad=6)
    a.text(0,-.095,'AI-assisted concept illustration',transform=a.transAxes,fontsize=6.4,color=MUTED)
    t=fig.add_axes([.385,.715,.57,.23]);t.axis('off')
    t.text(0,.91,'A changed component changes evidence applicability',fontsize=8.4,weight='bold')
    t.text(0,.61,'Full association · B / unfitted / relaxed',fontsize=8.1,color=BLUE)
    t.text(0,.34,'Coverage ≥ 0.50    Displacement ≤ 0.10 m\nReprojection ≤ 30 px    Ready = 1    δ = 0.15',fontsize=7.4,linespacing=1.5)
    b=fig.add_axes([.025,.285,.95,.355]);b.axis('off');b.set(xlim=(0,1),ylim=(0,1))
    b.text(.01,1.09,'b   Typed objects and executable relations',fontsize=8.4,weight='bold')
    for x,y,title,body,col,fill in [
      (.17,.79,'REQUEST R','Population + task event\nRisk allowance 0.15',BLUE,'#EEF3F8'),
      (.50,.79,'POLICY / SERVICE','FlatCART\nRelaxed processing',BLUE,'#EEF3F8'),
      (.83,.79,'SOURCE / VERSION','14,300,000 · v2\nCapture at 0.2 s',BLUE,'#EEF3F8'),
      (.17,.20,'PLAN / RECEIPT','Committed policy + card\nSource seal + history',TEAL,'#EAF4F1'),
      (.50,.20,'EVIDENCE CARD','229 / 2048 failures\nU = 0.143973',TEAL,'#EAF4F1'),
      (.83,.20,'PRODUCER','RGB + palette decoder\nRequested dependencies',TEAL,'#EAF4F1')]:
        evidence_node(b,x,y,title,body,col,fill)
    relation(b,(.30,.79),(.365,.79),'selects',(.333,.885),BLUE)
    relation(b,(.63,.79),(.695,.79),'executes',(.663,.885),BLUE)
    relation(b,(.83,.66),(.83,.33),'used at capture',(.83,.495),BLUE)
    relation(b,(.63,.20),(.695,.20),'depends on',(.663,.09),TEAL)
    relation(b,(.37,.20),(.305,.20),'supports',(.333,.09),TEAL)
    relation(b,(.17,.33),(.17,.66),'commits',(.17,.495),TEAL)
    relation(b,(.50,.66),(.50,.33),'effective program',(.50,.50),BLUE,True)
    relation(b,(.37,.28),(.27,.66),'covers R',(.315,.49),TEAL,True)
    c=fig.add_axes([.035,.055,.925,.13]);c.axis('off');c.set(xlim=(0,1),ylim=(0,1))
    c.text(0,1.21,'c   Evidence actions follow the changed relation',fontsize=8.4,weight='bold')
    states=[(.00,TEAL,'Requirement: 30 → 50 px','REUSE · same event anchor'),
            (.355,RED,'Decoder specification changes','WITHDRAW association · retain readiness'),
            (.73,TEAL,'Original decoder restored','RESTORE · same evidence')]
    widths=[.29,.31,.27]
    for (x,col,title,body),w in zip(states,widths):
        c.add_patch(Rectangle((x,.06),w,.83,fc='#F7F9FA',ec='none'))
        c.add_patch(Rectangle((x,.06),.006,.83,fc=col,ec='none'))
        c.text(x+.02,.65,title,fontsize=7.0,color=col,weight='bold')
        c.text(x+.02,.27,body,fontsize=6.1,color=INK)
    arrow(c,(.30,.46),(.345,.46));arrow(c,(.675,.46),(.72,.46))
    save(fig,'01_overview')

def mechanisms():
    path=ROOT/'studies/change_recovery_20261013/outputs/change_cases.csv'
    d=snapshot('change','cases',path)
    eligible=d[(d.method=='ContractCover') & d.before_authorized & (d.edit!='unchanged')]
    g=eligible.groupby('edit',sort=False).after_authorized.agg(['size','sum'])
    assert len(eligible)==705 and len(g)==15 and (g['size']==47).all()
    retained=g['sum'].astype(int).to_numpy();withdrawn=47-retained
    assert withdrawn.sum()==489 and retained.sum()==216 and eligible.recovered.all()
    labels={'target_plan':'Target plan','geometry_sampler':'Geometry sampler','focal_px':'Focal length',
       'exposure_s':'Exposure','motion_sampler':'Motion sampler','roi':'ROI',
       'renderer':'Renderer','detector':'Pixel decoder','pixel_noise':'Pixel noise',
       'localization':'Localization','capture_sampler':'Capture sampler','camera_clock':'Camera clock',
       'report_queue':'Report queue','roi_and_clock':'ROI + camera clock','decoder_and_clock':'Decoder + camera clock'}
    fig=plt.figure(figsize=(6.9,5.7))
    a=fig.add_axes([.215,.18,.375,.69]);panel(a,'a','Selective handling by edited provider')
    a.barh(range(len(g)),withdrawn,color=RED,height=.64,label='Withdraw')
    a.barh(range(len(g)),retained,left=withdrawn,color=TEAL,height=.64,label='Retain')
    for i,(w,r) in enumerate(zip(withdrawn,retained)):
        if w:a.text(w/2,i,str(w),ha='center',va='center',color='white',fontsize=6.8)
        if r:a.text(w+r/2,i,str(r),ha='center',va='center',color='white',fontsize=6.8)
    a.set_yticks(range(len(g)),[labels[k] for k in g.index],fontsize=6.8)
    a.set(xlim=(0,47),ylim=(len(g)-.35,-.65),xlabel='Initially admitted contexts per edit')
    a.set_xticks([0,10,20,30,40,47]);a.grid(axis='x',color=LIGHT,lw=.6);a.set_axisbelow(True)
    a.legend(loc='upper center',bbox_to_anchor=(.50,-.105),ncol=2,fontsize=7)
    b=fig.add_axes([.69,.57,.275,.30]);b.axis('off');panel(b,'b','All eligible changes')
    b.text(.5,.85,'705',ha='center',fontsize=25,weight='bold',color=INK)
    b.text(.5,.72,'47 contexts × 15 edits',ha='center',fontsize=7.2,color=MUTED)
    b.add_patch(Rectangle((0,.43),489/705,.17,fc=RED))
    b.add_patch(Rectangle((489/705,.43),216/705,.17,fc=TEAL))
    b.text((489/705)/2,.515,'489',ha='center',va='center',color='white',fontsize=10,weight='bold')
    b.text((1+489/705)/2,.515,'216',ha='center',va='center',color='white',fontsize=10,weight='bold')
    b.text(.0,.32,'WITHDRAW',color=RED,fontsize=7,weight='bold')
    b.text(1,.32,'RETAIN',ha='right',color=TEAL,fontsize=7,weight='bold')
    b.text(.5,.12,'705 / 705 restored',ha='center',color=TEAL,fontsize=9,weight='bold')
    b.text(.5,.01,'after restoring the original producers',ha='center',color=MUTED,fontsize=6.4)
    c=fig.add_axes([.725,.22,.24,.22]);panel(c,'c','Diagnostic control errors')
    c.barh([0,1,2],[489,216,0],height=.47,color=[RED,ORANGE,TEAL])
    c.set_yticks([0,1,2],['Stale plan','Whole producer','Contract'],fontsize=6.5)
    c.set(xlim=(0,570),ylim=(2.8,-.8),xlabel='Incorrect evidence decisions')
    c.set_xticks([0,250,500]);c.grid(axis='x',color=LIGHT,lw=.6);c.set_axisbelow(True)
    for y,n in enumerate([489,216,0]):c.text(n+12,y,str(n),va='center',fontsize=7.5)
    fig.text(.215,.055,'Declared dependency oracle: missed withdrawals 0 · unnecessary refusals 0 · restoration mismatches 0',fontsize=6.8,color=MUTED)
    fig.text(.215,.025,'Full matrix: 5,120 configurations per method, including unchanged controls and initial refusals.',fontsize=6.8,color=MUTED)
    save(fig,'05_mechanisms')

def boundaries():
    d=r9('certificate_prefix_sensitivity')
    timing=snapshot('audit','report_timing',Path('/workspace/a20-r9-review/manuscript/report_timing_lower_bounds.csv'))
    snapshot('audit','unique_support',Path('/workspace/a20-r9-review/manuscript/support_deduplicated.csv'))
    bench=snapshot('r9','preparation_benchmark',ROOT/'audits/preparation_benchmark.csv')
    costs=snapshot('change','matched_support_cost',ROOT/'studies/change_recovery_20261013/outputs/matched_support_cost.csv')
    matched=costs.query('study=="combined"').set_index('method')
    assert matched.matched_unique_requests.eq(47).all()
    fig=plt.figure(figsize=(6.9,6.25))
    a=fig.add_axes([.115,.665,.39,.225]);panel(a,'a','Same requests and fixed policies')
    vals=[matched.loc[m,'required_record_evaluations']/1000 for m in ['Anchor reuse','Direct event preparation']]
    a.bar(range(2),vals,color=[TEAL,ORANGE],width=.51)
    for i,v in enumerate(vals):a.text(i,v+2,f'{v*1000:,.0f}',ha='center',fontsize=8,weight='bold')
    a.set_xticks([0,1],['Anchor reuse','Direct event\npreparation'])
    a.set(ylim=(0,86),ylabel='Event–record evaluations (thousands)');clean(a)
    a.text(.5,78,'20% fewer evaluations',ha='center',fontsize=9,color=TEAL,weight='bold')
    a.text(.5,69,'47 identical contexts · 23 vs 29 proof cards',ha='center',fontsize=6.6,color=MUTED)
    b=fig.add_axes([.65,.665,.315,.225]);panel(b,'b','Complete catalogues')
    g=bench.query('stage=="cold_event_preparation"').groupby('method').first()
    vals=[g.loc[m,'record_evaluations']/1e6 for m in ['ContractCover','DirectRecertCached']]
    b.bar(range(2),vals,color=[TEAL,ORANGE],width=.51)
    for i,v in enumerate(vals):b.text(i,v+.12,f'{v:.2f} M',ha='center',fontsize=8)
    b.set_xticks([0,1],['Anchor reuse','Direct renewal'])
    b.set(ylim=(0,7.35),ylabel='Event–record evaluations (millions)');clean(b)
    b.text(.5,6.9,'53.66% fewer evaluations',ha='center',fontsize=7.5,color=TEAL)
    b.text(.5,6.1,'Support differs: 47 vs 59 unique contexts',ha='center',fontsize=6.4,color=MUTED)
    c=fig.add_axes([.115,.36,.85,.18]);panel(c,'c','Fixed-event calibration-size sensitivity')
    for ident,label,col in zip(d.id.unique(),['Component optics','Full association','Full acquisition'],[TEAL,BLUE,ORANGE]):
        z=d.query('id==@ident and beta==.05').sort_values('n')
        c.plot(z.n,z.upper,'o-',c=col,ms=3,label=label)
    c.axhline(.15,c=RED,ls='--',lw=.85);c.set_xscale('log',base=2)
    c.set_xticks([128,256,512,1024,2048],['128','256','512','1024','2048'])
    c.set(xlim=(110,2350),ylim=(0,.66),ylabel='Risk upper bound',xlabel='Nested calibration inputs');clean(c)
    c.legend(loc='upper right',fontsize=6.7,ncol=3)
    e=fig.add_axes([.115,.105,.85,.12]);panel(e,'d','Image-age lower bound from the virtual-service clock')
    z=np.array([[timing.query('study==@study and service==@se').image_age_lower_bound_s.iloc[0] for se in SERVICES] for study in ['A','B']])
    fail=z>1.8;assert int(fail.sum())==5
    e.imshow(fail.astype(int),cmap=ListedColormap(['#DFEDEB','#F0D8DA']),vmin=0,vmax=1,aspect='auto')
    for y in range(2):
        for x in range(4):e.text(x,y,f'{z[y,x]:.3g} s',ha='center',va='center',fontsize=8,color=RED if fail[y,x] else TEAL)
    e.set_xticks(range(4),[q.capitalize() for q in SERVICES]);e.set_yticks([0,1],['A · 62.5 ms','B · 125 ms'])
    e.set_xticks(np.arange(-.5,4,1),minor=True);e.set_yticks(np.arange(-.5,2,1),minor=True);e.grid(which='minor',c='white',lw=2)
    e.tick_params(which='minor',bottom=False,left=False)
    fig.text(.115,.034,'Full-report image-age limit: 1.8 s. Red: timing infeasible; green: other task conditions still apply.',fontsize=6.7,color=MUTED)
    save(fig,'09_boundaries')


if __name__=='__main__':
    overview();execution();platforms();performance();mechanisms();routes();requests();optics();boundaries();localization_diagnostics()
    (OUT/'figure_provenance.json').write_text(json.dumps({'sources':FILES,'result_tables_unchanged':True,
      'concept_image':'concept_provenance.json','software_fixture_counts':[16,4,2,0,0],
      'new_change_study':'studies/change_recovery_20261013/outputs/results.json',
      'route_error_bars':'sample standard deviations over four matched route inputs; not confidence intervals',
      'primary_matched_support':{'contexts':47,'anchor_record_evaluations':49152,'direct_record_evaluations':61440},
      'primary_change_counts':{'edits':705,'withdrawals':489,'retentions':216},
      'request_labels_retained':192,'unique_event_contexts_per_study':160},indent=2))
    (OUT/'figure_canvas_qa.json').write_text(json.dumps(QA,indent=2))
    print(json.dumps({'figures':len(QA),'canvas_issues':[q for q in QA if q['text_outside_canvas']]},indent=2))
