"""Generate manuscript results and complete SI from executed campaign outputs."""
from pathlib import Path
import json,pandas as pd
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'studies/change_campaign_20261014/outputs'
RESULT=json.loads((OUT/'results.json').read_text())
assert RESULT['status']=='PASS'
summary=pd.read_csv(OUT/'change_summary.csv').set_index('edit')
faults=['roi_focal_fault','decoder_ready_fault','exposure_focal_fault','roi_clock_fault']
active=sum(int(summary.loc[k,'active_faults']) for k in faults)
veto=sum(int(summary.loc[k,'vetoed_updates']) for k in faults)
assert active==veto
assert summary.loc[['roi','focal','exposure','decoder'],'vetoed_updates'].eq(0).all()
names={'roi':'ROI expansion','focal':'Focal length','exposure':'Exposure','decoder':'Decoder off',
       'roi_focal_fault':'ROI--focal coupling','decoder_ready_fault':'Decoder--readiness coupling',
       'exposure_focal_fault':'Exposure--focal coupling','roi_clock_fault':'ROI--clock coupling'}
parts=[r'\subsection{Producer changes across the camera operating range}',
'''The camera campaign recomputes eight task quantities for 2,560 paired updates across 320 configurations. ROI, focal-length, exposure and decoder updates retain the declared distinction between affected and unaffected quantities: all 1,280 declared-update cases pass the regression gate. Focal-length edits affect optical sampling, exposure affects blur, and decoder changes affect acquisition and association while preserving capture-time readiness.''',
f'''Conditional fault fixtures create {active:,} activated updates among 1,280 fault cases. Every activated update exposes an undeclared output change and is vetoed; inactive branches retain the declared update behavior. ROI--focal coupling is activated in {int(summary.loc['roi_focal_fault','active_faults'])} cases, decoder--readiness in {int(summary.loc['decoder_ready_fault','active_faults'])}, exposure--focal in {int(summary.loc['exposure_focal_fault','active_faults'])}, and ROI--clock in {int(summary.loc['roi_clock_fault','active_faults'])}. Figure~\\ref{{fig:mechanisms}} shows the changed quantities and the conditional activation counts.''',
'''These decisions use actual output differences, rather than a second implementation of the dependency table. The gate identifies the specific missing relation: optical sampling for a focal-length coupling, readiness for a decoder coupling, or delivery quantities for a clock coupling. Correcting the registered producer specification identifies which evidence requires renewal.''',
r'''\begin{figure}[!htbp]\centering\includegraphics[width=\linewidth]{visual/13_change_campaign.pdf}
\caption{Executed camera-change campaign. (a) Quantities changed across 320 camera configurations per intervention; highlighted cells expose changes outside the declared provider projection. (b) Conditional fault activation and regression veto counts. Geometry, rasterization, decoding and task scoring are recomputed within each pair.}\label{fig:mechanisms}\end{figure}''',
'''A separate declaration-model matrix evaluates 705 changes of initially admitted contexts: 489 withdraw affected statements and 216 retain applicable statements. All restoration checks agree. The complete 15,360-decision matrix and invalid-record checks establish execution-state consistency alongside the numerical campaign.''']
(ROOT/'paper/sections/change_campaign_results.tex').write_text('\n\n'.join(parts)+'\n')
abstract=f'''Engineering changes alter the evidence supporting inspection outputs. We develop executable operating contracts that connect CAD-guided aircraft inspection requirements to numerical services and reusable statistical statements. A typed representation and unit-aware compiler link task events, processing policies, producer dependencies and numerical versions. Requirement containment supports evidence reuse, registered dependency signatures support selective renewal, and persistent execution history connects evidence to the output produced. A reuse-first route with exact-event fallback retains all 59 directly supported request contexts under fixed numerical policies. Selected evidence preparation requires 63,488 event--record evaluations rather than 73,728, a 13.89\\% reduction. A controlled camera campaign recomputes 2,560 paired updates across 320 configurations, covering pose, focal length, exposure and brightness variation. Four conditional coupling classes activate in {active} cases; output-difference auditing identifies each activated update while accepting all 1,280 declared updates. The underlying calibration and test studies include 13,824 localization episodes, 36 continuous-route inputs and 12,800 image-task inputs. The framework coordinates evidence retention, withdrawal and restoration across localization, image acquisition, CAD association and reporting.'''
(ROOT/'paper/sections/visual_abstract.tex').write_text(abstract+'\n')
si=[r'\section{Controlled camera-change campaign}',
'''Five archived CAD/capture templates supply nominal A sources 13200000 and 13201023, unfitted A source 13300000, nominal B source 14200000 and unfitted B source 14300000. Each supplies 64 independently seeded camera perturbations. These are simulated configurations conditional on the templates; they add no population calibration cards. Camera translation and rotation have standard deviations 0.04 m and 0.001 rad. Focal length, exposure and brightness are uniform over 1600--2000 pixels, 4--8 ms and 0.70--1.15. Baseline and expanded ROIs are 384 by 288 and 512 by 384. Existing CAD addresses and installed localization estimates are retained.''',
'''The paired producer executes geometry, BVH raycasting, Gaussian exposure filtering, pixel decoding and task scoring. Focal-length updates multiply the original value by 1.20; exposure updates multiply it by 1.50; decoder updates suppress decoded output. Each pair uses the same noise seed. ROI--focal faults multiply focal length by 1.15 when the original focal length is at least 1800 pixels. Decoder--readiness faults make readiness depend on decoded output when exposure is at least 6 ms. Exposure--focal faults multiply focal length by 1.03 when edited exposure exceeds 10 ms. ROI--clock faults scale the camera operation clock with ROI area. Each faulty update advertises only its initiating provider change.''',
r'''\begin{table}[htbp]\centering\small
\caption{Executed updates, conditional activation and regression vetoes.}\begin{tabular}{@{}lrrrr@{}}\toprule
Update & Pairs & Active faults & Vetoes & Undeclared changes\\\midrule''']
for k,row in summary.iterrows():
 si.append(f"{names[k]} & {int(row.configurations)} & {int(row.active_faults)} & {int(row.vetoed_updates)} & {int(row.undeclared_quantity_changes)}"+r'\\')
si+= [r'\bottomrule\end{tabular}\end{table}',
'''The configurations, all 20,480 paired quantity comparisons, change-case decisions and output summaries are supplied as CSV. The frozen script and input hashes permit standalone regeneration. Numerical verification compares recomputed values at tolerance 1e-10; CPU timing is not used as the detection criterion. Original primary risk cards and policy plans remain unchanged.''']
(ROOT/'paper/sections/change_campaign_supplement.tex').write_text('\n\n'.join(si)+'\n')
print('Built camera-campaign manuscript and supplementary results:',active,'activated faults')
