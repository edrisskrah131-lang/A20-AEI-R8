# Innovation Hangar v2 — released version 1

Dataset project: https://universe.roboflow.com/innovation-hangar/innovation-hangar-v2

Release: https://universe.roboflow.com/innovation-hangar/innovation-hangar-v2/dataset/1

Public author mirror: https://github.com/cparyoto/Aircraft-Skin-Defect-Detection-YOLOv9-Vs.-RT-DETR/tree/main/datasets_2

The dataset project and mirrored export identify Creative Commons Attribution 4.0: https://creativecommons.org/licenses/by/4.0/ . Credit: Innovation Hangar dataset contributors and the authors of the public mirror and accompanying study, Nutchanon Suvittawat, Christian Kurniawan, Jetanat Datephanyawat, Jordan Tay, Zhihao Liu, De Wen Soh and Nuno Antunes Ribeiro. See *Advances in Aircraft Skin Defect Detection Using Computer Vision: A Survey and Comparison of YOLOv9 and RT-DETR Performance*, Aerospace 12(4), 356 (2025), https://doi.org/10.3390/aerospace12040356 . The upstream project's image-source credits remain applicable; dataset membership does not establish that every photograph was newly captured by these authors.

Changes in this redistribution: select representative images, infer source groups, replace filenames with stable identifiers, reassign complete groups to new partitions, and convert polygon labels to enclosing boxes. Released image bytes remain unchanged. `manifest.json` maps every representative to its upstream path and hashes. `data/source_annotations` preserves the selected original labels; `annotation_sources.json` maps these to converted training/scoring labels. The numeric image-gain operations in the experiment are applied in memory and identified as digital transformations.

The author-repository ZIP and full upstream augmented export are not needed to reproduce inference: all selected images, annotations, detector weights and output arrays are in this delivery. Upstream ZIP/tree hashes are retained in `source_metadata.json` and the repository dataset audit. No private project agreement or personal identifier is included.

Ultralytics implementation: https://github.com/ultralytics/ultralytics , version 8.3.232, AGPL-3.0. Official pretrained model: https://github.com/ultralytics/assets/releases/tag/v8.3.0 . This experiment uses YOLO11n and supplies its fine-tuned checkpoints with their original licensing obligations. This record does not relicense upstream software or weights.

Ultralytics corresponding implementation source for the pinned release: https://github.com/ultralytics/ultralytics/tree/v8.3.232 . The unmodified upstream AGPL license text is included as `LICENSE-ULTRALYTICS-AGPL-3.0.txt`. Training/inference modifications and configuration used here are supplied in this study directory.
