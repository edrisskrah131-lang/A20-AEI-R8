"""Read-only verification of the delivered prospective evidence bundle."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import json
from collections import Counter
from datetime import datetime,timezone
import numpy as np,pandas as pd
from scipy.stats import beta
from r8_protocol import ROOT,D,PROTOCOL,sha,digest
from r8_evaluate import assert_freeze
from r8_contracts import card_schema

def main():
    f0=assert_freeze();f1=json.loads((D/'selection_freeze.json').read_text())
    assert sha(ROOT/'qa/r8/preflight.json')==f0['preflight_sha256']
    assert sha(ROOT/'qa/r8/preserved_assets_manifest.json')==f0['retained_assets_manifest_sha256']
    for p,h in json.loads((ROOT/'qa/r8/preserved_assets_manifest.json').read_text()).items():assert sha(ROOT/p)==h,('preserved',p)
    for group in ['files','calibration_result_files']:
        for p,h in f1[group].items():assert sha(D/p)==h,('F1',p)
    amendment=json.loads((D/'claim_layer_freeze.json').read_text())
    for p,h in amendment['components'].items():assert sha(ROOT/p)==h,('V3',p)
    assert amendment['audit_sha256']==sha(ROOT/'qa/r8/claim_layer_audit.json')
    binding=json.loads((D/'attachment_selection_binding.json').read_text())
    assert binding['F1_sha256']==sha(D/'selection_freeze.json') and binding['amendment_sha256']==sha(D/'claim_layer_freeze.json')
    rows=[json.loads(x) for x in (D/'episodes.jsonl').read_text().splitlines()]
    assert len(rows)==13824 and len({r['seed'] for r in rows})==13824
    counts=Counter(r['phase'] for r in rows)
    for phase,spec in PROTOCOL['blocks'].items():
        seeds=sorted(r['seed'] for r in rows if r['phase']==phase);assert seeds==list(range(spec['base'],spec['base']+spec['n']))
    for r in rows:assert sha(D/'episode_inputs'/f"{r['seed']}.npz")==r['input_sha256']
    cal_inputs=json.loads((D/'calibration_inputs_manifest.json').read_text());original={r['seed']:r for r in rows}
    for r in cal_inputs:assert digest(original[r['seed']])==r['record_sha256']
    outcome_rows=0;confirmation_receipts=0
    for folder in ['results','integrated']:
        for m in sorted((D/folder).glob('*/chunk_*.json')):
            body=json.loads(m.read_text());path=m.with_suffix('.csv.gz');assert sha(path)==body['sha256'];outcome_rows+=body['rows'] if folder=='results' else 0
            if folder=='integrated':confirmation_receipts+=body['rows'];assert body['F1_sha256']==sha(D/'selection_freeze.json')
    assert outcome_rows==13824*88 and confirmation_receipts==131072
    cards=json.loads((D/'event_cards.json').read_text());assert len(cards)==528
    for c in cards:assert not card_schema(c)
    routes=pd.read_csv(D/'route_results.csv');assert len(routes)==432 and not routes.duplicated(['mesh','condition','rep','variant']).any()
    metrics=['rmse_cm','p95_cm','p99_cm','max_cm','loss_m2s','capture_ready','capture_success','fail_samples','event_after_5s']
    for r in routes.itertuples():
        folder=D/'routes'/f'{r.mesh}_{r.condition}_{r.rep}';manifest=json.loads((folder/'inputs_manifest.json').read_text())
        assert sha(folder/'inputs.npz')==manifest['input_sha256']
        with np.load(folder/f'{r.variant}.npz') as z:
            trace=z['trace'];captures=z['captures'];e=trace[:,1];assert len(trace)==6000
            recomputed=dict(rmse_cm=np.sqrt(np.mean(e**2))*100,p95_cm=np.quantile(e,.95)*100,p99_cm=np.quantile(e,.99)*100,
                max_cm=e.max()*100,loss_m2s=np.sum(e**2)*.1,capture_ready=captures[:,1].sum(),capture_success=captures[:,2].sum(),
                fail_samples=(e[50:]>.1).sum(),event_after_5s=int(np.any(e[50:]>.1)))
            for metric in metrics:assert np.isclose(recomputed[metric],getattr(r,metric),rtol=0,atol=2e-9),(r.mesh,r.condition,r.rep,r.variant,metric)
        raw=json.loads((folder/f'{r.variant}.json').read_text());assert raw['executor_sha256']==sha(ROOT/'source/r8_routes.py')
        assert raw['result']['authorized_episode_cards']==0
    for p in ['provider_audit.json','real_card_fault_audit.json','collector_recovery_audit.json']:
        assert json.loads((ROOT/'qa/r8'/p).read_text())['status']=='PASS'
    result={'status':'PASS','utc':datetime.now(timezone.utc).isoformat(),'independent_episode_inputs':13824,'phase_counts':dict(counts),
        'controlled_paired_outcomes':outcome_rows,'integrated_repeated_executions':confirmation_receipts,
        'direct_route_executions':432,'independent_route_inputs':36,'simultaneous_CP_cards':528,
        'preserved_assets_unchanged':True,'frozen_methods_models_clock_and_plans_unchanged':True,'all_original_seed_denominators_preserved':True,
        'native_CPU':'archived measurements; numerical recomputation does not pretend to recreate identical CPU on a new host'}
    (ROOT/'qa/r8/final_evidence_verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
if __name__=='__main__':main()
