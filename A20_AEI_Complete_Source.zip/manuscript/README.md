# Executable Evidence Management for CAD-Guided Aircraft Inspection

Current integrated article: **14 pages, 8 figures**. Supplement: **46 pages**. The article files are `paper/main.tex` and `paper/sections/integrated_*.tex`; earlier article sections remain archived and are not current build entry points. Public PDFs are distributed separately from this editable source package.

## Current research and evidence

- Controlled scene population: 256 calibration + 256 held-out scenes, six producer configurations, 3,072 outputs; another 128 stress scenes. Four layout families, missing sites, occlusion, surface appearance and physical-to-CAD discrepancy are independently sampled. Existing data remain unchanged.
- Fixed 48-event calibration family: all complete methods admit 41 contexts at allowance 0.15. Containment+fallback uses 6,656 record evaluations versus 10,752 for exact dependency caching, a 38.10% reduction. Catalogue CPU 2.725 ms versus 4.290 ms; large numerical renewal savings come from ordinary DAG caching shared by the matched methods.
- Independent held-out family check: all 41 calibration-selected programs have upper bounds at most 0.074568224 under a separate 95% simultaneous 48-event test statement. The complete 256-scene test population is used without issuance filtering. Main confidence result concerns the preselected service; source integrity does not imply a conditional risk bound for an arbitrary selected output subset.
- Validated recovery: 256 stored image sources × 8 requests × 2 fault types × 13 steps. Three implementations with the same authoritative information agree. All 3,072 eligible recovery scenarios (1,536 distinct source/request pairs) recover; the earlier irreversible latch recovers 0. Wrong numerical origin remains rejected. Thirteen independent check groups include API bypass, repair mutation, replay and truth separation.
- Blender Cycles transfer: 24 independent synthetic panels × 3 configurations = 72 actual path-traced images. Geometric rivets, panel seams, metal/painted materials, area illumination and radiometric gain. The existing pixel detector and estimator are unchanged. Association failures are 9/24 baseline, 5/24 gain and 10/24 lower light. This is a distinct renderer population, with no transfer of the controlled population's risk cards.
- All 72 images were independently reprocessed. Six images from the first painted and metallic sources were freshly rerendered with exactly matching pixels and correspondence arrays. Original rendered pixels, camera/geometry metadata, all outcomes and source hashes are included.

The illustrative main case is always the first controlled held-out source, 202619100. Its actual image passes both exposure configurations, while population complete-service support changes; the paper distinguishes these two observations explicitly. Authenticated repair fixes a binding, not a statistically refused producer.

## Build documents and figures

Python dependencies are listed in `requirements-artifacts.txt`; the manuscript also needs a LaTeX installation with elsarticle. The configured workspace Python is `/workspace/a20-r9-env/venv/bin/python`.

```sh
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python reporting/integrated_report.py
python reporting/integrated_supplement.py
python reporting/lifecycle_supplement.py
bash build.sh
python reporting/verify_lifecycle.py
python reporting/verify_visual_revision.py
python reporting/verify_integrated.py
```

The source ZIP preserves publication figure PDFs and editable figure scripts. Duplicate compiled article PDFs and reproducible presentation previews (`paper/figures/visual/*.png` and `*.svg`) are omitted to keep one source package below GitHub's file-size limit. These previews regenerate from preserved numerical data and original experimental pixels. Main and supplement PDFs are supplied through the repository download index.

## Reproduce the numerical studies

```sh
A20_PYTHON=python bash reproduce_artifacts.sh
```

This reruns the controlled studies and regression checks, verifies recovery and independently reprocesses every Cycles image, then regenerates figures/documents and checks consistency. The larger historical population release remains in its original repository archive. All previously packaged study files are preserved byte-for-byte.

Current studies:

- `studies/lifecycle_20261018/`:controlled images, stage cache, calibrated evidence, actual CPU timings and historical latch traces.
- `studies/validated_recovery_20261018/`:trusted registry, authenticated repair, matched implementations, replayed numerical records and independent invariants.
- `studies/decision_case_20261018/`:first-source case, allowance sensitivity, independent test bounds, threshold table and recovery trace.
- `studies/physical_render_20261018/`:Blender scene recipe, complete rawimages, manifests, pixel processing, verification and fresh-render reproduction.

To render a fresh physical panel independently, use Blender 4.3.2:

```sh
blender -b -t 4 --python studies/physical_render_20261018/render.py -- --seed 202618800 --samples 32 --threads 4 --out /tmp/a20-fresh-render
```

The study README documents renderer versus image-processing environments, gain versus shutter exposure, camera coordinates and all scoring definitions. Its runner skips already complete scenes; use a fresh output directory for a true rerender.

## Integrity and scope

`MANIFEST.json` covers every shipped source payload. `audits/integrated_qa.json` and the per-study verification/reproduction JSONs record executed checks. Component regression tests finite inputs against declared interfaces. The registry is a trusted in-process authority with an authentication fixture, not a distributed-security benchmark. Simulation outputs describe their specified populations; source declarations and photo credits are consolidated at the end of the supplement.

No AI-generated image is used. Original and credited open photographs provide engineering context. All quantitative experimental images are produced by the archived renderers. The immutable earlier experiments, including the regular-grid and numerical scheduling studies, remain available in the supplementary source history.
