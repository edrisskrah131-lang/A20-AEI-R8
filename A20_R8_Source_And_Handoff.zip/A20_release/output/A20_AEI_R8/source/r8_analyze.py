"""Frozen-protocol descriptive analysis and 16 pre-specified paired intervals."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd
from scipy.stats import beta
from r8_protocol import ROOT,D,PROTOCOL,sha
from r8_evaluate import assert_freeze,read_results

A=D/'analysis';A.mkdir(exist_ok=True)
EVENTS=PROTOCOL['events']
METRICS=['loss_m2s','work_s','native_charged_cpu_s','sender_work_s','rmse_m','p95_m','max_m',
 'trajectory_failure','observation_failure','union_failure','capture_ready','capture_success',
 'stop_iteration','publications','installed','budget_stop','profile_guard','deadline_guard','first_delivery_s',
 'front_cpu_s','solver_cpu_s','decision_cpu_s','receiver_cpu_s','stream_cpu_s','seal_cpu_s']
KEYS=['seed','phase','profile','mesh','service','policy','level','noise','sd']
def save(df,name):df.to_csv(A/(name+'.csv'),index=False)
def cp(k,n,confidence=.95):return 1. if k==n else float(beta.ppf(1-(1-confidence)/528,k+1,n-k))
def calibration():
    assert_freeze();f=json.loads((D/'selection_freeze.json').read_text())
    for p,h in f['files'].items():assert sha(D/p)==h
    frame=read_results(['nominal_calibration','geometry_calibration'],['seed','profile','service','policy']+[e+'_failure' for e in EVENTS])
    margins=pd.read_csv(D/'calibration.csv');save(margins,'certificate_margins')
    rec=[]
    for (profile,service,policy),g in frame.groupby(['profile','service','policy'],sort=True):
        g=g.sort_values('seed');assert len(g)==4096 and g.seed.nunique()==4096
        for n in PROTOCOL['calibration_sensitivity_n']:
            for confidence in PROTOCOL['sensitivity_confidence']:
                for e in EVENTS:
                    k=int(g.iloc[:n][e+'_failure'].sum());u=cp(k,n,confidence)
                    for allowance in PROTOCOL['risk_allowances']:
                        rec.append(dict(profile=profile,service=service,policy=policy,event=e,n=n,k=k,confidence=confidence,
                            allowance=allowance,upper=u,margin=allowance-u,admissible=int(u<=allowance),empirical=k/n))
    sens=pd.DataFrame(rec);save(sens,'certificate_sensitivity');counts=[]
    for context,g in sens.groupby(['profile','service','n','confidence','allowance']):
        for task in PROTOCOL['request_types']:
            ev=['trajectory','observation'] if task=='both_marginals' else [task]
            good=[p for p,h in g[g.event.isin(ev)].groupby('policy') if h.admissible.sum()==len(ev)]
            counts.append(dict(zip(['profile','service','n','confidence','allowance'],context))|{'task':task,'certified_policies':len(good),'catalogue':22})
    save(pd.DataFrame(counts),'certified_policy_counts')
    plans=json.loads((D/'selection_plans.json').read_text());records=[]
    for p in plans:
        req=p['request'];a=p['Full'];b=p['TaskAwareFlatValidated']
        assert (a['status'],a['policy'])==(b['status'],b['policy'])
        bounds=a.get('witness',{}).get('bounds',{})
        records.append({k:req[k] for k in ['profile','service','task','allowance']}|dict(status=a['status'],policy=a['policy'],
            eligible=len(a.get('eligible',[])),max_requested_upper=max(bounds.values(),default=np.nan),
            margin=req['allowance']-max(bounds.values()) if bounds else np.nan,
            trajectory_only=p['TrajectoryOnly']['policy'],same_as_validated_flat=True))
    save(pd.DataFrame(records),'request_feasibility');print('CALIBRATION_ANALYSIS',len(margins),len(sens),len(records),flush=True)

def paired_bootstrap(d):
    rng=np.random.default_rng(PROTOCOL['statistics']['seed']);d=np.asarray(d,float);means=[]
    for start in range(0,32000,256):means.append(d[rng.integers(0,len(d),size=(min(256,32000-start),len(d)))].mean(1))
    x=np.concatenate(means);q=.05/16/2
    return dict(mean=float(d.mean()),lo95=float(np.quantile(x,.025)),hi95=float(np.quantile(x,.975)),
        lo_family=float(np.quantile(x,q)),hi_family=float(np.quantile(x,1-q)),n=len(d),resamples=32000)

def controlled():
    phases=[p for p in PROTOCOL['blocks'] if not p.endswith('calibration')]
    frame=read_results(phases,KEYS+METRICS);assert len(frame)==5632*88
    assert frame.groupby(['phase','service','policy']).seed.nunique().eq(frame.groupby(['phase','service','policy']).size()).all()
    summary=frame.groupby(['phase','profile','service','policy'])[METRICS].mean().reset_index()
    nn=frame.groupby(['phase','profile','service','policy']).size().rename('n').reset_index();summary=summary.merge(nn)
    tails=[]
    for context,g in frame.groupby(['phase','profile','service','policy']):
        l=g.loss_m2s.to_numpy();k=max(1,int(np.ceil(.05*len(l))))
        tails.append(dict(zip(['phase','profile','service','policy'],context))|dict(n=len(l),loss_p95=float(np.quantile(l,.95)),
            loss_p99=float(np.quantile(l,.99)),loss_largest5pct_mean=float(np.sort(l)[-k:].mean()),
            max_error_p95=float(np.quantile(g.max_m,.95)),max_error_p99=float(np.quantile(g.max_m,.99)),worst_error_m=float(g.max_m.max())))
    save(summary,'controlled_summary');save(pd.DataFrame(tails),'controlled_tails')
    save(frame.groupby(['phase','profile','mesh','service','policy'])[METRICS].mean().reset_index(),'geometry_summary')
    ablations=[];influence=[]
    for (phase,service),g in frame.groupby(['phase','service']):
        pairs=[('CART_Time','FlatCART','Time/CART'),('KG1','CART_Time','Profile/CART'),('KG1','FlatCART','FullAction/CART'),
            ('RF_Time','FlatRF','Time/RF'),('ContractRF','RF_Time','Profile/RF'),('ContractRF','FlatRF','FullAction/RF')]
        for target,baseline,label in pairs:
            x=g[g.policy==target].set_index('seed');y=g[g.policy==baseline].set_index('seed');assert x.index.equals(y.index)
            dd=x.loss_m2s-y.loss_m2s
            ablations.append(dict(phase=phase,service=service,module=label,target=target,baseline=baseline,n=len(x),
                stop_changed=int((x.stop_iteration!=y.stop_iteration).sum()),publication_count_changed=int((x.publications!=y.publications).sum()),
                trajectory_changed=int((x.trajectory_failure!=y.trajectory_failure).sum()),observation_changed=int((x.observation_failure!=y.observation_failure).sum()),
                loss_delta=float(dd.mean()),work_delta=float((x.work_s-y.work_s).mean()),
                observation_delta=float((x.observation_failure-y.observation_failure).mean()),
                guard_rate=float(x.profile_guard.mean()) if 'Profile' in label else float(x.deadline_guard.mean())))
        for target,baseline in [('KG1','Fixed2'),('KG1','FlatCART'),('KG1','FlatRF')]:
            x=g[g.policy==target].set_index('seed');y=g[g.policy==baseline].set_index('seed');d=(y.loss_m2s-x.loss_m2s).sort_values(ascending=False)
            net=float(d.sum());top=float(d.iloc[:2].sum());positive=float(d.clip(lower=0).sum())
            influence.append(dict(phase=phase,service=service,target=target,baseline=baseline,n=len(d),mean_gain=float(d.mean()),
                top2_seeds=';'.join(map(str,d.index[:2])),top2_net_share=top/net if abs(net)>1e-14 else np.nan,
                top2_positive_share=top/positive if positive>1e-14 else np.nan,mean_gain_without_top2=float(d.iloc[2:].mean()),
                improved=int((d>1e-14).sum()),worsened=int((d<-1e-14).sum()),tied=int((abs(d)<=1e-14).sum())))
    save(pd.DataFrame(ablations),'module_ablations');save(pd.DataFrame(influence),'influence')
    front=[]
    for context,g in summary.groupby(['phase','profile','service']):
        for r in g.to_dict('records'):
            dominated=((g.work_s<=r['work_s'])&(g.loss_m2s<=r['loss_m2s'])&((g.work_s<r['work_s'])|(g.loss_m2s<r['loss_m2s']))).any()
            front.append({k:r[k] for k in ['phase','profile','service','policy','loss_m2s','work_s','capture_success']}|dict(pareto=int(not dominated)))
    save(pd.DataFrame(front),'pareto')
    print('CONTROLLED_ANALYSIS',len(frame),'outcomes;',frame.seed.nunique(),'inputs',flush=True)
    return frame

def integrated(frame):
    files=sorted((D/'integrated').glob('*/chunk_*.csv.gz'));assert len(files)==64
    cols=KEYS+METRICS+['variant','task','allowance','admission','chosen_policy','dispatch_cpu_s','eligible_policies','source_claims',
        'claim_unaccounted_cpu_s','frozen_component_cpu_s','executed_replay_including_scoring_cpu_s','inclusive_replay_charged_cpu_s']
    f=pd.concat([pd.read_csv(p,usecols=cols) for p in files],ignore_index=True);assert len(f)==131072
    f['receipt_coverage']=f.source_claims.map(lambda s:any(x['authorized'] for x in json.loads(s)['receipts']))
    f['all_requested_receipt_coverage']=[all(e in {x['event'] for x in json.loads(s)['receipts'] if x['authorized']} for e in
        (['trajectory','observation'] if task=='both_marginals' else [task])) for s,task in zip(f.source_claims,f.task)]
    f['authorized_receipt_count']=f.source_claims.map(lambda s:sum(x['authorized'] for x in json.loads(s)['receipts']))
    f['receiver_history_fault']=f.source_claims.map(lambda s:json.loads(s)['faulted'])
    assert not f.receiver_history_fault.any()
    assert (f.admission.isin(['SELECTED','REFUSED'])).all()
    gg=['profile','service','task','variant'];nums=METRICS+['dispatch_cpu_s','receipt_coverage','claim_unaccounted_cpu_s',
        'executed_replay_including_scoring_cpu_s','inclusive_replay_charged_cpu_s']
    nums+=['all_requested_receipt_coverage','authorized_receipt_count']
    summary=f.groupby(gg)[nums].mean().reset_index();summary['n']=2048;save(summary,'integrated_summary')
    save(f.groupby(gg+['admission','chosen_policy'],dropna=False).size().rename('n').reset_index(),'integrated_admission')
    intervals=[]
    for profile in ['nominal','unfitted']:
        g=frame[(frame.profile==profile)&(frame.service=='standard')]
        h=f[(f.profile==profile)&(f.service=='standard')&(f.task=='union')]
        pairs=[(h[h.variant=='Full'],h[h.variant=='TaskAwareFlatValidated'],'Full-ValidatedFlat'),
            (g[g.policy=='KG1'],g[g.policy=='FlatCART'],'KG1-FlatCART'),(g[g.policy=='KG1'],g[g.policy=='FlatRF'],'KG1-FlatRF'),
            (g[g.policy=='KG1'],g[g.policy=='Fixed2'],'KG1-Fixed2')]
        for x,y,label in pairs:
            x=x.sort_values('seed').set_index('seed');y=y.sort_values('seed').set_index('seed');assert x.index.equals(y.index)
            for metric in ['loss_m2s','observation_failure']:
                intervals.append(dict(profile=profile,contrast=label,metric=metric)|paired_bootstrap(x[metric]-y[metric]))
    assert len(intervals)==16;save(pd.DataFrame(intervals),'primary_intervals')
    equality=[]
    for ctx,g in f.groupby(['profile','service','task']):
        x=g[g.variant=='Full'].sort_values('seed');y=g[g.variant=='TaskAwareFlatValidated'].sort_values('seed')
        assert np.array_equal(x.seed.to_numpy(),y.seed.to_numpy())
        keys=['work_s','loss_m2s','trajectory_failure','observation_failure','union_failure','capture_ready','capture_success','stop_iteration']
        assert all(np.allclose(x[k],y[k],rtol=0,atol=2e-15) for k in keys)
        assert x.source_claims.tolist()==y.source_claims.tolist()
        equality.append(dict(zip(['profile','service','task'],ctx))|dict(n=2048,numeric_event_claim_differences=0))
    save(pd.DataFrame(equality),'full_flat_equivalence');print('INTEGRATED_ANALYSIS',len(f),'executions, 16 intervals',flush=True)

def routes():
    f=pd.read_csv(D/'route_results.csv');assert len(f)==432
    assert f.groupby(['mesh','condition','variant']).size().eq(4).all()
    f['capture_success_rate']=f.capture_success/f.opportunities;f['capture_ready_rate']=f.capture_ready/f.opportunities
    f['failure_time_rate']=f.fail_samples/(6000-50);f['drop_rate']=f.dropped/f.opportunities
    nums=[c for c in f.select_dtypes('number').columns if c not in ['rep']]
    save(f.groupby(['mesh','condition','variant'])[nums].mean().reset_index(),'route_summary')
    save(f.groupby(['mesh','condition','variant'])[nums].std().reset_index(),'route_std')
    pairs=[]
    for ctx,g in f.groupby(['mesh','condition']):
        for target,baseline in [('KG1','Fixed2'),('KG1','FlatCART'),('KG1','FlatRF'),('Full','TaskAwareFlatValidated'),('KG1','KG1_Held')]:
            x=g[g.variant==target].sort_values('rep');y=g[g.variant==baseline].sort_values('rep')
            for metric in ['rmse_cm','p95_cm','p99_cm','direct_online_cpu_s','capture_success_rate','drop_rate','policy_switches']:
                pairs.append(dict(zip(['mesh','condition'],ctx))|dict(target=target,baseline=baseline,metric=metric,n_routes=4,
                    delta_mean=float((x[metric].to_numpy()-y[metric].to_numpy()).mean()),
                    delta_each=';'.join(format(v,'.12g') for v in x[metric].to_numpy()-y[metric].to_numpy())))
    save(pd.DataFrame(pairs),'route_paired_descriptive');print('ROUTE_ANALYSIS',len(f),'executions, 36 route inputs',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--calibration-only',action='store_true');a=p.parse_args();calibration()
    if not a.calibration_only:
        frame=controlled();integrated(frame);routes()
        (A/'analysis_manifest.json').write_text(json.dumps({'script_sha256':sha(__file__),'protocol_sha256':sha(D/'protocol.json'),
            'F0_sha256':sha(D/'freeze.json'),'F1_sha256':sha(D/'selection_freeze.json'),
            'tables':{p.name:sha(p) for p in sorted(A.glob('*.csv'))},'all_prespecified_outcomes_retained':True},indent=2))
