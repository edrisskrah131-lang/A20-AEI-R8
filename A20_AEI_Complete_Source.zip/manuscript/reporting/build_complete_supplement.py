"""Build concise current-study supplement tables from preserved CSVs."""
from pathlib import Path
import pandas as pd, shutil
ROOT=Path(__file__).resolve().parents[1]
SECTIONS=ROOT/'paper/sections'
DATA=ROOT/'paper/figures/visual/data'
DEST=ROOT/'tables'

def escape(s):return str(s).replace('_',r'\_').replace('%',r'\%')
def longtable(frame,headers,caption):
    s=r'\small\setlength{\tabcolsep}{3.5pt}'+'\n'+r'\begin{longtable}{@{}'+('l'*len(headers))+r'@{}}'+'\n'
    s+=r'\caption{'+caption+r'}\\\toprule'+'\n'+' & '.join(headers)+r'\\\midrule\endfirsthead'+'\n'
    s+=r'\toprule '+' & '.join(headers)+r'\\\midrule\endhead'+'\n'
    for row in frame.itertuples(index=False,name=None):s+=' & '.join(escape(x) for x in row)+r'\\'+'\n'
    return s+r'\bottomrule\end{longtable}\normalsize'+'\n'

def main():
    s=''
    f=pd.read_csv(DATA/'r8_controlled_summary.csv').query('profile in ["nominal","unfitted"]')
    out=pd.DataFrame({'Population':f.profile,'Service':f.service,'Policy':f.policy,'n':f.n,
        'loss':[f'{v*1000:.3f}' for v in f.loss_m2s],'work':[f'{v*1000:.3f}' for v in f.work_s],
        'obs':[f'{v*100:.2f}' for v in f.observation_failure],'union':[f'{v*100:.2f}' for v in f.union_failure]})
    s+=r'\section{Complete localization confirmation catalogue}'+'\n'
    s+=longtable(out,['Population','Service','Policy','$n$','$L$','$W$','Obs.','Union'],
        r'All 22 policies, both populations and all four services. Loss $L$ is $10^{-3}$ m$^2$s; modeled work $W$ is ms; failure columns are percentages. Every source is retained. Native CPU and full tails are in the accompanying CSV.')
    r=pd.read_csv(DATA/'r8_route_summary.csv')
    out=pd.DataFrame({'Geometry':r.mesh.replace('UnfittedAirframe','Unfitted'),'Condition':r.condition.replace('geometric_stress','stress'),
      'Method':r.variant,'RMSE':[f'{v:.3f}' for v in r.rmse_cm],
      'Success':[f'{v*100:.2f}' for v in r.capture_success_rate],
      'CPU':[f'{v:.3f}' for v in r.direct_online_cpu_s]})
    s+=r'\section{Complete continuous-route catalogue}'+'\n'
    s+=longtable(out,['Geometry','Condition','Method','RMSE (cm)',r'Success (\%)','CPU (s)'],
        'All 12 methods and nine geometry/condition combinations. Each mean summarizes four matched 600-s inputs. CPU covers the complete online loop; route evidence remains descriptive.')
    f=pd.read_csv(DEST/'confirmation_geometry_statistics.csv').query('service=="standard"')
    out=pd.DataFrame({'Study':f.study,'Geometry':f.mesh.replace('UnfittedAirframe','Unfitted'),'Policy':f.policy,'n':f.n,
      'RMSE':[f'{v*100:.3f}' for v in f.rmse_m],'work':[f'{v:.3f}' for v in f.total_work_ms],
      'union':[f'{v*100:.2f}' for v in f.union_failure]})
    s+=r'\section{Image-task numerical confirmation and stress}'+'\n'
    s+=longtable(out,['Study','Geometry','Policy','$n$','RMSE (cm)','Work (ms)',r'Union (\%)'],
        'All eight numerical policies by geometry for the standard service. Total work includes the virtual camera. The complete 192-row all-service table is supplied as CSV; geometry summaries carry no conditional risk certificate.')
    f=pd.read_csv(DEST/'unsupported_stress_statistics.csv').query('service=="standard"')
    out=pd.DataFrame({'Study':f.study,'Stress':f.profile,'Geometry':f.mesh.replace('UnfittedAirframe','Unfitted'),
      'Policy':f.policy,'n':f.n,'RMSE':[f'{v*100:.2f}' for v in f.rmse_m],
      'union':[f'{v*100:.1f}' for v in f.union_failure]})
    s+=longtable(out,['Study','Stress','Geometry','Policy','$n$','RMSE (cm)',r'Union (\%)'],
        'All standard-service unsupported image stress strata and policies. The full 512-row all-service table is retained as CSV. These observations carry no transferred population-risk statement.')
    (SECTIONS/'complete_result_tables.tex').write_text(s)

    results=pd.read_csv(ROOT/'studies/change_recovery_20261013/outputs/change_summary.csv')
    out=pd.DataFrame({'Method':results.method.replace({'ProceduralCoverValidated':'Complete procedure','ContractCover':'Contract','DirectRecertCached':'Cached direct'}),
      'Cases':results.decisions,'Missed':results.missed_invalidation,'Excess':results.unnecessary_refusal,
      'Restore':results.restore_mismatch})
    s=r'\subsection{Conformance and common-support accounting}'+'\n'
    s+=longtable(out,['Method','Decisions','Missed','Unnecessary','Restore'],
        'Executed deterministic software decisions over the same prespecified change contexts. Counts are conformance fixtures, not independent population samples or fault-rate estimates.')
    costs=pd.read_csv(ROOT/'studies/change_recovery_20261013/outputs/matched_support_cost.csv')
    out=costs.copy();out['method']=out['method'].replace({'Direct event preparation':'Direct events'});out.columns=['Study','Method','Requests','Cards','Record visits']
    s+=longtable(out,list(out.columns),'Matched support with the same precommitted policies. Counted work to construct selected proof catalogues from archived calibration records; it excludes source acquisition and producer execution. Both complete implementations share anchor accounting.')
    (SECTIONS/'complete_case_tables.tex').write_text(s)

if __name__=='__main__':main()
