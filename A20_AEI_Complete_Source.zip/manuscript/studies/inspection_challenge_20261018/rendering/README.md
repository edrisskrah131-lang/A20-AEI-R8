# Structural inspection imaging challenge

The study renders actual curved inspection structures with Blender Cycles, exports the CAD skin used by the renderer, and supplies unretouched RGB pixels to an independent analysis program. It tests capture-to-CAD association under geometric and photometric changes. It does not create labels for defect classification.

Four construction families change the surface topology:

1. **Longitudinal lap:** overlapping curved sheets with a physical raised edge, sealant and staggered fastener rows.
2. **Access hatch:** curved rounded cover, independently sampled width/height/corner radius, gasket, hinge mounts, recessed handle and perimeter fasteners.
3. **Compound diagonal joint:** stronger curvature in two axes, cross curvature, diagonal overlapping sheet and a raised circular service-port assembly.
4. **Repair doubler:** independently perturbed asymmetric formed patch, sealant bed, two perimeter fastener rows and coating/metal variation.

The meshes contain three-dimensional fastener heads, machined rims, selected sealant collars and on-surface abrasion geometry. Metal/paint/primer materials have roughness, reflectance and fine normal variation. Area emitters produce directional illumination and specular reflections. The geometric surface changes are distinct from image-level color or noise perturbations.

## Fixed split and paired conditions

- Development: 8 independent scenes, 4 each in families 0/1, 4 conditions per scene: **32 images**.
- Test: 64 independent scenes, 16 in each family, 4 conditions per scene: **256 images**.
- Families 2/3 are excluded from detector selection. They had renderer-only engineering pilots before the freeze; they are not claimed to have been unseen by the renderer author. Families 0/1 test scenes have independent scene seeds.
- Conditions: `nominal`, `raking_light` (emitter direction/intensity and fill), `oblique_view` (camera pose), and `occlusion` (physical foreground hose/tool housing).
- All images: 768 × 576 pixels, maximum 32 Cycles samples/pixel, adaptive threshold 0.02, fixed AgX transform; no denoising or edited pixel images.

`protocol.json` fixes every source seed, family, condition and figure selection. `freeze.json` records source/protocol hashes before development rendering. The runner will not start test rendering until `../analysis/freeze.json` exists. No test outcomes determine source selection, material changes or detector parameters.

The nominal first test scene of each family is the fixed gallery selection (`202640000`, `202641000`, `202642000`, `202643000`). The occluded first family-3 scene is the fixed obstruction illustration. Every remaining test success and failure is retained.

## Coordinate and truth interface

All world coordinates are metres. Each scene JSON contains:

- `cad`, `actual`: N × 3 ideal CAD and independently displaced physical surface sites; their Z coordinates are sampled from the exact exported triangle skin.
- `missing`: N Boolean flags. A missing head does not remove its planned location from scoring denominators.
- `surface_mesh_file`: NPZ with `vertices` and triangle `faces`; includes base skin, elevated panels, patches and their physical rims. It excludes fastener heads, service-port accessories and foreground occluders.
- `translation_error`, `rotation_error`: the synthetic prior perturbations, with per-axis standard deviations of 3 mm and 0.001 rad.
- Per condition: RGB filename, pinhole focal length in pixels, camera origin, and rotation with columns right/down/forward; `blender_projected_pixels` uses centered image coordinates, +Y down.
- `visible`: a scoring diagnostic. The site is in frame, nonmissing and not blocked by another object. Its own head/rim/sealant collar does not count as an obstruction. Other ray hits more than 0.15 mm before the surface footpoint are occluding. The detector/estimator does not receive this flag.

The independent analysis program matches from CAD, image pixels and the synthetic prior. Ground truth enters only the subsequent correctness and mapping audit. Mapping is evaluated at all planned physical-site rays using the exact skin mesh, so coarse-surface interpolation is not silently included as a pose error.

## Development corrections

Initial engineering pilots exposed coarse radial-mesh interpolation that buried fasteners and displaced surface footpoints. Before development/test sampling, every patch boundary was densified to at most 6 mm and both ideal and physical footpoint heights were sampled from the exported mesh. Independent checks of all four corrected pilot families produced true-pose-to-mesh errors below 6 × 10⁻¹⁶ m. The initial pilots are retained as development history, not analysis inputs.

## Literature basis

Jovančević et al., *Matching CAD Model and Image Features for Robot Navigation and Inspection of an Aircraft*, ICPRAM 2016, DOI 10.5220/0005756303590366, motivates explicit geometric parts, low-contrast image conditions and independent CAD/image feature matching. Amosov et al., *Deep Neural Network Recognition of Rivet Joint Defects in Aircraft Products*, Sensors 22 (2022) 3417, DOI 10.3390/s22093417, documents distinct fastener types and sensitivity to real panel appearance. The present renderer is an independent controlled construction, not a replication of either paper's photographs or trained detector.

## Reproduce

Blender 4.3.2 with its NumPy 2.2.4 environment renders the images. The external Python driver requires only the standard library. Scene manifests preserve exact installed versions and per-image CPU/elapsed times.

```sh
python studies/inspection_challenge_20261018/rendering/run.py --phase development --threads 4
# Run the separate development-selection analysis to write analysis/freeze.json.
python studies/inspection_challenge_20261018/rendering/run.py --phase test --threads 4
python studies/inspection_challenge_20261018/rendering/verify.py
python studies/inspection_challenge_20261018/rendering/reproduce_check.py
```

The runner resumes completed sources without altering them. `*_manifest.json` records raw-file hashes; its wall time is the current driver invocation, not the sum of resumed invocations. Each scene records the actual renderer thread count and each image's CPU/elapsed time. `invocation_history.json` documents the resource-only development restart from two to four threads.

PNG headers contain dates and timing strings. Fresh-render reproducibility is assessed by exact decoded RGB pixels, exported mesh arrays and camera/geometry metadata, rather than by the PNG container's byte hash.
