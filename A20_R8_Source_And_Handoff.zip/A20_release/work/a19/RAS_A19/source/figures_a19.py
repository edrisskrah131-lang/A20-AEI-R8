"""Constituent-control and fixed-policy attribution figures.

Python style is inherited from the manuscript; every point comes from a
recorded source or full-route run. No learned policy is fitted here.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from figures_a18 import ROOT,F,save,panel,grid,COL

C={'always_full':'#53616D','full_4s':'#CA963F','always_tempered':'#725BA7',
   'always_converged':'#6B8058','joint':'#007F86','cascade_sc':'#BA7956','cascade_cf':'#818A93'}
L={'always_full':'Full','full_4s':'Full / 4 s','always_tempered':'Tempered',
   'always_converged':'Converged','joint':'Reuse-DP','cascade_sc':'Cascade S–C',
   'cascade_cf':'Cascade C–F','joint_nocache':'No-cache'}

def sources():
    s=pd.read_csv(ROOT/'data/control_snapshot_summary.csv')
    c=pd.read_csv(ROOT/'data/control_snapshot_contrasts.csv')
    old=pd.read_csv(ROOT/'data/confirmation_contrasts.csv').query('ratio==1 and price==.3 and metric=="loss" and baseline=="full"').rename(columns={'baseline':'comparator'})
    old['comparator']='always_full';c=pd.concat([c,old],ignore_index=True)
    fig,axs=grid(2,2,5.7)
    for j,mesh in enumerate(['B767','C172']):
        ax=axs[0,j]
        names=['always_full','always_converged','cascade_sc','joint_nocache']
        d=c.query('mesh==@mesh and metric=="loss"')
        for y,name in enumerate(names):
            r=d[d.comparator==name].iloc[0]
            ax.errorbar(r.difference*1000,y,xerr=[[1000*(r.difference-r.low)],[1000*(r.high-r.difference)]],fmt='o',ms=3,color=C['joint'],capsize=2,lw=1)
        ax.set(yticks=range(4),yticklabels=['Full','Converged','S–C','No-cache'],xlabel='Reuse-DP − comparator risk (×10⁻³)')
        ax.axvline(0,color='#B2BBC0',lw=.8);ax.invert_yaxis();panel(ax,'ab'[j],mesh+': paired risk differences')
        ax=axs[1,j]
        offsets={'B767':{'always_full':(-6,8),'always_converged':(8,3),'joint':(6,-13),'cascade_sc':(5,6),'cascade_cf':(6,4)},
                 'C172':{'always_full':(-7,8),'always_converged':(7,-8),'joint':(6,5),'cascade_sc':(-5,6),'cascade_cf':(7,3)}}
        for method in ['always_full','always_converged','joint','cascade_sc','cascade_cf']:
            r=s.query('mesh==@mesh and method==@method').iloc[0]
            marker='D' if method=='cascade_cf' else 'o'
            ax.scatter(r.cpu_ms,1000*r.pose_loss,marker=marker,s=28,facecolor='white' if method=='cascade_cf' else C[method],edgecolor=C[method],lw=1,zorder=3)
            off=offsets[mesh][method]
            label={'always_full':'Full','always_converged':'Converged','joint':'Reuse-DP','cascade_sc':'S–C','cascade_cf':'C–F'}[method]
            ax.annotate(label,(r.cpu_ms,r.pose_loss*1000),xytext=off,textcoords='offset points',ha='right' if off[0]<0 else 'left',fontsize=7,color=C[method])
        ax.margins(x=.24,y=.18)
        ax.set(xlabel='Registration CPU charged to source (ms)',ylabel='Four-second pose loss (×10⁻³)');panel(ax,'cd'[j],mesh+': primary operating points')
    save(fig,'controls_sources')

def missions():
    d=pd.read_csv(ROOT/'data/complete_control_missions.csv')
    fig,axs=plt.subplots(2,2,figsize=(7.09,5.8));fig.subplots_adjust(left=.10,right=.975,bottom=.13,top=.92,wspace=.38,hspace=.80)
    methods=['always_full','full_4s','always_tempered','always_converged','joint']
    for j,mesh in enumerate(['B767','C172']):
        ax=axs[0,j]
        for method in methods:
            z=d.query('mesh==@mesh and method==@method').sort_values('replicate')
            for r in z.itertuples():ax.scatter(r.cpu_s,r.rmse_m*100,s=19,c=C[method],marker=['o','^','s'][r.level],zorder=3)
        ax.set(xlabel='Total estimator CPU per 33 min (s)',ylabel='Relative position RMSE (cm)');panel(ax,'ab'[j],mesh+': constituent / schedule controls')
        ax=axs[1,j]
        z=d.query('mesh==@mesh and method in ["joint","joint_nocache"]')
        w=z.pivot(index='replicate',columns='method',values='cpu_s')
        for k in range(3):
            ax.plot([k-.08,k+.08],[w.loc[k,'joint'],w.loc[k,'joint_nocache']],c='#ADB7BD',lw=1)
            ax.scatter(k-.08,w.loc[k,'joint'],c=C['joint'],s=25,zorder=3)
            ax.scatter(k+.08,w.loc[k,'joint_nocache'],facecolor='white',edgecolor='#53616D',s=25,zorder=3)
        ax.set(xticks=[0,1,2],xticklabels=['0','1','2'],xlabel='Input / shape level',ylabel='Total estimator CPU (s)',xlim=(-.5,2.5))
        ax.margins(y=.22);panel(ax,'cd'[j],mesh+': fixed-policy cache intervention')
    handles=[Line2D([],[],marker='o',ls='',color=C[m],label=L[m],ms=4) for m in methods]
    fig.legend(handles=handles,ncol=5,loc='center',bbox_to_anchor=(.54,.525),frameon=False,columnspacing=1.1,handletextpad=.5)
    fig.legend(handles=[Line2D([],[],marker='o',ls='',color=C['joint'],label='Cache retained',ms=4),
                        Line2D([],[],marker='o',ls='',markerfacecolor='white',color='#53616D',label='Cache removed',ms=4)],
               loc='center',bbox_to_anchor=(.54,.025),ncol=2,frameon=False)
    save(fig,'controls_missions')

if __name__=='__main__':
    contract=dict(backend='python/matplotlib',reuse='Style only from preceding version; quantitative panels rebuilt for matched controls',
        conclusion='Separate selection, direct reuse and scheduling effects under explicit reservation feasibility',
        controls_sources=dict(archetype='quantitative grid',top='paired primary-risk contrasts, 4000 source bootstrap resamples, 240 sources per aircraft',
            bottom='descriptive mean geometric-loss/CPU operating points for feasible principal solvers and a marked relaxed cascade; full action table retains Skip, Strict and Tempered',
            uncertainty='Pointwise 95% intervals in the inferential panels; lower panels locate descriptive mean operating points.'),
        controls_missions=dict(archetype='quantitative grid',top='all three complete input realizations for each principal feasible controller',
            bottom='matched input-level CPU under unchanged policy and cache removal',
            uncertainty='All three inputs displayed; no time-tick or population-level interval.'),
        units='Source pose loss in m^2 s; source CPU in ms; mission relative-position RMSE in cm; mission CPU in s',
        exclusions='No source or route excluded. High-loss fixed actions and relaxed cascade full-route results retained in tables.',
        output='180 mm original PDF/SVG with 7 pt minimum text, rendered at 160 mm in manuscript; PNG previews',
        qa='Rendered plot-area alignment plus PDF text and collision audit; final-size visual review required')
    (ROOT/'figure_contract_A19.json').write_text(json.dumps(contract,indent=2))
    sources()
    if (ROOT/'data/complete_control_missions.csv').exists():missions()
