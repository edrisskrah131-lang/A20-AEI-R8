"""Fixed software/noninterference audit; emits no calibration summaries."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import copy,json,time
from datetime import datetime,timezone
import numpy as np,pandas as pd
from r8_protocol import ROOT,D,PROTOCOL,sha,digest
from r8_evaluate import assert_freeze,runtime_bindings,relevant_bindings
from r8_verify import fixtures
from r8_contracts import Registry,dispatch,procedural_dispatch,source_from_arrays
from r8_service import load_models,prediction_cache,controlled,state_from
from r8_policy import policies
from r8_claim_layer import execute_with_claims,ClaimLedger,receiver_observer,_Transaction,_procedural_version_check
import r8_service as service_module

FIELDS=['work_s','sender_work_s','sender_total_work_s','loss_m2s','rmse_m','p95_m','max_m',
    'trajectory_failure','observation_failure','union_failure','capture_ready','capture_success',
    'capture_error_m','stop_iteration','publications','installed','budget_stop','profile_guard','deadline_guard','first_delivery_s']
def projection(x):return {k:x[k] for k in FIELDS}|{'trace':json.loads(x['trace'])}
def verify():
    assert_freeze();runtime=runtime_bindings();cards=fixtures(runtime)
    fullreg=Registry(cards,runtime);flatreg=Registry(cards,runtime)
    ps={p['id']:p for p in policies()};models=load_models();clock=json.loads((D/'clock_profile.json').read_text())
    rows=[json.loads(x) for x in (D/'pilot/episodes.jsonl').read_text().splitlines()]
    comparisons=[];expiry=0;rollback=0
    for r in rows:
        with np.load(D/'pilot'/f"{r['seed']}.npz") as f:z={k:f[k] for k in f.files}
        cache=prediction_cache(r,models)
        for s in PROTOCOL['services']:
            for pid,p in ps.items():
                table={('nominal',s['id'],pid):0.};b=relevant_bindings(runtime,'nominal',s,p)
                original=controlled(r,z,p,cache,clock,s,b)
                for task in PROTOCOL['request_types']:
                    from r8_contracts import events_for
                    req=dict(profile='nominal',service=s['id'],task=task,events=events_for(task),allowance=.15,elapsed_s=0.,declared_population=True)
                    a=dispatch(fullreg,table,req,[pid]);bb=procedural_dispatch(flatreg.cards,table,req,[pid],runtime)
                    pair=[]
                    for manual,plan,reg in [(False,a,fullreg),(True,bb,flatreg)]:
                        out=execute_with_claims(r,z,p,cache,clock,s,b,plan,reg,manual)
                        assert all(out[k]==original[k] for k in FIELDS)
                        trace=json.loads(out['trace']);old=json.loads(original['trace'])
                        # Candidate descriptors are the sole additional F0
                        # journal fields when a calibrated plan is supplied.
                        stripped=copy.deepcopy(trace)
                        for x in [stripped,old]:
                            for j in x['installations']:j.pop('statements',None)
                        assert stripped==old
                        assert not out['source_claims']['faulted']
                        candidates=[v for j in trace['installations'] for v in j.get('statements',[])]
                        receipts=out['source_claims']['receipts'];assert len(candidates)==len(receipts)
                        assert all((x['authorized'],x['upper'])==(y['authorized'],y['upper']) for x,y in zip(candidates,receipts))
                        expiry+=sum(not x['authorized'] and x['tick']*.1>s['deadline_s']+1e-12 for x in receipts if x['event']!='trajectory')
                        rollback+=sum(j.get('rollback',False) for j in trace['installations'])
                        pair.append(out)
                    assert projection(pair[0])==projection(pair[1])
                    assert pair[0]['source_claims']==pair[1]['source_claims']
                    comparisons.append(digest(projection(pair[0])))
        print('CLAIM_PILOT',r['seed'],flush=True)
    # Automated projection comparison against an already generated chunk.
    # No event/accuracy means or policy rankings are computed or printed.
    path=D/'results/nominal_calibration/chunk_000.csv.gz';chunk=pd.read_csv(path)
    calrows={r['seed']:r for r in map(json.loads,(D/'episodes.jsonl').read_text().splitlines()) if r['phase']=='nominal_calibration'}
    services={s['id']:s for s in PROTOCOL['services']};chunk_n=0;chunk_digests=[]
    for seed,g in chunk.groupby('seed',sort=True):
        r=calrows[seed]
        with np.load(D/'episode_inputs'/f'{seed}.npz') as f:z={k:f[k] for k in f.files}
        cache=prediction_cache(r,models)
        for ref in g.to_dict('records'):
            s=services[ref['service']];p=ps[ref['policy']];b=relevant_bindings(runtime,'nominal',s,p)
            table={('nominal',s['id'],p['id']):0.}
            req=dict(profile='nominal',service=s['id'],task='union',events=['union'],allowance=.15,elapsed_s=0.,declared_population=True)
            a=dispatch(fullreg,table,req,[p['id']]);bb=procedural_dispatch(flatreg.cards,table,req,[p['id']],runtime)
            for manual,plan,reg in [(False,a,fullreg),(True,bb,flatreg)]:
                out=execute_with_claims(r,z,p,cache,clock,s,b,plan,reg,manual)
                assert all(abs(out[k]-ref[k])<2e-12 for k in FIELDS)
                trace=json.loads(out['trace'])
                for j in trace['installations']:j.pop('statements',None)
                reftrace=json.loads(ref['trace'])
                for j in reftrace['installations']:j.pop('statements',None)
                assert trace==reftrace
            chunk_n+=1;chunk_digests.append(digest(projection(ref)))
    fault_checks=[];r=rows[0]
    with np.load(D/'pilot'/f"{r['seed']}.npz") as f:z={k:f[k] for k in f.files}
    cache=prediction_cache(r,models);s=PROTOCOL['services'][0];p=ps['Fixed2'];b=relevant_bindings(runtime,'nominal',s,p)
    req=dict(profile='nominal',service=s['id'],task='trajectory',events=['trajectory'],allowance=.15,elapsed_s=0.,declared_population=True)
    table={('nominal',s['id'],p['id']):0.}
    for name,fault in [('wrong_source',{'source':'forged'}),('wrong_policy',{'policy':'Final'}),('wrong_data',{'data':'0'*64}),
        ('wrong_prior',{'prior':'0'*64}),('wrong_version',{'sequence':0}),('wrong_replay',{'replay_to':999}),
        ('wrong_payload',{'payload':'0'*64}),('budget',{'sender_work_s':99.}),('wrong_clock_bindings',{'bindings':{}}),('bad_rollback',{'rollback':'false'})]:
        pair=[]
        for manual,reg in [(False,fullreg),(True,flatreg)]:
            plan=procedural_dispatch(reg.cards,table,req,[p['id']],runtime) if manual else dispatch(reg,table,req,[p['id']])
            original=controlled(r,z,p,cache,clock,s,b,plan,reg,manual)
            out=execute_with_claims(r,z,p,cache,clock,s,b,plan,reg,manual,execution_id='fault/'+name,fault=fault)
            assert projection(out)==projection(original)
            assert out['source_claims']['faulted'] and out['source_claims']['status']=='PROVISIONAL'
            assert out['source_claims']['receipts'] and all(not x['authorized'] and x['upper'] is None for x in out['source_claims']['receipts'])
            assert plan.get('node') not in reg.graph.revoked
            rebuilt=procedural_dispatch(reg.cards,table,req,[p['id']],runtime) if manual else dispatch(reg,table,req,[p['id']])
            resumed=execute_with_claims(r,z,p,cache,clock,s,b,rebuilt,reg,manual,execution_id='fault/'+name)
            assert resumed['source_claims']['faulted'] and all(not x['authorized'] and x['upper'] is None for x in resumed['source_claims']['receipts'])
            # A clean independent source can still use the reusable plan.
            clean=execute_with_claims(r,z,p,cache,clock,s,b,plan,reg,manual,execution_id='clean/'+name)
            assert not clean['source_claims']['faulted'] and any(x['authorized'] for x in clean['source_claims']['receipts'])
            pair.append(out['source_claims'])
        assert [{k:v for k,v in x.items() if k!='receiver_checks'} for x in pair][0]==[{k:v for k,v in x.items() if k!='receiver_checks'} for x in pair][1]
        fault_checks.append(name)
    # A good receipt followed by a bad attempt is revoked permanently.
    for manual,reg in [(False,fullreg),(True,flatreg)]:
        plan=procedural_dispatch(reg.cards,table,req,[p['id']],runtime) if manual else dispatch(reg,table,req,[p['id']])
        ledger=ClaimLedger(reg,plan,'late-fault',manual)
        with receiver_observer(ledger):
            prior=state_from(z,0);src=source_from_arrays('late-source',z['cloud'],prior)
            tx=service_module.Transaction(src,p['id'],'nominal',s['id'],s['deadline_s'],s['budget_s'],b)
            payload=tx.register_payload(1,2,prior)
            v=dict(source=src.identity,prior=src.prior_seal,data=src.data_seal,sequence=1,iteration=2,rollback=False,
                policy=p['id'],profile='nominal',service=s['id'],bindings=b,replay_to=2,sender_work_s=.001,payload=payload)
            q={'event':'trajectory','assessment_s':4.,'active_bindings':b,'received_payload_seal':payload}
            def check(vv):
                return service_module.procedural_version_check(src,p['id'],'nominal',s['id'],s['deadline_s'],s['budget_s'],b,vv,.2,2,tx.last_sequence,tx.last_iteration,tx.rollback,q,tx.expected_versions) if manual else tx.assess(vv,.2,2,q)['valid']
            assert check(v);tx.install(v,2);assert ledger.receipts[0]['authorized']
            assert not check(dict(v,source='other'));assert not ledger.receipts[0]['authorized']
            tx.register_payload(2,4,prior);v2=dict(v,sequence=2,iteration=4)
            assert check(v2);tx.install(v2,2)
            assert ledger.faulted and all(not x['authorized'] and x['upper'] is None for x in ledger.receipts)
        fault_checks.append('issued_then_revoked_manual='+str(manual))
        ledger=ClaimLedger(reg,plan,'canonical-rollback',manual)
        with receiver_observer(ledger):
            tx=service_module.Transaction(src,p['id'],'nominal',s['id'],s['deadline_s'],s['budget_s'],b)
            payload=tx.register_payload(1,2,prior);v=dict(v,sequence=1,iteration=2,rollback=False,payload=payload)
            assert check(v);tx.install(v,2)
            tx.register_payload(2,0,prior);rb=dict(v,sequence=2,iteration=0,rollback=True)
            assert check(rb);tx.install(rb,2)
            assert not ledger.faulted and tx.rollback and all(x['authorized'] for x in ledger.receipts)
        fault_checks.append('valid_rollback_manual='+str(manual))
    try:
        with receiver_observer(ClaimLedger(fullreg,plan,'exception')):raise ValueError('test')
    except ValueError:pass
    assert service_module.Transaction is _Transaction and service_module.procedural_version_check is _procedural_version_check
    report={'status':'PASS','scope':'software audit; card fixtures are explicitly NOT calibration observations',
        'pilot_paired_paths':len(comparisons),'pilot_projection_digest':digest(comparisons),'late_expired_candidates':expiry,'canonical_rollbacks':rollback,
        'calibration_chunk_paths':chunk_n,'calibration_chunk_sha256':sha(path),'calibration_projection_digest':digest(chunk_digests),
        'fault_cases':fault_checks,'entry_points_restored':True,'performance_summaries_inspected':False}
    target=ROOT/'qa/r8/claim_layer_audit.json';target.write_text(json.dumps(report,indent=2))
    components={str((ROOT/'source'/n).relative_to(ROOT)):sha(ROOT/'source'/n) for n in ['r8_claim_layer.py','r8_verify_claims.py','r8_confirmation_services.py','r8_bind_attachment.py']}
    freeze={'amendment':'source-scoped statistical attachment history guard; numerical F0 unchanged',
        'utc':datetime.now(timezone.utc).isoformat(),'F0_sha256':sha(D/'freeze.json'),'protocol_sha256':sha(D/'protocol.json'),
        'clock_sha256':sha(D/'clock_profile.json'),'components':components,'audit_sha256':sha(target),
        'fault_trigger':'invalid operational receiver attempt in the trusted current source execution',
        'expiry':'scheduled statement expiry alone is not a history fault',
        'numerical_clock_event_changes':False,'native_timing':'original actually executed component CPU plus observer/check/issuance and separately measured dispatch; whole-wrapper replay ledger explicitly includes offline assertion/scoring and is not pure online CPU',
        'revision':'v3 final: persistent source-scope manual latch, graph revoked-state reconstruction, legal rollback tests, complete external wrapper bookkeeping timers and F1 binding sidecar; intermediate pre-F1 records preserved',
        'family_size_unchanged':528,'event_claim':'unconditional policy/population; no claim on receipt-selected subset or faulty histories'}
    output=D/'claim_layer_freeze.json';assert not output.exists();output.write_text(json.dumps(freeze,indent=2))
    print('CLAIM_LAYER_FROZEN',freeze['utc'],len(comparisons),chunk_n,len(fault_checks),flush=True)
if __name__=='__main__':verify()
