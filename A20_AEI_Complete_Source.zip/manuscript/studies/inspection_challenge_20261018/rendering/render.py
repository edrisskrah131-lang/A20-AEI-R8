"""Physically constructed inspection structures rendered by Blender Cycles.
All geometry and radiometry are procedural simulation, with independent CAD/pixel inputs.
"""
import argparse, json, math, platform, sys, time
from pathlib import Path
import bpy
import numpy as np
from mathutils import Vector, Matrix
from bpy_extras.object_utils import world_to_camera_view

parser=argparse.ArgumentParser()
parser.add_argument('--seed',type=int,required=True)
parser.add_argument('--family',type=int,choices=range(4),required=True)
parser.add_argument('--split',choices=['pilot','development','test'],default='pilot')
parser.add_argument('--out',type=Path,required=True)
parser.add_argument('--variants',default='nominal,raking_light,oblique_view,occlusion')
parser.add_argument('--samples',type=int,default=24)
parser.add_argument('--threads',type=int,default=2)
parser.add_argument('--save-blend',action='store_true')
args=parser.parse_args(sys.argv[sys.argv.index('--')+1:]);args.out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(args.seed)
FAMILIES=['lap_longitudinal','access_hatch','compound_diagonal','repair_doubler']
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU'
scene.cycles.samples=args.samples;scene.cycles.use_adaptive_sampling=True;scene.cycles.adaptive_threshold=.02
scene.cycles.use_denoising=False;scene.cycles.seed=args.seed%65536;scene.cycles.max_bounces=4
scene.cycles.diffuse_bounces=2;scene.cycles.glossy_bounces=3
scene.render.threads_mode='FIXED';scene.render.threads=args.threads
W,H=768,576
scene.render.resolution_x=W;scene.render.resolution_y=H;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.image_settings.color_depth='8'
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.view_settings.exposure=-.2
scene.world.use_nodes=True;world=scene.world.node_tree.nodes['Background'];world.inputs['Color'].default_value=(.16,.20,.29,1);world.inputs['Strength'].default_value=.18
family=args.family;a=float(rng.uniform(.25,.55));b=float(rng.uniform(.10,.30));c=0.
if family==2:a=float(rng.uniform(.7,1.1));b=float(rng.uniform(.4,.8));c=float(rng.uniform(.12,.25))
rough=float(rng.uniform(.24,.40));finish=int(rng.integers(3));wear=float(rng.uniform(.15,.45));spacing=float(rng.uniform(.027,.034));angle=float(rng.uniform(.30,.48))
head_radius=float(rng.uniform(.0030,.0038));head_height=float(rng.uniform(.00045,.0010))
part_width=float(rng.uniform(.158,.184));part_height=float(rng.uniform(.115,.136));corner_radius=float(rng.uniform(.025,.038))
outline_jitter=rng.normal(0,.004,(6,2))
skin_vertices=[];skin_faces=[]

def base_z(x,y):return .5*a*x*x+.5*b*y*y+c*x*y

def normal(x,y):
 n=Vector((-a*x-c*y,-b*y-c*x,1));n.normalize();return n

def mesh(name,vertices,faces,material,skin=False,smooth=True):
 m=bpy.data.meshes.new(name);m.from_pydata(vertices,[],faces);m.update();o=bpy.data.objects.new(name,m);bpy.context.collection.objects.link(o);o.data.materials.append(material)
 if smooth:
  for p in m.polygons:p.use_smooth=True
 if skin:
  offset=len(skin_vertices);skin_vertices.extend(vertices)
  for f in faces:
   for i in range(1,len(f)-1):skin_faces.append([offset+f[0],offset+f[i],offset+f[i+1]])
 return o

def material(name,base,metal=.0,roughness=.4,grain=True):
 m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF')
 p.inputs['Base Color'].default_value=(*base,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=roughness
 if 'Anisotropic IOR Level' in p.inputs:p.inputs['Anisotropic IOR Level'].default_value=.55 if metal>.7 else .05
 if grain:
  tex=n.new('ShaderNodeTexCoord');scale=n.new('ShaderNodeVectorMath');scale.operation='MULTIPLY';scale.inputs[1].default_value=(1,25,2);l.new(tex.outputs['Generated'],scale.inputs[0])
  fine=n.new('ShaderNodeTexNoise');fine.inputs['Scale'].default_value=100;fine.inputs['Detail'].default_value=2;l.new(scale.outputs[0],fine.inputs['Vector'])
  bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.18;bump.inputs['Distance'].default_value=.000035;l.new(fine.outputs['Fac'],bump.inputs['Height']);l.new(bump.outputs['Normal'],p.inputs['Normal'])
  coarse=n.new('ShaderNodeTexNoise');coarse.inputs['Scale'].default_value=7;coarse.inputs['Detail'].default_value=4;l.new(tex.outputs['Generated'],coarse.inputs['Vector'])
  ramp=n.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].position=.15;ramp.color_ramp.elements[0].color=(*(x*.78 for x in base),1);ramp.color_ramp.elements[1].position=.85;ramp.color_ramp.elements[1].color=(*(x*1.05 for x in base),1);l.new(coarse.outputs['Fac'],ramp.inputs[0]);l.new(ramp.outputs['Color'],p.inputs['Base Color'])
  rr=n.new('ShaderNodeMapRange');rr.inputs['To Min'].default_value=max(.12,roughness-.08);rr.inputs['To Max'].default_value=min(.9,roughness+.16);l.new(coarse.outputs['Fac'],rr.inputs[0]);l.new(rr.outputs[0],p.inputs['Roughness'])
 return m

paint=material('aged_offwhite_aircraft_coating',(.54,.59,.62),.10,rough+.12)
metal=material('brushed_aluminium',(.48,.50,.53),.92,rough)
primer=material('green_gray_protective_primer',(.19,.25,.22),.10,.53)
blue=material('gray_blue_panel_coating',(.17,.25,.30),.13,.36)
seal=material('dark_polysulfide_sealant',(.018,.021,.023),0,.9)
headmat=material('oxidised_fastener_metal',(.14,.16,.18),.82,.32)
bright=material('machined_countersink',(.51,.53,.55),.95,.24)
abrasion=material('exposed_metal_scuff',(.43,.46,.48),.88,.47,False)
ink=material('stencil_ink',(.025,.032,.037),0,.65,False)
yellow=material('maintenance_marking_ochre',(.55,.37,.045),.0,.65,False)
rubber=material('service_hose_rubber',(.018,.025,.029),0,.88)
body_mat=[paint,metal,paint][finish]

# Continuous base skin: curved, not a planar image card.
xs=np.linspace(-.47,.47,86);ys=np.linspace(-.35,.35,67)
vv=[(float(x),float(y),float(base_z(x,y))) for y in ys for x in xs];nx=len(xs)
ff=[(j*nx+i,j*nx+i+1,(j+1)*nx+i+1,(j+1)*nx+i) for j in range(len(ys)-1) for i in range(nx-1)]
mesh('base_airframe_skin',vv,ff,body_mat,skin=True)

def rounded_rectangle(wx,hy,r,n=12):
 points=[]
 for cx,cy,t0 in [(wx-r,hy-r,0),(-wx+r,hy-r,math.pi/2),(-wx+r,-hy+r,math.pi),(wx-r,-hy+r,3*math.pi/2)]:
  for t in np.linspace(t0,t0+math.pi/2,n,endpoint=False):points.append((cx+r*math.cos(t),cy+r*math.sin(t)))
 return np.asarray(points)

def disk_surface(name,boundary,height,mat,skin=True,rings=20):
 dense=[]
 for start,end in zip(boundary,np.roll(boundary,-1,axis=0)):
  dense.extend(np.linspace(start,end,max(1,int(np.ceil(np.linalg.norm(end-start)/.006))),endpoint=False))
 boundary=np.asarray(dense)
 center=boundary.mean(0);verts=[(*center,float(base_z(*center)+height))];n=len(boundary)
 for q in range(1,rings+1):
  for x,y in center+(boundary-center)*q/rings:verts.append((float(x),float(y),float(base_z(x,y)+height)))
 faces=[(0,1+k,1+(k+1)%n) for k in range(n)]
 for q in range(rings-1):
  low=1+q*n;high=low+n
  for k in range(n):faces.append((low+k,high+k,high+(k+1)%n,low+(k+1)%n))
 # Physical rim connects the elevated external face to the base skin.
 low=len(verts);verts.extend([(float(x),float(y),float(base_z(x,y)+.00004)) for x,y in boundary]);top=1+(rings-1)*n
 for k in range(n):faces.append((top+k,low+k,low+(k+1)%n,top+(k+1)%n))
 return mesh(name,verts,faces,mat,skin=skin)

def strip(name,points,width,height,mat):
 verts=[]
 for i,p in enumerate(points):
  d=np.asarray(points[min(i+1,len(points)-1)])-np.asarray(points[max(0,i-1)]);d=d/max(np.linalg.norm(d),1e-9);side=np.array([-d[1],d[0]])*width*.5
  for x,y in [p-side,p+side]:verts.append((float(x),float(y),float(base_z(x,y)+height)))
 return mesh(name,verts,[(2*i,2*i+1,2*i+3,2*i+2) for i in range(len(points)-1)],mat,False)

def edge_points(boundary,step):
 poly=np.vstack([boundary,boundary[0]]);length=np.linalg.norm(np.diff(poly,axis=0),axis=1);cs=np.r_[0,np.cumsum(length)];n=max(8,round(cs[-1]/step));result=[]
 for value in np.linspace(0,cs[-1],n,endpoint=False):
  i=min(np.searchsorted(cs,value,side='right')-1,len(length)-1);result.append(poly[i]+(value-cs[i])/length[i]*(poly[i+1]-poly[i]))
 return np.asarray(result)

# Structural families change the skin topology and CAD feature arrangement.
if family==0:
 # A 1.2 mm overlapped sheet; longitudinal edge is actual geometric layering.
 bound=np.array([[0,-.35],[.47,-.35],[.47,.35],[0,.35]])
 disk_surface('overlapped_longitudinal_sheet',bound,.0012,paint if finish==1 else metal)
 strip('longitudinal_sealant',np.c_[np.zeros(61),np.linspace(-.35,.35,61)],.003,.00125,seal)
 y=np.arange(-4,5)*spacing;xy=np.vstack([np.c_[np.full(len(y),x),y+(.5*spacing if j%2 else 0)] for j,x in enumerate([-.040,-.018,.018,.040])])
 surface_height=lambda x,y:.0012 if x>=0 else 0.
 label='LAP JOINT  /  04'
 label_position=(-.20,.135)
elif family==1:
 outer=rounded_rectangle(part_width,part_height,corner_radius);inner=rounded_rectangle(part_width-.005,part_height-.005,corner_radius-.003)
 disk_surface('access_cover_gasket',outer,.0014,seal)
 disk_surface('curved_access_cover',inner,.0023,blue if finish!=1 else paint)
 row=rounded_rectangle(part_width-.019,part_height-.019,corner_radius-.006);xy=edge_points(row,spacing)
 surface_height=lambda x,y:.0023 if (abs(x)<=.171 and abs(y)<=.122) else 0.
 # A recessed handle bezel and metallic latch make this an access structure.
 handle=rounded_rectangle(.039,.012,.007)+[0,.012]
 disk_surface('handle_recess',handle,.0026,seal,skin=False,rings=4)
 handlebar=rounded_rectangle(.031,.003,.002)+[0,.012]
 disk_surface('handle_latch',handlebar,.0042,bright,skin=False,rings=3)
 for y in [-part_height*.60,part_height*.60]:
  hinge=rounded_rectangle(.009,.022,.003)+[-part_width-.003,y];disk_surface('hinge_mount',hinge,.0032,bright,skin=False,rings=3)
 label='ACCESS  27'
 label_position=(-.058,-.055)
elif family==2:
 # Different curvature in both axes, oblique overlap and a circular service port.
 t=np.array([math.cos(angle),math.sin(angle)]);n=np.array([-t[1],t[0]])
 bound=np.array([-.50*t+.000*n,.50*t+.000*n,.50*t+.44*n,-.50*t+.44*n])
 disk_surface('compound_oblique_sheet',bound,.0018,metal if finish!=1 else paint)
 line=np.asarray([v*t for v in np.linspace(-.48,.48,71)]);strip('diagonal_sealant',line,.0032,.00185,seal)
 vals=np.arange(-5,6)*spacing;xy=np.vstack([vals[:,None]*t+offset*n for offset in [-.041,-.018,.020,.043]])
 portcenter=np.array([.105,-.075]);theta=np.linspace(0,2*np.pi,64,endpoint=False);port=portcenter+.028*np.c_[np.cos(theta),np.sin(theta)]
 disk_surface('service_port_flange',port,.0032,bright,skin=False,rings=5)
 inner=portcenter+.019*np.c_[np.cos(theta),np.sin(theta)];disk_surface('service_port_insert',inner,.0034,seal,skin=False,rings=5)
 for dy in [-.008,0,.008]:strip('port_slot',[portcenter+[-.012,dy],portcenter+[.012,dy]],.002,.00345,metal)
 surface_height=lambda x,y:.0018 if np.dot([x,y],n)>=0 else 0.
 label='SERVICE  /  19';label_position=(-.19,.11)
else:
 # Asymmetric doubler patch with two independent fastener rows.
 outline=np.array([[-.170,-.085],[-.115,-.130],[.145,-.108],[.177,.070],[.102,.124],[-.152,.095]])+outline_jitter
 # Dense polygon boundaries retain straight manufactured edges while curving with the skin.
 points=[]
 for p,q in zip(outline,np.roll(outline,-1,axis=0)):
  points.extend(np.linspace(p,q,12,endpoint=False))
 boundary=np.asarray(points);disk_surface('doubler_sealant_bed',boundary*1.02,.0011,seal)
 disk_surface('formed_repair_doubler',boundary,.0024,metal if finish!=1 else primer)
 xy=np.vstack([edge_points(boundary*.92,spacing),edge_points(boundary*.76,spacing*1.05)])
 surface_height=lambda x,y:.0024 # Every planned target belongs to the patch; outside targets are not generated.
 label='REPAIR  D-12';label_position=(-.070,-.025)

# Independent manufacturing position deviations; no hidden CAD labels reach detector.
xy=xy+rng.normal(0,.00012,xy.shape)
skin_triangles=np.asarray(skin_vertices)[np.asarray(skin_faces)]
def actual_skin_height(x,y):
 A=skin_triangles[:,0];B=skin_triangles[:,1]-A;C=skin_triangles[:,2]-A;det=B[:,0]*C[:,1]-B[:,1]*C[:,0]
 valid=np.abs(det)>1e-15;dx=x-A[:,0];dy=y-A[:,1]
 u=np.divide(dx*C[:,1]-dy*C[:,0],det,out=np.full(len(det),np.nan),where=valid)
 v=np.divide(B[:,0]*dy-B[:,1]*dx,det,out=np.full(len(det),np.nan),where=valid)
 inside=valid&(u>=-1e-9)&(v>=-1e-9)&(u+v<=1+1e-9)
 if not inside.any():raise ValueError('Target outside skin mesh')
 return float(np.max((A[:,2]+u*B[:,2]+v*C[:,2])[inside]))
cad=np.c_[xy,[actual_skin_height(x,y) for x,y in xy]]
actual_xy=xy+rng.normal(0,.00008,xy.shape)
actual=np.c_[actual_xy,[actual_skin_height(x,y) for x,y in actual_xy]]
missing=rng.random(len(xy))<.025

def rivet(index,point,radius):
 x,y,z=point;q=normal(x,y).to_track_quat('Z','Y');N=40
 # Domed heads and machined countersink rings are polygon geometry, with specular response.
 verts=[(0,0,head_height)];rings=[(.42*radius,.91*head_height),(.82*radius,.48*head_height),(radius,.00004)]
 for rad,h in rings:verts.extend([(rad*math.cos(2*math.pi*k/N),rad*math.sin(2*math.pi*k/N),h) for k in range(N)])
 faces=[(0,1+k,1+(k+1)%N) for k in range(N)]
 for j in range(2):
  lo=1+j*N;hi=lo+N;faces.extend([(lo+k,hi+k,hi+(k+1)%N,lo+(k+1)%N) for k in range(N)])
 o=mesh('target_'+str(index),verts,faces,headmat);o.location=point;o.rotation_mode='QUATERNION';o.rotation_quaternion=q
 bpy.ops.mesh.primitive_torus_add(major_radius=radius+.00012,minor_radius=.00015,major_segments=40,minor_segments=8,location=point)
 o=bpy.context.object;o.name='target_rim_'+str(index);o.rotation_mode='QUATERNION';o.rotation_quaternion=q;o.data.materials.append(bright)
 for poly in o.data.polygons:poly.use_smooth=True
 # Thin dark sealant/grime collar around some fasteners, without changing their identity.
 if index%4==0:
  bpy.ops.mesh.primitive_torus_add(major_radius=radius+.00038,minor_radius=.00013,major_segments=40,minor_segments=6,location=point)
  o=bpy.context.object;o.name='sealant_collar_'+str(index);o.rotation_mode='QUATERNION';o.rotation_quaternion=q;o.data.materials.append(seal)
for index,point in enumerate(actual):
 if not missing[index]:rivet(index,point,head_radius*float(rng.uniform(.94,1.06)))

# Material marks are geometry registered on exposed skin; they are not image edits.
for k in range(32):
 x=float(rng.uniform(-.23,.23));y=float(rng.uniform(-.15,.15));length=float(rng.uniform(.004,.035));slope=float(rng.uniform(-.4,.4));pts=np.c_[np.linspace(x,x+length,6),np.linspace(y,y+slope*length,6)]
 # Mark on the topological exterior only. The precise location is auxiliary to target CAD.
 if family==0:h=surface_height(x,y)
 elif family==1:h=.0023 if abs(x)<.155 and abs(y)<.105 else 0
 elif family==2:h=surface_height(x,y)
 else:h=.0024 if abs(x)<.10 and abs(y)<.07 else 0
 strip('abrasion_'+str(k),pts,float(rng.uniform(.000035,.00013)),h+.000025,abrasion)

# On-surface manufacturing stencil, deliberately sparse and outside most target rows.
bpy.ops.object.text_add(location=(label_position[0],label_position[1],base_z(*label_position)+(.0024 if family in (1,3) else .0014)))
text=bpy.context.object;text.name='maintenance_stencil';text.data.body=label;text.data.size=.008;text.data.extrude=0;text.data.materials.append(ink)

# Foreground service equipment is present only in the occlusion condition.
occluders=[]
curve=bpy.data.curves.new('service_hose_path','CURVE');curve.dimensions='3D';curve.resolution_u=16;curve.bevel_depth=.014;curve.bevel_resolution=4
sp=curve.splines.new('BEZIER');sp.bezier_points.add(4)
for p,co in zip(sp.bezier_points,[(.22,-.25,.08),(.135,-.09,.065),(.13,.03,.07),(.22,.13,.09),(.24,.27,.10)]):p.co=co;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
hose=bpy.data.objects.new('occluder_service_hose',curve);bpy.context.collection.objects.link(hose);hose.data.materials.append(rubber);occluders.append(hose)
bpy.ops.mesh.primitive_cube_add(size=1,location=(.23,-.12,.06));tool=bpy.context.object;tool.name='occluder_tool_housing';tool.dimensions=(.105,.15,.06);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);tool.data.materials.append(blue);bevel=tool.modifiers.new('rounded_case','BEVEL');bevel.width=.009;bevel.segments=3;occluders.append(tool)
for o in occluders:o.hide_render=True;o.hide_viewport=True

# Cameras: coordinate convention is right/down/forward, with centered image pixels.
focal=float(rng.uniform(1320,1480));distance=float(rng.uniform(.88,.98));camera0=np.array([rng.uniform(-.065,.065),rng.uniform(-.045,.045),distance])
translation_error=rng.normal(0,.003,3);rotation_error=rng.normal(0,.001,3)
bpy.ops.object.camera_add();camera=bpy.context.object;scene.camera=camera;camera.data.sensor_fit='HORIZONTAL';camera.data.sensor_width=36;camera.data.lens=focal*36/W;camera.data.clip_start=.005;camera.data.clip_end=10

def position_camera(position):
 forward=-position/np.linalg.norm(position);right=np.cross(forward,[0,1,0]);right/=np.linalg.norm(right);down=np.cross(forward,right);R=np.column_stack([right,down,forward])
 camera.location=position;camera.rotation_euler=Matrix(np.column_stack([right,-down,-forward]).tolist()).to_euler();return R

lights=[]
for name,position,power,sx,sy,color in [('key_softbox',(-.38,-.28,.75),float(rng.uniform(11,16)),.48,.23,(1,.93,.83)),('hangar_window',(.35,.36,.65),float(rng.uniform(4,7)),.45,.30,(.74,.85,1)),('strip_reflection',(.35,-.50,.40),float(rng.uniform(3,5)),.50,.045,(1,1,1))]:
 bpy.ops.object.light_add(type='AREA',location=position);obj=bpy.context.object;obj.name=name;obj.rotation_euler=(-obj.location).to_track_quat('-Z','Y').to_euler();obj.data.energy=power;obj.data.shape='RECTANGLE';obj.data.size=sx;obj.data.size_y=sy;obj.data.color=color;lights.append((obj,np.array(position),power))
mesh_name=str(args.seed)+'_surface.npz';np.savez_compressed(args.out/mesh_name,vertices=np.asarray(skin_vertices,float),faces=np.asarray(skin_faces,np.int32))
metadata={'schema':1,'scene_id':f'{args.split}_f{family}_{args.seed}','seed':args.seed,'family':family,'family_name':FAMILIES[family],'split':args.split,'width':W,'height':H,'surface':{'a':a,'b':b,'c':c},'surface_mesh_file':mesh_name,'cad':cad.tolist(),'actual':actual.tolist(),'missing':missing.tolist(),'translation_error':translation_error.tolist(),'rotation_error':rotation_error.tolist(),'finish':finish,'roughness':rough,'head_radius_m':head_radius,'head_height_m':head_height,'part_width_m':part_width,'part_height_m':part_height,'corner_radius_m':corner_radius,'repair_outline_jitter_m':outline_jitter.tolist(),'samples_max':args.samples,'adaptive_threshold':.02,'denoising':False,'threads':args.threads,'renderer':'Blender Cycles','blender_version':bpy.app.version_string,'python_version':sys.version,'numpy_version':np.__version__,'platform':platform.platform(),'variants':{}}
for variant in args.variants.split(','):
 position=camera0.copy()
 if variant=='oblique_view':position=np.array([camera0[0]+.28,camera0[1]+.06,camera0[2]-.07])
 R=position_camera(position)
 for obj,powerpos,power in lights:
  obj.location=powerpos;obj.data.energy=power
  if variant=='raking_light':
   if obj.name=='key_softbox':obj.location=(-.48,-.12,.21);obj.data.energy=power*.55
   else:obj.data.energy=power*.10
  obj.rotation_euler=(-obj.location).to_track_quat('-Z','Y').to_euler()
 world.inputs['Strength'].default_value=.025 if variant=='raking_light' else .18
 for obj in occluders:obj.hide_render=variant!='occlusion';obj.hide_viewport=variant!='occlusion'
 bpy.context.view_layer.update();deps=bpy.context.evaluated_depsgraph_get();uv=[world_to_camera_view(scene,camera,Vector(p)) for p in actual]
 visible=[]
 for i,p in enumerate(actual):
  direction=Vector(p)-camera.location;distance_to_site=direction.length;hit,loc,nrm,face,ob,matrix=scene.ray_cast(deps,camera.location,direction.normalized(),distance=distance_to_site+.001)
  own_object=hit and ob.name in {f'target_{i}',f'target_rim_{i}',f'sealant_collar_{i}'}
  visible.append(bool(not missing[i] and 0<=uv[i].x<=1 and 0<=uv[i].y<=1 and (own_object or not hit or (loc-camera.location).length>=distance_to_site-.00015)))
 filename=f'{args.seed}_{variant}.png';scene.render.filepath=str(args.out/filename);start=time.time();start_cpu=time.process_time();bpy.ops.render.render(write_still=True)
 metadata['variants'][variant]={'filename':filename,'camera':position.tolist(),'rotation':R.tolist(),'focal':focal,'blender_projected_pixels':[[float(q.x*W-W/2),float((1-q.y)*H-H/2)] for q in uv],'visible':visible,'elapsed_s':time.time()-start,'cpu_s':time.process_time()-start_cpu,'intervention':{'nominal':'none','raking_light':'directional key light and reduced fill/world illumination','oblique_view':'camera translation and orientation only','occlusion':'physical foreground hose/tool housing only'}[variant]}
 if args.save_blend and variant=='nominal':bpy.ops.wm.save_as_mainfile(filepath=str(args.out/(str(args.seed)+'.blend')))
(args.out/(str(args.seed)+'.json')).write_text(json.dumps(metadata,indent=2))
