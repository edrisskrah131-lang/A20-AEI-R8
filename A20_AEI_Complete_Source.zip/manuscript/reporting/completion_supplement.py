"""Build the new campaign/challenge supplement from completed, archived outputs.

This script is deliberately data-only: it neither reruns the numerical experiments
nor changes their protocols. Missing final inputs stop generation, so a partial
experiment cannot silently become a completed result table.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
CAMPAIGN = ROOT / "studies/lifecycle_campaign_20261018"
CHALLENGE = ROOT / "studies/inspection_challenge_20261018"
ANALYSIS = CHALLENGE / "analysis"
RENDERING = CHALLENGE / "rendering"
OUTPUT = ROOT / "paper/sections/completion_supplement.tex"

METHODS = ["Whole renewal", "DAG exact + registry", "Containment + repair", "Rules + registry"]
METHOD_LABELS = dict(zip(METHODS, ["Whole", "DAG", "Contract", "Rules"]))
STAGES = ["geometry", "radiance", "sensor", "decode", "pose", "optics"]
VARIANTS = {
    "baseline": "Baseline", "focal": "Focal", "exposure": "Exposure",
    "wide_roi": "Wide ROI", "lighting": "Lighting", "decoder": "Decoder",
    "exposure_light_decoder": "Exposure/light/decoder", "camera_focal_roi": "Focal/ROI",
}
REQUESTS = {
    "optical": "Optical", "optical_relaxed": "Optical+",
    "acquisition": "Acquisition", "acquisition_relaxed": "Acquisition+",
    "association": "Association", "association_relaxed": "Association+",
    "complete": "Complete", "complete_relaxed": "Complete+",
}
FAMILIES = {0: "Lap", 1: "Hatch", 2: "Diagonal", 3: "Doubler"}
CONDITIONS = {"nominal": "Nominal", "raking_light": "Raking", "oblique_view": "Oblique", "occlusion": "Occluded"}
EVENT_LABELS = {
    "baseline": "Baseline", "requirement_relax": "Relax request",
    "exposure_update": "Exposure", "requirement_tighten": "Tighten request",
    "lighting_update": "Lighting", "decoder_update": "Decoder",
    "combined_update": "Combined update", "camera_update": "Camera update",
    "stale_attachment": "Stale attachment", "out_of_order_repair": "Out-of-order repair",
    "validated_repair": "Valid repair", "repair_replay": "Repair replay",
    "numeric_rollback": "Numerical rollback", "population_mismatch": "Population mismatch",
    "late_version_delivery": "Late delivery", "validated_rollback_repair": "Rollback repair",
}

REQUIRED = [
    CAMPAIGN / "protocol.json", CAMPAIGN / "outputs/summary.json",
    CAMPAIGN / "outputs/exact_risk_cards.csv", CAMPAIGN / "outputs/heldout_request_scores.csv",
    CAMPAIGN / "outputs/method_summary.csv", CAMPAIGN / "outputs/event_summary.csv",
    CAMPAIGN / "outputs/catalogue_events.csv", CAMPAIGN / "outputs/family_method_summary.csv",
    CAMPAIGN / "outputs/decisions.csv", CAMPAIGN / "outputs/verification.json",
    RENDERING / "protocol.json", ANALYSIS / "protocol.json", ANALYSIS / "freeze.json",
    ANALYSIS / "outputs/test/summary.json", ANALYSIS / "outputs/test/metrics.csv",
    ANALYSIS / "outputs/test/strata.csv", ANALYSIS / "outputs/test/conditions.csv",
    ANALYSIS / "verification.json",
]


def read_json(path: Path):
    return json.loads(path.read_text())


def escaped(value) -> str:
    return str(value).replace("\\", r"\textbackslash{}").replace("&", r"\&").replace("%", r"\%").replace("_", r"\_").replace("#", r"\#")


def number(value, places=3, scale=1.0):
    if value is None or pd.isna(value):
        return "---"
    if math.isinf(float(value)):
        return r"$\infty$"
    return f"{float(value) * scale:.{places}f}"


def integer(value):
    return f"{int(value):,}"


def truth(value):
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    if isinstance(value, str):
        assert value.lower() in ("true", "false"), value
        return value.lower() == "true"
    assert value in (0, 1), value
    return bool(value)


def tex_table(caption, label, columns, headers, rows, long=False, small=True):
    size = r"\small" if small else r"\footnotesize"
    head = " & ".join(headers) + r"\\\midrule"
    if long:
        result = [size + r"\setlength{\tabcolsep}{4pt}",
                  r"\begin{longtable}{@{}" + columns + r"@{}}",
                  r"\caption{" + caption + r"}\label{" + label + r"}\\\toprule",
                  head, r"\endfirsthead\toprule", head, r"\endhead"]
        result.extend(" & ".join(map(str, row)) + r"\\" for row in rows)
        result.extend([r"\bottomrule\end{longtable}\normalsize", r"\setlength{\tabcolsep}{6pt}"])
    else:
        result = [r"\begin{table}[!htbp]\centering" + size,
                  r"\caption{" + caption + r"}\label{" + label + r"}",
                  r"\setlength{\tabcolsep}{4pt}\begin{tabular}{@{}" + columns + r"@{}}\toprule", head]
        result.extend(" & ".join(map(str, row)) + r"\\" for row in rows)
        result.append(r"\bottomrule\end{tabular}\end{table}")
    return "\n".join(result)


def test_column(frame, *candidates):
    for name in candidates:
        if name in frame.columns:
            return name
    raise KeyError(f"Missing one of {candidates}; actual columns {list(frame.columns)}")


def build():
    spec = read_json(CAMPAIGN / "protocol.json")
    campaign = read_json(CAMPAIGN / "outputs/summary.json")
    risk = pd.read_csv(CAMPAIGN / "outputs/exact_risk_cards.csv")
    heldout = pd.read_csv(CAMPAIGN / "outputs/heldout_request_scores.csv")
    methods = pd.read_csv(CAMPAIGN / "outputs/method_summary.csv").set_index("method")
    events = pd.read_csv(CAMPAIGN / "outputs/event_summary.csv")
    catalogues = pd.read_csv(CAMPAIGN / "outputs/catalogue_events.csv")
    family = pd.read_csv(CAMPAIGN / "outputs/family_method_summary.csv").set_index("method")
    decisions = pd.read_csv(CAMPAIGN / "outputs/decisions.csv")
    campaign_verification = read_json(CAMPAIGN / "outputs/verification.json")
    render_spec = read_json(RENDERING / "protocol.json")
    freeze = read_json(ANALYSIS / "freeze.json")
    challenge = read_json(ANALYSIS / "outputs/test/summary.json")
    metrics = pd.read_csv(ANALYSIS / "outputs/test/metrics.csv")
    challenge_verification = read_json(ANALYSIS / "verification.json")
    ncal = int(campaign["independent_calibration_sources"])
    ntest = int(campaign["independent_test_sources"])
    nscene = int(challenge["scene_count"])
    nimage = int(challenge["image_count"])
    ndev = len(freeze["development_seeds"])
    nfamily = int(campaign["family_K"])
    baseline, alternative = freeze["baseline"]["name"], freeze["selected"]["name"]
    provider_labels = {baseline: "Frozen", alternative: "Selected"}
    assert ncal == spec["calibration_scene_count"] == 256
    assert ntest == spec["primary_scene_count"] == 64
    assert nfamily == len(risk) == 64
    assert risk.groupby("variant").size().eq(8).all()
    assert risk.n.eq(ncal).all()
    assert family.supported.eq(int(risk.authorized.sum())).all()
    assert len(decisions) == ntest * len(spec["steps"]) * len(METHODS)
    assert len(metrics) == 2 * nimage == 2 * nscene * 4
    assert metrics.groupby(["seed", "frontend"]).size().eq(4).all()
    assert len(challenge["strata"]) == 32
    assert set(metrics.frontend) == {baseline, alternative}
    assert set(metrics.seed) == {r["seed"] for r in render_spec["test_sources"]}
    assert not set(metrics.seed) & set(freeze["development_seeds"])
    assert campaign_verification.get("status") == "PASS", campaign_verification
    assert challenge_verification.get("status") == "PASS", challenge_verification

    parts = [r"\section{Sequential change campaign and geometric image challenge}\label{supp:completion}",
             r"\subsection{Populations, fixed families and independent units}",
             f"The principal campaign uses {ncal} fresh calibration scenes and {ntest} fresh test scenes from the four-layout skin population. "
             f"All eight producer configurations execute on every calibration scene, giving {ncal * 8:,} calibration outputs. "
             f"Each test scene follows the same 16 operations; the resulting {ntest * 16:,} decisions per implementation are repeated workflow observations of {ntest} independent sources. "
             f"The {ntest} stress alternatives share those source seeds and form paired interventions. "
             f"The geometric challenge separately contains {ndev} development scenes and {nscene} test scenes, each rendered under four conditions. "
             f"Its {nimage} test images give {2 * nimage} evaluations across the two providers.",
             f"The campaign fixes eight producers and eight request events, with $K={nfamily}$, family error $\\beta=0.05$, per-event allocation $\\alpha=0.05/{nfamily}$ and allowance $\\delta=0.15$. "
             "The family statement concerns scene-level request failures for these fixed functions. Shared scene inputs induce dependence between producer/event outcomes; the union bound permits that dependence. "
             "It does not convert the marginal allowance into a probability of zero failures over an entire 16-operation trajectory. The independent test assessment evaluates the producer/request contexts actually executed by the campaign.",
             "Each operation selects a complete named configuration. The combined configurations explicitly change multiple parameters; individual update names do not accumulate patches from preceding operations. "
             "All methods receive the same numerical inputs, request thresholds, calibration allocation and authoritative records. "
             "The population mismatch operation executes a stress input and compares its explicit population identity with the calibration identity."]

    sampling_rows = [
        ["Campaign calibration", str(ncal), "8 producers", f"{spec['calibration_seed_start']}--{spec['calibration_seed_start'] + ncal - 1}"],
        ["Campaign test", str(ntest), "16 operations", f"{spec['test_seed_start']}--{spec['test_seed_start'] + ntest - 1}"],
        ["Paired stress", str(ntest), "1 alternative/source", "Same primary seeds"],
        ["Challenge development", str(ndev), "4 conditions", "Families 0 and 1"],
        ["Challenge test", str(nscene), "4 conditions", "Families 0, 1, 2 and 3"],
    ]
    parts.append(tex_table("Sampling units and repeated observations. Challenge conditions and provider evaluations remain paired within a source.", "stab:completion-sampling", "lrll", ["Set", "Sources", "Repeated observations", "Seed range / structure"], sampling_rows))
    config_rows = [
        ["Baseline", "1", "1", r"$768\times576$", "1", "18"],
        ["Focal", "1.15", "1", r"$768\times576$", "1", "18"],
        ["Exposure", "1", "1.5", r"$768\times576$", "1", "18"],
        ["Wide ROI", "1", "1", r"$896\times672$", "1", "18"],
        ["Lighting", "1", "1", r"$768\times576$", "0.45", "18"],
        ["Decoder", "1", "1", r"$768\times576$", "1", "10"],
        ["Exposure/light/decoder", "1", "1.5", r"$768\times576$", "0.45", "10"],
        ["Focal/ROI", "1.15", "1", r"$896\times672$", "1", "18"],
    ]
    parts.append(tex_table("Complete campaign configurations. Focal length, exposure and illumination are factors relative to the sampled baseline; decoder entries are contrast thresholds.", "stab:completion-configs", "lrrlrr", ["Producer", "Focal", "Exposure", "Raster", "Light", "Decoder"], config_rows))

    ncol = test_column(heldout, "test_sources", "n", "test_n")
    kcol = test_column(heldout, "test_failures", "failures", "k")
    combined = risk.merge(heldout[["variant", "request", ncol, kcol]], on=["variant", "request"], how="left", validate="one_to_one")
    test_variants = sorted(heldout.variant.unique())
    assert len(heldout) == 8 * len(test_variants)
    parts.extend([r"\subsection{Complete calibration catalogue and executed test events}",
                  f"Table~\\ref{{stab:completion-cards}} reports every fixed-family calibration bound. {int(risk.authorized.sum())} of {nfamily} contexts satisfy the allowance. "
                  f"The held-out assessment covers {len(heldout)} producer/request contexts from {len(test_variants)} executed nominal configurations, with {ntest} test scenes per context. "
                  "A dash denotes a configuration not executed in the test campaign. Test entries are observed failure counts; the fixed-family confidence statement comes from calibration. The test check does not alter the plans. "
                  "A plus sign denotes the relaxed version of the corresponding request."])
    rows = []
    for variant in spec["configs"]:
        for request in REQUESTS:
            row = combined[(combined.variant == variant) & (combined.request == request)].iloc[0]
            rows.append([VARIANTS[variant], REQUESTS[request], f"{int(row.k)}/{int(row.n)}", number(row.upper, 6),
                         "yes" if truth(row.authorized) else "no",
                         "---" if pd.isna(row[ncol]) else f"{int(row[kcol])}/{int(row[ncol])}"])
    parts.append(tex_table("All 64 calibrated contexts and independent failure counts for the executed test contexts. Calibration uses per-event error $0.05/64$.", "stab:completion-cards", "llrlcr", ["Producer", "Request", "Cal. $k/n$", "Cal. $U$", "Admit", "Test $k/n$"], rows, long=True, small=False))

    parts.extend([r"\subsection{Campaign decisions, revision state and measured work}",
                  "The output packet authenticates the actual RGB raster, decoded and predicted coordinates, fitted residual, matched/planned counts, source identity, population and producer. "
                  "Physical mapping error and correct-address coverage remain offline scoring fields. "
                  "The three incremental methods use the same persistent numerical DAG. Whole renewal discards its cache for ordinary request, producer and rollback evaluations and serves as the numerical cost reference. "
                  "Fault, repair and replay operations validate stored outputs in every implementation.",
                  "The state and issuance columns in Table~\\ref{stab:completion-steps} agree across all four implementations. "
                  "Eligibility denotes admission by the exact event together with a matching population; issuance also requires the current authenticated output and active state. "
                  "A valid numerical rollback advances the registry revision, so a late output from a previous revision remains invalid."])
    for column in ("issued", "exact_eligible", "state", "revision"):
        pivot = decisions.pivot(index=["seed", "index"], columns="method", values=column)
        assert pivot.eq(pivot[METHODS[1]], axis=0).all().all(), column
    reference = decisions[decisions.method == METHODS[1]]
    rows = []
    for index, group in reference.groupby("index", sort=True):
        assert group.revision.nunique() == 1
        rows.append([str(int(index) + 1), EVENT_LABELS[group.event.iloc[0]], REQUESTS[group.request.iloc[0]],
                     "/".join(sorted(group.state.unique())), str(int(group.revision.iloc[0])),
                     f"{int(group.exact_eligible.sum())}/{len(group)}", f"{int(group.issued.sum())}/{len(group)}"])
    parts.append(tex_table("Complete 16-operation state sequence, aggregated over the independent test sources. All matched implementations give these decisions.", "stab:completion-steps", "rllcrrr", ["Step", "Operation", "Request", "State", "Rev.", "Eligible", "Issued"], rows, long=True, small=False))

    demand = catalogues.groupby("method").agg(cards=("new_cards", "sum"), records=("record_evaluations", "sum"), cpu=("cpu_s", "sum"), wall=("wall_s", "sum"))
    rows = []
    for method in METHODS:
        d, f = demand.loc[method], family.loc[method]
        rows.append([METHOD_LABELS[method], "16-step demand", integer(d.cards), integer(d.records), number(d.cpu, 3, 1000), number(d.wall, 3, 1000)])
        rows.append([METHOD_LABELS[method], "Complete family", integer(f.constructed_cards), integer(f.record_evaluations), number(f.cpu_s, 3, 1000), number(f.wall_s, 3, 1000)])
    parts.append("The table abbreviations map to the four protocol methods as follows: Whole is Whole renewal; DAG is DAG exact + registry; Contract is Containment + repair, labelled Containment in the main figures; and Rules is Rules + registry. "
                 "DAG uses exact evidence with the ordinary dependency cache and authoritative registry. Contract implements containment with validated repair; Rules uses independently implemented interval/provider rules and event-log authority. "
                 "The complete-family catalogue and the 16-step demand catalogue describe separate cold-start demand patterns and are not added together.")
    parts.append(tex_table("Two independent catalogue demand patterns. Each catalogue is built once per population and reused across test sources. Counts are not multiplied by the number of image sources.", "stab:completion-catalogues", "llrrrr", ["Method", "Demand pattern", "Cards", "Record tests", "CPU (ms)", "Wall (ms)"], rows))
    full_exact = int(family.loc[METHODS[1], "record_evaluations"])
    full_reuse = int(family.loc[METHODS[2], "record_evaluations"])
    demand_exact = int(demand.loc[METHODS[1], "records"])
    demand_reuse = int(demand.loc[METHODS[2], "records"])
    parts.append(f"Full-catalogue containment reduces calibration-record evaluations from {full_exact:,} to {full_reuse:,}, "
                 f"a {100 * (1 - full_reuse / full_exact):.2f}\\% reduction relative to exact dependency caching. "
                 f"The separate 16-step demand reduces evaluations from {demand_exact:,} to {demand_reuse:,}, "
                 f"a {100 * (1 - demand_reuse / demand_exact):g}\\% reduction. "
                 f"Every complete-family implementation supports the same {int(risk.authorized.sum())} of {nfamily} contexts.")

    rows = []
    for method in METHODS:
        m = methods.loc[method]
        rows.append([METHOD_LABELS[method], integer(m.issued), integer(m.invalid_binding_issuances), integer(m.successful_repair_commits),
                     number(m.pipeline_cpu_s), number(m.event_cpu_s), number(m.event_wall_s)])
    parts.append(tex_table("End-to-end campaign totals. Each method executes 1,024 workflow decisions. Numerical CPU is a component of event CPU; evidence-catalogue preparation is reported separately.", "stab:completion-methods", "lrrrrrr", ["Method", "Issued", "Wrong binding", "Repair commits", "Numerical CPU (s)", "Event CPU (s)", "Wall (s)"], rows, small=False))
    primary = methods.loc[METHODS[2]]
    assert methods.issued.eq(primary.issued).all()
    assert methods.restored_recovery_checkpoints.eq(primary.restored_recovery_checkpoints).all()
    assert methods.invalid_binding_issuances.eq(0).all()
    assert methods.restored_recovery_checkpoints.eq(methods.eligible_recovery_checkpoints).all()
    parts.append(f"Each implementation issues {int(primary.issued):,} of {int(primary.workflow_decisions):,} operations and restores "
                 f"all {int(primary.restored_recovery_checkpoints):,} eligible recovery checkpoints, including the final recovery for "
                 f"all {int(primary.final_recovered_sources):,} test sources. No invalid binding is issued.")
    rows = []
    for method in METHODS:
        m = methods.loc[method]
        rows.append([METHOD_LABELS[method], *[integer(m["calls_" + s]) for s in STAGES]])
    parts.append(tex_table("Actual provider calls over all campaign operations. Request changes and valid numerical rollback can reuse cached stage outputs.", "stab:completion-provider-calls", "lrrrrrr", ["Method", "Geometry", "Radiance", "Sensor", "Decode", "Pose", "Optics"], rows))

    rows = []
    for index in range(16):
        for method in METHODS:
            e = events[(events["index"] == index) & (events.method == method)].iloc[0]
            c = catalogues[(catalogues["index"] == index) & (catalogues.method == method)].iloc[0]
            rows.append([str(index + 1), METHOD_LABELS[method], integer(sum(e["calls_" + s] for s in STAGES)),
                         integer(c.new_cards), integer(c.record_evaluations), number(e.cpu_s, 4), number(e.wall_s, 4)])
    parts.append(tex_table("Per-operation work across all sources. Provider calls and event times aggregate the 64 sources; new cards and record tests belong to the single shared catalogue.", "stab:completion-step-work", "rlrrrrr", ["Step", "Method", "Provider calls", "New cards", "Record tests", "CPU (s)", "Wall (s)"], rows, long=True, small=False))
    ci = campaign["dag_paired_source_bootstrap_ci"]
    parts.append(f"Timing rotates method order by source and uses two worker processes with single-threaded BLAS. "
                 "Initial nominal-scene sampling, process startup and file export are excluded from event timing; stress-input sampling is included in its event. "
                 "Event CPU includes executed providers, offline geometric scoring, payload hashing, and registry and consistency checks. Catalogue planning is measured separately. "
                 "The paired timing bootstrap resamples complete source trajectories, keeping every operation and method paired. "
                 f"Its {campaign['bootstrap_replicates']:,} replicates use seed {campaign['bootstrap_seed']}. "
                 f"The DAG event-CPU saving relative to whole renewal is {campaign['dag_event_cpu_saving_vs_whole_percent']:.2f}\\%, "
                 f"with percentile 95\\% interval {ci[0]:.2f}--{ci[1]:.2f}\\%. "
                 "These times describe the shared Linux execution host recorded in the machine-readable summary.")

    parts.extend([r"\subsection{Geometric scene construction and development-only provider selection}",
                  f"The geometric challenge renders {nscene} independently seeded test scenes, stratified equally across longitudinal lap joints, rounded access hatches, compound-curved diagonal joints and raised repair doublers. "
                  f"The {ndev} development scenes use only the first two families. Test scenes in these families have new seeds; diagonal joints and repair doublers are excluded from provider selection. "
                  "Every source is rendered under nominal, raking-light, oblique-view and foreground-occlusion conditions. The occluders are scene geometry, and each condition preserves the source's planned target set.",
                  f"Blender Cycles uses {render_spec['width']} by {render_spec['height']} pixels, at most {render_spec['samples_max']} samples per pixel, adaptive threshold {render_spec['adaptive_sampling_threshold']:g}, and no denoising. "
                  "Geometric sheet boundaries, sealant, fastener heads, wear, reflective materials and actual area lights contribute to image formation. "
                  "The fixed AgX transform is applied consistently. The exported exterior-surface mesh contains the skin, panel and doubler surfaces and rims; it excludes fastener heads and foreground equipment.",
                  "The scene-level fastener-head radius is sampled from 3.0--3.8 mm, with an independent per-head multiplier of 0.94--1.06; head height is 0.45--1.0 mm. "
                  "The nominal spacing parameter is 27--34 mm, with perimeter discretization adjusting individual spacings. "
                  "Surface relief is 1.2 mm for the lap joint, 2.3 mm for the hatch, 1.8 mm for the diagonal joint and 2.4 mm for the repair doubler. "
                  "Nominal CAD-layout coordinates receive 0.12-mm per-axis Gaussian jitter; physical target coordinates add independent 0.08-mm per-axis displacement in the surface plane. "
                  "Nominal focal length is 1,320--1,480 pixels and camera $z$ is 0.88--0.98 m above the CAD origin. These settings define the geometric challenge's patch scale.",
                  "Nominal CAD addresses and physically displaced targets are placed on the exported skin geometry. "
                  "The prior adds independent Gaussian translation noise with 3-mm per-axis standard deviation and rotation noise with 0.001-rad per-axis standard deviation. "
                  "Detection and pose estimation receive pixels, CAD locations and this prior. Visibility and true physical locations enter only scoring. Missing and occluded sites remain in the planned denominator.",
                  "The frozen local-contrast provider uses threshold 18. The alternative normalizes dark contrast by local intensity variation and uses one of six predeclared $(z,a)$ pairs, with $z\\in\\{1.0,1.6,2.2\\}$ and $a\\in\\{4,8\\}$. "
                  "Development selection weights every family/condition cell equally, minimizes association-event failure, then maximizes coverage, with a lexical provider-name tie-break. "
                  f"The selected provider is \\texttt{{{escaped(alternative)}}}. Table~\\ref{{stab:completion-development}} retains all development alternatives and the frozen comparator."])
    rows = []
    for rank in sorted(freeze["ranking"], key=lambda r: (r["quality_failure"], -r["coverage"], r["frontend"])):
        rows.append([escaped(rank["frontend"]), number(rank["quality_failure"], 2, 100), number(rank["coverage"], 2, 100),
                     "yes" if rank["frontend"] == alternative else "baseline" if rank["frontend"] == baseline else "no"])
    parts.append(tex_table("Development results averaged equally over family/condition cells. Only the six alternatives participate in selecting the replacement provider.", "stab:completion-development", "lrrl", ["Provider", "Quality failure (\\%)", "Coverage (\\%)", "Selected"], rows))

    parts.extend([r"\subsection{All family--condition outcomes and observable screening}",
                  "The challenge uses the Association request's three thresholds in the main requirement table, evaluated within its own image population. "
                  "The association event fails if correct-address coverage is below 0.8, the maximum fitted residual exceeds 8 pixels, or maximum mapping error across all planned sites exceeds 8 mm. "
                  "Correct correspondence requires the same target identity, a center within 8 pixels, and a target that is present and visible in the rendered image. "
                  "The observable screen uses matched/planned count at least 0.8 and maximum fitted residual at most 8 pixels. An accepted-but-failed image passes this screen and fails the association event.",
                  "Mapping casts each planned physical target's image ray from the estimated camera and intersects the known exterior CAD mesh. A missing ray intersection remains infinite and counts as a mapping failure. "
                  "Reported quantiles use all images, including those infinite values, with the nearest-rank order statistic. "
                  "Component-failure counts can overlap; their union is the association-event failure count. The archived field name is \\texttt{quality\\_failure}. Screening and quality proportions use all images unless an accepted subset is explicitly specified."])
    strata = challenge["strata"]
    key = lambda r: (0 if r["frontend"] == baseline else 1, r["family"], list(CONDITIONS).index(r["condition"]))
    rows = []
    failures = []
    for s in sorted(strata, key=key):
        n = int(s["n_images"])
        source_rows = metrics[(metrics.frontend == s["frontend"]) &
                              (metrics.family == s["family"]) &
                              (metrics.condition == s["condition"])]
        assert len(source_rows) == n == source_rows.seed.nunique()
        assert np.isclose(source_rows.coverage.mean(), s["coverage_mean"], atol=1e-14)
        for count_name, raw_column in (
            ("quality_failures", "quality_failure"),
            ("coverage_failures", "coverage_failure"),
            ("mapping_failures", "mapping_failure"),
            ("residual_failures", "residual_failure"),
            ("observable_screen_acceptances", "observable_screen_accept"),
            ("accepted_but_failed", "accepted_but_failed"),
        ):
            assert int(source_rows[raw_column].map(truth).sum()) == s[count_name], (s, count_name)
        assert s["independent_scenes"] == n
        assert 0 <= s["accepted_but_failed"] <= s["observable_screen_acceptances"] <= n
        assert s["accepted_but_failed"] <= s["quality_failures"] <= n
        assert max(s["coverage_failures"], s["mapping_failures"], s["residual_failures"]) <= s["quality_failures"]
        median = r"$\infty$" if s["mapping_median_unbounded"] else number(s["mapping_median_m"], 3, 1000)
        p95 = r"$\infty$" if s["mapping_p95_unbounded"] else number(s["mapping_p95_m"], 3, 1000)
        prefix = [provider_labels[s["frontend"]], FAMILIES[s["family"]] + ("*" if s["structure_holdout"] else ""), CONDITIONS[s["condition"]]]
        rows.append([*prefix, str(n), number(s["coverage_mean"], 2, 100), median, p95, integer(s["images_with_mesh_miss"]), number(s["estimator_cpu_median_s"], 3, 1000)])
        failures.append([*prefix, integer(s["coverage_failures"]), integer(s["residual_failures"]), integer(s["mapping_failures"]),
                         integer(s["quality_failures"]), integer(s["observable_screen_acceptances"]), integer(s["accepted_but_failed"])])
    parts.append(tex_table("Every family/condition/provider quality summary. Coverage is in percent; mapping median and 95th percentile are in mm; CPU is median estimation time in ms. An asterisk marks a structure family excluded from development. Miss denotes images with at least one failed skin intersection.", "stab:completion-challenge-quality", "lllrrrrrr", ["Provider", "Family", "Condition", "$n$", "Coverage", "Map med.", "Map 95th", "Miss", "CPU"], rows, long=True, small=False))
    parts.append(tex_table("Every family/condition/provider failure count. Cov., Res. and Map are component failures, Any is their union, Accept is observable-screen acceptance, and A+F counts accepted-but-failed images. Each row uses the full stratum image count from Table~\\ref{stab:completion-challenge-quality}.", "stab:completion-challenge-failures", "lllrrrrrr", ["Provider", "Family", "Condition", "Cov.", "Res.", "Map", "Any", "Accept", "A+F"], failures, long=True, small=False))

    bootstrap = challenge["bootstrap"]
    parts.extend([r"\subsection{Paired comparisons and resampling hierarchy}",
                  f"The challenge bootstrap draws {bootstrap['replicates']:,} replicates with seed {bootstrap['seed']}. "
                  "Each replicate resamples independent scenes within each of the four fixed geometry families and retains all conditions and both providers for the selected scenes. "
                  "The 2.5th and 97.5th percentiles give descriptive paired intervals. The provider contrast is selected minus frozen; a negative quality-failure difference favors the selected provider. "
                  "Accepted-but-failed contrasts use the fraction of all images. These descriptive intervals summarize the stratified challenge and do not replace the campaign's finite-family calibration bounds."])
    metric_names = {"coverage": "Coverage", "quality_failure": "Quality failure", "accepted_but_failed": "Accepted + failed"}
    rows = []
    for c in sorted(challenge["provider_comparisons"], key=lambda r: (list(CONDITIONS).index(r["condition"]), list(metric_names).index(r["metric"]))):
        lo, hi = c["scene_cluster_percentile_95"]
        rows.append([CONDITIONS[c["condition"]], metric_names[c["metric"]], number(c["alternative_minus_frozen_mean"], 2, 100), f"[{lo * 100:.2f}, {hi * 100:.2f}]"])
    parts.append(tex_table("Paired provider differences and scene-stratified percentile intervals, in percentage points.", "stab:completion-provider-differences", "llrr", ["Condition", "Outcome", "Selected -- frozen", "95\\% interval"], rows))
    rows = []
    for c in challenge["paired_condition_changes"]:
        lo, hi = c["coverage_change_scene_cluster_95"]
        rows.append([provider_labels[c["frontend"]], CONDITIONS[c["condition"]], str(c["n_scene_pairs"]), integer(c["pass_to_failure"]), integer(c["failure_to_pass"]),
                     number(c["mean_coverage_change"], 2, 100), f"[{lo * 100:.2f}, {hi * 100:.2f}]"])
    parts.append(tex_table("Within-source changes from nominal imaging. Pass-to-fail and fail-to-pass count association-event transitions; coverage changes and intervals are percentage points.", "stab:completion-condition-changes", "llrrrrr", ["Provider", "Condition", "Pairs", "Pass $\\to$ fail", "Fail $\\to$ pass", "$\\Delta$ coverage", "95\\% interval"], rows, small=False))

    gallery = sorted((min(r["seed"] for r in render_spec["test_sources"] if r["family"] == f), f) for f in range(4))
    parts.extend([r"\subsection{Deterministic presentation, checks and reproduction}",
                  "Campaign examples use the first calibration seed and first two test seeds in ascending source order. Their full arrays, observable payloads and traces are archived. "
                  "The geometric gallery uses the first test source of each family: " + ", ".join(str(s) for s, _ in gallery) + ". "
                  "The rendering protocol specifies the associated condition panels. Image selection follows source identity; every test success and failure remains in the result files.",
                  "Calibration and campaign tables retain pixel, observable-payload and numerical hashes. The challenge archive retains every raw image, scene description, exterior-surface mesh, fitted camera and correspondence array. "
                  "The independent checkers recompute statistical bounds and state transitions, compare actual stage calls, reexecute stored numerical examples, and reprocess the challenge pixels. "
                  "Geometric verification separately checks camera projection, true-pose surface intersection and an independent plane/barycentric intersection implementation on the first scene of each family.",
                  "From the manuscript directory, the default verification and reporting entry point is:",
                  r"\begin{verbatim}" + "\n" +
                  "A20_PYTHON=python bash reproduce_artifacts.sh\n" + r"\end{verbatim}",
                  "This entry point preserves the archived experiment records and uses isolated copies for report regeneration. "
                  "A fresh numerical reproduction writes new measurements, timing records and selection metadata. Run the following execution commands only in a separate copy of the manuscript source tree. "
                  "Within that separate copy, the campaign execution interface is:",
                  r"\begin{verbatim}" + "\n" +
                  "export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1\n" +
                  "cd studies/lifecycle_campaign_20261018\n" +
                  "python calibrate.py\npython run.py\n" +
                  "python analyze.py\npython verify.py\n" + r"\end{verbatim}",
                  "Within the separate copy's challenge analysis directory, the processing interface is:",
                  r"\begin{verbatim}" + "\n" +
                  "python check_legacy.py\n" +
                  "python run.py select --input ../rendering/development\n" +
                  "python run.py process --input ../rendering/test --split test\n" +
                  "python summarize.py\npython verify.py\n" + r"\end{verbatim}",
                  "These commands replace the copied calibration, campaign, development-selection and test-processing records. "
                  "Selection reproduces the archived development-only choice; test processing checks the frozen implementation hashes. Use single-threaded BLAS for analysis. "
                  "The renderer's executable recipe and frozen protocol reconstruct the raw images. "
                  "The reporting command \\texttt{python reporting/completion\\_supplement.py} rebuilds this section from completed result files and refuses missing final inputs. "
                  "The following supplementary sections preserve earlier experiments under their original populations and allocations.",
                  r"\FloatBarrier"])
    OUTPUT.write_text("\n\n".join(parts) + "\n")
    return dict(status="PASS", output=str(OUTPUT.relative_to(ROOT)), calibration_rows=len(risk),
                independently_scored_test_contexts=len(heldout), campaign_sources=ntest,
                challenge_sources=nscene, challenge_images=nimage, challenge_strata=len(strata),
                input_sha256={str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in REQUIRED})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-inputs", action="store_true", help="List final-input availability without writing TeX")
    args = parser.parse_args()
    missing = [str(p.relative_to(ROOT)) for p in REQUIRED if not p.is_file()]
    if args.check_inputs:
        print(json.dumps(dict(ready=not missing, missing=missing), indent=2))
        return
    if missing:
        raise SystemExit("Final experiment outputs are incomplete:\n" + "\n".join(missing))
    print(json.dumps(build(), indent=2))


if __name__ == "__main__":
    main()
