"""Compare all pre-existing study files with the pre-revision inventory."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
records=json.loads((ROOT/'audits/prior_study_inventory_20261020.json').read_text())
for name,expected in records.items():
    relative=Path(name).relative_to('manuscript');p=ROOT/relative
    assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==expected,name
result=dict(status='PASS',previous_study_files_verified=len(records),previous_study_files_changed=0)
(ROOT/'audits/prior_study_preservation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
