"""Check the closed manuscript, preserved numerical evidence and software study."""
from pathlib import Path
import json, hashlib, re
import numpy as np, pandas as pd, fitz
from scipy.stats import beta

ROOT=Path(__file__).resolve().parents[1]
FIG=ROOT/'paper/figures/visual'
DATA=FIG/'data'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
provenance=json.loads((FIG/'figure_provenance.json').read_text())
for name,value in provenance['sources'].items():assert sha(ROOT/name)==value,name
open_photos=ROOT/'paper/figures/open_photos'
photo_sources=json.loads((open_photos/'sources.json').read_text())
assert len(photo_sources)==2
for record in photo_sources:
 assert sha(open_photos/record['file'])==record['sha256'],record['file']
 assert record['metadata']['LicenseShortName']['value'] in ['Public domain','CC BY 2.0']
 assert record['role']=='Engineering context photograph; not a quantitative benchmark input'
qa=json.loads((FIG/'figure_canvas_qa.json').read_text())
assert len(qa)==13 and all(not q['text_outside_canvas'] for q in qa)

plans=pd.read_csv(DATA/'r9_all_frozen_plans.csv')
primary=plans.query('allowance==.15')
rows=[]
for study in ['A','B']:
 for method in ['ContractCover','ProceduralCoverValidated','DirectRecertCached','ExactCard']:
  g=primary.query('study==@study and method==@method')
  unique=g.drop_duplicates(['profile','service','event_id'])
  rows.append({'study':study,'method':method,'request_labels':len(g),
   'supported_labels':int((g.status=='AUTHORIZED').sum()),
   'unique_compiled_request_contexts':len(unique),
   'supported_unique_compiled_contexts':int((unique.status=='AUTHORIZED').sum())})
actual=pd.DataFrame(rows)
pd.testing.assert_frame_equal(actual,pd.read_csv(DATA/'audit_unique_support.csv'),check_dtype=False)
assert len(plans)==6144

cards=pd.read_csv(ROOT/'tables/all_risk_cards.csv')
mask=cards.k<cards.n
upper=np.ones(len(cards));upper[mask]=beta.isf(cards.loc[mask,'alpha'],cards.loc[mask,'k']+1,cards.loc[mask,'n']-cards.loc[mask,'k'])
cp_error=float(np.max(np.abs(upper-cards.upper)))
assert cp_error<1e-12 and len(cards)==3072
assert np.allclose(cards.alpha, .05/4608, rtol=1e-12, atol=0)
timing=pd.read_csv(DATA/'audit_report_timing.csv')
bad=timing[timing.full_report_necessarily_fails_timing]
assert len(bad)==5
report=cards.query('task=="report" and variant=="full"')
forced=pd.concat([report.query('study==@r.study and service==@r.service') for r in bad.itertuples()])
assert len(forced)==80 and (forced.k==forced.n).all() and (forced.upper==1).all()

summary=pd.read_csv(DATA/'r8_controlled_summary.csv')
effects={}
for profile in ['nominal','unfitted']:
 g=summary.query('profile==@profile and service=="standard"').set_index('policy')
 assert g.loc['Fixed2','n']==2048
 for metric in ['loss_m2s','work_s','observation_failure','union_failure']:
  assert g.loc['KG1',metric]==g.loc['FlatCART',metric]
 effects[profile]={'loss_reduction_pct':float(100*(1-g.loc['KG1','loss_m2s']/g.loc['Fixed2','loss_m2s'])),
                  'work_increase_pct':float(100*(g.loc['KG1','work_s']/g.loc['Fixed2','work_s']-1))}
assert round(effects['nominal']['loss_reduction_pct'],2)==15.68
assert round(effects['unfitted']['loss_reduction_pct'],2)==12.61
intervals=pd.read_csv(DATA/'r8_primary_intervals.csv')
assert len(intervals)==16 and (intervals.n==2048).all() and (intervals.resamples==32000).all()
routes=pd.read_csv(DATA/'r8_route_summary.csv')
assert len(routes)==108 and routes.groupby(['mesh','variant']).condition.nunique().eq(3).all()
assert set(routes.condition)=={'ordinary','contention','geometric_stress'}
assert routes.groupby(['mesh','condition']).variant.nunique().eq(12).all()
benchmark=pd.read_csv(DATA/'r9_preparation_benchmark.csv')
cold=benchmark.query('stage=="cold_event_preparation"').groupby('method').first()
reduction=100*(1-cold.loc['ContractCover','record_evaluations']/cold.loc['DirectRecertCached','record_evaluations'])
assert round(reduction,2)==53.66

study=ROOT/'studies/change_recovery_20261013'
freeze=json.loads((study/'freeze.json').read_text())
for name,value in freeze['files'].items():assert sha(study/name)==value,name
changes=pd.read_csv(study/'outputs/change_cases.csv')
results=json.loads((study/'outputs/results.json').read_text())
case=json.loads((study/'outputs/illustrated_case.json').read_text())
assert results['status']=='PASS' and results['freeze_sha256']==sha(study/'freeze.json')
assert results['new_independent_population_inputs']==results['newly_calibrated_event_cards']==0
assert len(changes)==15360 and changes.groupby('method').size().eq(5120).all()
assert changes.groupby(['study','profile','service','event_id','method']).edit.nunique().eq(16).all()
assert changes[['missed_invalidation','unnecessary_refusal','restore_mismatch']].eq(0).all().all()
assert changes.after_authorized.eq(changes.expected_authorized).all()
pivot=changes.pivot(index=['study','profile','service','event_id','edit'],columns='method',values='after_authorized')
assert pivot.ContractCover.eq(pivot.ProceduralCoverValidated).all()
assert case['source_sha256']==sha(study/'inputs/14300000.json')
source=json.loads((study/'inputs/14300000.json').read_text())
for name,value in source['files'].items():assert sha(study/'inputs'/name)==value
assert case['outcome']['active_index']==2 and case['capture_tick']==2
assert case['observed_full_report_pass'] and case['plan']['k']==229 and case['plan']['n']==2048
assert abs(case['plan']['upper']-0.14397310714093464)<1e-15
journey={x['stage']:x for x in case['journey'] if x['method']=='ContractCover'}
assert journey['decoder_v2_full_association']['status']=='REFUSED'
assert journey['decoder_v2_optical_component']['status']=='REFUSED'
assert journey['decoder_v2_readiness_component']['status']=='AUTHORIZED'
assert journey['original_full_association']['card']==journey['restore_decoder_full_association']['card']
assert all(x['new_calibration_records']==0 for x in case['journey'])
assert len(case['faults'])==24 and all(x['false_authorizations']==0 and x['reconstructed_history_refused'] and x['independent_successor_admitted'] for x in case['faults'])
costs=pd.read_csv(study/'outputs/matched_support_cost.csv').query('study=="combined"').set_index('method')
assert costs.matched_unique_requests.eq(47).all()
matched_reduction=100*(1-costs.loc['Anchor reuse','required_record_evaluations']/costs.loc['Direct event preparation','required_record_evaluations'])
assert round(matched_reduction,8)==20
eligible=changes[(changes.method=='ContractCover') & changes.before_authorized & (changes.edit!='unchanged')]
assert len(eligible)==705 and eligible.edit.nunique()==15
assert int((~eligible.after_authorized).sum())==489 and int(eligible.after_authorized.sum())==216
assert eligible.recovered.all()
corecost_text='\n'.join(p.get_text() for p in fitz.open(FIG/'09_boundaries.pdf'))
assert all(x in corecost_text for x in ['13.89%', '63,488', '73,728', 'Same 59 contexts', '0.143973'])
change_text='\n'.join(p.get_text() for p in fitz.open(FIG/'12_conformance.pdf'))
assert all(x in change_text for x in ['705', '489', '216', '705 / 705 restored', 'Stale plan', 'Whole producer'])
overview_text='\n'.join(p.get_text() for p in fitz.open(FIG/'01_overview.pdf'))
assert all(x in overview_text for x in ['Offline calibration', 'Typed request', 'Compile and match', 'Receipt monitor', 'Offline component-update audit'])
assert len(pd.read_csv(ROOT/'tables/confirmation_geometry_statistics.csv'))==192
assert len(pd.read_csv(ROOT/'tables/unsupported_stress_statistics.csv'))==512

methodology=ROOT/'studies/methodology_review_20261014'
for name,value in json.loads((methodology/'freeze.json').read_text())['files'].items():
 assert sha(methodology/name)==value,name
methodology_results=json.loads((methodology/'outputs/results.json').read_text())
assert methodology_results['status']=='PASS'
assert methodology_results['new_population_inputs']==methodology_results['new_calibration_cards']==0
assert len(methodology_results['archived_baselines'])==5
assert all(x['rgb_equal'] and x['metrics_match_archive'] for x in methodology_results['archived_baselines'])
assert sum(x['undeclared_quantity_changes'] for x in methodology_results['producer_audit'])==14
assert sum(x['flagged_source_pairs'] for x in methodology_results['producer_audit'])==10
hybrid_cost=pd.read_csv(methodology/'outputs/hybrid_cost.csv').query('study=="combined"').set_index('method')
assert hybrid_cost.supported_contexts.eq(59).all()
assert hybrid_cost.loc['Reuse plus direct fallback','event_record_evaluations']==63488
assert hybrid_cost.loc['Direct fixed policy','event_record_evaluations']==73728
assert methodology_results['compiler']['task_variant_roundtrips']==24
campaign=ROOT/'studies/change_campaign_20261014'
for name,value in json.loads((campaign/'freeze.json').read_text())['files'].items():
 assert sha(ROOT/name)==value,name
campaign_results=json.loads((campaign/'outputs/results.json').read_text())
assert campaign_results['status']=='PASS'
assert campaign_results['camera_configurations']==320
assert campaign_results['paired_pipeline_updates']==2560 and campaign_results['quantity_comparisons']==20480
campaign_cases=pd.read_csv(campaign/'outputs/change_cases.csv')
assert len(campaign_cases)==2560
assert campaign_cases.conditional_fault_active.eq(campaign_cases.gate_veto).all()
assert campaign_cases.gate_veto.sum()==747
assert campaign_results['primary_population_cards_changed']==0


surface=ROOT/'studies/cad_surface_20261014'
for name,value in json.loads((surface/'freeze.json').read_text())['files'].items():
 assert sha(surface/name)==value,name
spec=json.loads((surface/'protocol.json').read_text())
ob=pd.read_csv(surface/'outputs/observations.csv')
configuration=pd.read_csv(surface/'outputs/configurations.csv')
newcards=pd.read_csv(surface/'outputs/risk_cards.csv')
assert len(configuration)==384 and len(ob)==2304 and len(newcards)==48
assert configuration.groupby('phase').size().eq(192).all()
assert not set(configuration.query('phase=="calibration"').seed)&set(configuration.query('phase=="test"').seed)
assert ob.groupby(['phase','seed']).variant.nunique().eq(6).all()
assert spec['family_K']==48 and spec['confidence_error']==.05 and spec['allowance']==.15

def failure(frame,request):
 good=np.ones(len(frame),dtype=bool)
 for metric,(lo,hi) in request.items():
  values=frame[metric].to_numpy();good &= np.isfinite(values)
  if lo is not None:good &= values>=lo
  if hi is not None:good &= values<=hi
 return ~good
for row in newcards.itertuples():
 g=ob.query('phase=="calibration" and variant==@row.variant')
 t=ob.query('phase=="test" and variant==@row.variant')
 assert row.k==int(failure(g,spec['requests'][row.request]).sum())
 assert row.test_failures==int(failure(t,spec['requests'][row.request]).sum())
 assert row.n==row.test_n==192
 expected=1 if row.k==row.n else beta.isf(.05/48,row.k+1,row.n-row.k)
 assert abs(row.upper-expected)<1e-12
 assert bool(row.authorized)==(expected<=.15)
assert newcards.authorized.sum()==44
catalogue=pd.read_csv(surface/'outputs/catalogue_cost.csv')
assert catalogue.constructed_proofs.to_list()==[48,42,25]
assert catalogue.record_evaluations.to_list()==[9216,8064,4800]
assert catalogue.supported_contexts.eq(44).all()
ledger=pd.read_csv(surface/'outputs/refresh_ledger.csv')
assert len(ledger)==40
assert ledger[['whole_producer_runs','dependency_pipeline_runs','dependency_optical_runs','dependency_reuses']].sum().to_list()==[7680,5760,768,1152]
compiled=json.loads((surface/'outputs/compiled_requests.json').read_text())
assert len(compiled)==8 and len({c['event_identity'] for c in compiled})==8
for name,value in json.loads((FIG/'cad_surface_figure_provenance.json').read_text())['sources'].items():
 assert sha(ROOT/name)==value,name
surface_qa=json.loads((FIG/'cad_surface_canvas_qa.json').read_text())
assert len(surface_qa)==6 and all(not q['outside'] for q in surface_qa)

main=fitz.open(ROOT/'paper/main.pdf');supp=fitz.open(ROOT/'paper/supplement.pdf')
alltext='\n'.join(p.get_text() for p in main)
supptext='\n'.join(p.get_text() for p in supp)
normalized=re.sub(r'\s+',' ',alltext)
captions=re.findall(r'Figure (\d+):',alltext)
assert captions==list(map(str,range(1,9))),captions
assert all(x in normalized for x in ['38.10%', '3,072', '512', '10,752', '6,656', '41', '183.993'])
assert 'Appendix Appendix' not in alltext and 'Appendix A' not in alltext
for phrase in ['Primary-study provenance and scope','Physical implementation requires','Declaration of generative AI',
 'OpenAI-generated','pre-confirmation','prospective freezes','B line','A line','Baseline equivalence and attribution']:
 assert phrase not in alltext,phrase
assert 'Controlled scene population and service requirements' in alltext and 'Support preservation with exact fallback' in alltext
assert 'Evidence scope, data provenance and declarations' in supptext
assert 'not physical aircraft measurements' in supptext
assert 'Physical implementation requires' in supptext
assert 'Declaration of generative AI' in supptext
assert 'Complete localization confirmation catalogue' in supptext and 'Executed change and recovery validation' in supptext
assert 'All 48 controlled-study risk cards' in supptext and 'All 48 risk cards in the new population' in supptext
assert 'Simon Butler' in alltext and 'Rob Marshall' in alltext
assert 'Open photograph credits and reuse' in supptext
references_position=alltext.rfind('\nReferences\n')
assert references_position>0
reference_labels=re.findall(r'(?m)^\[(\d+)\]',alltext[references_position:])
bibitems=re.findall(r'\\bibitem(?:\[[^\]]*\])?\{([^}]+)\}',(ROOT/'paper/main.bbl').read_text())
assert reference_labels==list(map(str,range(1,len(bibitems)+1))),(reference_labels,bibitems)
urls=[x['uri'] for p in main for x in p.get_links() if 'uri' in x]
for doi in ['10.1016/j.aei.2026.104824','10.1109/TAES.2016.140952','10.1007/978-3-031-06773-0_12']:
 assert any(doi.lower() in u.lower() for u in urls),doi
content=(ROOT/'paper/sections/integrated_content.tex').read_text()
assert len(re.findall(r'\\section\{',content))==8
assert all(x in content for x in ['31_actual_inputs.pdf','03_platforms.pdf','integrated_results','request-grammar','eq:transfer','componentwise Huber'])
assert 'inspection_workflow_concept' not in content
assert all(x in alltext for x in ['Validity of calibration-selected services','Quarantine and authenticated repair','Matched comparisons'])
assert 'producer projection' in alltext
for name in ['main','supplement']:
 log=(ROOT/'paper'/f'{name}.log').read_text()
 assert not any(x in log for x in ['undefined references','Citation','Overfull','LaTeX Error','multiply defined']),name
result={'status':'PASS','main_pages':len(main),'supplement_pages':len(supp),'main_figures':len(captions),
 'preserved_source_snapshots_verified':len(provenance['sources']),'preserved_cards_verified':len(cards),
 'max_legacy_binomial_inversion_error':cp_error,'controlled_regular_grid_scenes':len(configuration),
 'controlled_producer_executions':len(ob),'controlled_calibrated_events':len(newcards),
 'controlled_supported_contexts':44,'controlled_contract_proofs':25,'controlled_exact_proofs':42,
 'controlled_contract_record_evaluations':4800,'controlled_exact_record_evaluations':8064,
 'controlled_record_reduction_percent':100*(1-4800/8064),
 'change_recovery_decisions_verified':len(changes),'receipt_faults_verified':len(case['faults']),
 'paired_camera_updates':2560,'activated_conditional_faults':747,
 'open_context_photographs':len(photo_sources),'photo_sources_and_licenses_verified':True,
 'all_statements_in_supplement':True,'generative_artwork_in_pdfs':False,'canvas_qa':'PASS',
 'scope':'Primary lifecycle study verified separately; preserved controlled studies and current manuscript structure.'}
(ROOT/'audits/visual_revision_qa.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
