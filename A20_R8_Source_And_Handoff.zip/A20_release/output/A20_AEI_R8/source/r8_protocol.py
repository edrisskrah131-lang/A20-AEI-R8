"""Prospective A20-AEI study. Never modifies the retained R4/R5 studies."""
from pathlib import Path
import hashlib, json

ROOT = Path(__file__).resolve().parents[1]
D = ROOT / 'data/r8_final'
BASE = ROOT / 'data/r4_final'
A19 = ROOT.parents[1] / 'work/a19/RAS_A19'

PROTOCOL = {
    'version': 'A20-AEI-R8-prospective-2',
    'design': 'matched input/predictor/price/budget; requests fixed before sensing',
    'pilot': {'base': 8200000, 'n': 48, 'use': 'implementation checks and service-cost characterization, never calibration/confirmation'},
    'blocks': {
        'nominal_calibration': {'base': 8300000, 'n': 4096, 'profile': 'nominal'},
        'geometry_calibration': {'base': 8400000, 'n': 4096, 'profile': 'unfitted'},
        'nominal_confirmation': {'base': 8500000, 'n': 2048, 'profile': 'nominal'},
        'geometry_confirmation': {'base': 8600000, 'n': 2048, 'profile': 'unfitted'},
        'occlusion_stress': {'base': 8700000, 'n': 384, 'profile': 'occlusion'},
        'degeneracy_stress': {'base': 8800000, 'n': 384, 'profile': 'degeneracy'},
        'prior_shift_stress': {'base': 8900000, 'n': 384, 'profile': 'prior_shift'},
        'map_shift_stress': {'base': 9000000, 'n': 384, 'profile': 'map_shift'}},
    'services': [
        {'id': 'relaxed', 'load': 10., 'deadline_s': .5, 'budget_s': .020},
        {'id': 'standard', 'load': 20., 'deadline_s': .3, 'budget_s': .012},
        {'id': 'tight', 'load': 40., 'deadline_s': .2, 'budget_s': .006},
        {'id': 'contended', 'load': 60., 'deadline_s': .3, 'budget_s': .012}],
    'dt_s': .1, 'queue_s': .05, 'horizon_s': 4., 'threshold_m': .1,
    'trajectory_times_s': [round(.5+.1*i, 10) for i in range(36)],
    'events': ['trajectory', 'observation', 'union'],
    'observation_failure': 'no operationally valid positive scan version ACTIVE at D after ordered installations/rollbacks, OR true position error at D > 0.1 m',
    'union_failure': 'trajectory failure OR observation failure on the same episode',
    'request_types': ['trajectory', 'observation', 'both_marginals', 'union'],
    'risk_allowances': [.10, .15, .20], 'primary_risk_allowance': .15,
    'family_error': .05, 'prices': [.3, 1., 3.],
    'policy_ids': ['KG0.3','KG1','KG3','FlatCART0.3','FlatCART','FlatCART3','FlatRF0.3','FlatRF','FlatRF3','ContractRF0.3','ContractRF','ContractRF3','Fixed2','Fixed4','Fixed8','Fixed16','Final','Residual','Random2or4','OldRAVC','CART_Time','RF_Time'],
    'family_size': 528,
    'budget': 'hard registration-stage sender cap in frozen normalized CPU-equivalent seconds, including source seal, registration, forecast, decision and publication validation; common front end and receiver replay/stream propagation charged separately in total work and availability',
    'budget_enforcement': 'before each next checkpoint, reserve a deterministic worst-case six correspondence queries per new iteration plus checkpoint/prediction/rule/witness costs; if unaffordable, stop and publish an eligible current candidate, otherwise retain prior. Same wrapper on every policy. No old certificate is reused.',
    'selection_tie': 'lexicographic (mean L + lambda_sel * mean total normalized work, policy_id)',
    'calibration_sensitivity_n': [128, 256, 512, 1024, 2048, 4096],
    'sensitivity_confidence': [.90, .95, .99],
    'selection_objective': 'mean L [m2 s] + lambda_sel [m2] * mean normalized work [s]',
    'lambda_sel_m2': 1., 'omega_m2s': .002,
    'predictors': 'unchanged R4 CART/RF, trained/validated on 1120 retained development sources',
    'primary_hypotheses': {
        'H1': 'Time/profile predicates change decisions under binding declared constraints, without assuming universal accuracy improvement.',
        'H2': 'Full transaction contracts prevent attachment to invalid lineage/configuration/versions; a fully validated procedural Flat comparator may be equivalent.',
        'H3': 'Event-aware policy selection differs from trajectory-only selection, but is compared to a same-task calibrated table selector.',
        'H4': 'Union calibration differs from intersecting marginal constraints; unsupported requests are refused.',
        'H5': 'Adaptive computation has conditional route trade-offs; Fixed2 can be preferable in ordinary conditions.'},
    'fault_cases': ['valid', 'wrong_policy', 'wrong_event', 'wrong_profile', 'wrong_model',
                    'wrong_source', 'wrong_prior', 'expired', 'stale_version', 'future_replay',
                    'invalid_card_bound', 'invalid_card_count', 'changed_service', 'rollback_resurrection'],
    'route_design': {'geometries': ['B767', 'C172', 'UnfittedAirframe'],
        'conditions': ['ordinary', 'contention', 'geometric_stress'], 'replicates': 4,
        'base': 9200000, 'duration_s': 600., 'scan_interval_s': 2.,
        'requests': 'exogenous task/service schedule; route profile remains separate from episode profiles',
        'unit': 'one independent stochastic route; repeated methods are paired executions',
        'certificate': 'descriptive full-route experiment; no episode-to-mission transfer'},
    'statistics': {'paired_bootstrap': 32000, 'seed': 2026101208,
        'episode_unit': 'unique fresh seed within its declared mixture',
        'route_unit': 'route input, stratified by geometry and condition',
        'primary_comparisons': 'Full vs TaskAwareFlatValidated and KG1 vs same-price FlatCART/FlatRF; adverse and null results retained',
        'primary_ci_family': 'standard service; Full and ValidatedFlat pre-specified union task at allowance 0.15, with refused admission retaining prior; two confirmation profiles, four contrasts (Full-ValidatedFlat, KG1-FlatCART, KG1-FlatRF, KG1-Fixed2), loss and observation failure = 16 intervals; pointwise 95% and Bonferroni-adjusted percentile bootstrap both reported; other summaries descriptive',
        'tails': 'p95, p99 and largest-5% mean; influence top-two deletion is descriptive'},
    'timing': {'availability': 'deterministic operation-count service profile characterized on separate pilot sources, then frozen',
        'cpu': 'native prefix CPU charged in controlled trace experiments; directly timed integrated service CPU in complete routes',
        'boundary': 'synthetic contention/service model, not embedded or robot latency measurement'},
    'same_tick_order': 'apply every arrived version in source-sequence order, including rollback, then assess the observation at D; publication/receiver validation work is charged before the version becomes available',
    'sampling_profiles': {
        'nominal': {'geometry':['B767','C172'],'prior_sd_m':[.015,.03,.06],'noise':[1.,2.],'shape_levels':[0,1,2],'sampling':'independent seed; uniform listed discrete choices; uniform route source frame 100..N-101; map translation SD .025 m and rotation SD .001 rad'},
        'unfitted': {'geometry':['UnfittedAirframe'],'prior_sd_m':[.015,.03,.06],'noise':[1.,2.],'shape_levels':[0,1,2],'sampling':'same source/prior/noise sampler, independent procedural geometry excluded from all fitting'},
        'stress': 'occlusion removes a uniformly oriented 2.2-rad azimuth sector; degeneracy retains a .5-rad sector centered at median measured azimuth; prior_shift SD .08/.12 m; map_shift uses newly specified .06 m normal warp; otherwise nominal sampler; no matching primary cards'},
    'freeze_rule': 'protocol, executable methods, predictors and service profile frozen before any final calibration/confirmation generation; calibration chooses from the frozen family, then all cards and full/fair plans are frozen before confirmation generation or any access',
    'legacy': 'R4 2680 inputs, R4 81 executions, R5 secondary reuse and original A19/A20 preserved as separate studies',
    'truth': 'sensor generation and offline scoring only; never passed to online predicates/selector',
    'physical_trials': 0}

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def write_protocol():
    D.mkdir(parents=True, exist_ok=True)
    p=D/'protocol.json'
    if p.exists() and json.loads(p.read_text()) != PROTOCOL:
        raise RuntimeError('Protocol amendment requires a new named version')
    p.write_text(json.dumps(PROTOCOL,indent=2,allow_nan=False))

if __name__ == '__main__': write_protocol()
