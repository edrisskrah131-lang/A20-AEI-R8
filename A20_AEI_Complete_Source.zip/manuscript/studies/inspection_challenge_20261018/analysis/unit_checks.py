"""Finite checks of raised-surface mapping, missing rays and occluded-match scoring."""
import json
import numpy as np
from pipeline import ROOT, intersect_mesh, project, estimate, score

base = np.array([[-1,-1,0],[1,-1,0],[1,1,0],[-1,1,0]], float)
raised = np.array([[-.2,-.2,.1],[.2,-.2,.1],[.2,.2,.1],[-.2,.2,.1]], float)
vertices = np.vstack([base, raised])
faces = np.array([[0,1,2],[0,2,3],[4,5,6],[4,6,7]])
camera = np.array([0.,0.,1.])
rays = np.array([[0,0,-1],[.5,0,-1],[2,0,-1]], float)
rays /= np.linalg.norm(rays, axis=1, keepdims=True)
hit = intersect_mesh(camera, rays, vertices, faces)
assert np.allclose(hit[0], [0,0,.1])
assert np.allclose(hit[1], [.5,0,0])
assert np.isnan(hit[2]).all()

xy = np.array([(x,y) for y in [-.1,0,.1] for x in [-.1,0,.1]])
targets = np.c_[xy, np.full(len(xy), .1)]
rotation = np.diag([1.,-1.,-1.])
pixels = project(targets, camera, rotation, 1000.)
fitted = estimate(targets, camera, rotation, 1000., pixels)
scene = dict(actual=targets.tolist(), missing=[False]*9, translation_error=[0,0,0])
variant = dict(camera=camera.tolist(), rotation=rotation.tolist(), focal=1000., visible=[True]*9)
perfect, _ = score(scene, variant, fitted, vertices, faces)
assert perfect['coverage'] == 1
assert perfect['association_m'] < 1e-12
assert perfect['observable_screen_accept'] and not perfect['quality_failure']
variant['visible'][0] = False
variant['visible'][1] = False
occluded, _ = score(scene, variant, fitted, vertices, faces)
assert occluded['coverage'] == 7/9
assert occluded['planned_targets'] == 9
assert occluded['accepted_but_failed']
result = dict(status='PASS', nearest_raised_surface_hit=True, outside_mesh_ray_preserved=True,
              exact_pose_mapping_error_m=perfect['association_m'],
              occluded_targets_remain_in_denominator=True,
              invisible_target_distractors_do_not_count_as_correct=True,
              observable_screen_false_acceptance_distinguished=True)
(ROOT/'unit_checks.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
