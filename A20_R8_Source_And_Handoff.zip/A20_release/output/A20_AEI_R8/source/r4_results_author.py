"""Build manuscript evidence tables from the independently verified final batch."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import json
import numpy as np,pandas as pd
from r4_protocol import ROOT,D
PH=['nominal_confirmation','difficult_confirmation','geometry_confirmation','shift_confirmation']
LABEL=dict(zip(PH,['Nominal','Difficult priors','Unfitted geometry','Shifted noise/prior']))
def label(p):return p.replace('ProceduralAirframe','Procedural').replace('_no_profile',' w/o profile').replace('_no_deadline',' w/o time').replace('_held',' held')
def table(caption,key,columns,rows,size=r'\footnotesize'):
    body='\n'.join(' & '.join(map(str,r))+r'\\' for r in rows)
    return (r'\begin{table}[!htbp]\centering'+size+'\n'+r'\caption{'+caption+r'}\label{'+key+'}\n'+
            r'\begin{tabular}{@{}l'+'r'*(len(columns)-1)+r'@{}}\toprule'+'\n'+' & '.join(columns)+r'\\\midrule'+'\n'+body+'\n'+r'\bottomrule\end{tabular}\end{table}'+'\n')
def figure(name,caption,key):
    return r'\begin{figure}[t]\centering\includegraphics[width=.98\linewidth]{r4/'+name+r'.pdf}\caption{'+caption+r'}\label{'+key+r'}\end{figure}'+'\n'
def main():
    s=pd.read_csv(D/'summary.csv');cf=pd.read_csv(D/'calibration.csv');routes=pd.read_csv(D/'route_results.csv')
    inf=pd.read_csv(D/'influence.csv');mech=pd.read_csv(D/'mechanisms.csv');stress=pd.read_csv(D/'service_stress_summary.csv')
    effects=json.loads((D/'paired_effects.json').read_text());selection=json.loads((D/'selection.json').read_text())
    audit=json.loads((D/'contract_audit.json').read_text());cost=json.loads((D/'interface_cost.json').read_text())
    assert len(routes)==81 and len(cf)==120 and audit['checks']==9000
    ragg=routes.groupby(['mesh','policy']).agg(n=('rep','size'),cpu_s=('cpu_s','mean'),rmse_cm=('rmse_cm','mean'),
        loss_m2s=('loss_m2s','mean'),capture_success=('capture_success','mean'),capture_ready=('capture_ready','mean')).reset_index()
    ragg.to_csv(D/'route_summary.csv',index=False)
    ra=routes[routes.policy=='KG1'].set_index(['mesh','rep']).sort_index();rng=np.random.default_rng(202610118);routefx=[]
    for control in ['Fixed2','Fixed4','Final','FlatRF','ContractRF','KG1_no_profile','KG1_no_deadline','KG1_held']:
        rb=routes[routes.policy==control].set_index(['mesh','rep']).loc[ra.index]
        strata=[np.flatnonzero(ra.index.get_level_values(0)==m) for m in sorted(routes.mesh.unique())]
        ix=np.concatenate([rng.choice(g,(10000,len(g)),replace=True) for g in strata],axis=1)
        for metric in ['rmse_cm','cpu_s','loss_m2s','capture_success']:
            scale=100/299 if metric=='capture_success' else 1
            delta=(ra[metric].to_numpy()-rb[metric].to_numpy())*scale
            routefx.append({'policy':'KG1','control':control,'metric':metric,'difference':float(delta.mean()),
              'difference_ci':np.quantile(delta[ix].mean(axis=1),[.025,.975]).tolist(),'n':9,'resamples':10000,
              'unit':'nine paired route inputs; stratified resampling of three seeds per geometry',
              'difference_unit':'percentage points' if metric=='capture_success' else metric})
    (D/'route_effects.json').write_text(json.dumps(routefx,indent=2))
    def row(phase,policy,load=20):return s[(s.phase==phase)&(s.policy==policy)&(s.load==load)].iloc[0]
    def eff(phase,control,metric='loss_m2s'):return next(e for e in effects if e['phase']==phase and e['control']==control and e['metric']==metric)
    setup=table('Independent inputs in the regenerated final study. The 24 service-benchmark inputs are excluded from risk calibration.','tab:splits',
        ['Input mixture','Risk calibration','Confirmation'],[['Nominal B767/C172',456,640],['Difficult prior B767/C172','---',480],
        ['Shifted noise/prior B767/C172','---',360],['Procedural geometry',240,480],['Service benchmark (24)','---','---'],['Risk/confirmation total',696,1960]])
    selrows=[]
    for x in sorted(selection,key=lambda x:(x['context'],x['load'])):
        g=x['global'];k=x['certified_KG']
        selrows.append(['Nominal' if x['context'].startswith('nominal') else 'Procedural',f"{x['load']:g}",g['policy'],
            f"{g['k']}/{g['n']}",f"{g['upper_risk']:.4f}",k['policy'] or 'None'])
    sel=table('Common selection across all 20 policies for the trajectory event at allowance 0.15. The last column selects within contract-CART. Observation cards are assessed separately.','tab:selection',
        ['Mixture',r'$\alpha$','All-family choice',r'$k/n$',r'$U_{\rm traj}$','Contract-CART choice'],selrows)
    mainrows=[]
    for phase in PH:
        mainrows.append([r'\multicolumn{7}{l}{\textit{'+LABEL[phase]+r'}}'])
        for policy in ['Fixed2','Fixed4','Final','FlatCART','FlatRF','ContractRF','KG1']:
            r=row(phase,policy);mainrows.append([policy,f'{r.cpu_ms:.2f}',f'{r.loss:.5f}',f'{r.rmse_cm:.2f}',int(r.events),
                f'{int(r.success)}/{int(r.n)}',f'{r.mean_iterations:.2f}'])
    mainbody=table('Independent confirmation at declared load 20. CPU includes numerical front-end processing, solver, decisions, propagation and receiver replay. Success requires a positive scan-source version active at 0.3 s and error at most 0.1 m.','tab:confirmation',
        ['Policy','CPU (ms)',r'$L$ (m$^2$s)','RMSE (cm)','Traj. fails','Pose success','Mean it.'],mainrows)
    pairrows=[]
    for phase in PH:
        for control in ['Fixed2','Fixed4','FlatCART','FlatRF']:
            e=eff(phase,control);c=eff(phase,control,'cpu_s')
            pairrows.append([LABEL[phase],control,f"{100*e['improvement']:.2f}",
                f"{100*e['improvement_ci'][0]:.2f}, {100*e['improvement_ci'][1]:.2f}",f"{-100*c['improvement']:+.2f}"])
    pairtab=table('Paired KG1 loss effects at load 20; positive gain means lower loss. Descriptive 95\\% intervals resample paired independent seeds 10,000 times. CPU change is relative to the comparator; intervals are not simultaneous tests.','tab:paired',
        ['Mixture','Comparator','Loss gain (\\%)','95\\% interval (\\%)','CPU change (\\%)'],pairrows)
    infrows=[]
    for phase in PH:
        x=inf[inf.phase==phase].iloc[0];infrows.append([LABEL[phase],f'{x.improved:.0f}/{x.worse:.0f}/{x.equal:.0f}',
            f'{100*x.top_two_fraction_of_net:.1f}',f'{100*x.gain_excluding_top_two:.1f}',f'{100*x.tail_improvement:.1f}'])
    inftab=table('KG1 versus Fixed2 influence and tail analysis at load 20. Tail means use the largest 5\\% losses within each policy. Deletion and tail summaries are descriptive.','tab:influence',
        ['Mixture','Better/worse/equal','Top-two share (\\%)','Gain w/o two (\\%)','Tail gain (\\%)'],infrows)
    mrows=[]
    for phase in PH:
        for p in ['KG1_no_profile','KG1_no_deadline','KG1_held']:
            x=mech[(mech.phase==phase)&(mech.control==p)].iloc[0];mrows.append([LABEL[phase],label(p),int(x.changed_jobs),
                f'{x.mean_cpu_difference_ms:+.3f}',f'{1e3*x.mean_loss_difference:+.3f}',f'{x.capture_success_KG:.0f}/{x.capture_success_control:.0f}'])
    mt=table('Same-forecast interventions at load 20. Changed jobs differ in stop iteration or publication count. Differences are KG1 minus control; loss is in $10^{-3}$ m$^2$s.','tab:mechanisms',
        ['Mixture','Control','Changed','CPU (ms)','Loss','Pose successes'],mrows)
    strows=[]
    for phase in PH:
        for p in ['KG1','KG1_no_deadline','Fixed2']:
            x=stress[(stress.phase==phase)&(stress.load==60)&(stress.policy==p)].iloc[0];strows.append([LABEL[phase],label(p),
                f'{x.cpu_ms:.2f}',f'{x.loss:.5f}',int(x.events),f'{int(x.success)}/{int(x.n)}'])
    st=table('Additional workload at load 60 on the same confirmation inputs. These loads are outside the calibration family and carry no event-card guarantee.','tab:workload',
        ['Mixture','Policy','CPU (ms)',r'$L$ (m$^2$s)','Traj. fails','Pose success'],strows)
    route_rows=[]
    for p in ['Fixed2','Fixed4','Final','FlatRF','ContractRF','KG1','KG1_no_profile','KG1_no_deadline','KG1_held']:
        x=routes[routes.policy==p].mean(numeric_only=True);route_rows.append([label(p),f'{x.cpu_s:.3f}',f'{x.rmse_cm:.3f}',
            f'{x.loss_m2s:.4f}',f'{100*x.capture_ready/299:.2f}',f'{100*x.capture_success/299:.2f}'])
    rt=table('Complete-route means over nine paired 600-s inputs, with 299 observation opportunities each. Eighty-one executions are nine policies on nine inputs.','tab:routes',
        ['Policy','CPU (s)','RMSE (cm)',r'$L$ (m$^2$s)','Ready (\\%)','Success (\\%)'],route_rows)
    evaluation=(ROOT/'sections/evaluation_narrative.tex').read_text()
    replacements={'SETUP':setup,'SELECTION':sel,'CONFIRMATION':mainbody,'PAIRED':pairtab,'INFLUENCE':inftab,'MECHANISMS':mt,'STRESS':st,'ROUTES':rt,
        'FRONTIER_FIG':figure('frontier','Matched work--loss comparison at load 20. Lower points have less loss; points farther left use less numerical CPU.','fig:frontier'),
        'INFLUENCE_FIG':figure('influence','Paired improvements and influence at load 20. The difficult-mixture plot includes adverse and beneficial individual effects. Top-two deletion is a sensitivity analysis.','fig:influence'),
        'WORKLOAD_FIG':figure('workload','Additional nominal workload analysis. Earlier stopping reduces CPU and improves deadline availability while increasing loss; these loads have no calibrated card.','fig:workload'),
        'ROUTES_FIG':figure('routes','Means over nine paired independent routes. CPU, RMSE and deadline-pose success describe distinct requirements. Fixed2 remains competitive.','fig:routes'),
        'CHECK_MEDIAN':f"{cost['median_us']:.2f}",'CHECK_P95':f"{cost['p95_us']:.2f}"}
    for key,value in replacements.items():evaluation=evaluation.replace('@@'+key+'@@',value)
    assert '@@' not in evaluation
    (ROOT/'sections/evaluation.tex').write_text(evaluation)
    supp=(ROOT/'sections/supplement_protocol.tex').read_text()
    for phase in ['nominal_calibration','geometry_calibration']:
        for load in [1,10,20]:
            q=cf[(cf.phase==phase)&(cf.load==load)].sort_values('policy')
            rows=[[x.policy,int(x.n),int(x.k),f'{x.upper_risk:.5f}',int(x.task_k),f'{x.task_upper_risk:.5f}',f'{1000*x.cpu_s:.3f}',f'{x.loss_m2s:.5f}'] for x in q.itertuples()]
            supp+=table(('Nominal' if phase.startswith('nominal') else 'Procedural geometry')+f' calibration at load {load}. Event-specific counts and simultaneous upper risks.','supp:cal'+phase+str(load),
                ['Policy',r'$n$',r'$k_{\rm traj}$',r'$U_{\rm traj}$',r'$k_{\rm obs}$',r'$U_{\rm obs}$','CPU (ms)',r'$L$ (m$^2$s)'],rows)+'\n'
    supp+=r'\FloatBarrier'+'\n'+r'\section{All-family independent confirmation}'+'\n'+r'Tables include all 20 calibrated policies. Each cell is numerical CPU (ms) / loss (m$^2$s) / trajectory failures / observation successes. Loads reuse the same inputs and are not additional independent samples.'+'\n'
    for phase in PH:
        rows=[]
        for p in sorted(cf.policy.unique()):
            values=[p]
            for load in [1,10,20]:
                x=row(phase,p,load);values.append(f'{x.cpu_ms:.2f}/{x.loss:.5f}/{int(x.events)}/{int(x.success)}')
            rows.append(values)
        supp+=table(LABEL[phase]+f": $n={int(row(phase,'KG1').n)}$ independent inputs.",'supp:confirm'+phase,
            ['Policy','Load 1','Load 10','Load 20'],rows,size=r'\scriptsize')+'\n'
    supp+=r'\FloatBarrier'+'\n'+r'\section{Complete routes and additional workload}'+'\n'+r'Route seeds are 5,700,000 + replicate + 10,000 $\times$ geometry index (B767: 0; C172: 1; procedural: 2), with replicate 0, 1 or 2. Each raw input is shared by nine variants. Each route has 299 observation opportunities. Means below use three seeds per geometry.'+'\n'
    for mesh in ['B767','C172','ProceduralAirframe']:
        q=ragg[ragg.mesh==mesh].sort_values('policy')
        rows=[[label(x.policy),f'{x.cpu_s:.3f}',f'{x.rmse_cm:.3f}',f'{x.loss_m2s:.4f}',f'{100*x.capture_ready/299:.2f}',f'{100*x.capture_success/299:.2f}'] for x in q.itertuples()]
        supp+=table(label(mesh)+' means over three independent 600-s routes.','supp:route'+mesh,
            ['Policy','CPU (s)','RMSE (cm)',r'$L$ (m$^2$s)','Ready (\\%)','Success (\\%)'],rows)+'\n'
    rfrows=[]
    for control in ['Fixed2','Final','FlatRF','ContractRF','KG1_no_profile','KG1_no_deadline','KG1_held']:
        for metric in ['rmse_cm','cpu_s','capture_success']:
            x=next(v for v in routefx if v['control']==control and v['metric']==metric)
            rfrows.append([label(control),{'rmse_cm':'RMSE (cm)','cpu_s':'CPU (s)','capture_success':'Success (pp)'}[metric],
                f"{x['difference']:+.4f}",f"{x['difference_ci'][0]:+.4f}, {x['difference_ci'][1]:+.4f}"])
    supp+=table('Paired KG1 minus comparator route effects. Descriptive percentile 95\\% intervals use 10,000 stratified resamples of the nine inputs, three per geometry.','supp:routeeffects',
        ['Comparator','Metric','Difference','95\\% interval'],rfrows)+'\n'
    for load in [40,60]:
        rows=[]
        for phase in PH:
            for p in ['KG1','KG1_no_deadline','Fixed2','FlatCART','FlatRF','ContractRF']:
                x=stress[(stress.phase==phase)&(stress.load==load)&(stress.policy==p)].iloc[0]
                rows.append([LABEL[phase],label(p),f'{x.cpu_ms:.3f}',f'{x.loss:.5f}',int(x.events),f'{int(x.success)}/{int(x.n)}'])
        supp+=table(f'Additional workload at load {load}; reused confirmation inputs, no matching calibration card.','supp:stress'+str(load),
            ['Mixture','Policy','CPU (ms)',r'$L$ (m$^2$s)','Traj. fails','Pose success'],rows,size=r'\scriptsize')+'\n'
    supp+=r'\FloatBarrier'+'\n'+(ROOT/'sections/supplement_reproduction.tex').read_text()
    (ROOT/'sections/supplement_r4.tex').write_text(supp)
    print('R4_AUTHOR_COMPLETE',flush=True)
if __name__=='__main__':main()
