"""Execute frozen checkpoint policies with source replacement and motion replay.

Six retained aircraft sensor/motion realizations; no new physical measurements.
Runtime multipliers model concurrent processor load, not a hardware benchmark.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import time,json,hashlib,sys
import numpy as np
import pandas as pd
from checkpoint import ROOT,WORK,CompactTree,run_registration
from rcp.core import JointState,propagate,exp,log,register
from rcp.sensor import Mesh

D=ROOT/'data';R=D/'route_execution';R.mkdir(exist_ok=True)
freeze=json.loads((D/'frozen_policies.json').read_text())
selection=json.loads((D/'policy_selection.json').read_text())
assert hashlib.sha256((D/'checkpoint_model.npz').read_bytes()).hexdigest()==freeze['model_sha256']
model=CompactTree(D/'checkpoint_model.npz')
chosen=next(q for q in selection if q['runtime_multiplier']==10. and q['delta']==.15 and q['family']=='learned')
baseline=next(q for q in selection if q['runtime_multiplier']==10. and q['delta']==.15 and q['family']=='baseline')
policy=next(p for p in freeze['policies'] if p['id']==chosen['policy'])
methods=[('selected','learned',False,False),('hold_publication','learned',True,False),
         ('continue_to_completion','learned',False,True),('final','final',False,False),
         ('calibrated_baseline',baseline['policy'],False,False),('fixed_4','fixed_4',False,False)]
if '--native' in sys.argv:
    methods=[('native_final','native_final',False,False)]
protocol=dict(version='R3-route-execution-1',policy=policy,baseline=baseline['policy'],
    runtime_multiplier=10.,queue_s=.05,methods=[m[0] for m in methods],
    causal_scan_source='retained A19 fixed two-second sensor realizations',
    reliability_scope='descriptive complete-route exposure, not calibrated four-second episode risk')
(D/('protocol_native_routes.json' if '--native' in sys.argv else 'protocol_routes.json')).write_text(json.dumps(protocol,indent=2))

def error(s,truth,mt,mR):
    p=(s.t-s.mt)@s.mR-(truth[:3]-mt)@mR
    r=log(s.mR.T@s.R@(mR.T@exp(truth[3:])).T)
    return float(np.linalg.norm(p)),float(np.linalg.norm(r))

def run(folder,name,method,held,no_stop,prior_map,mesh_id):
    out=R/f'{folder.name}_{name}.json'
    if out.exists():return json.loads(out.read_text())['result']
    z=np.load(folder/'inputs.npz');a=np.load(folder/'initial.npz')
    s=JointState(*(a[k] for k in ['t','R','bias','mt','mR','P']))
    truth=z['truth'];increments=z['increment'];mt=z['map_t'];mR=exp(z['map_rot'])
    clouds={int(frame):z['xyz'][z['offsets'][i]:z['offsets'][i+1]] for i,frame in enumerate(z['frames'])}
    jobs=[];events=[];pending=None;trace=[];prop_cpu=reg_cpu=replay_cpu=0.;dropped=0
    for frame in range(len(truth)):
        if frame:
            start=time.process_time_ns();s=propagate(s,.1,increments[frame]);prop_cpu+=(time.process_time_ns()-start)*1e-9
        if pending is not None:
            while pending['pubs'] and pending['pubs'][0][0]<=frame:
                delivery,post,it=pending['pubs'].pop(0)
                start=time.process_time_ns();replayed=post.copy()
                for tick in range(pending['source']+1,frame+1):replayed=propagate(replayed,.1,increments[tick])
                s=replayed;replay_cpu+=(time.process_time_ns()-start)*1e-9
                events.append(dict(source_frame=pending['source'],delivery_frame=frame,iteration=it,
                                   replay_steps=frame-pending['source']))
            if frame>=pending['end'] and not pending['pubs']:pending=None
        if frame>0 and frame in clouds:
            if pending is not None:dropped+=1
            else:
                if method=='native_final':
                    start=time.process_time_ns();wall=time.perf_counter_ns()
                    post,rs,_,_=register(prior_map,clouds[frame],s,'converged',cpu_limit=1.)
                    cpu=(time.process_time_ns()-start)*1e-9;wt=(time.perf_counter_ns()-wall)*1e-9
                    pubs=[(post,cpu,wt,rs['iterations'])] if rs['accepted'] else []
                    stats=dict(cpu_s=cpu,wall_s=wt,solver_cpu_s=rs['cpu_s'],decision_cpu_s=0.,
                               iterations=rs['iterations'],checkpoints=1,accepted=rs['accepted'],trace=[rs])
                else:
                    pubs,stats=run_registration(prior_map,clouds[frame],s,mesh_id,method,model,
                        policy['price'],policy['tail_limit'],stop=not no_stop)
                reg_cpu+=stats['cpu_s']
                if held and pubs:
                    p,c,w,it=pubs[-1];pubs=[(p,stats['cpu_s'],stats['wall_s'],it)]
                delivery=[(frame+max(1,int(np.ceil((.05+10.*c)/.1))),post,it) for post,c,w,it in pubs]
                end=frame+max(1,int(np.ceil((.05+10.*stats['cpu_s'])/.1)))
                pending=dict(source=frame,pubs=delivery,end=end)
                jobs.append(dict(source_frame=frame,end_frame=end,**stats))
        pe,re=error(s,truth[frame],mt,mR)
        trace.append([frame*.1,*s.t,*log(s.R),pe,re])
    t=np.asarray(trace);e=t[:,7];rot=t[:,8]
    result=dict(route=folder.name,mesh=folder.name.split('_')[0],method=name,solver_method=method,
        duration_s=len(truth)*.1,rmse_m=float(np.sqrt(np.mean(e**2))),p95_m=float(np.quantile(e,.95)),
        max_m=float(e.max()),rotation_rmse_deg=float(np.rad2deg(np.sqrt(np.mean(rot**2)))),
        fraction_above_10cm=float(np.mean(e>.1)),route_event_after_5s=int(np.any(e[50:]>.1)),
        integrated_position_mse_m2s=float(np.sum(e**2)*.1),cpu_s=prop_cpu+reg_cpu+replay_cpu,
        correction_cpu_s=reg_cpu,propagation_cpu_s=prop_cpu,replay_cpu_s=replay_cpu,
        initial_cpu_s=float(a['cpu']),calls=len(jobs),dropped_scans=dropped,publications=len(events),
        mean_iterations=float(np.mean([j['iterations'] for j in jobs])),
        mean_decision_us=float(np.mean([j['decision_cpu_s'] for j in jobs])*1e6),
        provenance='NEW_EXECUTION_ON_RETAINED_CAUSAL_AIRCRAFT_INPUTS')
    np.savez_compressed(R/f'{folder.name}_{name}.npz',trace=t)
    out.write_text(json.dumps(dict(result=result,jobs=jobs,publications=events),indent=2))
    print('ROUTE',folder.name,name,'RMSE_cm',round(result['rmse_m']*100,3),'CPU_s',round(result['cpu_s'],3),flush=True)
    return result

if __name__=='__main__':
    tasks=[];maps={}
    folders=sorted((WORK/'work/a19/RAS_A19/data/missions').glob('*_mission*'))
    assert len(folders)==6
    for mesh_id,mesh in enumerate(['B767','C172']):maps[mesh]=Mesh(WORK/f'work/a19/RAS_A19/meshes/{mesh}/airframe_mesh.npz').prior
    for folder in folders:
        for m in methods:tasks.append((folder,*m))
    # Order is fixed independently of outcomes to distribute host timing drift.
    rng=np.random.default_rng(202610112);rng.shuffle(tasks);results=[]
    for folder,name,method,held,no_stop in tasks:
        mesh=folder.name.split('_')[0]
        results.append(run(folder,name,method,held,no_stop,maps[mesh],int(mesh=='C172')))
        pd.DataFrame(results).sort_values(['route','method']).to_csv(D/('native_route_results.csv' if '--native' in sys.argv else 'route_results.csv'),index=False)
    print('COMPLETE_ROUTE_RUNS',len(results),flush=True)
