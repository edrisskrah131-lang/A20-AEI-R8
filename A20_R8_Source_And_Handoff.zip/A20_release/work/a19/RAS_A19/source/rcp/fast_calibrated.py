"""Shared sufficient statistics for the same paired risk model.

All four actions were collected at each source. Their conditioning features,
source errors and weights are identical; only the paired output differs.
This implementation shares the neighbour query and source pseudoinverse.
"""
from collections import OrderedDict
import numpy as np
from .calibrated_v2 import ClosedLoopRisk as ReferenceRisk
from .core import ACTIONS,psd

class FastClosedLoopRisk(ReferenceRisk):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        base=self.indices['full']
        for a in ACTIONS[1:]:
            ids=self.indices[a]
            assert np.array_equal(self.x[ids],self.x[base])
            assert np.array_equal(self.P[ids],self.P[base])
            assert np.array_equal(self.paired[ids,:18],self.paired[base,:18])
        self.local_position=np.zeros(len(self.x),dtype=int)
        self.local_position[base]=np.arange(len(base))
        self.contexts=OrderedDict()

    def predict(self,x,P,action,k=None):
        key=(x.tobytes(),P.tobytes())
        if key not in self.contexts:
            ids,w=self.neighbours(x,P,'full');local=self.local_position[ids]
            u=self.paired[ids,:18];mu=w@u;U=(u-mu)/self.scale
            C=np.einsum('n,ni,nj->ij',w,U,U);Ci=np.linalg.pinv(C,rcond=1e-10)
            ms=psd(np.einsum('n,ni,nj->ij',w,u,u),floor=0.)
            Cs=psd(np.einsum('n,ni,nj->ij',w,u-mu,u-mu),floor=0.)
            self.contexts[key]=(local,w,u,mu,U,C,Ci,ms,Cs,{})
            if len(self.contexts)>128:self.contexts.popitem(last=False)
        local,w,u,mu,U,C,Ci,ms,Cs,answers=self.contexts[key]
        if action not in answers:
            ids=self.indices[action][local];v=self.paired[ids,18:];alpha=self.alpha.get(action,1.)
            mvraw=w@v;mv=(1-alpha)*mu+alpha*mvraw
            D=np.einsum('n,ni,nj->ij',w,(v-mvraw)/self.scale,U)
            Aw=np.eye(18)+alpha*(D-C)@Ci
            A=Aw*self.scale[:,None]/self.scale[None,:];b=mv-A@mu
            prediction=u@A.T+b;rv=v-prediction;ru=u-prediction
            R=psd(alpha*np.einsum('n,ni,nj->ij',w,rv,rv)+(1-alpha)*np.einsum('n,ni,nj->ij',w,ru,ru),floor=0.)
            mp=psd((1-alpha)*ms+alpha*np.einsum('n,ni,nj->ij',w,v,v),floor=0.)
            probs=np.array([w[self.outcome[ids]==i].sum() for i in range(3)])
            answers[action]=(ms,mp,probs,float(np.quantile(self.cost[ids],.95)),A,b,R,mu,Cs)
        return answers[action]
