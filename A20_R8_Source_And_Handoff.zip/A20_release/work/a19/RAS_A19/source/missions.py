"""Full 33-minute route execution with causal cached registration probes.

Only scans at the fixed two-second decision opportunities are materialized.
All policies consume the same motion and scan realization; state feedback is
recomputed separately for each policy. Controller timing is serial.
"""
import json,pickle,hashlib
from pathlib import Path
from time import process_time_ns,perf_counter_ns,perf_counter
import numpy as np
import pandas as pd
from prospective import ROOT,Mesh,scan,rel_error,context,ACTIONS,exp,log,JointState,initial_cov,propagate,register
from reuse import dispatch

def generate(c):
    name=f"{c['mesh']}_mission{c['replicate']}";folder=ROOT/'data/missions'/name;folder.mkdir(parents=True,exist_ok=True)
    if (folder/'manifest.json').exists():return folder
    mesh=Mesh(ROOT/f"meshes/{c['mesh']}/world_discrepancy_{c['level']}.npz")
    route=np.load(ROOT/f"meshes/{c['mesh']}/route.npz")['pose'];truth=route.copy();n=len(truth)
    rng=np.random.default_rng(c['seed']);inc=np.zeros((n,6));bias=np.zeros((n,6));sd=np.r_[np.full(3,.0015),np.full(3,.00015)]
    bias[0]=rng.normal(0,sd)
    for j in range(1,n):
        bias[j]=np.exp(-.1/125)*bias[j-1]+rng.normal(0,sd)*np.sqrt(1-np.exp(-.2/125))
        inc[j]=np.r_[(truth[j,:3]-truth[j-1,:3])@exp(truth[j-1,3:]),log(exp(truth[j-1,3:]).T@exp(truth[j,3:]))]
    measured=inc+bias*.1+rng.normal(0,np.sqrt(.1)*np.r_[np.full(3,.004),np.full(3,.0004)],inc.shape)
    mt=rng.normal(0,.025,3);mr=rng.normal(0,.001,3);clouds=[];frames=[];offsets=[0]
    for j in range(0,n,20):
        velocity=inc[min(j+1,n-1)]/.1
        causal=measured[j]/.1
        cloud=scan(mesh,truth[j],velocity,c['seed']*10000+j,j*.1,1024,mt,exp(mr),deskew_velocity=causal)['xyz']
        clouds.append(cloud);frames.append(j);offsets.append(offsets[-1]+len(cloud))
    np.savez_compressed(folder/'inputs.npz',truth=truth,increment=measured,map_t=mt,map_rot=mr,
                        xyz=np.concatenate(clouds),frames=frames,offsets=offsets)
    (folder/'manifest.json').write_text(json.dumps(dict(**c,duration_s=n*.1,motion_hz=10.,
        scans_materialized=len(frames),scan_model='16 elevations, 1024 columns, rolling 0.1-second sweep',
        sha256=hashlib.sha256((folder/'inputs.npz').read_bytes()).hexdigest()),indent=2))
    print('GENERATED',name,len(frames),'scans',flush=True)
    return folder

def run(c,ratio,method,models):
    folder=ROOT/'data/missions'/f"{c['mesh']}_mission{c['replicate']}"
    tag=f'{method}_r{ratio:g}';resultfile=folder/(tag+'.json')
    if resultfile.exists():return json.loads(resultfile.read_text())['result']
    z=np.load(folder/'inputs.npz');truth=z['truth'];increments=z['increment'];mt=z['map_t'];mR=exp(z['map_rot'])
    clouds={int(frame):z['xyz'][z['offsets'][i]:z['offsets'][i+1]] for i,frame in enumerate(z['frames'])}
    mesh=Mesh(ROOT/f"meshes/{c['mesh']}/airframe_mesh.npz")
    rng=np.random.default_rng(c['seed']+91)
    s=JointState(truth[0,:3]+rng.normal(0,.025,3),exp(rng.normal(0,.002,3))@exp(truth[0,3:]),
                 np.zeros(6),np.zeros(3),np.eye(3),initial_cov(.03))
    # Common initialization is deterministic in pose; CPU is kept separate.
    initial=folder/'initial.npz'
    if initial.exists():
        a=np.load(initial);s=JointState(*(a[k] for k in ['t','R','bias','mt','mR','P']));init_cpu=float(a['cpu'])
    else:
        post,stats,_,_=register(mesh.prior,clouds[0],s,'full');s=post;init_cpu=stats['cpu_s']
        np.savez_compressed(initial,t=s.t,R=s.R,bias=s.bias,mt=s.mt,mR=s.mR,P=s.P,cpu=init_cpu)
    trace=[];jobs=[];pending=None;prop_cpu=0.;work_cpu=0.;replay_cpu=0.;accepted=0
    for frame in range(len(truth)):
        if frame:
            t=process_time_ns();s=propagate(s,.1,increments[frame]);prop_cpu+=(process_time_ns()-t)*1e-9
        if pending is not None and frame>=pending['delivery']:
            if pending['accepted']:
                t=process_time_ns();ss=pending['post']
                for j in range(pending['source']+1,frame+1):ss=propagate(ss,.1,increments[j])
                s=ss;replay_cpu+=(process_time_ns()-t)*1e-9;accepted+=1
            pending=None
        if frame in clouds and frame>0 and pending is None:
            model=models[(c['mesh'],context(s),ratio,.3,method)];cache={};source=s.copy()
            begin=process_time_ns();wall=perf_counter_ns()
            def probe(q):
                a=q+1
                post,stats,_,_=register(mesh.prior,clouds[frame],source,ACTIONS[a])
                cache[a]=(post,stats)
                return stats['accepted']
            action,path=dispatch(model,method,probe)
            if action==0:post=source;ok=False
            elif action in cache:
                post,stats=cache[action];ok=stats['accepted']
            else:
                post,stats,_,_=register(mesh.prior,clouds[frame],source,ACTIONS[action]);ok=stats['accepted']
            cpu=(process_time_ns()-begin)*1e-9;wall_s=(perf_counter_ns()-wall)*1e-9;work_cpu+=cpu
            delay=max(1,int(np.ceil(wall_s/.1)))
            reserved=sum(model['costs'][q+1] for q in path)
            if action not in cache:reserved+=model['costs'][action]
            assert reserved<=model['budget']
            pending=dict(post=post,accepted=ok,source=frame,delivery=frame+delay)
            jobs.append(dict(frame=frame,action=action,path=path,accepted=bool(ok),cpu_s=cpu,wall_s=wall_s,
                budget_s=model['budget']*.00001,overrun=cpu>model['budget']*.00001,
                delivery_frame=frame+delay,cache_hit=action in cache,context=context(source)))
        p,r=rel_error(s,truth[frame],mt,mR)
        trace.append([frame*.1,*s.t,float(np.linalg.norm(p)),float(np.linalg.norm(r))])
    a=np.asarray(trace);e=a[:,4];rot=a[:,5];n=len(truth)
    result=dict(mesh=c['mesh'],replicate=c['replicate'],level=c['level'],seed=c['seed'],method=method,ratio=ratio,
        duration_s=n*.1,rmse_m=float(np.sqrt(np.mean(e**2))),p95_m=float(np.quantile(e,.95)),
        rotation_rmse_deg=float(np.rad2deg(np.sqrt(np.mean(rot**2)))),cpu_s=prop_cpu+work_cpu+replay_cpu,
        correction_cpu_s=work_cpu,propagation_cpu_s=prop_cpu,replay_cpu_s=replay_cpu,initial_cpu_s=init_cpu,
        probes=sum(len(j['path']) for j in jobs),cache_hits=sum(j['cache_hit'] for j in jobs),
        calls=len(jobs),accepted=accepted,overruns=sum(j['overrun'] for j in jobs),
        fraction_above_10cm=float(np.mean(e>.1)),max_m=float(e.max()))
    np.savez_compressed(folder/(tag+'.npz'),trace=a)
    resultfile.write_text(json.dumps(dict(result=result,jobs=jobs),indent=2))
    print('RUN',c['mesh'],c['replicate'],ratio,method,'RMSE',round(result['rmse_m'],5),'CPU',round(result['cpu_s'],3),flush=True)
    return result

def main():
    p=json.loads((ROOT/'protocol_missions.json').read_text());models=pickle.load(open(ROOT/'data/reuse_models.pkl','rb'))
    for c in p['cases']:generate(c)
    tasks=[(c,ratio,method) for c in p['cases'] for ratio in p['ratios'] for method in p['methods']]
    rng=np.random.default_rng(781811);rng.shuffle(tasks);results=[]
    for c,ratio,method in tasks:
        results.append(run(c,ratio,method,models));pd.DataFrame(results).to_csv(ROOT/'data/mission_results.csv',index=False)
    print('MISSIONS COMPLETE',len(results),flush=True)

if __name__=='__main__':main()
