"""Check active citations against verified publication records and the compiled PDF."""
from pathlib import Path
from collections import Counter
import hashlib,html,json,re,unicodedata
from urllib.parse import unquote
import fitz
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'paper'
def expand(path):
    return re.sub(r'\\input\{([^}]+)\}',lambda m:expand(P/(m[1]+'.tex')),path.read_text())
def parse_bib(s):
    entries={}
    for m in re.finditer(r'@(\w+)\{([^,]+),',s):
        d=1;i=m.end()
        while d and i<len(s):
            if s[i]=='{' and s[i-1]!='\\':d+=1
            elif s[i]=='}' and s[i-1]!='\\':d-=1
            i+=1
        block=s[m.end():i-1];fields={}
        for f in re.finditer(r'(\w+)\s*=\s*\{',block):
            d=1;j=f.end()
            while d and j<len(block):
                if block[j]=='{' and block[j-1]!='\\':d+=1
                elif block[j]=='}' and block[j-1]!='\\':d-=1
                j+=1
            fields[f[1]]=block[f.end():j-1]
        assert m[2] not in entries,m[2]
        entries[m[2]]=fields
    return entries
def norm(s):
    s=html.unescape(re.sub(r'<[^>]+>','',s))
    s=s.replace(r'\l','l').replace(r'\L','L').replace(r'\ss','ss').replace(r'\ae','ae')
    s=re.sub(r'\\[\'"`^~=.]\s*', '',s)
    s=re.sub(r'\\[cuvHr](?=\s|\{)\s*', '',s)
    s=unicodedata.normalize('NFKD',s).casefold().translate(str.maketrans({'ł':'l','ø':'o','æ':'ae','œ':'oe'}))
    return ''.join(x for x in s if x.isalnum())
full=expand(P/'main.tex');assert r'\nocite' not in full
keys=list(dict.fromkeys(k.strip() for group in re.findall(r'\\cite\w*(?:\[[^\]]*\])*\{([^}]+)\}',full) for k in group.split(',')))
bib=parse_bib((P/'references_integrated.bib').read_text())
evidence=json.loads((ROOT/'literature/citation_evidence.json').read_text())
records={r['key']:r for r in evidence['records']}
bbl=re.findall(r'\\bibitem(?:\[[^\]]*\])?\{([^}]+)\}',(P/'main.bbl').read_text())
assert set(keys)==set(bib)==set(records)==set(bbl)
assert len(bbl)==len(set(bbl))==31
checked=[]
for k in keys:
    e=bib[k];r=records[k];m=r['publisher_metadata'];assert e==r['bib_fields'],k
    assert r['reading_support'].get('reading'),k
    assert r['reading_support'].get('claims'),k
    if e.get('doi'):
        assert e['doi'].lower()==m['DOI'].lower(),k
        assert norm(e['title'])==norm(m['title'][0]),(k,'title',e['title'],m['title'])
        assert norm(e['author'].split(' and ')[0].split(',')[0])==norm(m['author'][0]['family']),(k,'first author')
        dates=[v['date-parts'][0][0] for x,v in m.items() if x.startswith('published') and isinstance(v,dict)]
        assert int(e['year']) in dates,(k,'year',dates)
        if e.get('volume') and m.get('volume'):assert e['volume']==m['volume'],(k,'volume')
        if e.get('pages') and (m.get('page') or m.get('article-number')):
            assert norm(e['pages'])==norm(m.get('page',m.get('article-number'))),(k,'pages')
    else:assert e.get('url','').startswith('https://'),k
    checked.append(k)
counts=Counter();label_counts=Counter();section='Front matter';section_label=None
for m in re.finditer(r'\\section\{([^}]+)\}(?:\s*\\label\{([^}]+)\})?|\\cite\w*(?:\[[^\]]*\])*\{([^}]+)\}',full):
    if m[1]:section=m[1];section_label=m[2]
    else:
        counts[section]+=len(m[3].split(','))
        if section_label:label_counts[section_label]+=len(m[3].split(','))
for label in ['sec:introduction','sec:related','sec:method','sec:changes','sec:design','sec:discussion']:
    assert label_counts[label]>0,('section lacks substantive citations',label)
assert not set(keys)&{'besl1992icp','censi2007','bonnabel2016','brossard2020','barfoot2014'}
d=fitz.open(P/'main.pdf');text='\n'.join(p.get_text() for p in d)
refs=text[text.rfind('\nReferences\n'):];labels=re.findall(r'(?m)^\[(\d+)\]',refs)
assert labels==list(map(str,range(1,len(keys)+1))),labels
links=[unquote(x['uri']).lower() for p in d for x in p.get_links() if 'uri' in x]
for k in keys:
    e=bib[k]
    target=e.get('doi',e.get('url'))
    assert any(target.lower() in u for u in links),(k,'missing PDF link',target)
log=(P/'main.log').read_text()
assert not any(x in log for x in ['undefined references','Citation','Overfull','LaTeX Error','multiply defined','Label(s) may have changed'])
assert 'ultrasonic' in full and 'representational completeness and expressiveness' in full
r={'status':'PASS','main_pages':len(d),'active_references':len(keys),'aei_references':sum(x.get('journal')=='Advanced Engineering Informatics' for x in bib.values()),'doi_records_verified':sum('doi' in x for x in bib.values()),'non_doi_primary_sources':sum('doi' not in x for x in bib.values()),'reference_mentions':sum(counts.values()),'reference_mentions_by_section':dict(counts),'all_entries_cited':True,'all_pdf_reference_links_present':True,'old_icp_method_citations_removed':True,'bibliography_sha256':hashlib.sha256((P/'references_integrated.bib').read_bytes()).hexdigest(),'verified_keys':checked}
(ROOT/'audits/citation_qa.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
