"""Render the complete-route section directly from the result ledger."""
import json
from checkpoint import ROOT
d=json.loads((ROOT/'data/manuscript_numbers.json').read_text());rr=d['routes']
total=d['route_run_count'];native=all(rr[m].get('native_final',{}).get('runs')==3 for m in rr)
methods=[('calibrated_baseline','Fixed 2'),('fixed_4','Fixed 4'),('final','Checkpoint final')]
if native:methods.append(('native_final','Native final'))
methods.append(('selected','RAVC-Loc'))
text=[]
text.append(f'The new study executes {total} complete controller runs on the six retained inputs, totalling {total*1980/3600:.1f} simulated controller hours. Every run feeds delivered state versions into subsequent scan priors and directly times registration, decisions, motion propagation and replay. Table~\\ref{{tab:new-routes}} reports means over the three paired inputs per aircraft. Figure~\\ref{{fig:route-tradeoff}} shows the individual realizations and method means. No complete-route risk certificate is inferred from these six inputs.\n')
text.append(r'\begin{table}[t]\centering\small'+'\n'+r'\caption{New complete-route executions, load factor 10 and two-second scan opportunities. Each entry averages three 1,980-second retained inputs. CPU is directly measured online estimator work, excluding common initialization and offline error scoring. Events exceed 10 cm at a 10 Hz sample after the first five seconds.}\label{tab:new-routes}'+'\n'+r'\begin{tabular}{@{}llrrrr@{}}\toprule Aircraft&Policy&RMSE (cm)&CPU (s)&Replay (s)&Events\\\midrule'+'\n')
for mesh in ['B767','C172']:
 for i,(key,label) in enumerate(methods):
  q=rr[mesh][key];text.append(f"{mesh if i==0 else ''}&{label}&{q['mean_rmse_cm']:.3f}&{q['mean_cpu_s']:.3f}&{q['mean_replay_cpu_s']:.3f}&{q['route_events']}/3\\\\\n")
 if mesh=='B767':text.append(r'\midrule'+'\n')
text.append(r'\bottomrule\end{tabular}\end{table}'+'\n')
b=rr['B767'];c=rr['C172'];vs='native_final' if native else 'final'
text.append(f"The selected policy gives mean route RMSE {b['selected']['mean_rmse_cm']:.3f}~cm on B767 and {c['selected']['mean_rmse_cm']:.3f}~cm on C172. Relative to {'native final' if native else 'checkpoint final'}, measured total CPU decreases by {100*(1-b['selected']['mean_cpu_s']/b[vs]['mean_cpu_s']):.1f}\\% and {100*(1-c['selected']['mean_cpu_s']/c[vs]['mean_cpu_s']):.1f}\\%, respectively. Its RMSE is {b['selected']['mean_rmse_cm']-b[vs]['mean_rmse_cm']:+.3f} and {c['selected']['mean_rmse_cm']-c[vs]['mean_rmse_cm']:+.3f}~cm higher in the paired method means. These are descriptive contrasts on three inputs per aircraft, not population precision or hardware-latency guarantees.\n")
text.append(f"Fixed~2 uses {b['calibrated_baseline']['mean_cpu_s']:.3f}~s and {c['calibrated_baseline']['mean_cpu_s']:.3f}~s, compared with {b['selected']['mean_cpu_s']:.3f}~s and {c['selected']['mean_cpu_s']:.3f}~s for RAVC-Loc. On these sequential inputs the learned policy often selects the same shallow prefix; its adaptation margin over Fixed~2 is correspondingly small. Fixed~4 and final convergence retain the more accurate operating points shown in the table.\n")
text.append(f"Holding publication changes mean route RMSE from {b['selected']['mean_rmse_cm']:.3f} to {b['hold_publication']['mean_rmse_cm']:.3f}~cm on B767 and from {c['selected']['mean_rmse_cm']:.3f} to {c['hold_publication']['mean_rmse_cm']:.3f}~cm on C172. Continuing to completion gives {b['continue_to_completion']['mean_rmse_cm']:.3f} and {c['continue_to_completion']['mean_rmse_cm']:.3f}~cm. The modest delivery effect agrees with the episode intervention: publication and final completion are usually separated by only a few motion ticks.\n")
events=sum(rr[m]['selected']['route_events'] for m in rr)
native_events=sum(rr[m].get('native_final',{}).get('route_events',0) for m in rr)
text.append(f"The complete-route event is a position norm above 0.10~m at any stored 10~Hz instant from 5.0 to 1,979.9~s. The selected policy has {events}/6 such events, compared with {native_events}/6 for native final, with selected maximum position error {max(rr[m]['selected']['max_position_cm'] for m in rr):.2f}~cm. This evaluation horizon and route distribution differ from Eq.~\\eqref{{eq:episode-event}}; the count is reported without applying the episode certificate.\n")
text.append(r'\begin{figure}[t]\centering\includegraphics[width=.97\linewidth]{route_tradeoff.pdf}\caption{Directly executed complete-route work--error trade-offs. Small points are the three retained sensor/motion realizations per aircraft; large points are their method means. RAVC-Loc and every control use the same scan cadence and delivery model.}\label{fig:route-tradeoff}\end{figure}'+'\n')
(ROOT/'sections/route_results.tex').write_text('\n'.join(text))
print(total,native)
