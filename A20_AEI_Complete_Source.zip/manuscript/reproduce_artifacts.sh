#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
PYTHON_BIN="${A20_PYTHON:-python}"
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
"$PYTHON_BIN" studies/change_recovery_20261013/validate.py
"$PYTHON_BIN" studies/methodology_review_20261014/run.py --verify
"$PYTHON_BIN" studies/change_campaign_20261014/run.py --verify
"$PYTHON_BIN" reporting/build_complete_supplement.py
"$PYTHON_BIN" reporting/build_methodology_supplement.py
"$PYTHON_BIN" reporting/build_change_campaign.py
"$PYTHON_BIN" reporting/visual_revision.py
bash build.sh
"$PYTHON_BIN" reporting/verify_visual_revision.py
