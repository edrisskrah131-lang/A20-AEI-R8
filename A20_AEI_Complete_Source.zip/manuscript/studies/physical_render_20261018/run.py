"""Sequential deterministic render/processing runner; no held-out selection."""
from pathlib import Path
import json,subprocess,hashlib,platform,datetime,sys,time,os
ROOT=Path(__file__).parent
protocol=json.loads((ROOT/'protocol.json').read_text());test=ROOT/'outputs'/'test';test.mkdir(parents=True,exist_ok=True);logs=ROOT/'outputs'/'logs';logs.mkdir(exist_ok=True)
start=time.time()
for index,seed in enumerate(protocol['held_out_seeds']):
 path=test/(str(seed)+'.json')
 if path.exists() and all((test/(str(seed)+'_'+v+'.png')).exists() for v in protocol['variants']):print(f'{index+1}/24 already complete {seed}',flush=True);continue
 command=['/usr/bin/blender','-b','-t',str(protocol['threads']),'--python',str(ROOT/'render.py'),'--','--seed',str(seed),'--out',str(test),'--samples',str(protocol['samples']),'--threads',str(protocol['threads'])]
 if index==0:command+=['--save-blend']
 with (logs/(str(seed)+'.log')).open('w') as f:subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=True)
 if not path.exists():raise RuntimeError(f'Blender did not finish seed {seed}')
 print(f'{index+1}/24 rendered {seed}; elapsed {time.time()-start:.1f}s',flush=True)
subprocess.run([sys.executable,str(ROOT/'process.py')],check=True)
manifest={'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'platform':platform.platform(),'cpu':'AMD EPYC 9V74 host, shared cloud CPU quota 5 cores','threads':protocol['threads'],'sequential_render_wall_s':time.time()-start,'files':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'outputs').rglob('*')) if p.is_file() and p.suffix in ('.png','.json','.csv','.npz','.blend')}}
(ROOT/'run_manifest.json').write_text(json.dumps(manifest,indent=2))
