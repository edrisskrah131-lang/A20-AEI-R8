"""Finite policy rollout on a complete four-second decision grid.

The base policy and first-action alternatives use the same local risk head.
This is a deterministic moment surrogate, not an exact observation tree.
"""
import numpy as np
from .core import *

class RolloutPlanner(Planner):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.horizon=(0.,4.,8.,12.,16.)
    def choose(self,inp,features,J,future_features=None):
        if self.policy!='rcp':return super().choose(inp,features,J,future_features)
        if inp.age>=12.:return ('full' if self.costs['full']<=inp.tokens else 'skip'),{'reason':'common_cadence_floor'}
        intervals=forecast_intervals(inp.state,inp.velocity,self.horizon)
        # A common source distribution is used for all first-action alternatives.
        p0=self.model.predict(features,inp.state.P,'full');mu0,C0=p0[7],p0[8]
        candidates=['skip']+[a for a in ACTIONS[1:] if self.costs[a]<=inp.tokens]
        trajectories=[]
        for first in candidates:
            mu,C=mu0.copy(),C0.copy();P=inp.state.P.copy();age=inp.age;tokens=inp.tokens;value=0.;seq=[];valid=True
            for k,(G,F,Q,qnoise) in enumerate(intervals):
                f=(features if future_features is None else future_features[k][0]).copy();f[0]=np.log1p(age)
                Ji=J if future_features is None else future_features[k][2]
                posterior=psd(np.linalg.inv(np.linalg.inv(psd(P))+Ji));gain=P-posterior
                f[1:3]=np.log(np.maximum([np.trace(gain[:3,:3]),np.trace(gain[3:6,3:6])],1e-12))
                can_decide=(tokens>=self.decision_cost)
                if k and age<12. and can_decide:
                    tokens-=self.decision_cost;value+=self.lam*self.decision_cost
                affordable=[a for a in ACTIONS[1:] if self.costs[a]<=tokens]
                options=['skip']+affordable
                if age>=12.:options=['full'] if 'full' in affordable else ['skip']
                elif k and not can_decide:options=['skip']
                if k==0:options=[first]
                scored=[]
                for a in options:
                    if a=='skip':nm,nC=mu,C;cost=0.;qaccept=0.
                    else:
                        pred=self.model.predict(f,P,a);A,b,R=pred[4:7];nm=A@mu+b;nC=A@C@A.T+R;cost=self.costs[a];qaccept=pred[2][1:].sum()
                    # Conservative source-to-delivery floor uses reserved solver CPU
                    # as a delay proxy; measured execution latency remains authoritative.
                    delay=min(4.,max(.02,cost));local=nm@G@nm+np.trace(G@nC)
                    old=mu@G@mu+np.trace(G@C)
                    local=(1-delay/4)*local+delay/4*old+self.lam*cost
                    scored.append((local,a,nm,nC,cost,qaccept))
                chosen=min(scored,key=lambda r:r[0]);local,a,mu,C,cost,qaccept=chosen;seq.append(a);value+=local+qnoise;tokens-=cost
                # Moment closure for correction age, stated explicitly in the paper.
                age=(1-qaccept)*age+4.
                P=psd((1-qaccept)*P+qaccept*posterior);mu=F@mu;C=psd(F@C@F.T+Q);P=psd(F@P@F.T+Q)
                overhead=4*self.overhead_rate;tokens=min(.1,tokens+4*inp.budget_rate-overhead);value+=self.lam*overhead
                if tokens<0:valid=False;break
            trajectories.append((value if valid else np.inf,first,seq))
        best=min(trajectories,key=lambda v:v[0])
        if not np.isfinite(best[0]):return 'skip',{'reason':'no_affordable_plan'}
        return best[1],{'reason':'closed_loop_rollout','sequence':best[2],'predicted_objective':float(best[0]),'evaluated':len(trajectories),'candidate_plans':[{'value':float(v),'first':a,'sequence':seq} for v,a,seq in trajectories]}
