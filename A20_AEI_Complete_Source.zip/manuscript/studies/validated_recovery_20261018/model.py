"""Revision recovery against an authoritative output store.

The fixed HMAC key emulates an authenticated control channel in this deterministic
fixture. This is an integrity/workflow experiment, not a cryptographic benchmark.
"""
from copy import deepcopy
from hashlib import sha256
import hmac
import json

TEST_KEY = b'validated-recovery-fixture-only-not-a-production-secret'


def digest(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                             allow_nan=False).encode()).hexdigest()


def certificate(fields):
    body = deepcopy(fields)
    signature = hmac.new(TEST_KEY, digest(body).encode(), 'sha256').hexdigest()
    return dict(body=body, signature=signature)


def authentic(cert):
    return bool(cert) and hmac.compare_digest(
        cert.get('signature', ''),
        hmac.new(TEST_KEY, digest(cert['body']).encode(), 'sha256').hexdigest())


class Registry:
    """Control-plane authority. Quarantine is scoped to a binding, not a capture."""
    def __init__(self, binding, capture, payloads, cards):
        self.binding, self.capture = binding, capture
        self.payloads = deepcopy(payloads)
        self.cards = deepcopy(cards)
        self.log = []
        self.record = None
        self.status = 'unregistered'

    def _record(self, revision, producer, predecessor):
        return dict(binding=self.binding, capture=self.capture, revision=revision,
                    producer=producer, payload_digest=digest(self.payloads[producer]),
                    calibration=self.cards[producer]['identity'], predecessor=predecessor)

    def register(self, producer):
        if self.status == 'quarantined':
            raise ValueError('quarantined binding requires validated repair')
        revision = 0 if self.record is None else self.record['revision'] + 1
        predecessor = None if self.record is None else digest(self.record)
        self.record = self._record(revision, producer, predecessor)
        self.status = 'active'
        self.log.append(dict(kind='commit', record=deepcopy(self.record)))

    def quarantine(self, attempt):
        self.status = 'quarantined'
        self.log.append(dict(kind='quarantine', binding=self.binding,
                             rejected_digest=digest(attempt)))

    def validate_attachment(self, envelope):
        """Check binding integrity and quarantine a newly detected mismatch.

        The returned Boolean describes attachment integrity, not permission to
        issue: a valid retry cannot itself release an existing quarantine, and
        statistical refusal is deliberately absent from this integrity check.
        """
        if self.record is None:
            raise ValueError('attachment requires a registered binding')
        fields = ('binding', 'capture', 'revision', 'producer', 'calibration')
        valid = (all(envelope.get(field) == self.record[field] for field in fields)
                 and 'payload' in envelope
                 and digest(envelope['payload']) == self.record['payload_digest'])
        if not valid and self.status != 'quarantined':
            self.quarantine(envelope)
        return valid

    def envelope(self, payload=None, binding=None, revision=None, producer=None,
                 calibration=None):
        record = self.record
        return dict(binding=binding or self.binding, capture=self.capture,
                    revision=record['revision'] if revision is None else revision,
                    producer=producer or record['producer'],
                    calibration=calibration or record['calibration'],
                    payload=deepcopy(self.payloads[record['producer']] if payload is None else payload))

    def issue_certificate(self, **overrides):
        body = self._record(self.record['revision'] + 1, self.record['producer'],
                            digest(self.record))
        body.update(overrides)
        return certificate(body)

    def repair(self, envelope, cert):
        """Validate provenance before a compare-and-swap revision commit."""
        accepted = False
        if authentic(cert):
            c, old = cert['body'], self.record
            producer = old['producer']
            expected = self._record(old['revision'] + 1, producer, digest(old))
            expected_envelope = dict(binding=self.binding, capture=self.capture,
                                     revision=old['revision'] + 1, producer=producer,
                                     calibration=self.cards[producer]['identity'],
                                     payload=self.payloads[producer])
            accepted = c == expected and envelope == expected_envelope
        self.log.append(dict(kind='repair_attempt', accepted=accepted,
                             certificate=None if cert is None else digest(cert),
                             payload=digest(envelope)))
        if accepted:
            self.record = deepcopy(cert['body'])
            self.status = 'active'
            self.log.append(dict(kind='commit', record=deepcopy(self.record)))
        return accepted

    def snapshot(self):
        return dict(record=deepcopy(self.record), status=self.status,
                    risk_authorized=bool(self.cards[self.record['producer']]['authorized']))


def snapshot_issue(envelope, snapshot):
    """No local latch; all authority state is obtained in a fresh snapshot."""
    r = snapshot['record']
    checks = (snapshot['status'] == 'active', snapshot['risk_authorized'],
              envelope['binding'] == r['binding'], envelope['capture'] == r['capture'],
              envelope['revision'] == r['revision'], envelope['producer'] == r['producer'],
              envelope['calibration'] == r['calibration'],
              digest(envelope['payload']) == r['payload_digest'])
    return all(checks)


class PermanentLatch:
    def __init__(self):
        self.intact = True

    def issue(self, envelope, snapshot):
        # Statistical refusal alone never poisons the historical binding.
        probe = dict(snapshot, risk_authorized=True)
        self.intact = self.intact and snapshot_issue(envelope, probe)
        return self.intact and snapshot['risk_authorized']


class QuarantineGate:
    def __init__(self):
        self.known = None
        self.state = 'unregistered'
        self.invalid_attempts = []

    def sync(self, snapshot):
        r = snapshot['record']
        if self.known is not None:
            if r['revision'] < self.known['revision']:
                raise ValueError('registry revision rollback')
            if r['revision'] == self.known['revision'] and r != self.known:
                raise ValueError('immutable revision changed in place')
            if r['revision'] > self.known['revision']:
                if r['revision'] != self.known['revision'] + 1 or r['predecessor'] != digest(self.known):
                    raise ValueError('broken predecessor chain')
        self.known = deepcopy(r)
        self.state = snapshot['status']

    def issue(self, envelope, snapshot):
        self.sync(snapshot)
        good = snapshot_issue(envelope, snapshot)
        if not snapshot_issue(envelope, dict(snapshot, risk_authorized=True)):
            self.invalid_attempts.append(digest(envelope))
        return good


def event_sourced_issue(envelope, log, cards):
    """Separate implementation: fold committed events, then match explicit facts."""
    record, active, approved_repair = None, False, False
    for entry in log:
        if entry['kind'] == 'commit':
            if record is not None and not active and not approved_repair:
                return False
            record, active = entry['record'], True
            approved_repair = False
        elif entry['kind'] == 'quarantine':
            active = False
            approved_repair = False
        elif entry['kind'] == 'repair_attempt':
            approved_repair = bool(entry['accepted'])
    if record is None or not active:
        return False
    if not cards[record['producer']]['authorized']:
        return False
    for field in ('binding', 'capture', 'revision', 'producer', 'calibration'):
        if envelope[field] != record[field]:
            return False
    return digest(envelope['payload']) == record['payload_digest']


def metadata_only_issue(envelope, snapshot):
    """Ablation: trusts self-declared producer/card, omits authoritative identity."""
    return (snapshot['risk_authorized'] and
            envelope['producer'] == snapshot['record']['producer'] and
            envelope['calibration'] == snapshot['record']['calibration'])
