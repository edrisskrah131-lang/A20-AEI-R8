"""Independent numerical reexecution, family bounds and transition invariants."""
from concurrent.futures import ProcessPoolExecutor
import hashlib
import json
import math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import beta
from campaign import ROOT,CONFIGS,METHODS,EVENTS,REQUESTS,STAGES,configuration,draw,stable_hash,POPULATION,OTHER_POPULATION
from imaging import geometry,radiance,sensor,decode,fit,optical,DIRECT,PARENTS
from numerics import array_hash,clean

OUT=ROOT/'outputs'

def signature(stage,config):
    return (stage,tuple((k,str(config[k])) for k in DIRECT[stage]),
            tuple(signature(parent,config) for parent in PARENTS[stage]))

def cold(job):
    seed,variant,stress=job;s=draw(seed,stress=stress);config=configuration(variant)
    # Direct composition deliberately bypasses Pipeline.get and its keys/cache.
    geo=geometry(s,config);raw=radiance(s,config,geo);rgb=sensor(s,config,raw)
    centers=decode(rgb,config['decoder']);quality,aux=fit(s,config,centers)
    optics=optical(s,config);values={k:v for k,v in optics.items() if k!='gsds'}|quality
    payload=dict(source_seed=seed,population=OTHER_POPULATION if stress else POPULATION,
        configuration_sha256=stable_hash(config),rgb_sha256=array_hash(rgb),
        decoded_sha256=array_hash(aux['decoded']),predicted_sha256=array_hash(aux['predicted']),
        reprojection_px=clean(values['reprojection_px']),matched_targets=int(values['matched_targets']),
        planned_targets=int(values['planned_targets']))
    return job,dict(pixel_sha256=array_hash(rgb),observable_sha256=stable_hash(payload),
                   numerical_sha256=stable_hash(clean(values)))

def main():
    checks=[]
    for name in ('design_freeze.json','calibration_execution_freeze.json','campaign_execution_freeze.json'):
        frozen=json.loads((ROOT/name).read_text())
        for path,sha in frozen['files'].items():
            assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==sha,(name,path)
    checks.append('design and execution hashes match frozen versions and recorded pre-test amendment')
    cal=pd.read_csv(OUT/'calibration_observations.csv');obs=pd.read_csv(OUT/'campaign_observations.csv')
    decisions=pd.read_csv(OUT/'decisions.csv');risk=pd.read_csv(OUT/'exact_risk_cards.csv')
    family=pd.read_csv(OUT/'family_plans.csv')
    assert len(cal)==2048 and cal.seed.nunique()==256 and decisions.seed.nunique()==64
    assert not set(cal.seed)&set(decisions.seed)
    assert set(cal.variant)==set(CONFIGS) and len(risk)==64
    checks.append('fresh calibration/test identities are disjoint and the full fixed64-context family is present')
    for r in risk.itertuples():
        group=cal[cal.variant==r.variant];valid=np.ones(len(group),dtype=bool)
        for metric,(lo,hi) in REQUESTS[r.request].items():
            values=group[metric].to_numpy();valid &= np.isfinite(values)
            if lo is not None:valid &= values>=lo
            if hi is not None:valid &= values<=hi
        k=int((~valid).sum());upper=1. if k==256 else beta.isf(.05/64,k+1,256-k)
        assert r.k==k and r.n==256 and abs(r.upper-upper)<1e-13
        assert bool(r.authorized)==bool(upper<=.15)
    expected={(r.variant,r.request):bool(r.authorized) for r in risk.itertuples()}
    for row in family.itertuples():assert bool(row.authorized)==expected[row.variant,row.request]
    checks.append('all64 Clopper-Pearson bounds and all256 method/family support decisions independently recalculated')
    for (seed,method),g in decisions.groupby(['seed','method']):
        g=g.sort_values('index');keys=set();last_revision=-1
        assert list(g['index'])==list(range(16))
        for r in g.itertuples():
            event=EVENTS[r.index];counts={s:0 for s in STAGES}
            if event['kind'] in ('numerical','request','rollback','population'):
                active=set() if method=='Whole renewal' or event['kind']=='population' else keys
                config=configuration(event['variant'])
                for stage in STAGES:
                    key=signature(stage,config)
                    if key not in active:counts[stage]=1;active.add(key)
            for stage in STAGES:assert getattr(r,'calls_'+stage)==counts[stage],(seed,method,r.index,stage)
            commits=event['kind'] in ('numerical','request','rollback','repair')
            assert r.revision==last_revision+int(commits),(seed,method,r.index)
            last_revision=r.revision
            assert bool(r.issued)==bool(r.oracle_issue)
            if r.kind=='population':assert not r.population_compatible and not r.issued
            if r.kind in ('stale','late','invalid_repair'):assert not r.issued
    checks.append('every executed provider count matches independent missing-key accounting; all4096 revisions/admissions checked')
    p=decisions.pivot(index=['seed','index'],columns='method',values='issued')
    assert p.eq(p['DAG exact + registry'],axis=0).all().all()
    for (seed,population,variant),g in obs.groupby(['seed','population','variant']):
        for name in ('pixel_sha256','observable_sha256','numerical_sha256'):assert g[name].nunique()==1
    checks.append('all strong methods preserve identical service and all methods produce identical pixels/numerical outputs')
    traces=json.loads((OUT/'example_traces.json').read_text())
    assert len(traces)==2
    for seed,methods in traces.items():
        for method,archive in methods.items():
            assert len(archive['trace'])==16
            previous=None;quarantined=False;approved=False
            for entry in archive['event_log']:
                if entry['kind']=='quarantine':quarantined=True;approved=False
                elif entry['kind']=='repair_attempt':approved=entry['accepted']
                elif entry['kind']=='commit':
                    record=entry['record']
                    if previous is None:assert record['revision']==0 and record['predecessor'] is None
                    else:assert record['revision']==previous['revision']+1 and record['predecessor']==stable_hash(previous)
                    if quarantined:assert approved
                    previous=record;quarantined=False;approved=False
            assert previous['revision']==10
            for item in archive['trace']:
                payload=item['envelope']['payload']
                assert not {'coverage','association_m','gsd_m','blur_px'}&set(payload)
    checks.append('two complete traces preserve predecessor chains, reject repair bypass and keep latent quality outside runtime payload')
    archives=list((OUT/'representative_calibration').glob('*.npz'))+list((OUT/'representative_campaigns').glob('*.npz'))
    for path in archives:
        data=np.load(path);meta=json.loads(str(data['metadata']));record=meta['record'];payload=meta['runtime_observable_payload']
        assert array_hash(data['rgb'])==record['pixel_sha256']==payload['rgb_sha256']
        assert array_hash(data['decoded'])==payload['decoded_sha256']
        assert array_hash(data['predicted'])==payload['predicted_sha256']
    checks.append(f'all{len(archives)} preserved image arrays match their numerical-source and pixel digests')
    jobs=[(seed,v,False) for seed in (202629100,202629101) for v in CONFIGS]
    visited=tuple(dict.fromkeys(e['variant'] for e in EVENTS if e['kind']!='population'))
    jobs += [(seed,v,False) for seed in (202630100,202630101) for v in visited]
    jobs += [(seed,'baseline',True) for seed in (202630100,202630101)]
    reference=pd.concat([cal,obs],ignore_index=True)
    with ProcessPoolExecutor(max_workers=2) as pool:
        for (seed,variant,stress),hashes in pool.map(cold,jobs):
            population=OTHER_POPULATION if stress else POPULATION
            match=reference[(reference.seed==seed)&(reference.variant==variant)&(reference.population==population)]
            assert len(match)>0
            for key,value in hashes.items():assert set(match[key])=={value},(seed,variant,key)
    checks.append(f'{len(jobs)} independent direct-stage reexecutions reproduce exact pixel, observable and numerical digests')
    report=dict(status='PASS',check_groups=len(checks),checks=checks,cold_reexecutions=len(jobs),
                runtime_truth_labels_used=False,primary_independent_sources=64,
                workflow_rows_checked=len(decisions),calibration_rows_checked=len(cal))
    (OUT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
