"""Create an isolated reproduction tree and publish only generated documents.

Study data, recorded timings and freezes in the original tree are never written.
The shell entry point calls publish only after all checks in the copy succeed.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil


def sha(path):
    digest=hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda:handle.read(1024*1024),b''):
            digest.update(chunk)
    return digest.hexdigest()


def snapshot(source):
    return {p.relative_to(source).as_posix():sha(p)
            for p in sorted((source/'studies').rglob('*'))
            if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}


def locations(source,workspace):
    source,workspace=source.resolve(),workspace.resolve()
    if source==workspace or source in workspace.parents or workspace in source.parents:
        raise ValueError('Reproduction workspace must be outside the original manuscript tree')
    if not (source/'reproduce_artifacts.sh').is_file():
        raise ValueError('Source is not a manuscript directory')
    return source,workspace


def prepare(source,workspace):
    source,workspace=locations(source,workspace)
    if workspace.exists():
        raise ValueError('Use a fresh, nonexistent reproduction workspace')
    before=snapshot(source)
    if not before:
        raise ValueError('Study data are missing; restore every delivery data volume first')
    workspace.parent.mkdir(parents=True,exist_ok=True)
    shutil.copytree(source,workspace,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    if snapshot(workspace)!=before or snapshot(source)!=before:
        raise ValueError('Study files changed during snapshot creation; finish experiment execution first')
    (workspace.parent/'study_snapshot.json').write_text(json.dumps(
        {'source':str(source),'workspace':str(workspace),'files':before},indent=2)+'\n')
    # A copied release QA file cannot stand in for the new reproduction run.
    (workspace/'audits/completion_qa.json').unlink(missing_ok=True)
    print(json.dumps({'status':'READY','workspace':str(workspace),'preserved_study_files':len(before)}))


def publish(source,workspace):
    source,workspace=locations(source,workspace)
    saved=json.loads((workspace.parent/'study_snapshot.json').read_text())
    assert saved['source']==str(source) and saved['workspace']==str(workspace)
    assert snapshot(source)==saved['files'],'Original studies changed during reproduction'
    qa=json.loads((workspace/'audits/completion_qa.json').read_text())
    assert qa['status']=='PASS','Final completion checks have not passed'
    # Legacy reporters may rewrite derived study metadata in the isolated copy.
    # No newly generated figure may cite different study bytes on publication.
    for path in (workspace/'paper/figures').rglob('*provenance.json'):
        data=json.loads(path.read_text())
        if not isinstance(data,dict):
            continue
        for name,digest in data.get('sources',{}).items():
            if name.startswith('studies/'):
                assert sha(source/name)==digest,('Derived figure relies on changed archived study',path.name,name)
    outputs=[workspace/'A20_AEI_Manuscript.pdf',workspace/'Supplement.pdf']
    for directory in ['paper','audits']:
        outputs.extend(p for p in (workspace/directory).rglob('*')
                       if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
    for path in outputs:
        assert path.is_file(),path
        destination=source/path.relative_to(workspace)
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(path,destination)
    assert snapshot(source)==saved['files'],'Original study bytes changed while publishing documents'
    result={'status':'PASS','execution':'isolated full manuscript copy',
            'original_study_files_unchanged':len(saved['files']),
            'copied_document_and_audit_files':len(outputs),
            'original_study_data_and_timings_overwritten':False,
            'full_image_render_repeated':False,
            'main_pdf_sha256':sha(source/'A20_AEI_Manuscript.pdf'),
            'supplement_pdf_sha256':sha(source/'Supplement.pdf')}
    (source/'audits/reproduction_qa.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['prepare','publish'])
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--workspace',type=Path,required=True)
    args=parser.parse_args()
    (prepare if args.action=='prepare' else publish)(args.source,args.workspace)


if __name__=='__main__':
    main()
