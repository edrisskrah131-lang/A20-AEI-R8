# Cycles renderer-transfer challenge

This study evaluates the unchanged pixel detector and CAD pose estimator on an independent path tracer. It is separate from the procedural renderer used for risk calibration. Every submitted image was rendered by Blender Cycles from the archived source geometry, materials, camera and lights, then supplied to the same image-only detector. No photograph, image-generation model or manually marked correspondence is used.

## Fixed experiment

- Held-out sources: 24 independently seeded scenes (`202618800` through `202618823`).
- Three paired variants per source: baseline; camera exposure gain of +1.3 stops; area-light and world radiance scaled by 0.1. Gain does not mean shutter motion or motion blur.
- 768 × 576 pixels, a maximum of 32 native Cycles samples/pixel (adaptive threshold 0.01, Blender default minimum), CPU rendering with four threads. No denoiser or post-render smoothing. Blender's AgX display transform is fixed.
- Geometric construction: curved skin meshes with a 0.25 mm lap offset, flush domed fastener heads and countersink toruses, recessed longitudinal joint, transverse sealant strips and shallow abrasion geometry. Three distinct rivet layouts, independent camera pose, curvature, missing heads, material class (painted or metallic), roughness and illumination.
- The image decoder receives only pixels and uses the existing contrast threshold 18. The subsequent estimator receives CAD sites, decoded centers and a perturbed pose prior. Truth enters scoring only. It is never used to delete poor matches or to choose fit parameters.
- Reported association failure applies the already specified request: coverage ≥ 0.8, maximum fitted residual ≤ 8 px and maximum CAD mapping error ≤ 8 mm. This is an observed transfer check, not a new population risk guarantee.

The `inherited_acquisition_failures` field in the machine-readable summary counts coverage below 0.8. It must not be interpreted as evaluation of the full acquisition predicate (which additionally includes optical sampling and motion blur); those latter quantities are not reevaluated here. This benchmark is a static camera surface-association challenge.

## Processing and numerical checks

`process.py` imports the original `decode` and `fit` implementations without changing their thresholds or priors. Metadata contains independent Blender `world_to_camera_view` projections. Those are checked against the analytical pinhole model to 0.001 pixels. Mapping uses the original analytical base-skin surface; the physical 0.25 mm panel lap is retained as a small surface-model discrepancy.

Outputs contain all 72 RGB PNGs, all 24 scene manifests, per-image correspondence arrays, every metric, run logs and a SHA256 inventory. The first held-out scene also has its `.blend` file. The script rebuilds every remaining scene exactly from its seed. Pilot development images are retained separately and are excluded from the 24-source result.

The initial pilot `202618701` used brighter lighting before material tuning. The final distribution was selected using pilots `202618702`, `202618703` and `202618706`. The pixel decoder and pose-estimation settings were never tuned. `freeze.json` records code and protocol hashes before the first held-out render.

## Reproduce

Dependencies: Blender 4.3.2, Python with NumPy, SciPy, Pandas and Pillow; existing `lifecycle_20261018/imaging.py` and `cad_surface_20261014/model.py`.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python studies/physical_render_20261018/run.py
python studies/physical_render_20261018/process.py
python studies/physical_render_20261018/verify.py
```

The runner skips already complete scenes. For a fresh numerical render, point `render.py` at a new output directory:

```sh
blender -b -t 4 --python studies/physical_render_20261018/render.py -- --seed 202618800 --samples 32 --threads 4 --out /tmp/physical-render-check
```

Runtime depends on the shared CPU host. Renderer construction/render time is recorded separately from the pixel-decoder and solver; no real-time inspection claim follows from these timings.

## Recorded outcomes

The held-out set contains {2: 8, 1: 7, 0: 9} scenes by layout and {'painted': 15, 'metal': 9} by material.

| Variant | Mean coverage | Median maximum mapping error, mm | Association failures / 24 |
|---|---:|---:|---:|
| baseline | 84.32% | 0.748 | 9 |
| exposure | 89.54% | 0.878 | 5 |
| lighting | 78.12% | 0.791 | 10 |

These observed transfer failures are retained. The original procedural-population confidence cards are not used to certify the Cycles population. Geometry, radiance and detector responses differ; a new producer/population requires new calibration.
