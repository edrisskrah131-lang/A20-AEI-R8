"""Evidence semantics and an independent rule-oriented comparison implementation."""
import json,hashlib
from functools import lru_cache
from pathlib import Path
import sys
import numpy as np
from scipy.stats import beta
from imaging import VARIANTS,QDEPS,CHANGES,configuration
ROOT=Path(__file__).parent
REQUESTS=json.loads((ROOT.parent/'cad_surface_20261014/protocol.json').read_text())['requests']
sys.path.insert(0,str(ROOT.parent/'change_recovery_20261013/snapshots'))
sys.path.insert(0,str(ROOT.parent/'methodology_review_20261014'))
from knowledge_compiler import compile_request
COMPILED={}
for name,event in REQUESTS.items():
 atoms=[]
 for metric,(lower,upper) in event.items():
  unit='mm' if metric in ('gsd_m','association_m') else 'px' if metric in ('blur_px','reprojection_px') else 'ratio'
  scale=1000 if unit=='mm' else 1
  atoms.append(dict(metric=metric,unit=unit,lower=None if lower is None else lower*scale,upper=None if upper is None else upper*scale))
 COMPILED[name]=compile_request(dict(population='four-layout skin mixture v1',service='capture-to-CAD',allowance=.15,**{'all':atoms}),QDEPS)
 for atom in COMPILED[name].event.atoms:
  assert (atom.lower,atom.upper)==tuple(REQUESTS[name][atom.metric])

ANCHORS=('optical','acquisition','association','complete')
METHODS=('Whole renewal','DAG exact cache','Contract + fallback','Rules + containment')

def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
@lru_cache(maxsize=None)
def projection(variant,request):
 c=configuration(variant);deps=COMPILED[request].dependencies;return tuple((k,str(c[k])) for k in sorted(deps))
def failures(frame,request):
 good=np.ones(len(frame),bool)
 for m,(lo,hi) in REQUESTS[request].items():
  x=frame[m].to_numpy();good&=np.isfinite(x)
  if lo is not None:good&=x>=lo
  if hi is not None:good&=x<=hi
 return ~good
@lru_cache(maxsize=None)
def covers(anchor,request):
 for m,(lo,hi) in REQUESTS[request].items():
  if m not in REQUESTS[anchor]:return False
  a,b=REQUESTS[anchor][m]
  if lo is not None and (a is None or a<lo):return False
  if hi is not None and (b is None or b>hi):return False
 return True

def construct(groups,method,alpha=.05/48,allowance=.15):
 cards=[];answers=[];visits=0
 def get(v,q):
  nonlocal visits
  sig=projection(v,q)
  for card in cards:
   if card['request']==q and (card['variant']==v if method=='Whole renewal' else card['projection']==sig):return card
  frame=groups[v];n=len(frame);k=int(failures(frame,q).sum());u=1. if k==n else float(beta.isf(alpha,k+1,n-k));visits+=n
  card=dict(variant=v,request=q,projection=sig,n=n,k=k,upper=u);cards.append(card);return card
 for v in VARIANTS:
  if method in ('Contract + fallback','Rules + containment'):
   for q in ANCHORS:get(v,q)
  for q in REQUESTS:
   suitable=[]
   if method=='Contract + fallback':
    suitable=[a for a in cards if a['upper']<=allowance and covers(a['request'],q) and projection(a['variant'],q)==projection(v,q)]
   elif method=='Rules + containment':
    # Independent forward chaining over bound, interval and provider facts.
    for card in cards:
     facts=set()
     if card['upper']<=allowance:facts.add('risk')
     old=REQUESTS[card['request']];new=REQUESTS[q];all_intervals=True
     for m,(lower,upper) in new.items():
      a,b=old.get(m,(float('-inf'),float('inf')))
      a=float('-inf') if a is None else a;b=float('inf') if b is None else b
      lo=float('-inf') if lower is None else lower;hi=float('inf') if upper is None else upper
      all_intervals &= m in old and a>=lo and b<=hi
     if all_intervals:facts.add('cover')
     a=configuration(card['variant']);b=configuration(v)
     if all(a[p]==b[p] for m in new for p in QDEPS[m]):facts.add('producer')
     if {'risk','cover','producer'}<=facts:suitable.append(card)
   if suitable:card=min(suitable,key=lambda a:(a['upper'],a['variant'],a['request']));route='cover'
   else:card=get(v,q);route='exact'
   answers.append(dict(variant=v,request=q,authorized=card['upper']<=allowance,upper=card['upper'],proof_variant=card['variant'],proof_request=card['request'],route=route))
 return dict(method=method,constructed_cards=len(cards),record_evaluations=visits,supported=sum(a['authorized'] for a in answers),contexts=len(answers)),answers,cards

class ReceiptGate:
 def __init__(self):self.current={};self.history={}
 def register(self,source,version,payload):
  if source in self.current and version<=self.current[source][0]:raise ValueError('non-increasing source version')
  self.current[source]=(version,digest(payload));self.history.setdefault(source,True)
 def issue(self,source,version,payload,producer,plan,baseline=False):
  active=self.current.get(source);valid=plan['variant']==producer and active==(version,digest(payload))
  if baseline=='snapshot':return bool(plan['authorized']) and valid
  if baseline=='stateless':return bool(plan['authorized']) and plan['variant']==producer
  if baseline=='no_integrity':valid=plan['variant']==producer and active and active[0]==version
  self.history[source]=bool(self.history.get(source,True) and valid)
  return bool(plan['authorized']) and self.history[source]
