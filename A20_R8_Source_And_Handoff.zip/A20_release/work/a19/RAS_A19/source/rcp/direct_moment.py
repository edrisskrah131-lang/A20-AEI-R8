"""One-interval empirical risk without reconstructing affine transitions.

The source and candidate output samples have common conditioning and weights.
For one decision, the paired second moment gives exactly the scalar quadratic
objective required by the reference controller. No learned parameters change.
"""
import numpy as np
from .core import ACTIONS, Planner, forecast_intervals
from .fast_calibrated import FastClosedLoopRisk


class DirectMomentRisk(FastClosedLoopRisk):
    def scalar_scores(self, features, P, G):
        ids, w = self.neighbours(features, P, 'full')
        local = self.local_position[ids]
        u = self.paired[ids, :18]
        before = float(w @ np.einsum('ni,ij,nj->n', u, G, u))
        values = {'skip': before}
        costs = {'skip': 0.}
        for action in ACTIONS[1:]:
            aid = self.indices[action][local]
            v = self.paired[aid, 18:]
            alpha = self.alpha.get(action, 1.)
            after = float(w @ np.einsum('ni,ij,nj->n', v, G, v))
            values[action] = (1-alpha)*before + alpha*after
            costs[action] = float(np.quantile(self.cost[aid], .95))
        return values, costs


class DirectMomentPlanner(Planner):
    def choose(self, inp, features, J, future_features=None):
        affordable = [a for a in ACTIONS[1:] if self.costs[a] <= inp.tokens]
        if not affordable:
            return 'skip', {'reason': 'tokens'}
        if inp.age >= 12.:
            return ('full' if 'full' in affordable else 'skip'), {'reason': 'common_cadence_floor'}
        h = self.horizon[1] - self.horizon[0]
        G, _, _, qnoise = forecast_intervals(inp.state, inp.velocity, self.horizon[:2])[0]
        losses, local_costs = self.model.scalar_scores(features, inp.state.P, G)
        values = {}
        overhead = h*self.overhead_rate
        for a in ACTIONS:
            price = 0. if a == 'skip' else max(local_costs[a], self.costs[a])
            end_credit = min(.1, inp.tokens-price + (inp.budget_rate-self.overhead_rate)*h)
            feasible = price <= inp.tokens and end_credit >= 0
            values[a] = losses[a] + qnoise + self.lam*(price+overhead) if feasible else float('inf')
        action = min(ACTIONS, key=values.get)
        if not np.isfinite(values[action]):
            return 'skip', {'reason': 'no_affordable_plan', 'evaluated': len(ACTIONS)}
        return action, {'reason': 'direct_moment', 'predicted_objective': float(values[action]),
                        'sequence': [action], 'evaluated': len(ACTIONS),
                        'candidate_values': values}
