"""Typed plan dependencies and a monitored source-version transaction.

Statements concern unconditional policy/population events. An admitted version
does not acquire scan-conditional confidence. The procedural control below is
deliberately fully validated, rather than an artificially weak risk baseline.
"""
from dataclasses import dataclass
from collections import defaultdict,deque
import copy,hashlib,json,math,time
from numbers import Real,Integral
from scipy.stats import beta
from r8_protocol import PROTOCOL,digest

def number(x): return isinstance(x,Real) and not isinstance(x,bool) and math.isfinite(x)
def integer(x): return isinstance(x,Integral) and not isinstance(x,bool)

class DependencyGraph:
    def __init__(self): self.children=defaultdict(set);self.values={};self.revoked=set()
    def bind(self,node,value,parents=()):
        self.values[node]=value
        for p in parents:self.children[p].add(node)
    def invalidate(self,node):
        queue=deque([node]);affected=set()
        while queue:
            n=queue.popleft()
            if n in affected:continue
            affected.add(n);queue.extend(self.children[n])
        self.revoked.update(affected)
        return sorted(affected)

@dataclass(frozen=True)
class Source:
    identity: str
    prior_seal: str
    data_seal: str

def source_from_arrays(identity,cloud,prior):
    h=hashlib.sha256()
    for a in [prior.t,prior.R,prior.bias,prior.mt,prior.mR,prior.P]:h.update(a.tobytes())
    return Source(identity,h.hexdigest(),hashlib.sha256(cloud.tobytes()).hexdigest())

def payload_seal(state):
    h=hashlib.sha256()
    for k in ['t','R','bias','mt','mR','P']:h.update(getattr(state,k).tobytes())
    return h.hexdigest()

def prepare_payload(state):
    import numpy as np
    if not all(np.all(np.isfinite(getattr(state,k))) for k in ['t','R','bias','mt','mR','P']):raise ValueError('nonfinite numerical payload')
    return payload_seal(state)

def seal_card(card):
    c=copy.deepcopy(card);c['seal']=digest(c);return c

def card_schema(card,K=528):
    reasons=[]
    if not isinstance(card,dict):return ['card_type']
    try:
        body={k:v for k,v in card.items() if k!='seal'}
        if card.get('seal')!=digest(body):reasons.append('card_seal')
    except (ValueError,TypeError):reasons.append('nonfinite_card')
    n=card.get('n');k=card.get('k');u=card.get('upper');gamma=card.get('family_error')
    if not integer(n) or n<=0 or not integer(k) or not 0<=k<=n:reasons.append('card_count')
    if not number(u) or not 0<=u<=1:reasons.append('card_bound')
    if card.get('K')!=K or not number(gamma) or gamma!=PROTOCOL['family_error']:reasons.append('confidence_family')
    if not reasons:
        expected=1. if k==n else float(beta.ppf(1-gamma/K,k+1,n-k))
        if abs(u-expected)>2e-12:reasons.append('binomial_inversion')
    return reasons

class Registry:
    def __init__(self,cards,runtime):
        self.runtime=copy.deepcopy(runtime);self.cards={};self.graph=DependencyGraph()
        for key,value in runtime.items():self.graph.bind('component/'+key,value)
        for c in cards:
            errors=card_schema(c)
            if errors:raise ValueError('invalid event card: '+','.join(errors))
            for key,value in c['bindings'].items():
                if runtime.get(key)!=value:raise ValueError('inactive dependency: '+key)
            index=(c['profile'],c['service'],c['policy'],c['event'])
            if index in self.cards:raise ValueError('duplicate card')
            self.cards[index]=copy.deepcopy(c)
            self.graph.bind('card/'+c['id'],c['seal'],['component/'+k for k in c['bindings']])
    def applicable(self,c,request,policy):
        if 'card/'+c['id'] in self.graph.revoked:return False
        return (number(c.get('upper')) and 0<=c['upper']<=1 and c['profile']==request['profile'] and c['service']==request['service']
            and c['policy']==policy and c['event'] in request['events']
            and c['upper']<=request['allowance']
            and all(self.runtime.get(k)==v for k,v in c['bindings'].items()))
    def change(self,key,value):
        if self.runtime.get(key)==value:return []
        self.runtime[key]=value
        return self.graph.invalidate('component/'+key)

def events_for(task):
    return ['trajectory','observation'] if task=='both_marginals' else [task]

class Precommit:
    """Trusted service state: a source cannot change its exogenous admission."""
    def __init__(self,request,plan):
        self.request=copy.deepcopy(request);self.plan=copy.deepcopy(plan);self.phase='PRECOMMITTED'
        self.identity=digest({'request':self.request,'policy':plan.get('policy'),'witness':plan.get('witness')})
    def bind_source(self,source):
        if self.phase!='PRECOMMITTED':raise ValueError('source already acquired')
        self.source=source;self.phase='SOURCE_BOUND'
    def replace_request(self,request):
        if self.phase!='PRECOMMITTED':raise ValueError('late admission request')
        raise ValueError('create a new exogenous precommit instead of altering this one')
    def verify(self,plan):
        if self.phase!='SOURCE_BOUND' or plan.get('policy')!=self.plan.get('policy') or plan.get('witness')!=self.plan.get('witness'):raise ValueError('altered admission')
    def verify_execution(self,policy,profile,service):
        if (policy,profile,service)!=(self.plan.get('policy'),self.request.get('profile'),self.request.get('service')):raise ValueError('execution differs from precommit')

def dispatch(registry,table,request,policy_ids,mode='full'):
    """Request is exogenous; no source quality or outcome enters dispatch."""
    start=time.process_time_ns()
    if (request.get('task') not in PROTOCOL['request_types'] or
        not number(request.get('allowance')) or not 0<=request['allowance']<=1 or
        request.get('elapsed_s')!=0. or request.get('declared_population') is not True or
        request.get('events')!=events_for(request.get('task'))):
        return {'status':'REFUSED','policy':None,'reasons':['invalid_pre_sensing_request'],
            'cpu_s':(time.process_time_ns()-start)*1e-9}
    choices=[]
    for pid in policy_ids:
        selected=[]
        for event in request['events']:
            c=registry.cards.get((request['profile'],request['service'],pid,event))
            if c is None or not registry.applicable(c,request,pid):break
            selected.append(c)
        if len(selected)==len(request['events']):
            score=table[(request['profile'],request['service'],pid)]
            choices.append((score,pid,selected))
    choices.sort(key=lambda x:(x[0],x[1]))
    if not choices:
        return {'status':'REFUSED','policy':None,'reasons':['empty_feasible_catalogue'],
            'eligible':[],'cpu_s':(time.process_time_ns()-start)*1e-9}
    score,pid,cards=choices[0]
    witness={'profile':request['profile'],'service':request['service'],'policy':pid,
        'task':request['task'],'allowance':request['allowance'],'cards':[c['seal'] for c in cards],
        'bounds':{c['event']:c['upper'] for c in cards},'runtime':copy.deepcopy(registry.runtime)}
    plan={'status':'SELECTED','policy':pid,'score_m2s':score,'witness':witness,
        'eligible':[x[1] for x in choices],'reasons':[]}
    if mode=='full':
        name='plan/'+digest(witness);registry.graph.bind(name,digest(witness),['card/'+c['id'] for c in cards]);plan['node']=name
    plan['cpu_s']=(time.process_time_ns()-start)*1e-9
    return plan

def procedural_dispatch(cards,table,request,policy_ids,runtime):
    """Independent non-graph implementation with the same task/risk/resources."""
    start=time.process_time_ns();choices=[]
    if (request.get('elapsed_s')!=0. or request.get('declared_population') is not True
        or not number(request.get('allowance')) or not 0<=request['allowance']<=1
        or request.get('task') not in PROTOCOL['request_types'] or request.get('events')!=events_for(request.get('task'))):
        return {'status':'REFUSED','policy':None,'cpu_s':(time.process_time_ns()-start)*1e-9}
    for pid in policy_ids:
        bounds={};seals=[]
        for event in request['events']:
            c=cards.get((request['profile'],request['service'],pid,event))
            if c is None:break
            if not number(c.get('upper')) or not 0<=c['upper']<=1 or any(runtime.get(k)!=v for k,v in c['bindings'].items()) or c['upper']>request['allowance']:break
            bounds[event]=c['upper'];seals.append(c['seal'])
        if len(bounds)==len(request['events']):choices.append((table[(request['profile'],request['service'],pid)],pid,bounds,seals))
    choices.sort(key=lambda x:(x[0],x[1]))
    if not choices:return {'status':'REFUSED','policy':None,'cpu_s':(time.process_time_ns()-start)*1e-9}
    score,pid,bounds,seals=choices[0]
    witness={'profile':request['profile'],'service':request['service'],'policy':pid,'task':request['task'],
        'allowance':request['allowance'],'cards':seals,'bounds':bounds,'runtime':copy.deepcopy(runtime)}
    return {'status':'SELECTED','policy':pid,'score_m2s':score,'bounds':bounds,'cards':seals,'witness':witness,
        'eligible':[x[1] for x in choices],'cpu_s':(time.process_time_ns()-start)*1e-9}

class Transaction:
    def __init__(self,source,policy,profile,service,deadline,budget,bindings,commit_id=None):
        self.source=source;self.policy=policy;self.profile=profile;self.service=service
        self.deadline=deadline;self.budget=budget;self.bindings=bindings
        self.last_sequence=0;self.last_iteration=0;self.rollback=False;self.active=0;self.journal=[]
        self.installed_payload_seal=None
        self.payloads={}
        self.expected_versions={}
        self.commit_id=commit_id
    def register_payload(self,sequence,iteration,state):
        if not integer(sequence) or sequence<=0 or sequence in self.expected_versions or not integer(iteration) or iteration<0:raise ValueError('invalid produced version')
        seal=prepare_payload(state);self.payloads[sequence]=seal
        self.expected_versions[sequence]=(iteration,iteration==0,seal)
        return seal
    def assess(self,version,elapsed,receiver_tick,request,layer='full'):
        reasons=[]
        if not number(elapsed) or elapsed<0:reasons.append('time')
        if version.get('source')!=self.source.identity or version.get('prior')!=self.source.prior_seal or version.get('data')!=self.source.data_seal:reasons.append('lineage')
        for k,v in self.bindings.items():
            if version.get('bindings',{}).get(k)!=v:reasons.append('dependency/'+k)
        if request.get('active_bindings')!=self.bindings:reasons.append('active_dependencies')
        if self.commit_id is not None and version.get('commit_id')!=self.commit_id:reasons.append('precommit_identity')
        if not isinstance(version.get('payload'),str) or len(version['payload'])!=64 or version['payload']!=request.get('received_payload_seal'):reasons.append('payload_fingerprint')
        if version.get('policy')!=self.policy:reasons.append('policy')
        if version.get('profile')!=self.profile or version.get('service')!=self.service:reasons.append('configuration')
        seq=version.get('sequence');it=version.get('iteration');replay_to=version.get('replay_to')
        if not integer(seq) or self.expected_versions.get(seq)!=(it,version.get('rollback'),version.get('payload')):reasons.append('producer_version')
        if not integer(seq) or seq<=self.last_sequence:reasons.append('version_order')
        if not integer(it) or it<0 or (it>0 and it<self.last_iteration):reasons.append('iteration_order')
        if not integer(replay_to) or replay_to!=receiver_tick:reasons.append('causal_replay')
        if not integer(receiver_tick) or not number(elapsed) or abs(elapsed-receiver_tick*PROTOCOL['dt_s'])>1e-12:reasons.append('source_clock')
        if type(version.get('rollback')) is not bool or version.get('rollback')!=(it==0):reasons.append('rollback_type')
        if self.rollback and it>0:reasons.append('rollback_resurrection')
        if request.get('event') not in PROTOCOL['events']:reasons.append('event')
        if not number(request.get('assessment_s')) or (request['event']!='trajectory' and request['assessment_s']!=self.deadline):reasons.append('assessment')
        if request['event']!='trajectory' and elapsed>self.deadline+1e-12:reasons.append('expired_statement')
        if not number(version.get('sender_work_s')) or not 0<=version['sender_work_s']<=self.budget+1e-12:reasons.append('budget')
        if layer=='none':reasons=[]
        elif layer=='matching':reasons=[r for r in reasons if r not in ['version_order','iteration_order','causal_replay','rollback_type','rollback_resurrection']]
        return {'valid':not reasons,'reasons':reasons}
    def install(self,version,tick):
        self.last_sequence=version['sequence'];self.last_iteration=max(self.last_iteration,version['iteration'])
        self.rollback=bool(version['rollback']);self.active=version['iteration']
        self.installed_payload_seal=version['payload']
        self.journal.append({'tick':tick,'sequence':self.last_sequence,'active_iteration':self.active,'rollback':self.rollback})

def procedural_version_check(source,policy,profile,service,deadline,budget,bindings,version,elapsed,tick,
                             last_sequence,last_iteration,rolled_back,request,expected_versions=None):
    """Strong comparator implemented independently of Transaction/its graph."""
    if not number(elapsed) or elapsed<0:return False
    if (version.get('source'),version.get('prior'),version.get('data'))!=(source.identity,source.prior_seal,source.data_seal):return False
    if (version.get('policy'),version.get('profile'),version.get('service'))!=(policy,profile,service):return False
    if any(version.get('bindings',{}).get(k)!=v for k,v in bindings.items()):return False
    if request.get('active_bindings')!=bindings:return False
    if not isinstance(version.get('payload'),str) or len(version['payload'])!=64 or version['payload']!=request.get('received_payload_seal'):return False
    seq=version.get('sequence');it=version.get('iteration')
    if not integer(seq) or expected_versions is None or expected_versions.get(seq)!=(it,version.get('rollback'),version.get('payload')):return False
    if not integer(seq) or seq<=last_sequence or not integer(it) or it<0:return False
    if it and (it<last_iteration or rolled_back):return False
    if type(version.get('rollback')) is not bool or version.get('rollback')!=(it==0):return False
    if not integer(version.get('replay_to')) or version['replay_to']!=tick:return False
    if not integer(tick) or abs(elapsed-tick*PROTOCOL['dt_s'])>1e-12:return False
    if request.get('event') not in PROTOCOL['events'] or not number(request.get('assessment_s')):return False
    if request['event']!='trajectory' and (request['assessment_s']!=deadline or elapsed>deadline+1e-12):return False
    return number(version.get('sender_work_s')) and 0<=version['sender_work_s']<=budget+1e-12

def authorize_statement(registry,plan,transaction,version,request,elapsed,layer='full'):
    """Attach a policy/population bound to its scheduled event, not to true error."""
    reasons=[];event=request.get('event');w=plan.get('witness',{})
    if plan.get('status')!='SELECTED':reasons.append('no_admission_plan')
    if event not in events_for(w.get('task')):reasons.append('wrong_requested_event')
    card=registry.cards.get((w.get('profile'),w.get('service'),w.get('policy'),event))
    if card is None:return {'authorized':False,'upper':None,'reasons':['no_card']}
    if not number(card.get('upper')) or not 0<=card['upper']<=1:reasons.append('invalid_card_bound')
    if request.get('card_seal')!=card['seal'] or card['seal'] not in w.get('cards',[]):reasons.append('evidence_match')
    if plan.get('node') in registry.graph.revoked:reasons.append('revoked_plan')
    if any(registry.runtime.get(k)!=v for k,v in card['bindings'].items()):reasons.append('active_dependencies')
    if (version.get('policy'),version.get('profile'),version.get('service'))!=(w.get('policy'),w.get('profile'),w.get('service')):reasons.append('execution_identity')
    if (version.get('source'),version.get('prior'),version.get('data'))!=(transaction.source.identity,transaction.source.prior_seal,transaction.source.data_seal):reasons.append('source')
    if not integer(version.get('sequence')) or version['sequence']!=transaction.last_sequence:reasons.append('inactive_version')
    if version.get('iteration')!=transaction.active:reasons.append('inactive_payload')
    if version.get('payload')!=transaction.installed_payload_seal:reasons.append('payload_fingerprint')
    if transaction.commit_id is not None and version.get('commit_id')!=transaction.commit_id:reasons.append('precommit_identity')
    if not integer(version.get('replay_to')) or version['replay_to']!=request.get('receiver_tick'):reasons.append('replay_time')
    if not integer(request.get('receiver_tick')) or not number(elapsed) or abs(elapsed-request['receiver_tick']*PROTOCOL['dt_s'])>1e-12:reasons.append('source_clock')
    assessment=transaction.deadline if event in ['observation','union'] else 4.
    if not number(elapsed) or not 0<=elapsed<=assessment+1e-12 or request.get('assessment_s')!=assessment:reasons.append('expired_or_wrong_assessment')
    if not number(w.get('allowance')) or not number(card.get('upper')) or card['upper']>w.get('allowance',-1):reasons.append('risk_allowance')
    if layer=='matching':reasons=[r for r in reasons if r not in ['inactive_version','inactive_payload','replay_time']]
    elif layer=='none':reasons=[r for r in reasons if r in ['invalid_card_bound','risk_allowance']]
    return {'authorized':not reasons,'upper':card['upper'] if not reasons else None,'reasons':reasons,
        'meaning':'unconditional frozen policy/population event bound; not scan-conditional confidence'}

def procedural_statement_check(registry,plan,tx,version,request,elapsed):
    # Independently stated conjunction, without the dependency graph.
    w=plan.get('witness',{});event=request.get('event')
    if plan.get('status')!='SELECTED' or event not in events_for(w.get('task')):return False
    c=registry.cards.get((w.get('profile'),w.get('service'),w.get('policy'),event))
    if c is None or not number(c.get('upper')) or not 0<=c['upper']<=1:return False
    if request.get('card_seal')!=c['seal'] or c['seal'] not in w.get('cards',[]):return False
    if any(registry.runtime.get(k)!=v for k,v in c['bindings'].items()):return False
    if (version.get('policy'),version.get('profile'),version.get('service'))!=(w.get('policy'),w.get('profile'),w.get('service')):return False
    if (version.get('source'),version.get('prior'),version.get('data'))!=(tx.source.identity,tx.source.prior_seal,tx.source.data_seal):return False
    if not integer(version.get('sequence')) or version['sequence']!=tx.last_sequence or version.get('iteration')!=tx.active:return False
    if version.get('payload')!=tx.installed_payload_seal:return False
    if tx.commit_id is not None and version.get('commit_id')!=tx.commit_id:return False
    if not integer(version.get('replay_to')) or version['replay_to']!=request.get('receiver_tick'):return False
    if not integer(request.get('receiver_tick')) or not number(elapsed) or abs(elapsed-request['receiver_tick']*PROTOCOL['dt_s'])>1e-12:return False
    assessment=tx.deadline if event in ['observation','union'] else 4.
    return (number(elapsed) and 0<=elapsed<=assessment+1e-12 and request.get('assessment_s')==assessment
        and number(w.get('allowance')) and c['upper']<=w['allowance'])
