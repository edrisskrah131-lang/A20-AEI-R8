# Real-image defect evidence lifecycle

This study trains and executes a real detector on public Innovation Hangar v2, version 1. All image processing, prediction arrays, event counts and report operations are executed; numerical outcomes are in `outputs/summary.json` after completion. Dataset credits, upstream links and licensing are in `SOURCE_CREDIT.md`.

## What is independent

The release has 10,722 augmented/repeated images. The retained manifest has 1,339 representative images in 222 inferred source groups, split as 122/33/33/34 groups (458/34/368/479 images) for training/development/calibration/test. The source-photo and capture-day grouping is inferred from filenames and visual matching; aircraft identities are not available. Do not count all released files, bounding boxes or repeated frames as independent calibration trials. The provenance manifest and split audit preserve every grouping decision.

The trial unit is one complete source group. Its event pools annotated-defect recall and unmatched predictions per image over all member frames. It is a pooled-category service, not a per-class sensitivity guarantee. Missing head, paint loss and scratch each occur in one positive calibration and test source group; frame-level results for these classes are descriptive.

## Models and fixed data use

`train.py` is the executed initial 16-epoch fit at 320 pixels; `initial_fit/` retains its freeze, arguments and thread audit. `models/early.pt` is epoch 4. `models/initial16.pt` preserves the original epoch-16 output. `extend.py` develops the final model on the training/development partitions at 480 pixels, following `development_plan.json`. Checkpoint and operational confidence are selected on development data only. `development_selection.json`, `model_freeze.json` and `resolved_protocol.json` record the final choice. The model signatures include weights, digital gain and inference settings.

`protocol.json` records the original plan; `resolved_protocol.json` supplies the executed final inference specification. The early checkpoint, final checkpoint and two digital-gain variants are four distinct producers. Digital gain 0.5/1.5 changes existing decoded pixels; it is not a fresh measurement of different lighting.

## Reproduce with archived weights

Install CPU PyTorch/torchvision and the pinned libraries from `../../requirements-real-images.txt` in a separate environment. From the manuscript directory:

```sh
python studies/real_defects_20261020/checks.py
python studies/real_defects_20261020/evaluate.py --verify
python studies/real_defects_20261020/analyze.py
python studies/real_defects_20261020/verify.py
```

`evaluate.py --verify` reexecutes all 3,524 detector outputs from pixels and archived weights, retaining original measured timings and prediction files. Detection receives pixels, not labels; scoring subsequently reads fixed annotations. Independent verification matches raw predictions against annotations, reconstructs group events, inverts binomial tails and checks every report history. `artifact_manifest.json` covers the archived source, models, pixels and results. Verification reports are excluded from that self-inventory.

The complete paper entry point uses `A20_PYTHON` for historical studies and reporting and `A20_DETECTOR_PYTHON` for this study's model environment. No network or GPU is needed for inference reproduction after restoring all data volumes.

## Refit instead of verifying

Refitting produces new measured costs and potentially different floating-point outputs. Work in a separate copy and retain this archived study for comparison. `train.py` and `extend.py` preserve the executed environment paths and full optimizer arguments; update their runtime work/configuration paths for a different machine. Acquire the official COCO-pretrained YOLO11n checkpoint, verify its hash against `pretraining_freeze.json`, run the initial fit, preserve its epoch-16 model as `models/initial16.pt`, and then run the extension. Training data and the development split are sufficient; do not change the final model using calibration/test scores.

`data/source_annotations` retains each selected original label. `data/{split}/labels` holds converted axis-aligned boxes. `outputs/*.npz` stores every raw candidate detection, and metadata includes image, transformed-pixel, producer and prediction hashes. `workflow.csv` is a 12-operation report campaign per test group, distinct from the independent sample count. A repair can restore integrity even when the quality statement remains refused.
