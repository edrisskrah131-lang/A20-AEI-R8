"""Package complete R8/retained evidence in independently extractable ZIP groups."""
from pathlib import Path
import json,hashlib,zipfile,shutil
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];WORK=ROOT.parents[1]
R=ROOT/'release';R.mkdir(exist_ok=True)
LIMIT=420_000_000
CACHE={}
def digest(p):
    p=p.resolve()
    if p not in CACHE:
        h=hashlib.sha256()
        with p.open('rb') as f:
            for b in iter(lambda:f.read(8<<20),b''):h.update(b)
        CACHE[p]=h.hexdigest()
    return CACHE[p]
def eligible(p):
    return p.is_file() and not any(x.startswith('.') or x=='__pycache__' for x in p.relative_to(WORK).parts)
def files(folder):return sorted(p for p in folder.rglob('*') if eligible(p))
def member(p):return 'A20_release/'+str(p.relative_to(WORK))
DONE=[]
def make(name,items,scope):
    items=sorted(set(items));out=R/name;manifest=[]
    with zipfile.ZipFile(out,'w',allowZip64=True) as z:
        for p in items:
            entry={'path':member(p),'bytes':p.stat().st_size,'sha256':digest(p)}
            manifest.append(entry)
            stored=p.suffix.lower() in {'.npz','.gz','.zip','.png','.jpg','.jpeg','.tiff','.pdf','.so'} or '.part' in p.name
            z.write(p,entry['path'],compress_type=zipfile.ZIP_STORED if stored else zipfile.ZIP_DEFLATED,compresslevel=6)
        z.writestr('PACKAGE_MANIFESTS/'+name+'.json',json.dumps({'archive':name,'scope':scope,'members':manifest},indent=2),compress_type=zipfile.ZIP_DEFLATED)
    with zipfile.ZipFile(out) as z:
        bad=z.testzip();assert bad is None,(name,bad)
        names=z.namelist();assert len(names)==len(set(names))
        assert all(not n.startswith('/') and '..' not in Path(n).parts for n in names)
    assert out.stat().st_size<450_000_000,(name,out.stat().st_size)
    record={'filename':name,'bytes':out.stat().st_size,'sha256':digest(out),'scope':scope,'members':len(items)}
    DONE.append(record);print('PACKAGE_OK',json.dumps(record),flush=True)
def shards(prefix,items,scope):
    group=[];size=0;n=1
    for p in sorted(items):
        s=p.stat().st_size;assert s<LIMIT,(p,s)
        if size+s>LIMIT and group:
            make(prefix+f'_Part{n:02d}.zip',group,scope);group=[];size=0;n+=1
        group.append(p);size+=s
    if group:make(prefix+f'_Part{n:02d}.zip',group,scope)
def main():
    shutil.copy2(ROOT/'main.pdf',R/'A20_AEI_R8_Manuscript.pdf')
    shutil.copy2(ROOT/'supplement.pdf',R/'A20_AEI_R8_Supplement.pdf')
    shutil.copy2(ROOT/'README.md',R/'A20_AEI_R8_Reproducibility_README.md')
    for stem,target in [('REVISION_REPORT_CN','A20_AEI_R8_Revision_Report_CN'),('INDEPENDENT_REVIEW_CN','A20_AEI_R8_Independent_Review_CN')]:
        shutil.copy2(ROOT/(stem+'.md'),R/(target+'.md'))
    rootdocs=[p for p in ROOT.iterdir() if p.is_file() and p.suffix.lower() in {'.tex','.bib','.cls','.bst','.md','.txt','.pdf'}]
    sections=files(ROOT/'sections')
    latexfigs=[p for p in files(ROOT/'figures') if p.suffix.lower()=='.pdf' or 'hardware_originals' in p.parts or 'simulation_originals' in p.parts]
    sources=files(ROOT/'source')
    make('A20_AEI_R8_Editable_LaTeX.zip',rootdocs+sections+latexfigs+sources,'Complete main/SI publisher source, all referenced graphics/original images, writing/plot/build/verification code; numerical recomputation additionally uses research/data groups.')
    native=WORK/'work/a19/RAS_A19'
    qa=[p for p in files(ROOT/'qa') if 'pdf_pages' not in p.parts and 'report_build' not in p.parts]
    make('A20_AEI_R8_Research_Code_And_Audits.zip',rootdocs+sections+sources+qa+files(native),'All program/config/readme/review/audit records and complete byte-preserved native A19 dependency; current data/config supplied in data groups.')
    make('A20_AEI_R8_All_Figures_And_Source.zip',files(ROOT/'figures')+sources,'All old/new figure PDF/SVG/high-resolution PNG/TIFF, uncropped original photos/screenshots, plot and QA source. Full data groups regenerate numerical plots.')
    d=ROOT/'data/r8_final'
    shards('A20_AEI_R8_Episode_Raw',files(d/'episode_inputs'),'All 13,824 independent raw/source archives. All parts required for complete episode input inventory.')
    other=[p for p in files(d) if 'episode_inputs' not in p.parts and 'routes' not in p.parts]
    make('A20_AEI_R8_Results_Calibration_And_Protocol.zip',other,'All controlled/integrated raw results, seed index/traces, 528 cards/96 choices, protocol/clock/F0/V3/F1, analysis, pilot, geometry, environment and execution logs.')
    shards('A20_AEI_R8_Complete_Routes',files(d/'routes'),'All 36 route raw inputs and all 432 live executions, full tick/capture arrays, per-method journals and input provenance.')
    old=[p for p in files(ROOT/'data') if not p.is_relative_to(d)]
    shards('A20_AEI_R8_Historical_Assets',old+files(ROOT/'preserved'),'Complete retained A19/A20/R4/R5 data/history/archives, amendments/recovery records and incoming byte-exact 25-page/18-page baseline. Reassemble original source ZIP with source/r8_restore_original_baseline.py after extracting all parts.')
    compiled=[]
    for name in ['A20_AEI_R8_Manuscript.pdf','A20_AEI_R8_Supplement.pdf','A20_AEI_R8_Revision_Report_CN.pdf','A20_AEI_R8_Independent_Review_CN.pdf','A20_AEI_R8_Revision_Report_CN.md','A20_AEI_R8_Independent_Review_CN.md','A20_AEI_R8_Reproducibility_README.md']:
        p=R/name;assert p.is_file();compiled.append({'filename':name,'bytes':p.stat().st_size,'sha256':digest(p)})
    (R/'A20_AEI_R8_Release_Manifest.json').write_text(json.dumps({'utc':datetime.now(timezone.utc).isoformat(),'status':'all ZIP CRC/member paths verified','compiled_and_reports':compiled,'archives':DONE,'independent_episode_inputs':13824,'independent_route_inputs':36,'frozen_method_files_modified':False,'complete_extract_base':'common parent containing A20_release','archive_member_manifest':'PACKAGE_MANIFESTS/<archive-name>.json'},indent=2))
    print('RELEASE_PACKAGE_COMPLETE',len(DONE),flush=True)
if __name__=='__main__':main()
