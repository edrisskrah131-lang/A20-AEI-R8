"""Prespecified deterministic change/recovery validation using sealed evidence.

This is a software conformance study. It generates no new population samples
or calibration cards and never edits the original numerical producer.
"""
from pathlib import Path
from copy import deepcopy
from functools import lru_cache
import sys,json,hashlib,time,platform
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'snapshots'))
from event_semantics import Atom,Event,Card,containment,procedural_contains,digest
import task_requirements as tr
from runtime_receipts import TrustedSource,ReceiptGate

METHODS=('ContractCover','ProceduralCoverValidated','DirectRecertCached')
FIELDS=('target_plan','geometry_sampler','focal_px','exposure_s','motion_sampler',
        'roi','renderer','detector','pixel_noise','localization','capture_sampler',
        'camera_clock','report_queue')
SPEC=json.loads((ROOT/'protocol.json').read_text())
AMEND=json.loads((ROOT/'inputs/dependency_amendment.json').read_text())
tr.DEPENDENCIES={k:tuple(v) for k,v in AMEND['amended_dependencies'].items()}
CARDS=json.loads((ROOT/'inputs/cards.json').read_text())
PLANS=json.loads((ROOT/'inputs/plans.json').read_text())
SHA=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def normalize(c):
    c=deepcopy(c)
    for field in ['roi','localization']:c[field]=tuple(c[field])
    return c

INDEX={}
for c in CARDS:
    c['context']=normalize(c['context'])
    c['_event']=Event(tuple(Atom(*a) for a in c['atoms']))
    c['_value']=Card(c['event_id'],c['producer_id'],c['population_id'],
                    c['calibration_manifest'],c['n'],c['k'],c['alpha'],c['upper'])
    if not c['_value'].valid() or c['_event'].identity!=c['event_id']:
        raise ValueError('Invalid archived card: '+c['id'])
    if tr.event_capsule(c['_event'],c['context'])!=c['producer_id']:
        raise ValueError('Amended producer dependency does not match sealed card')
    INDEX.setdefault((c['profile'],c['service'],c['policy']),[]).append(c)

def library(study,profile,service,policy):
    return [c for c in INDEX[profile,service,policy] if study=='B' or c['study']=='A']

def engine(study,profile,service,policy,event,ctx,method):
    """Validate before-sensing fixed-policy evidence after a known edit."""
    accepted=[]
    for c in library(study,profile,service,policy):
        if c['upper']>SPEC['allowance']:continue
        if method=='DirectRecertCached':
            if event.identity!=c['event_id']:continue
            if tr.event_capsule(event,ctx)!=tr.event_capsule(event,c['context']):continue
            witness=[('exact_event',event.identity)]
        elif method=='ContractCover':
            if c['variant'] not in tr.ANCHORS:continue
            witness=containment(c['_event'],event)
            if witness is None:continue
            if tr.event_capsule(event,ctx)!=tr.event_capsule(event,c['context']):continue
        else:
            if c['variant'] not in tr.ANCHORS or not procedural_contains(c['_event'],event):continue
            valid=True
            for a in event.atoms:
                for field in tr.DEPENDENCIES[a.metric]:
                    if c['context'][field]!=ctx[field]:valid=False
            if not valid:continue
            witness=[('independent_procedure',event.identity)]
        accepted.append((c['upper'],c['id'],c,witness))
    if not accepted:return {'status':'REFUSED','policy':policy,'event_id':event.identity,'upper':None,'card':None}
    _,_,c,w=min(accepted,key=lambda v:(v[0],v[1]))
    return {'status':'AUTHORIZED','policy':policy,'event_id':event.identity,
            'upper':c['upper'],'card':c['id'],'n':c['n'],'k':c['k'],
            'witness':w,'calibration_manifest':c['calibration_manifest']}

def oracle(study,profile,service,policy,event,ctx,method):
    """Independent field/interval inspection; no capsule or engine predicates."""
    requested={a.metric:(-np.inf if a.lower is None else a.lower,
                         np.inf if a.upper is None else a.upper) for a in event.atoms}
    for c in library(study,profile,service,policy):
        if c['upper']>SPEC['allowance']:continue
        old={a[0]:(-np.inf if a[1] is None else a[1],np.inf if a[2] is None else a[2]) for a in c['atoms']}
        if method=='DirectRecertCached':
            if requested!=old:continue
        elif c['variant'] not in ('full','partial','single_service'):continue
        if any(m not in old or old[m][0]<bounds[0] or old[m][1]>bounds[1] for m,bounds in requested.items()):continue
        required=set()
        for metric in requested:required.update(AMEND['amended_dependencies'][metric])
        if any(json.dumps(ctx[f],sort_keys=True)!=json.dumps(c['context'][f],sort_keys=True) for f in required):continue
        return True
    return False

def changed(ctx,fields):
    out=deepcopy(ctx)
    for field in fields:
        value=out[field]
        if field=='focal_px':out[field]=2400.
        elif field=='exposure_s':out[field]=.009
        elif field=='camera_clock':out[field]=value*2
        elif field=='report_queue':out[field]=.10
        elif field=='roi':out[field]=(value[0]+96,value[1]+72)
        elif field=='localization':out[field]=tuple(value[:-1])+(value[-1]+'/fixture-v2',)
        else:out[field]=value+'/fixture-v2'
    return out

def contexts():
    # Every unique compiled context is retained. Fixed policies are committed
    # before the edit; no observed image quality is used to choose a policy.
    lookup={(p['study'],p['profile'],p['service'],p['event_id'],p['method']):p
            for p in PLANS if p['allowance']==SPEC['allowance']}
    seen=set();out=[]
    for q in PLANS:
        key=(q['study'],q['profile'],q['service'],q['event_id'])
        if q['allowance']!=SPEC['allowance'] or q['method']!='ContractCover' or key in seen:continue
        seen.add(key)
        direct=lookup[(*key,'DirectRecertCached')]
        policy=q['policy'] if q['status']=='AUTHORIZED' else direct['policy'] or 'Fixed2'
        ctx=next(c['context'] for c in library(q['study'],q['profile'],q['service'],policy) if c['study']==q['study'])
        out.append((q,policy,tr.requirement(q['task'],q['variant']),ctx))
    assert len(out)==320
    return out

def run():
    freeze=json.loads((ROOT/'freeze.json').read_text())
    for file,hashval in freeze['files'].items():
        if SHA(ROOT/file)!=hashval:raise ValueError('Changed prespecified input: '+file)
    rows=[];timing={m:0. for m in METHODS};disagreements=[]
    for q,policy,event,ctx in contexts():
        base={m:engine(q['study'],q['profile'],q['service'],policy,event,ctx,m) for m in METHODS}
        for name,fields in SPEC['edits']:
            edited=changed(ctx,fields)
            for method in METHODS:
                start=time.perf_counter_ns()
                after=engine(q['study'],q['profile'],q['service'],policy,event,edited,method)
                restored=engine(q['study'],q['profile'],q['service'],policy,event,ctx,method)
                timing[method]+=(time.perf_counter_ns()-start)*1e-9
                expected=oracle(q['study'],q['profile'],q['service'],policy,event,edited,method)
                actual=after['status']=='AUTHORIZED'
                if actual!=expected:disagreements.append((q['study'],q['event_id'],name,method))
                assert restored['status']==base[method]['status'] and restored['card']==base[method]['card']
                rows.append(dict(study=q['study'],profile=q['profile'],service=q['service'],
                    task=q['task'],variant=q['variant'],event_id=event.identity,policy=policy,
                    edit=name,fields=';'.join(fields),method=method,
                    before_authorized=base[method]['status']=='AUTHORIZED',after_authorized=actual,
                    expected_authorized=expected,recovered=restored['status']=='AUTHORIZED',
                    missed_invalidation=int(actual and not expected),
                    unnecessary_refusal=int(expected and not actual),
                    restore_mismatch=0,
                    stale_cache_error=int(base[method]['status']=='AUTHORIZED' and not expected),
                    blanket_refusal_error=int(bool(fields) and expected)))
    frame=pd.DataFrame(rows);frame.to_csv(ROOT/'outputs/change_cases.csv',index=False)
    assert not disagreements
    summary=frame.groupby('method').agg(decisions=('edit','size'),initial_admissions=('before_authorized','sum'),
        retained_admissions=('after_authorized','sum'),missed_invalidation=('missed_invalidation','sum'),
        unnecessary_refusal=('unnecessary_refusal','sum'),restore_mismatch=('restore_mismatch','sum'),
        stale_cache_error=('stale_cache_error','sum'),blanket_refusal_error=('blanket_refusal_error','sum')).reset_index()
    summary['revalidation_and_restore_wall_s']=summary.method.map(timing)
    summary.to_csv(ROOT/'outputs/change_summary.csv',index=False)
    piv=frame.pivot(index=['study','profile','service','event_id','edit'],columns='method',values='after_authorized')
    assert (piv.ContractCover==piv.ProceduralCoverValidated).all()

    # Fixed actual archived trace, chosen in the previous reproduction handoff.
    meta=json.loads((ROOT/'inputs/14300000.json').read_text())
    for name,value in meta['files'].items():assert SHA(ROOT/'inputs'/name)==value
    q=next(q for q in PLANS if q['study']=='B' and q['profile']=='unfitted' and q['service']=='relaxed'
           and q['task']=='association' and q['variant']=='full' and q['method']=='ContractCover' and q['allowance']==.15)
    ctx=next(c['context'] for c in CARDS if c['id']==q['card'])
    full=tr.requirement('association','full')
    relaxed=Event(tuple(Atom(a.metric,a.lower,50. if a.metric=='reprojection_px' else a.upper) for a in full.atoms))
    optics=tr.requirement('acquisition','single_service')
    readiness=Event((Atom('localization_ready',lower=1.),))
    journey=[]
    for stage,event,current in [('original_full_association',full,ctx),('consumer_reprojection_30_to_50',relaxed,ctx),
        ('decoder_v2_full_association',full,changed(ctx,['detector'])),
        ('decoder_v2_optical_component',optics,changed(ctx,['detector'])),
        ('decoder_v2_readiness_component',readiness,changed(ctx,['detector'])),
        ('restore_decoder_full_association',full,ctx)]:
        for method in METHODS[:2]:
            p=engine('B','unfitted','relaxed','FlatCART',event,current,method)
            source=TrustedSource('EXCLUDED_LIFECYCLE/'+stage,SHA(ROOT/'inputs/14300000.json'),'unfitted','B')
            committed={**p,'profile':'unfitted','study':'B','allowance':.15}
            gate=ReceiptGate(method)
            receipt=gate.issue(committed,source,gate.packet(committed,source))
            journey.append(dict(stage=stage,method=method,**p,receipt_issued=receipt['issued'],
                                new_calibration_records=0))
    refused={'decoder_v2_full_association','decoder_v2_optical_component'}
    assert all(x['status']=='AUTHORIZED' for x in journey if x['stage'] not in refused)
    assert all(x['status']=='REFUSED' for x in journey if x['stage'] in refused)
    faults=[]
    for method in METHODS:
        for field in ['source','source_seal','profile','study','policy','event_id','plan_seal','card']:
            hist={};gate=ReceiptGate(method,hist)
            p=engine('B','unfitted','relaxed','FlatCART',full,ctx,method)
            plan={**p,'profile':'unfitted','study':'B','allowance':.15}
            source=TrustedSource('EXCLUDED_FAULT/'+method+'/'+field,SHA(ROOT/'inputs/14300000.json'),'unfitted','B')
            good=gate.packet(plan,source);assert gate.issue(plan,source,good)['issued']
            bad={**good,field:'CONSTRUCTED_WRONG_VALUE'}
            assert not gate.issue(plan,source,bad)['issued']
            assert not ReceiptGate(method,hist).issue(plan,source,good)['issued']
            new=TrustedSource(source.scope+'/trusted_successor',source.seal,'unfitted','B')
            assert ReceiptGate(method,hist).issue(plan,new,gate.packet(plan,new))['issued']
            faults.append(dict(method=method,field=field,false_authorizations=0,
                               reconstructed_history_refused=True,independent_successor_admitted=True))
    actual=next(v for v in meta['outcomes'] if v['policy']=='FlatCART' and v['service']=='relaxed')
    trace=next(v for v in meta['execution_traces'] if v['policy']=='FlatCART' and v['service']=='relaxed')
    case=dict(source_seed=14300000,source_sha256=SHA(ROOT/'inputs/14300000.json'),
        capture_tick=meta['capture_tick'],outcome=actual,execution_trace=trace,
        plan={k:v for k,v in q.items()},journey=journey,faults=faults,
        observed_full_report_pass=bool(not tr.requirement('report','full').failure({k:np.array([actual[k]]) for k in tr.DEPENDENCIES})[0]))
    (ROOT/'outputs/illustrated_case.json').write_text(json.dumps(case,indent=2))

    # Matched support and fixed selected policies; counted work, not new runtime.
    matched=[]
    for q in PLANS:
        if q['method']!='ContractCover' or q['allowance']!=.15 or q['status']!='AUTHORIZED':continue
        key=(q['study'],q['profile'],q['service'],q['event_id'])
        if any(tuple(row[k] for k in ('study','profile','service','event_id'))==key for row in matched):continue
        event=tr.requirement(q['task'],q['variant'])
        ctx=next(c['context'] for c in CARDS if c['id']==q['card'])
        direct=engine(q['study'],q['profile'],q['service'],q['policy'],event,ctx,'DirectRecertCached')
        assert direct['status']=='AUTHORIZED'
        matched.append(dict(study=q['study'],profile=q['profile'],service=q['service'],event_id=q['event_id'],
             policy=q['policy'],anchor=q['card'],direct=direct['card']))
    costs=[]
    for study in ['A','B','combined']:
        selected=matched if study=='combined' else [x for x in matched if x['study']==study]
        for method,column in [('Anchor reuse','anchor'),('Direct event preparation','direct')]:
            ids=set(x[column] for x in selected)
            # Deduplicate event/producer/population/source-manifest identities.
            unique={tuple(c[k] for k in ['event_id','producer_id','population_id','calibration_manifest']):c for c in CARDS if c['id'] in ids}
            costs.append(dict(study=study,method=method,matched_unique_requests=len(selected),
                proof_cards=len(unique),required_record_evaluations=sum(c['n'] for c in unique.values())))
    pd.DataFrame(costs).to_csv(ROOT/'outputs/matched_support_cost.csv',index=False)
    result=dict(status='PASS',study='deterministic software change/recovery conformance',
        distinct_existing_contexts=320,edits_per_context=len(SPEC['edits']),paired_change_contexts=320*len(SPEC['edits']),
        methods=list(METHODS),method_change_decisions=len(frame),new_independent_population_inputs=0,
        newly_calibrated_event_cards=0,primary_implementations_equal=True,summary=summary.to_dict('records'),
        receipt_fault_cases=len(faults),false_receipt_authorizations=0,matched_costs=costs,
        timing_boundary='preloaded-card query plus producer restore; excludes numerical processing, data acquisition and human maintenance',
        machine=dict(python=platform.python_version(),system=platform.system()),freeze_sha256=SHA(ROOT/'freeze.json'))
    (ROOT/'outputs/results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))

if __name__=='__main__':run()
