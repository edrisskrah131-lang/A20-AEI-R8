"""Generate the real-image case from executed predictions and grouped events."""
from pathlib import Path
import csv,hashlib,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Patch
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parents[1];S=ROOT/'studies/real_defects_20261020';SEC=ROOT/'paper/sections';FIG=ROOT/'paper/figures/visual'
SOURCES={}
BLUE='#25628B';TEAL='#287F72';RED='#B9484A';ORANGE='#DB8D35';INK='#263747';MUTED='#627381'
NAMES=dict(early='Early model',final='Updated model',dark='Gain 0.5',bright='Gain 1.5')

def track(path):
    path=Path(path);SOURCES[path.relative_to(ROOT).as_posix()]=hashlib.sha256(path.read_bytes()).hexdigest();return path

def read(path):return json.loads(track(path).read_text())
def write(name,text):(SEC/(name+'.tex')).write_text(text.strip()+'\n')
def save(fig,name):
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer();bad=[];hidden=set()
    for ax in fig.axes:
        if not ax.axison:hidden.update(id(t) for t in ax.get_xticklabels()+ax.get_yticklabels())
        else:
            hidden.update(id(t) for t in ax.get_xticklabels() if not min(ax.get_xlim())<=t.get_position()[0]<=max(ax.get_xlim()))
            hidden.update(id(t) for t in ax.get_yticklabels() if not min(ax.get_ylim())<=t.get_position()[1]<=max(ax.get_ylim()))
    for item in fig.findobj(matplotlib.text.Text):
        if not item.get_visible() or not item.get_text() or id(item) in hidden:continue
        bbox=item.get_window_extent(renderer)
        if bbox.x0 < -2 or bbox.y0 < -2 or bbox.x1 > fig.bbox.width+2 or bbox.y1 > fig.bbox.height+2:bad.append(item.get_text())
    assert not bad,(name,bad)
    fig.savefig(FIG/(name+'.pdf'),facecolor='white');fig.savefig(FIG/(name+'.png'),dpi=160,facecolor='white');plt.close(fig)
def pct(x):return f'{100*x:.1f}'
def tex(s):return str(s).replace('_',r'\_').replace('%',r'\%')

def figures(summary,spec,manifest,cards,performance):
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelcolor':INK,'text.color':INK,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    fig,axes=plt.subplots(1,2,figsize=(6.9,3.25),gridspec_kw={'width_ratios':[1.45,1]})
    fig.subplots_adjust(left=.15,right=.98,bottom=.24,top=.82,wspace=.45)
    values=np.array([[next(c['upper'] for c in cards if c['producer']==p and c['request']==r) for r in ['triage','review','coverage','strict']] for p in NAMES])
    ax=axes[0];im=ax.imshow(values,cmap='YlOrRd',vmin=0,vmax=1,aspect='auto')
    for i in range(4):
        for j in range(4):ax.text(j,i,f'{values[i,j]:.3f}',ha='center',va='center',color='white' if values[i,j]>.68 else INK,fontsize=8)
    ax.set_yticks(range(4),list(NAMES.values()));ax.set_xticks(range(4),['Triage','Review','Coverage','Strict'],rotation=32,ha='right')
    ax.tick_params(length=0);ax.set_title('a   Source-group risk upper bounds',loc='left',fontsize=9,pad=15)
    ax.set_xticks(np.arange(-.5,4,1),minor=True);ax.set_yticks(np.arange(-.5,4,1),minor=True);ax.grid(which='minor',color='white',lw=1.2);ax.tick_params(which='minor',length=0)
    ax=axes[1];x=np.arange(4);width=.35
    ax.bar(x-width/2,[p['ap50']*100 for p in performance],width,color=BLUE,label='AP50')
    ax.bar(x+width/2,[p['recall']*100 for p in performance],width,color=TEAL,label='Recall at fixed threshold')
    ax.set_xticks(x,['Early','Updated','Gain 0.5','Gain 1.5'],rotation=32,ha='right');ax.set_ylabel('Held-out image metric (%)');ax.set_ylim(0,max(12,max(max(p['ap50'],p['recall'])*100 for p in performance)*1.22));ax.legend(loc='upper left',fontsize=6.6,frameon=False)
    ax.set_title('b   Held-out detector quality',loc='left',fontsize=9,pad=15)
    fig.text(.02,.04,f"33 calibration groups · 34 test groups · 16 fixed events · allowance {summary['primary_allowance']:.2f}",fontsize=7.3,color=MUTED)
    save(fig,'43_real_image_evidence')
    test=sorted([r for r in manifest['records'] if r['split']=='test'],key=lambda r:r['uid']);chosen=[];seen=set()
    for category in range(5):
        candidates=[r for r in test if any(int(t[0])==category for t in r['targets']) and r['uid'] not in seen]
        row=candidates[0] if candidates else next(r for r in test if any(int(t[0])==category for t in r['targets']))
        chosen.append(row);seen.add(row['uid'])
    arrays=np.load(track(S/'outputs/final.npz'));scores=read(S/'outputs/image_scores.json');lookup={r['uid']:r for r in scores if r['producer']=='final'}
    fig,axes=plt.subplots(3,2,figsize=(6.9,9.7));fig.subplots_adjust(left=.02,right=.98,bottom=.06,top=.965,wspace=.06,hspace=.23)
    selection=[]
    for index,(row,ax,category) in enumerate(zip(chosen,axes.flat,spec['classes'])):
        ax.imshow(Image.open(track(S/row['image'])));ax.set_xlim(0,640);ax.set_ylim(640,0);ax.axis('off')
        for c,x,y,w,h in row['targets']:ax.add_patch(Rectangle(((x-w/2)*640,(y-h/2)*640),w*640,h*640,fill=False,ec='#56E6C6',lw=.8))
        predictions=arrays[row['uid']];predictions=predictions[predictions[:,4]>=spec['detector']['confidence']]
        for x1,y1,x2,y2,confidence,c in predictions:
            ax.add_patch(Rectangle((x1,y1),x2-x1,y2-y1,fill=False,ec='#FFC257',lw=1.05,ls='--'))
            ax.text(min(x1,440),max(12,y1-4),f'{spec["classes"][int(c)]} {confidence:.2f}',fontsize=5.4,color='#FFD481',bbox=dict(facecolor='black',alpha=.65,pad=.5,ec='none'))
        r=lookup[row['uid']];ax.set_title(f'{chr(97+index)}   {category} source example',loc='left',fontsize=8.8)
        ax.text(0,-.055,f"{row['uid']} · TP {r['tp']} / FP {r['fp']} / FN {r['fn']}",transform=ax.transAxes,fontsize=6.7,color=MUTED)
        selection.append(dict(category=category,uid=row['uid'],group=row['group'],selection='First unused test UID containing this category; no prediction criterion'))
    ax=axes.flat[5];ax.axis('off');ax.legend(handles=[Patch(facecolor='none',edgecolor='#26AA8C',label='Released annotation'),Patch(facecolor='none',edgecolor=ORANGE,linestyle='--',label='Model prediction')],loc='upper left',frameon=False,fontsize=8)
    ax.text(.04,.63,'Actual held-out inputs\nand archived model detections',fontsize=10,color=INK,transform=ax.transAxes,linespacing=1.6)
    ax.text(.04,.36,f"Confidence {spec['detector']['confidence']:.2f} · matching IoU 0.50\n640 × 640 released images\n480 × 480 inference input\nMisses and false positives retained",fontsize=8,color=MUTED,transform=ax.transAxes,linespacing=1.8)
    fig.text(.02,.015,'Class examples selected by source identifier before inspecting prediction quality; colors identify box provenance.',fontsize=7,color=MUTED)
    save(fig,'44_real_defect_predictions')
    (FIG/'real_image_gallery.json').write_text(json.dumps(selection,indent=2)+'\n')

def text(summary,spec,manifest,cards,performance):
    s=summary;theta=spec['detector']['confidence'];selection=read(S/'development_selection.json');freeze=read(S/'model_freeze.json');initial=read(S/'initial_fit/model_freeze.json')
    design=r'''\subsection{Real-image defect detection and report updates}
The second case uses Innovation Hangar v2, version 1, distributed with the public aircraft-defect study of Suvittawat et al. \cite{suvittawat2025aircraft}. Its categories are crack, dent, missing fastener head, paint loss and scratch. The released 10,722 images contain augmentation copies and repeated captures. We first retain one representative for each source-photo family, group dated captures by complete day, and merge additional near-duplicates by image correlation or geometric feature agreement. The resulting 1,339 representative images belong to 222 inferred source groups. Whole groups are assigned to training, development, calibration and test; the corresponding image counts are 458, 34, 368 and 479, and group counts are 122, 33, 33 and 34. Aircraft identities are unavailable, so these are inferred source groups rather than identified airframes. Table~\ref{tab:real-data} records the retained evidence units.

A COCO-pretrained YOLO11n detector \cite{ultralytics2026yolo11} is trained on the training partition. The early producer uses epoch 4. Further training and the final checkpoint are selected using development data alone, where crack and dent are the annotated categories; the final prediction threshold is THETA. Inference resizes the 640-pixel released inputs to 480 pixels. The other two producers apply digital gain 0.5 or 1.5 to the same test pixels before running the updated model. These are controlled digital processing changes. The existing typed compiler registers group recall and false positives per image as two additional quantities; the common containment and authorization API checks both cases, including the archived CAD cards. Detection receives pixels only; labels enter subsequent scoring. We report bounding-box AP50 and AP50--95 with the COCO evaluation implementation \cite{lin2014coco}, together with counts at the fixed operational threshold.

Four nested requests set $(r_R,f_R)$ to $(0.25,2)$, $(0.50,1)$, $(0.75,0.50)$ and $(0.90,0.25)$, named Triage, Review, Coverage and Strict. Each source group contributes one Bernoulli outcome to Eq.~\eqref{eq:defect-event}; repeated images are pooled within that group. The fixed family has four producers and four events, $K=16$, with $\beta=0.05$ and primary group-failure allowance $\delta=0.25$. The confidence calculation assumes independent source-group draws from the stated population. Its application to the inferred groups is assessed through the recorded grouping audit. We also report allowances 0.10 and 0.40, and 100 subsets of 24 calibration groups as a descriptive sensitivity analysis. A threshold query $(0.60,0.75)$ outside the fixed family uses a covering allocated event or is refused.

Each of 34 test groups then follows 12 report operations: early-model output, model update, request tightening, stale delivery, repair, darkened producer, request relaxation, brightened producer, numerical rollback, late old-version output, repair and repair replay. Payload digests include the actual image and detection hashes. The same authoritative registry and independently folded history used in the CAD case check every operation. Training and inference execute on a four-core Linux CPU allocation; their measured costs are reported separately from the CAD campaign timings and from evidence-card work. The Supplementary Material supplies per-class results, the complete split manifest, training selection and all report transitions.

\begin{table}[!htbp]\centering\small
\caption{Retained real-image partitions. Source groups, rather than augmented images or boxes, define the calibration unit.}\label{tab:real-data}
\begin{tabular}{@{}lrrr@{}}\toprule
Partition & Source groups & Representative images & Defect instances\\\midrule
ROWS
\bottomrule\end{tabular}\end{table}
'''.replace('THETA',f'{theta:.2f}')
    rows=[]
    for split,label in [('train','Training'),('development','Development'),('calibration','Calibration'),('test','Test')]:
        selected=[r for r in manifest['records'] if r['split']==split];rows.append(f"{label} & {len(set(r['group'] for r in selected))} & {len(selected):,} & {sum(len(r['targets']) for r in selected):,} \\\\")
    design=design.replace('ROWS','\n'.join(rows))
    campaign=(SEC/'realcase_campaign_design.tex').read_text()
    write('completion_design',campaign+'\n'+design)
    failure_range=[min(c['failures'] for c in cards),max(c['failures'] for c in cards)]
    result=r'''\subsection{Real-image quality, admission and report integrity}
The updated detector reaches AP50 APVAL and AP50--95 APALL on 479 test images. At confidence THETA it recovers TRUE_COUNT of TRUTH_COUNT annotated defects, with FALSE_COUNT false positives. Table~\ref{tab:real-quality} separates all four numerical producers. Figure~\ref{fig:real-predictions} shows fixed-identifier examples containing each defect category, with both annotations and actual predictions. These image-level scores describe the detector; source-group event failures determine service admission.

Across the 16 fixed producer/request contexts, calibration observes KRANGE failures among 33 groups. The resulting simultaneous upper bounds admit SUPPORTED contexts at allowance 0.25 (Fig.~\ref{fig:real-evidence}). Exact renewal and containment with fallback agree for every context; both retain every failed group. The threshold query outside the reserved family is handled by containment when possible and refused otherwise. SOURCE_FINDING The three less represented categories each appear in only one calibration and one test source group. Their frame counts do not provide a class-specific population guarantee: even zero failures in one independent group has unadjusted 95\% upper bound 0.95.

The report campaign executes WORKFLOW operations on the 34 test groups. All REPAIRS authenticated repairs commit a new registry revision, while replayed transactions and all stale-output attempts remain rejected. No quality-qualified report is issued. The repairs restore binding integrity while the current statistical admission remains unavailable. These report transitions are protocol checks; the CAD campaign supplies the positive service-recovery cases.

\begin{table}[!htbp]\centering\small
\caption{Actual detector results on the shared real-image test partition. Recall and false positives use the development-selected fixed confidence; AP uses the archived candidate detections.}\label{tab:real-quality}
\begin{tabular}{@{}lrrrrr@{}}\toprule
Producer & AP50 (\%) & AP50--95 (\%) & TP & FP & Recall (\%)\\\midrule
ROWS
\bottomrule\end{tabular}\end{table}

\begin{figure}[!htbp]\centering\includegraphics[width=\linewidth]{visual/43_real_image_evidence.pdf}
\caption{Real-image evidence at two units of analysis. (a) Each bound uses 33 complete calibration source groups with allocation $0.05/16$. (b) AP and recall summarize detections on the shared 479-image test partition. The image summaries and source-group risk bounds describe different quantities.}\label{fig:real-evidence}\end{figure}

\begin{figure}[!htbp]\centering\includegraphics[width=\linewidth]{visual/44_real_defect_predictions.pdf}
\caption{Actual held-out defect images and updated-model outputs. Solid green boxes are released annotations; dashed orange boxes are model predictions with category and confidence. Each panel uses the first unused test identifier containing its named category. TP, FP and FN count matched predictions, unmatched predictions and missed annotations for the complete panel.}\label{fig:real-predictions}\end{figure}
'''
    final=next(p for p in performance if p['producer']=='final')
    finding=('Every observed group-failure frequency already exceeds the allowance before confidence adjustment. The measured detection quality therefore drives refusal. With no qualified stronger anchor available, both exact renewal and containment evaluate the same 528 calibration-group records.' if s['supported_contexts']==0 else f"The admitted set contains {s['supported_contexts']} of 16 contexts; every other context remains unavailable at this allowance. Admission is established before the test reports are inspected.")
    replacements=dict(APVAL=pct(final['ap50'])+r'\%',APALL=pct(final['ap50_95'])+r'\%',THETA=f'{theta:.2f}',TRUE_COUNT=str(final['tp']),TRUTH_COUNT=str(final['gt']),FALSE_COUNT=str(final['fp']),KRANGE=failure_range[0].__str__()+'--'+str(failure_range[1]),SUPPORTED=str(s['supported_contexts']),SOURCE_FINDING=finding,WORKFLOW=str(s['workflow_rows']),REPAIRS=str(s['valid_repairs']),ISSUED=str(s['issued']),RESTORED=str(s['restored_eligible_checkpoints']))
    rows=[f"{NAMES[p['producer']]} & {pct(p['ap50'])} & {pct(p['ap50_95'])} & {p['tp']} & {p['fp']} & {pct(p['recall'])} \\\\" for p in performance]
    result=result.replace('ROWS','\n'.join(rows))
    # Replace complete words only; TP/FP appear in LaTeX labels and narrative.
    import re
    result=re.sub(r'\b('+ '|'.join(sorted(replacements,key=len,reverse=True))+r')\b',lambda m:replacements[m[0]],result)
    write('realcase_results',result);write('completion_results',r'\input{sections/completion_campaign_results}'+'\n'+r'\input{sections/realcase_results}')
    abstract=r'''Inspection evidence can become inapplicable when a camera, detector, engineering requirement or output version changes. We present an executable interface that maintains quality statements through these updates. Typed requests compile to calibrated events; containment reuses compatible stronger events, exact fallback preserves direct-renewal support, and authenticated repair binds evidence to the current output. A CAD-association campaign uses 256 calibration scenes and 64 independent test scenes, each undergoing 16 operations including combined updates, stale delivery, repair and rollback. All complete methods support 54 of 64 fixed contexts. Containment reduces full-catalogue record evaluations from 13,824 to 8,960 (35.19\%) and restores all 128 eligible repair checkpoints without an invalid binding. A second case executes four detector producers on public aircraft-defect imagery. Source-family and repeated-capture grouping reduces 10,722 released images to 1,339 representatives in 222 inferred source groups, with 33 calibration and 34 test groups. REAL_ABSTRACT The two cases separate detector or mapping quality, statistical applicability and report integrity within one reproducible evidence workflow.'''
    realabstract=(f"The real-image bounds admit {s['supported_contexts']} of 16 producer/request contexts at group-failure allowance 0.25; the report workflow executes {s['workflow_rows']} operations with no invalid binding." if s['supported_contexts'] else f"None of the 16 real-image requests passes the source-group calibration at allowance 0.25, so all quality statements are withheld while {s['valid_repairs']} authenticated report repairs preserve output integrity.")
    write('completion_abstract',abstract.replace('REAL_ABSTRACT',realabstract))
    conclusion=r'''This study connects engineering requirements, calibrated quality events and current inspection outputs through an executable evidence interface. Event containment reduces renewal work, exact fallback preserves the support of the fixed catalogue, and authenticated repair restores the output binding without reversing registry history.

The CAD campaign retains all 54 supported contexts while reducing full-catalogue evidence evaluations by 35.19\% and sequential-demand evaluations by 25\%. Each complete implementation restores its 128 eligible repair checkpoints with no invalid binding. The real-image case applies the same interface to actual defect detections, treating inferred source groups as the evidence unit and keeping detector performance separate from admission and report integrity. REAL_CONCLUSION The resulting workflow makes retention, renewal, refusal and recovery explicit decisions with traceable numerical inputs.'''
    realconclusion=(f"It admits {s['supported_contexts']} of the 16 fixed contexts and checks {s['workflow_rows']} report operations." if s['supported_contexts'] else 'The measured quality fails all 16 requests, while authenticated repairs restore report integrity. The two outcomes remain separate throughout the workflow.')
    write('completion_conclusion',conclusion.replace('REAL_CONCLUSION',realconclusion))
    supp=r'''\section{Real-image source audit and detection experiment}\label{supp:real-images}
This section records the real-image case in the main article. The source is Innovation Hangar v2, released version 1, mirrored in the aircraft-defect study's public author repository. The project and mirrored export identify CC BY 4.0. The complete source manifest records original paths, image and annotation hashes, representative selection, inferred source groups and partition membership. The redistributed representative images retain the released pixels and license credit. No generated photograph or model-generated defect image is used in this case.

\subsection{Source families, grouping and annotation conversion}
The released 10,722 images comprise 9,651 training, 642 validation and 429 test files under the author's original split. Stripping Roboflow augmentation suffixes produces 4,161 filename families, but numeric filename variants also encode earlier rotations and flips. We group numeric variants by their base identifier and prefer variant zero, then the smallest available variant; for equivalent released copies we prefer validation or test before training. Timestamped captures share their complete calendar-day group. Flip/quarter-rotation invariant perceptual hashes propose additional matches at distance at most 10; normalized correlation at least 0.985 or at least 20 ORB/RANSAC inliers with fraction at least 0.65 accepts a merge. Five additional merges reduce 227 preliminary groups to 222. The retained 1,339 images have no exact decoded-pixel overlap between partitions. These checks establish the recorded source partition, not a complete recovery of unavailable aircraft identities.

A seeded whole-group split assigns 122/33/33/34 groups to training/development/calibration/test. Before fitting any detector, one whole-group swap ensures every available category occurs in training. No prediction was used in that choice. All original image identifiers and the swap remain in the manifest. Polygon annotations are converted to their axis-aligned enclosing boxes; released bounding boxes are retained. Image coordinates, class identifiers and original annotations remain recoverable from the manifest.

\subsection{Training, producer identity and measured environment}
The initial fit runs 16 epochs at 320 pixels, batch 8, AdamW learning rate 0.001, with COCO-pretrained YOLO11n. Epoch 4 supplies the early checkpoint. The initial final checkpoint is retained separately. Development then permits up to 48 additional epochs at 480 pixels, no mosaic, batch 8, AdamW learning rate 0.001 and patience 16. The final model maximizes the trainer's development AP50--95 over the categories present in that partition: crack and dent. The other three categories have only three retained capture-day groups each, assigned to training, calibration and test; they have no fourth group available for a separate development partition. Its operational confidence maximizes development F1 among 0.05, 0.10, 0.25 and 0.50, breaking ties toward the higher threshold. Neither calibration nor test detections enter training, checkpoint selection or threshold choice. The exact optimization arguments, epoch histories, selected model hashes and measured process/elapsed times are archived.

TRAINING_FACTS

Inference uses Ultralytics INFERENCE_VERSION, PyTorch TORCH_VERSION and OpenCV CV_VERSION on a four-core Linux CPU allocation. The extended fit and all inference explicitly use four Torch threads; the initial fit requested four threads but the library set eight, as retained in the thread audit. The four producers are early weights, final weights, final weights after gain 0.5, and final weights after gain 1.5. Gain multiplies decoded BGR pixels, rounds and clips to 0--255 without JPEG recompression. These are digital producer perturbations, not newly acquired illumination measurements. Each signature hashes model weights, gain, resolution, operational confidence, raw-candidate confidence 0.001, NMS IoU 0.7 maximum 100 detections, batch size 8, float32 CPU inference and the implementation library versions. Each stored output contains prediction arrays, input-pixel hashes and its producer identity. The new adapter registers two quantities in the existing typed compiler and calls the reference event-containment and card-authorization functions. A protocol cross-check applies this API to all 64 archived CAD cards and all 64 pairs of CAD event relations; it agrees with the original independent rule planner and does not add numerical observations. Metric implementation and source-manifest identities are checked before reuse; negative type checks reject changed population, producer, service or incompatible units and prevent a pooled card from covering a per-class event.

\subsection{All calibrated events and held-out outcomes}
One complete inferred source group supplies one binomial trial. Pooled recall is matched defects divided by annotated defects; false positives are unmatched predictions divided by images in that group. Matching sorts predictions by confidence and assigns the best unused annotation of the same class at IoU at least 0.5. Categories without any annotation in a group contribute no denominator to pooled recall. Duplicate or wrong-class predictions remain false positives. The 16 events share allocation $0.05/16$. The table includes every failure and every refused event; test data do not revise these cards.

\begin{longtable}{@{}llrrrr@{}}\caption{Every fixed real-image event. Calibration uses 33 groups and test uses 34 groups.}\\\toprule Producer & Request & Cal. failures & Upper & Test failures & Admitted\\\midrule\endfirsthead
\toprule Producer & Request & Cal. failures & Upper & Test failures & Admitted\\\midrule\endhead
CARD_ROWS
\bottomrule\end{longtable}

An unreserved query requires recall at least 0.60 and false positives per image at most 0.75. A compatible stronger allocated card can cover it; otherwise it is refused without a fresh unallocated inversion. The descriptive calibration sensitivity uses 100 subsets of 24 out of the same 33 groups. These overlapping subsets are not 100 independent experiments. Likewise, the supplementary image-as-unit calculation pools a different weighting of observations and treats repeated frames as if independent; it is a diagnostic of that alternative analysis, not a matched confidence guarantee for the group event.

SENSITIVITY_FACTS

\subsection{Class support and the meaning of the event}
Crack and dent occupy many independent filename groups. Missing head, paint loss and scratch are concentrated in one capture-day group per calibration/test partition. Their per-frame counts can support descriptive detection metrics; they do not establish class-specific population risks. With one independent positive group, even zero failures has unadjusted one-sided 95\% upper bound 0.95. The fixed family reserves pooled-group events, not project-specific per-category inspection quotas. A per-category service is a different metric and cannot inherit a pooled-recall card.

\begin{longtable}{@{}llrrrr@{}}\caption{Updated-model class results on test images. Group counts measure source support separately from box counts.}\\\toprule Category & Positive groups & GT & TP & FP & Recall (\%)\\\midrule\endfirsthead
\toprule Category & Positive groups & GT & TP & FP & Recall (\%)\\\midrule\endhead
CLASS_ROWS
\bottomrule\end{longtable}

\subsection{Report transitions and preserved artifacts}
Each test source group follows the fixed 12-operation sequence. The stored report payload identifies the exact observation images and prediction arrays, with no scoring labels included. The independent event-history implementation agrees with the registry snapshot on every issuance decision. WORKFLOW_FACTS A valid repair changes the binding revision; statistical admission is checked independently. Replayed transactions cannot leave quarantine or roll back a current version.

The delivered archive contains every representative image, converted label, source mapping, early and final detector weights, initial-fit checkpoint, epoch history, model-selection record, raw detection array, score, event card and transition row. The default reproduction reruns inference from pixels with the archived weights, rechecks grouped counts and binomial inversion, then rebuilds figures and documents. It preserves original measured timings. All earlier CAD, rendering and recovery studies remain byte-identical and are retained below as supplementary evidence.
'''
    tf=f"The initial fit takes {initial.get('training_wall_s',initial.get('wall_s',0)):.1f} s elapsed. The extended fit takes {freeze['training_wall_s']:.1f} s elapsed and {freeze['training_process_cpu_s']:.1f} process CPU seconds. Development selects confidence {theta:.2f}; the selected final checkpoint and full development ranking are archived."
    epoch_rows=list(csv.DictReader(track(S/'extended_training_results.csv').open()))
    inference_wall=0.;inference_cpu=0.
    for producer in NAMES:
        metadata=read(S/'outputs'/(producer+'_metadata.json'))
        inference_wall+=sum(row['wall_s'] for row in metadata['timings'])
        inference_cpu+=sum(row['process_cpu_s'] for row in metadata['timings'])
    tf+=f" The extension executes {len(epoch_rows)} epochs; development selects additional epoch {selection['selected_additional_epoch']}. Across all 3,524 outputs, measured prediction batch calls take {inference_wall:.1f} s elapsed and {inference_cpu:.1f} process CPU seconds. These calls include model preprocessing, inference and postprocessing; model construction, image-file decoding, the explicit digital gain operation, annotation scoring, COCO evaluation and registry operations are outside this prediction timer."
    comparison=list(csv.DictReader(track(S/'outputs/calibration_comparison.csv').open()))
    cardrows=[]
    for row in comparison:cardrows.append(f"{NAMES[row['producer']]} & {row['request'].title()} & {row['group_failures']} & {float(row['group_upper']):.4f} & {row['test_group_failures']} & {'Yes' if row['group_authorized']=='True' else 'No'} \\\\")
    classrows=[]
    for row in read(S/'outputs/class_diagnostics.json'):
        if row['producer']=='final' and row['split']=='test':classrows.append(f"{tex(row['category'])} & {row['positive_source_groups']} & {row['gt']} & {row['tp']} & {row['fp']} & {pct(row['recall']) if row['recall'] is not None else '--'} \\\\")
    sens='At allowances 0.10, 0.25 and 0.40, the admitted-context counts are '+', '.join(str(row['supported']) for row in s['sensitivity'])+'. Exact and containment-plus-fallback support agree in every subset and allowance. At the primary allowance, exact renewal evaluates '+str(s['record_evaluations_exact'])+' calibration-group records and containment evaluates '+str(s['record_evaluations_reuse'])+'.'
    wf=f"The {s['workflow_rows']} operations include {s['valid_repairs']} accepted repairs, {s['issued']} issued reports and {s['restored_eligible_checkpoints']} repair checkpoints satisfying the current quality admission. Invalid bindings issued: {s['invalid_bindings_issued']}."
    for k,v in dict(TRAINING_FACTS=tf,INFERENCE_VERSION=freeze['environment']['ultralytics'],TORCH_VERSION=freeze['environment']['torch'],CV_VERSION=freeze['environment']['opencv'],CARD_ROWS='\n'.join(cardrows),CLASS_ROWS='\n'.join(classrows),SENSITIVITY_FACTS=sens,WORKFLOW_FACTS=wf).items():supp=supp.replace(k,v)
    write('realcase_supplement',supp)
    claims=json.loads((FIG/'completion_claims.json').read_text())
    for row in claims['claims']:
        if row['key'].startswith('challenge.'):row['locations']=['supplement']
    (FIG/'completion_claims.json').write_text(json.dumps(claims,indent=2)+'\n')

def main():
    track(__file__)
    summary=read(S/'outputs/summary.json');spec=read(S/'resolved_protocol.json');manifest=read(S/'manifest.json');cards=read(S/'outputs/cards.json')
    metrics=read(S/'outputs/coco_metrics.json');performance=[]
    for row in summary['test_performance']:
        ap=next(r for r in metrics if r['producer']==row['producer'] and r['split']=='test');performance.append(dict(row,ap50=ap['ap50'],ap50_95=ap['ap50_95']))
    figures(summary,spec,manifest,cards,performance);text(summary,spec,manifest,cards,performance)
    (FIG/'real_image_figure_provenance.json').write_text(json.dumps(dict(sources=SOURCES),indent=2)+'\n')
    print(json.dumps(dict(status='GENERATED',real_image_outputs=summary['image_producer_outputs'],supported_contexts=summary['supported_contexts'],main_figures_added=2)))
if __name__=='__main__':main()
