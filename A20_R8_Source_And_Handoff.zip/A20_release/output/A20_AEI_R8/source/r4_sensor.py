"""Offline rolling sensor sampling and separately charged causal frontend."""
import numpy as np,time
from scipy.spatial.transform import Rotation
from rcp.sensor import directions
from rcp.core import exp
def raw_scan(mesh,pose,velocity,seed,stamp,map_t,map_R,noise):
 rng=np.random.default_rng(seed);dirs,rel,ring=directions(1024);R=exp(pose[3:])
 rs=np.einsum('ij,njk->nik',R,Rotation.from_rotvec(rel[:,None]*velocity[3:]).as_matrix())
 ts=pose[:3]+rel[:,None]*(R@velocity[:3])[None,:]
 origins=ts+np.einsum('nij,j->ni',rs,[.15,0,.75]);wd=np.einsum('nij,nj->ni',rs,dirs)
 ranges,faces=mesh.cast((origins-map_t)@map_R,wd@map_R)
 ids=np.flatnonzero(np.isfinite(ranges)&(ranges>.3)&(faces>=0))
 incidence=np.abs(np.einsum('ij,ij->i',mesh.n[faces[ids]],(wd@map_R)[ids]))
 glass=np.asarray(['glass' in str(x).lower() for x in mesh.names[faces[ids]]]);sd=.015+.02*(1-incidence)+.03*glass
 keep=rng.random(len(ids))>(.025+.08*(1-incidence)+.15*glass);ids=ids[keep];sd=sd[keep]
 measured=ranges[ids]+rng.normal(0,sd)
 az=np.arctan2(dirs[ids,1],dirs[ids,0]);sector=(np.abs(np.angle(np.exp(1j*(az-.7*np.sin(stamp*.025)))))<.06)&(stamp%45<8)
 measured[sector]=np.minimum(measured[sector],3.+.2*np.sin(stamp*.2))
 raw=dirs[ids]*measured[:,None]+[.15,0,.75]
 if noise>1:raw+=rng.normal(0,.025*np.sqrt(noise**2-1),raw.shape)
 return raw,rel[ids],ring[ids]
def frontend(raw,rel,measured_past):
 start=time.process_time_ns();velocity=np.mean(measured_past,axis=0)/.1
 dr=Rotation.from_rotvec(rel[:,None]*velocity[3:]).as_matrix()
 cloud=np.einsum('nij,nj->ni',dr,raw)+rel[:,None]*velocity[:3]
 _,take=np.unique(np.floor(cloud/.4).astype(np.int32),axis=0,return_index=True);take=np.sort(take)
 if len(take)>1500:take=take[np.linspace(0,len(take)-1,1500,dtype=int)]
 cloud=cloud[take].astype(float)
 return cloud,(time.process_time_ns()-start)*1e-9
