"""Resumable fixed research execution. No tuning or exclusion decisions."""
import argparse,json,subprocess,sys,time
from pathlib import Path
from datetime import datetime,timezone
from r8_protocol import ROOT,D,PROTOCOL

def run(stop_after=None):
    jobs=[]
    for phase in ['nominal_calibration','geometry_calibration']:
        jobs.extend([(phase+'_collect',['r8_collect.py','--block',phase]),(phase+'_evaluate',['r8_evaluate.py','--phase',phase])])
    jobs.append(('F1_selection',['r8_evaluate.py','--calibrate']))
    if stop_after!='calibration':
        for phase in [p for p in PROTOCOL['blocks'] if not p.endswith('calibration')]:
            jobs.extend([(phase+'_collect',['r8_collect.py','--block',phase]),(phase+'_evaluate',['r8_evaluate.py','--phase',phase])])
        jobs.extend([('route_inputs',['r8_routes.py','--collect']),('route_executions',['r8_routes.py'])])
    logs=D/'logs';logs.mkdir(exist_ok=True);ledger=D/'execution_ledger.jsonl'
    for name,args in jobs:
        command=[sys.executable,str(ROOT/'source'/args[0]),*args[1:]];start=datetime.now(timezone.utc).isoformat();t=time.perf_counter()
        print('R8_STAGE_START',name,start,flush=True)
        with (logs/(name+'.log')).open('a') as log:rc=subprocess.call(command,stdout=log,stderr=subprocess.STDOUT,cwd=ROOT)
        end=datetime.now(timezone.utc).isoformat();record={'stage':name,'started_utc':start,'ended_utc':end,'wall_s':time.perf_counter()-t,'exit_code':rc,'command':args}
        with ledger.open('a') as f:f.write(json.dumps(record)+'\n')
        print('R8_STAGE_END',name,'rc',rc,'wall',round(record['wall_s'],1),flush=True)
        if rc:raise RuntimeError('stage failed: '+name+'; inspect its retained log')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--stop-after',choices=['calibration']);a=ap.parse_args();run(a.stop_after)
