"""Build readable Chinese revision/review PDFs from their preserved Markdown."""
from pathlib import Path
import re,subprocess
ROOT=Path(__file__).resolve().parents[1]
Q=ROOT/'qa/r8/report_build';Q.mkdir(exist_ok=True)
HEADER=r'''\usepackage{seqsplit}
\microtypesetup{protrusion=false,expansion=false}
\usepackage{xurl}
\setlength{\emergencystretch}{3em}
\XeTeXlinebreaklocale "zh"
\XeTeXlinebreakskip = 0pt plus 1pt
'''
(Q/'header.tex').write_text(HEADER)

def main():
    for name,output in [('REVISION_REPORT_CN','A20_AEI_R8_Revision_Report_CN'),('INDEPENDENT_REVIEW_CN','A20_AEI_R8_Independent_Review_CN')]:
        text=(ROOT/(name+'.md')).read_text()
        # Add TeX break opportunities for full hashes; preserve original MD.
        text=re.sub(r'`([a-f0-9]{64})`',lambda m:r'\seqsplit{'+m[1]+'}',text)
        text=re.sub(r'(?<![a-f0-9{])([a-f0-9]{64})(?![a-f0-9}])',lambda m:r'\seqsplit{'+m[1]+'}',text)
        text=re.sub(r'`([A-Za-z0-9_./*+-]{25,})`',lambda m:r'\path{'+m[1]+'}',text)
        md=Q/(name+'.md');md.write_text(text)
        tex=Q/(output+'.tex')
        subprocess.run(['pandoc',str(md),'--standalone','--from','markdown+raw_tex+tex_math_single_backslash','--to','latex',
            '--include-in-header',str(Q/'header.tex'),'-V','mainfont=Noto Serif CJK SC','-V','mainfontoptions=AutoFakeBold=2,AutoFakeSlant=0.2',
            '-V','monofont=DejaVu Sans Mono','-V','fontsize=10pt','-V','geometry:a4paper,margin=18mm',
            '-V','colorlinks=true','-V','linkcolor=blue','-V','urlcolor=blue','-o',str(tex)],check=True)
        for _ in range(2):
            subprocess.run(['xelatex','-interaction=nonstopmode','-halt-on-error',tex.name],cwd=Q,check=True,stdout=subprocess.DEVNULL)
        (ROOT/'release'/ (output+'.pdf')).write_bytes((Q/(output+'.pdf')).read_bytes())
        print(output,flush=True)
if __name__=='__main__':main()
