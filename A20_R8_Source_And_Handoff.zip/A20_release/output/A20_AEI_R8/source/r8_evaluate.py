"""Prospective paired trace experiment and two-stage selection freeze."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import argparse,json,time,gzip
from datetime import datetime,timezone
from pathlib import Path
import numpy as np,pandas as pd
from scipy.stats import beta
from r8_protocol import ROOT,BASE,D,PROTOCOL,sha,digest
from r8_policy import policies
from r8_service import load_models,prediction_cache,controlled
from r8_geometry import geometry
from r8_contracts import Registry,seal_card,dispatch,procedural_dispatch,events_for

def runtime_bindings():
    modelhash={m:sha(BASE/f'{m}_forecast.npz') for m in ['cart','rf']};modelhash['old']=sha(ROOT/'data/checkpoint_model.npz')
    runtime={'solver':sha(ROOT/'source/checkpoint.py'),'policy_implementation':sha(ROOT/'source/r8_policy.py'),
        'execution':sha(ROOT/'source/r8_service.py'),'contracts':sha(ROOT/'source/r8_contracts.py'),
        'clock':sha(D/'clock_profile.json'),'protocol':sha(D/'protocol.json')}
    for m,h in modelhash.items():runtime['forecast:'+m]=h
    for profile in ['nominal','unfitted']:
        runtime['profile:'+profile]=digest({'sampling':PROTOCOL['sampling_profiles'][profile],
            'generator':sha(ROOT/'source/r8_collect.py'),'geometry_generator':sha(ROOT/'source/r8_geometry.py')})
        ms=['B767','C172'] if profile=='nominal' else ['UnfittedAirframe']
        runtime['artifacts:'+profile]=digest({m:sha(geometry(m)) for m in ms})
    for p in policies():runtime['spec:'+p['id']]=digest(p)
    for s in PROTOCOL['services']:runtime['service:'+s['id']]=digest(s)
    for e in PROTOCOL['events']:
        runtime['event:'+e]=digest({'id':e,'trajectory_times':PROTOCOL['trajectory_times_s'],
            'observation':PROTOCOL['observation_failure'],'union':PROTOCOL['union_failure'],
            'threshold':PROTOCOL['threshold_m'],'services':PROTOCOL['services'],'order':PROTOCOL['same_tick_order']})
    return runtime

def relevant_bindings(runtime,profile,service,policy,event=None):
    keys=['solver','policy_implementation','execution','contracts','clock','protocol',
        'spec:'+policy['id'],'service:'+service['id']]
    if policy['model']:keys.append('forecast:'+policy['model'])
    if profile in ['nominal','unfitted']:keys+=['profile:'+profile,'artifacts:'+profile]
    if event:keys.append('event:'+event)
    return {k:runtime[k] for k in keys}

def assert_freeze():
    f=json.loads((D/'freeze.json').read_text());assert f['protocol_sha256']==sha(D/'protocol.json')
    for path,h in f['components'].items():assert sha(ROOT/path)==h,('changed method',path)
    assert f['clock_sha256']==sha(D/'clock_profile.json')
    return f

def evaluate(phase,pilot=False):
    if not pilot:assert_freeze()
    log=D/('pilot/episodes.jsonl' if pilot else 'episodes.jsonl')
    rows=[json.loads(x) for x in log.read_text().splitlines() if json.loads(x)['phase']==phase]
    expected=48 if pilot else PROTOCOL['blocks'][phase]['n'];assert len(rows)==expected
    rows.sort(key=lambda r:r['seed']);models=load_models();ps=policies();clock=json.loads((D/'clock_profile.json').read_text());runtime=runtime_bindings()
    folder=D/('pilot/results' if pilot else 'results/'+phase);folder.mkdir(parents=True,exist_ok=True)
    inputfolder=D/('pilot' if pilot else 'episode_inputs');start=time.perf_counter();total=0
    for chunk in range((len(rows)+63)//64):
        output=folder/f'chunk_{chunk:03d}.csv.gz';manifest=folder/f'chunk_{chunk:03d}.json'
        if output.exists() and manifest.exists():
            assert sha(output)==json.loads(manifest.read_text())['sha256'];continue
        records=[];seeds=[]
        for r in rows[chunk*64:(chunk+1)*64]:
            z=np.load(inputfolder/f"{r['seed']}.npz");cache=prediction_cache(r,models)
            tasks=[(s,p) for s in PROTOCOL['services'] for p in ps]
            np.random.default_rng(r['seed']+31).shuffle(tasks)
            for s,p in tasks:
                b=relevant_bindings(runtime,r['profile'],s,p)
                result=controlled(r,z,p,cache,clock,s,b)
                assert result['sender_work_s']<=s['budget_s']+1e-12,(r['seed'],p['id'],'budget exceeded',result['sender_work_s'])
                records.append(result)
            seeds.append(r['seed']);z.close()
        tmp=output.with_suffix('.tmp');pd.DataFrame(records).to_csv(tmp,index=False,compression='gzip');tmp.replace(output)
        manifest.write_text(json.dumps({'phase':phase,'seeds':seeds,'rows':len(records),'sha256':sha(output),
            'protocol_sha256':sha(D/'protocol.json'),'clock_sha256':sha(D/'clock_profile.json')},indent=2))
        total+=len(records);print('R8_EVALUATE',phase,chunk+1,len(rows),round(time.perf_counter()-start,1),flush=True)
    print('R8_EVALUATE_DONE',phase,total,round(time.perf_counter()-start,1),flush=True)

def read_results(phases=None,columns=None):
    phases=list(PROTOCOL['blocks']) if phases is None else phases
    paths=[p for phase in phases for p in sorted((D/'results'/phase).glob('chunk_*.csv.gz'))]
    return pd.concat([pd.read_csv(p,usecols=columns) for p in paths],ignore_index=True)

def calibrate():
    assert_freeze();phases=['nominal_calibration','geometry_calibration']
    if (D/'selection_freeze.json').exists():
        f=json.loads((D/'selection_freeze.json').read_text())
        for p,h in f['files'].items():assert sha(D/p)==h,('F1 changed',p)
        for p,h in f['calibration_result_files'].items():assert sha(D/p)==h,('calibration changed',p)
        print('R8_F1_ALREADY_FROZEN_VALIDATED',flush=True);return
    if (D/'episodes.jsonl').exists():
        observed=[json.loads(x)['phase'] for x in (D/'episodes.jsonl').read_text().splitlines()]
        if any(p not in phases for p in observed):raise RuntimeError('F1 cannot follow confirmation/stress access')
    for p in (D/'episode_inputs').glob('*.npz'):
        seed=int(p.stem)
        if not any(PROTOCOL['blocks'][phase]['base']<=seed<PROTOCOL['blocks'][phase]['base']+4096 for phase in phases):raise RuntimeError('non-calibration input precedes F1')
    cols=['seed','phase','profile','service','policy','loss_m2s','work_s','native_charged_cpu_s','trajectory_failure','observation_failure','union_failure']
    frame=read_results(phases,cols);K=PROTOCOL['family_size'];ps={p['id']:p for p in policies()};services={s['id']:s for s in PROTOCOL['services']}
    assert K==len(ps)*len(services)*2*3
    cal=[];cards=[];runtime=runtime_bindings();table={}
    for (profile,service,pid),g in frame.groupby(['profile','service','policy']):
        assert len(g)==4096 and g.seed.nunique()==4096
        score=float(g.loss_m2s.mean()+PROTOCOL['lambda_sel_m2']*g.work_s.mean());table[(profile,service,pid)]=score
        for event in PROTOCOL['events']:
            k=int(g[event+'_failure'].sum());n=len(g);u=1. if k==n else float(beta.ppf(1-.05/K,k+1,n-k))
            r={'profile':profile,'service':service,'policy':pid,'event':event,'n':n,'k':k,'upper':u,'margin':.15-u,
                'loss_m2s':float(g.loss_m2s.mean()),'work_s':float(g.work_s.mean()),'native_cpu_s':float(g.native_charged_cpu_s.mean()),'score_m2s':score}
            cal.append(r);cards.append(seal_card(dict(id='/'.join([profile,service,pid,event]),
                profile=profile,service=service,policy=pid,event=event,n=n,k=k,upper=u,K=K,family_error=.05,
                bindings=relevant_bindings(runtime,profile,services[service],ps[pid],event),
                statement='unconditional population event risk for the frozen complete effective policy/service',
                calibration_input_seeds=[int(g.seed.min()),int(g.seed.max())])))
    cf=pd.DataFrame(cal).sort_values(['profile','service','policy','event']);assert len(cf)==528
    cf.to_csv(D/'calibration.csv',index=False)
    (D/'event_cards.json').write_text(json.dumps(cards,indent=2,allow_nan=False))
    registry=Registry(cards,runtime);plans=[]
    for profile in ['nominal','unfitted']:
        for service in services:
            for task in PROTOCOL['request_types']:
                for allowance in PROTOCOL['risk_allowances']:
                    req={'profile':profile,'service':service,'task':task,'events':events_for(task),
                        'allowance':allowance,'declared_population':True,'elapsed_s':0.}
                    full=dispatch(registry,table,req,list(ps));flat=procedural_dispatch(registry.cards,table,req,list(ps),runtime)
                    assert full['policy']==flat['policy'] and full['status']==flat['status']
                    assert full.get('eligible',[])==flat.get('eligible',[])
                    # Calibrated trajectory-only diagnostic is separately named.
                    trajectory_req=dict(req,task='trajectory',events=['trajectory'])
                    trajectory=dispatch(registry,table,trajectory_req,list(ps))
                    plans.append({'request':req,'Full':full,'TaskAwareFlat':flat,'TaskAwareFlatValidated':flat,
                        'TrajectoryOnly':trajectory,'numeric_refusal_action':'RETAIN_SOURCE_PRIOR',
                        'route_provisional_action':'nearest-profile recommendation is descriptive only; no episode card transfer'})
    assert len(plans)==96
    (D/'selection_plans.json').write_text(json.dumps(plans,indent=2,allow_nan=False))
    (D/'runtime_bindings.json').write_text(json.dumps(runtime,indent=2))
    log=[json.loads(x) for x in (D/'episodes.jsonl').read_text().splitlines()]
    calibration_inputs=[{'seed':r['seed'],'phase':r['phase'],'input_sha256':r['input_sha256'],
        'record_sha256':digest(r)} for r in log if r['phase'] in phases]
    assert len(calibration_inputs)==8192
    (D/'calibration_inputs_manifest.json').write_text(json.dumps(calibration_inputs,indent=2))
    files=['calibration.csv','event_cards.json','selection_plans.json','runtime_bindings.json',
        'calibration_inputs_manifest.json','protocol.json','freeze.json','clock_profile.json']
    resultshashes={str(p.relative_to(D)):sha(p) for phase in phases for p in sorted((D/'results'/phase).glob('*'))}
    f={'version':'R8-F1-calibration-and-plans','utc':datetime.now(timezone.utc).isoformat(),
        'files':{p:sha(D/p) for p in files},'calibration_result_files':resultshashes,
        'calibration_inputs':8192,'K':528,'request_configurations':96,
        'rule':'created before any confirmation generation/access; no refit/reselection after confirmation'}
    (D/'selection_freeze.json').write_text(json.dumps(f,indent=2));print('R8_SELECTION_FREEZE',sum(p['Full']['status']=='SELECTED' for p in plans),96,flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--phase');ap.add_argument('--pilot',action='store_true');ap.add_argument('--calibrate',action='store_true');a=ap.parse_args()
    calibrate() if a.calibrate else evaluate('pilot' if a.pilot else a.phase,a.pilot)
