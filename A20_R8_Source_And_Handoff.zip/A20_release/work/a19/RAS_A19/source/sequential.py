"""Finite empirical posterior, shared query/execution budget, exact offline DP.

Losses are arbitrary (not balanced/Gaussian). Queries reveal binary score bins.
The caller supplies query reservations: these are not measured feature runtimes.
"""
from functools import lru_cache
import numpy as np


class Planner:
    def __init__(self, losses, observations, reservations, budget, query_costs,
                 price=0., reserve_full=False, prune=True, myopic=False):
        self.losses = np.asarray(losses, float)
        self.observations = np.asarray(observations, int)
        self.costs = np.asarray(reservations, int)
        self.budget = int(budget)
        self.query_costs = np.asarray(query_costs, int)
        self.price = float(price)
        self.reserve_full = reserve_full
        self.prune = prune
        self.myopic = myopic
        self.q = self.observations.shape[1]
        self.stats = dict(states=0, queries=0, pruned=0)
        assert self.losses.shape[0] == self.observations.shape[0]
        assert np.all(self.query_costs > 0)
        assert np.all(self.costs <= budget)
        self.solve = lru_cache(None)(self._solve)
        self.root = (-1,) * self.q

    def subset(self, state):
        mask = np.ones(len(self.losses), bool)
        for q, z in enumerate(state):
            if z >= 0:
                mask &= self.observations[:, q] == z
        return np.flatnonzero(mask)

    def spent(self, state):
        return int(sum(self.query_costs[q] for q, z in enumerate(state) if z >= 0))

    def menu(self, spent):
        return np.flatnonzero(self.costs + spent <= self.budget)

    def stop(self, state, ids=None, spent=None):
        ids = self.subset(state) if ids is None else ids
        spent = self.spent(state) if spent is None else spent
        menu = self.menu(spent)
        means = self.losses[ids][:, menu].mean(axis=0)
        j = int(np.argmin(means))
        return float(means[j]), int(menu[j])

    def _solve(self, state):
        self.stats['states'] += 1
        ids = self.subset(state)
        assert len(ids)
        spent = self.spent(state)
        best, action = self.stop(state, ids, spent)
        decision = ('stop', action)
        for q, z in enumerate(state):
            if z >= 0:
                continue
            after = spent + int(self.query_costs[q])
            menu = self.menu(after)
            if not len(menu) or (self.reserve_full and after + max(self.costs) > self.budget):
                continue
            self.stats['queries'] += 1
            charge = self.price * self.query_costs[q]
            # Perfect information over survivors lower-bounds all continuations.
            optimistic = charge + self.losses[ids][:, menu].min(axis=1).mean()
            if self.prune and optimistic >= best - 1e-14:
                self.stats['pruned'] += 1
                continue
            risk = charge
            for outcome in np.unique(self.observations[ids, q]):
                child = list(state); child[q] = int(outcome); child = tuple(child)
                weight = np.mean(self.observations[ids, q] == outcome)
                future = self.stop(child)[0] if self.myopic else self.solve(child)[0]
                risk += weight * future
            if risk < best - 1e-14:
                best, decision = float(risk), ('query', q)
        return best, decision

    def execute(self, observe):
        """Only requested held-out feature values enter observe(q); no labels."""
        state = self.root
        path = []
        while True:
            _, decision = self.solve(state)
            kind, j = decision
            if kind == 'stop':
                return j, self.spent(state), path, False
            outcome = int(observe(j))
            child = list(state); child[j] = outcome; child = tuple(child)
            path.append(j)
            if not len(self.subset(child)):
                # Unseen feature conjunction: pay query, stop with parent belief.
                action = self.stop(state, spent=self.spent(child))[1]
                return action, self.spent(child), path, True
            state = child

    def fixed_subset(self):
        """Best nonadaptive subset, with outcome-dependent terminal action."""
        best, _ = self.stop(self.root)
        chosen = ()
        for bits in range(1, 1 << self.q):
            queries = tuple(q for q in range(self.q) if bits & (1 << q))
            spent = int(self.query_costs[list(queries)].sum())
            menu = self.menu(spent)
            if not len(menu):
                continue
            risk = self.price * spent
            groups = {}
            for i in range(len(self.losses)):
                key = tuple(self.observations[i, list(queries)])
                groups.setdefault(key, []).append(i)
            for ids in groups.values():
                risk += len(ids) / len(self.losses) * self.losses[ids][:, menu].mean(axis=0).min()
            if risk < best - 1e-14:
                best, chosen = float(risk), queries
        return best, chosen

    def execute_fixed(self, queries, observe):
        state = [-1] * self.q
        for q in queries:
            state[q] = int(observe(q))
        state = tuple(state)
        ids = self.subset(state)
        missing = not len(ids)
        if missing:
            # Fully nonadaptive fallback: initial belief after paying all queries.
            ids = np.arange(len(self.losses))
        return self.stop(state, ids)[1], self.spent(state), list(queries), missing
