"""Verify the complete fixed raw rendering inventory and geometric interface."""
from pathlib import Path
import hashlib,json
import numpy as np
from PIL import Image
ROOT=Path(__file__).parent
(ROOT/'verification.json').unlink(missing_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protocol=json.loads((ROOT/'protocol.json').read_text());freeze=json.loads((ROOT/'freeze.json').read_text())
for name,value in freeze['sha256'].items():assert sha(ROOT/name)==value,name
maximum_projection=0.;maximum_surface=0.;count=0;ids=[]
for phase in ('development','test'):
 manifest=json.loads((ROOT/(phase+'_manifest.json')).read_text())
 if phase=='test':assert manifest['analysis_freeze_sha256']==sha(ROOT.parent/'analysis'/'freeze.json')
 for name,value in manifest['files'].items():assert sha(ROOT/name)==value,name
 sources=protocol[phase+'_sources'];assert manifest['sources']==len(sources);assert manifest['images']==4*len(sources)
 expected={s['seed'] for s in sources};observed={int(f.stem) for f in (ROOT/phase).glob('*.json')};assert expected==observed
 for source in sources:
  m=json.loads((ROOT/phase/(str(source['seed'])+'.json')).read_text());ids.append(m['seed']);assert m['seed']==source['seed'];assert m['family']==source['family'];assert m['split']==phase;assert set(m['variants'])==set(protocol['conditions'])
  assert m['width']==768 and m['height']==576 and m['samples_max']==32 and m['adaptive_threshold']==.02 and not m['denoising']
  q=np.asarray(m['actual']);cad=np.asarray(m['cad']);assert q.shape==cad.shape and q.shape[1]==3;assert np.isfinite(q).all() and np.isfinite(cad).all();assert len(m['missing'])==len(q)
  mesh=np.load(ROOT/phase/m['surface_mesh_file']);v=mesh['vertices'];f=mesh['faces'];assert f.shape[1]==3 and f.min()>=0 and f.max()<len(v);assert np.isfinite(v).all()
  # Independent vertical triangle interpolation checks the highest external skin.
  tri=v[f];a=tri[:,0];b=tri[:,1]-a;c=tri[:,2]-a;det=b[:,0]*c[:,1]-b[:,1]*c[:,0];good=np.abs(det)>1e-15
  for point in np.vstack([q,cad]):
   dx=point[0]-a[:,0];dy=point[1]-a[:,1]
   u=np.divide(dx*c[:,1]-dy*c[:,0],det,out=np.full(len(det),np.nan),where=good);w=np.divide(b[:,0]*dy-b[:,1]*dx,det,out=np.full(len(det),np.nan),where=good)
   inside=good&(u>=-1e-9)&(w>=-1e-9)&(u+w<=1+1e-9);assert inside.any()
   height=float(np.max((a[:,2]+u*b[:,2]+w*c[:,2])[inside]));difference=abs(point[2]-height);maximum_surface=max(maximum_surface,difference);assert difference<1e-7
  for name,x in m['variants'].items():
   with Image.open(ROOT/phase/x['filename']) as im:assert im.size==(768,576) and im.mode=='RGB'
   camera=np.asarray(x['camera']);rotation=np.asarray(x['rotation']);assert np.allclose(rotation.T@rotation,np.eye(3),atol=1e-12);assert np.isclose(np.linalg.det(rotation),1.)
   local=(q-camera)@rotation;projected=x['focal']*local[:,:2]/local[:,2,None];difference=float(np.max(np.abs(projected-x['blender_projected_pixels'])));maximum_projection=max(maximum_projection,difference);assert difference<1e-3
   assert len(x['visible'])==len(q);assert not any(vis and missing for vis,missing in zip(x['visible'],m['missing']));assert x['elapsed_s']>0 and x['cpu_s']>0;count+=1
assert len(ids)==len(set(ids))==72 and count==288
report={'status':'PASS','sources':72,'development_sources':8,'test_sources':64,'raw_images':288,'source_protocol_and_inventory_hashes_match':True,'source_disjointness':True,'max_camera_projection_difference_px':maximum_projection,'max_highest_skin_height_difference_m':maximum_surface,'test_analysis_freeze_binding_matches':True}
(ROOT/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
