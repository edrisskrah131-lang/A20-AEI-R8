"""Check published evidence counts, frozen identities, and table/ledger consistency."""
from pathlib import Path
import hashlib,json,pickle
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads((R/p).read_text())
dev=[json.loads(x) for x in (R/'data/prospective_cases.jsonl').read_text().splitlines()]
confirm=[json.loads(x) for x in (R/'data/confirmation_cases.jsonl').read_text().splitlines()]
assert len(dev)==1200 and len(confirm)==480
assert len({r['seed'] for r in dev+confirm})==1680
assert {k:sum(r['split']==k for r in dev) for k in ['train','validation','test']}=={'train':480,'validation':240,'test':480}
for r in dev+confirm:
    assert len(r['losses'])==len(r['cpu'])==len(r['accepted'])==5
    assert np.isfinite(r['losses']).all() and np.isfinite(r['cpu']).all()
    assert min(r['losses'])>=0 and min(r['cpu'])>=0
p=read('protocol_confirmation.json')
for key,path in [('method_sha256','source/reuse.py'),('model_sha256','data/reuse_models.pkl'),('generator_sha256','source/prospective.py')]:
    assert p[key]==hashlib.sha256((R/path).read_bytes()).hexdigest(),key
d=pd.read_csv(R/'data/confirmation_replay.csv');s=pd.read_csv(R/'data/confirmation_summary.csv')
assert len(d)==30240 and len(d.seed.unique())==480
assert (d.groupby(['mesh','level','noise','ratio','price','method']).size()==40).all()
assert np.allclose(d.loss,d.pose_loss+d.price*d.cpu_ms/1000,rtol=1e-10,atol=1e-12)
assert (d.loss+1e-12>=d.oracle_loss).all()
means=d.groupby(['mesh','ratio','price','method'])[['loss','pose_loss','cpu_ms']].mean()
assert np.allclose(s.set_index(['mesh','ratio','price','method'])[means.columns].sort_index(),means.sort_index())
ms=pd.read_csv(R/'data/mission_results.csv');assert len(ms)==48
assert len(ms[['mesh','replicate']].drop_duplicates())==6
assert set(ms.calls)=={989} and set(ms.duration_s)=={1980.}
models=pickle.load(open(R/'data/reuse_models.pkl','rb'));njobs=0
for folder in sorted((R/'data/missions').iterdir()):
    manifest=json.loads((folder/'manifest.json').read_text())
    assert hashlib.sha256((folder/'inputs.npz').read_bytes()).hexdigest()==manifest['sha256']
    for path in folder.glob('*_r*.json'):
        obj=json.loads(path.read_text());r=obj['result'];jobs=obj['jobs'];njobs+=len(jobs)
        assert sum(j['overrun'] for j in jobs)==r['overruns']
        assert sum(j['cache_hit'] for j in jobs)==r['cache_hits']
        trace=np.load(path.with_suffix('.npz'))['trace'];assert trace.shape==(19800,6)
        assert np.isclose(np.sqrt(np.mean(trace[:,4]**2)),r['rmse_m'])
        assert np.isclose(r['cpu_s'],r['propagation_cpu_s']+r['correction_cpu_s']+r['replay_cpu_s'])
        assert np.isclose(sum(j['cpu_s'] for j in jobs),r['correction_cpu_s'])
        for j in jobs:
            m=models[(r['mesh'],j['context'],r['ratio'],.3,r['method'])]
            cache={q+1 for q in j['path']}
            cost=sum(m['costs'][i] for i in cache)+(0 if j['action'] in cache else m['costs'][j['action']])
            assert cost<=m['budget'] and j['cache_hit']==(j['action'] in cache)
out=dict(development_sources=1200,confirmation_sources=480,unique_sources=1680,paired_action_outcomes=8400,
    confirmation_replays=len(d),unique_mission_inputs=6,complete_controller_runs=48,correction_decisions=njobs,
    simulated_controller_hours=float(ms.duration_s.sum()/3600),actual_reservation_overruns=int(ms.overruns.sum()),
    frozen_method_and_models='hashes match',mission_input_hashes='all match',metric_and_cost_ledgers='pass',status='PASS')
(R/'qa/evidence_audit.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
