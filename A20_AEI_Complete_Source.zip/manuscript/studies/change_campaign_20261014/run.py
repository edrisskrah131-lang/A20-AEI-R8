"""Execute a controlled camera-change campaign on archived CAD capture templates.

The 320 configurations are new simulated perturbations, not 320 physical scans.
All image quantities are recomputed by the unchanged geometric/raster/scoring
producer. Conditional fault fixtures change an implemented function without
changing its declared provider list. Original population risk cards are read-only.
"""
from pathlib import Path
import sys,json,hashlib,platform,copy
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
PACKAGE=ROOT.parents[1]
sys.path.insert(0,str(PACKAGE/'studies/methodology_review_20261014'))
import run as original
SPEC=json.loads((ROOT/'protocol.json').read_text())
OUT=ROOT/'outputs';OUT.mkdir(exist_ok=True)
VERIFY='--verify' in sys.argv
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def emit(frame,name):
    if not isinstance(frame,pd.DataFrame):frame=pd.DataFrame(frame)
    if VERIFY:
        pd.testing.assert_frame_equal(frame.reset_index(drop=True),pd.read_csv(OUT/name).reset_index(drop=True),
                                      check_dtype=False,check_exact=False,rtol=1e-12,atol=1e-10)
    else:frame.to_csv(OUT/name,index=False)

def produce(case,configuration,edit):
    meta,z,cam,mesh,prior_mesh,state,targets,actual=case
    width,height=SPEC['roi'];focal=configuration['focal_px'];exposure=configuration['exposure_s']
    pose=configuration['pose'];gimbal=cam['gimbal_R'];speed=meta['speed_m_s']
    fields={'baseline':(), 'roi':('roi',),'focal':('focal_px',),'exposure':('exposure_s',),
            'decoder':('detector',),'roi_focal_fault':('roi',),
            'decoder_ready_fault':('detector',),'exposure_focal_fault':('exposure_s',),
            'roi_clock_fault':('roi',)}[edit]
    if edit in ('roi','roi_focal_fault','roi_clock_fault'):width,height=SPEC['expanded_roi']
    if edit=='focal':focal*=1.20
    if edit in ('exposure','exposure_focal_fault'):exposure*=1.50
    active=False
    if edit=='roi_focal_fault' and configuration['focal_px']>=1800:
        focal*=1.15;active=True
    if edit=='exposure_focal_fault' and exposure>.010:
        focal*=1.03;active=True
    geometry=original.target_geometry(mesh,targets,pose,z['map_t'],z['map_R'],original.exp,
                                      focal,speed,exposure,gimbal)
    frame=original.render(mesh,pose,z['map_t'],z['map_R'],np.random.default_rng(configuration['noise_seed']),
                          original.exp,width,height,focal,exposure,speed,gimbal,geometry)
    rgb=np.clip(np.rint(frame['rgb'].astype(float)*configuration['brightness']),0,255).astype(np.uint8)
    detected,_=original.detect_fiducials(rgb,len(targets['faces']))
    if edit in ('decoder','decoder_ready_fault'):detected[:]=np.nan
    image=original.score_image(frame,geometry,width,height,detected)
    association=original.score_association(state,targets,geometry,original.exp,width,height,focal,gimbal,detected)
    ready=float(actual['active_index']>0)
    if edit=='decoder_ready_fault' and configuration['exposure_s']>=.006:
        ready*=float(np.isfinite(detected).any());active=True
    clock=.0625 if meta['study']=='A' else .125
    if edit=='roi_clock_fault':clock*=width*height/(SPEC['roi'][0]*SPEC['roi'][1]);active=True
    capture=meta['capture_tick']*.1
    report=max(actual['first_delivery_s'],capture+.05+10*clock)
    values={**{k:image[k] for k in ('gsd_m','blur_px','coverage')},**association,
            'localization_ready':ready,'report_delay_s':report,'image_age_s':report-capture}
    return values,fields,active,rgb

def main():
    for name,value in json.loads((ROOT/'freeze.json').read_text())['files'].items():
        assert sha(PACKAGE/name)==value,name
    rows=[];samples=[];case_rows=[];meshes={}
    for template_index,desc in enumerate(original.SPEC['sources']):
        case=original.source_case(desc,meshes)
        meta,z,cam,mesh,prior_mesh,state,targets,actual=case
        assert meta['study']==desc['study']
        for draw in range(SPEC['draws_per_template']):
            seed=SPEC['seed']+template_index*1000+draw;rng=np.random.default_rng(seed)
            pose=z['future_truth'][meta['capture_tick']].copy()
            pose[:3]+=rng.normal(0,SPEC['translation_std_m'],3)
            pose[3:]+=rng.normal(0,SPEC['rotation_std_rad'],3)
            configuration={'pose':pose,'focal_px':rng.uniform(*SPEC['focal_px']),
                           'exposure_s':rng.uniform(*SPEC['exposure_s']),
                           'brightness':rng.uniform(*SPEC['brightness']),
                           'noise_seed':seed+60000000}
            samples.append({'scenario':seed,'template':desc['seed'],'study':desc['study'],
                            'profile':desc['profile'],'mesh':meta['source']['mesh'],
                            **{k:configuration[k] for k in ('focal_px','exposure_s','brightness')},
                            **{f'pose_{i}':float(v) for i,v in enumerate(pose)}})
            base,_,_,rgb=produce(case,configuration,'baseline')
            for edit in SPEC['interventions']:
                after,fields,active,edited_rgb=produce(case,configuration,edit)
                gate=original.audit_transfer(base,after,fields)
                if not edit.endswith('fault'):assert gate['status']=='CONSISTENT_ON_TESTED_INPUT'
                case_rows.append({'scenario':seed,'template':desc['seed'],'edit':edit,
                                  'conditional_fault_active':active,'gate_veto':gate['status']=='VETO',
                                  'undeclared_changes':len(gate['undeclared_quantities'])})
                for metric in original.METRICS:
                    changed=original.numeric_changed(base[metric],after[metric])
                    declared=bool(set(fields)&set(original.evidence.tr.DEPENDENCIES[metric]))
                    rows.append({'scenario':seed,'template':desc['seed'],'edit':edit,'metric':metric,
                                 'baseline':base[metric],'edited':after[metric],'changed':changed,
                                 'declared_affected':declared,'undeclared_change':changed and not declared})
            if draw==0 and template_index==4:
                if VERIFY:assert np.array_equal(np.load(OUT/'example_raster.npz')['rgb'],rgb)
                else:np.savez_compressed(OUT/'example_raster.npz',rgb=rgb)
        print('CAMERA_CHANGE_CAMPAIGN',desc['seed'],SPEC['draws_per_template'],flush=True)
    for mesh in meshes.values():mesh.close()
    emit(samples,'configurations.csv');emit(rows,'quantity_pairs.csv');emit(case_rows,'change_cases.csv')
    cases=pd.DataFrame(case_rows);summary=[]
    for edit,g in cases.groupby('edit',sort=False):
        summary.append({'edit':edit,'configurations':len(g),'active_faults':int(g.conditional_fault_active.sum()),
                        'vetoed_updates':int(g.gate_veto.sum()),'undeclared_quantity_changes':int(g.undeclared_changes.sum())})
    emit(summary,'change_summary.csv')
    result={'status':'PASS','geometric_templates':len(original.SPEC['sources']),
            'camera_configurations':len(samples),'paired_pipeline_updates':len(case_rows),
            'quantity_comparisons':len(rows),'summary':summary,
            'primary_population_cards_changed':0,'scope':'Controlled simulated camera perturbations around five CAD capture templates'}
    if VERIFY:assert result==json.loads((OUT/'results.json').read_text())
    else:(OUT/'results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
