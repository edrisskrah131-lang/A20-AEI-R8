"""Build each complete calibrated catalogue, including refusal decisions."""
from pathlib import Path
import sys,json,time
import numpy as np,pandas as pd
from scipy.stats import beta
from model import VARIANTS,DEPENDENCIES
from run import event,contains,invariant,REQUESTS,ANCHORS,SPEC

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'outputs'
frame=pd.read_csv(OUT/'observations.csv').query('phase=="calibration"')
GROUP={v:g.sort_values('seed') for v,g in frame.groupby('variant')}
VERIFY='--verify' in sys.argv

def build(method):
    cache={};answers=[];visits=0
    def get(v,request):
        nonlocal visits
        if method!='Whole-producer renewal' and invariant(REQUESTS[request],v):v='baseline'
        key=(v,request)
        if key not in cache:
            g=GROUP[v];k=int(event(g,REQUESTS[request]).sum());n=len(g);visits+=n
            upper=1. if k==n else float(beta.isf(SPEC['confidence_error']/SPEC['family_K'],k+1,n-k))
            cache[key]=(k,n,upper)
        return key,cache[key]
    for v in VARIANTS:
        if method=='Contract plus fallback':
            for a in ANCHORS:get(v,a)
        for request,spec in REQUESTS.items():
            options=[]
            if method=='Contract plus fallback':
                for a in ANCHORS:
                    if not contains(REQUESTS[a],spec):continue
                    for producer in dict.fromkeys([v,'baseline']):
                        if producer=='baseline' and not invariant(spec,v):continue
                        key=(producer,a)
                        if key in cache and cache[key][2]<=SPEC['allowance']:options.append((cache[key][2],key))
            if options:upper,key=min(options)
            else:key,card=get(v,request);upper=card[2]
            answers.append({'variant':v,'request':request,'authorized':upper<=SPEC['allowance']})
    return {'method':method,'constructed_proofs':len(cache),'record_evaluations':visits,
            'supported_contexts':sum(x['authorized'] for x in answers),'contexts':len(answers)},answers

rows=[];timing=[];reference=None
for method in ['Whole-producer renewal','Dependency-aware exact','Contract plus fallback']:
    trials=[]
    for _ in range(11):
        t=time.process_time_ns();r,answers=build(method);trials.append((time.process_time_ns()-t)*1e-9)
    if reference is None:reference=answers
    else:assert answers==reference
    rows.append(r);timing.append({'method':method,'median_cpu_s':float(np.median(trials)),'trials':11})
if VERIFY:
    pd.testing.assert_frame_equal(pd.DataFrame(rows),pd.read_csv(OUT/'catalogue_cost.csv'),check_dtype=False)
else:
    pd.DataFrame(rows).to_csv(OUT/'catalogue_cost.csv',index=False)
    pd.DataFrame(timing).to_csv(OUT/'catalogue_timing.csv',index=False)
print(json.dumps({'status':'PASS','catalogue':rows},indent=2))
