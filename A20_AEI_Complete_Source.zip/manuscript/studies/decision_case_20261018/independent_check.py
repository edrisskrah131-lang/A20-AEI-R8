"""Check archived numerical claims without importing the evidence implementation."""
from __future__ import annotations

import hashlib
import json
from math import isfinite
from pathlib import Path
import sys

sys.dont_write_bytecode = True
import numpy as np
import pandas as pd
from scipy.special import betaincinv
from scipy.stats import binom

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "lifecycle_20261018"


def main():
    spec = json.loads((SOURCE / "protocol.json").read_text())
    requests = json.loads((ROOT.parent / "cad_surface_20261014/protocol.json").read_text())["requests"]
    observations = pd.read_csv(SOURCE / "outputs/observations.csv")
    saved = pd.read_csv(ROOT / "event_validation.csv")
    alpha = 0.05 / 48
    assert spec["family_K"] == 48 and spec["calibration_inputs"] == spec["test_inputs"] == 256
    derived = []
    for variant in spec["variants"]:
        for request, intervals in requests.items():
            result = {"variant": variant, "request": request}
            for phase in ("calibration", "test"):
                rows = observations[(observations.phase == phase) & (observations.variant == variant)]
                failures = 0
                for row in rows.to_dict("records"):
                    passed = all(isfinite(row[m]) and (lo is None or row[m] >= lo) and
                                 (hi is None or row[m] <= hi) for m, (lo, hi) in intervals.items())
                    failures += int(not passed)
                n = len(rows)
                assert n == 256
                upper = 1.0 if failures == n else float(betaincinv(failures + 1, n - failures, 1 - alpha))
                assert np.isclose(binom.cdf(failures, n, upper), alpha, rtol=1e-10, atol=1e-13)
                result[phase + "_failures"] = failures
                result[phase + "_upper"] = upper
            derived.append(result)
    independent = pd.DataFrame(derived).set_index(["variant", "request"])
    saved = saved.set_index(["variant", "request"])
    for column in ("calibration_failures", "test_failures", "calibration_upper", "test_upper"):
        assert np.allclose(independent[column], saved.loc[independent.index, column], atol=1e-12, rtol=1e-12)

    sensitivity = pd.read_csv(ROOT / "sensitivity.csv")
    expected_support = {0.02: 0, 0.05: 18, 0.10: 40, 0.15: 41, 0.20: 43}
    for allowance, expected in expected_support.items():
        assert int((independent.calibration_upper <= allowance).sum()) == expected
        rows = sensitivity[np.isclose(sensitivity.allowance, allowance)]
        assert len(rows) == 4 and (rows.supported == expected).all()
        assert (rows.record_evaluations == rows.constructed_cards * 256).all()
        assert rows.loc[rows.method == "Whole renewal", "constructed_cards"].iloc[0] == 48
        assert rows.loc[rows.method == "DAG exact cache", "constructed_cards"].iloc[0] == 42
        equal_semantics = rows[rows.method.isin(["Contract + fallback", "Rules + containment"])]
        assert equal_semantics.constructed_cards.nunique() == 1

    # Reconstruct event-work counts using a separate plain-Python interval/signature implementation.
    dependencies = json.loads((SOURCE / "outputs/compiled_requests.json").read_text())
    deps = {r["request"]: r["dependencies"] for r in dependencies}
    def config(variant):
        return {"focal": 1.15 if variant == "focal" else 1.0,
                "exposure": 1.5 if variant == "exposure" else 1.0,
                "roi": (896, 672) if variant == "wide_roi" else (768, 576),
                "lighting": 0.45 if variant == "lighting" else 1.0,
                "decoder": 10.0 if variant == "decoder" else 18.0,
                "geometry": "skin-v1", "motion": 1.0, "cad": "cad-v1", "prior": "prior-v1"}
    def signature(variant, request):
        return tuple((dep, config(variant)[dep]) for dep in sorted(deps[request]))
    def contains(anchor, request):
        for metric, (low, high) in requests[request].items():
            if metric not in requests[anchor]:
                return False
            anchor_low, anchor_high = requests[anchor][metric]
            if low is not None and (anchor_low is None or anchor_low < low):
                return False
            if high is not None and (anchor_high is None or anchor_high > high):
                return False
        return True
    for allowance in expected_support:
        cards = []
        def exact(variant, request):
            if not any(q == request and signature(v, q) == signature(variant, request) for v, q in cards):
                cards.append((variant, request))
        for variant in spec["variants"]:
            for request in ("optical", "acquisition", "association", "complete"):
                exact(variant, request)
            for request in requests:
                available = any(independent.loc[(v, q), "calibration_upper"] <= allowance and
                                contains(q, request) and signature(v, request) == signature(variant, request)
                                for v, q in cards)
                if not available:
                    exact(variant, request)
        recorded = sensitivity[(sensitivity.method == "Contract + fallback") &
                               np.isclose(sensitivity.allowance, allowance)].constructed_cards.iloc[0]
        assert len(cards) == recorded

    first_seed = int(observations.loc[observations.phase == "test", "seed"].min())
    case = json.loads((ROOT / "case.json").read_text())
    assert first_seed == spec["test_seed_start"] == case["selection"]["seed"] == 202619100
    scales = {"gsd_m": ("gsd_mm_per_pixel", 1000), "blur_px": ("blur_px", 1),
              "coverage": ("correct_address_coverage_percent", 100),
              "reprojection_px": ("reprojection_px", 1), "association_m": ("mapping_error_mm", 1000)}
    for variant in ("baseline", "exposure"):
        sample = observations[(observations.phase == "test") & (observations.seed == first_seed) &
                              (observations.variant == variant)].iloc[0]
        for metric, (display, scale) in scales.items():
            assert np.isclose(sample[metric] * scale, case["variants"][variant]["values_in_report_units"][display],
                              rtol=1e-13, atol=1e-13)
        for request, intervals in requests.items():
            passed = all(isfinite(sample[m]) and (lo is None or sample[m] >= lo) and
                         (hi is None or sample[m] <= hi) for m, (lo, hi) in intervals.items())
            assert passed == case["variants"][variant]["requests"][request]["instance_passes"]
            assert passed  # The fixed first seed does not exhibit an instance-level failure.
    assert independent.loc[("baseline", "complete"), "calibration_upper"] <= 0.15
    assert independent.loc[("exposure", "complete"), "calibration_upper"] > 0.15
    assert independent.loc[("exposure", "complete_relaxed"), "calibration_upper"] <= 0.15

    thresholds = pd.read_csv(ROOT / "request_thresholds.csv").set_index("request")
    threshold_columns = {"gsd_m": ("gsd_upper_mm_per_pixel", 1, 1000),
                         "blur_px": ("blur_upper_px", 1, 1),
                         "coverage": ("coverage_lower_percent", 0, 100),
                         "reprojection_px": ("reprojection_upper_px", 1, 1),
                         "association_m": ("mapping_upper_mm", 1, 1000)}
    for request, intervals in requests.items():
        for metric, (column, side, scale) in threshold_columns.items():
            bound = intervals.get(metric, (None, None))[side]
            observed = thresholds.loc[request, column]
            assert pd.isna(observed) if bound is None else np.isclose(observed, bound * scale)

    provenance = json.loads((ROOT / "provenance.json").read_text())
    for name, expected in provenance["inputs"].items():
        assert hashlib.sha256((ROOT.parent / name).read_bytes()).hexdigest() == expected
    recovery = json.loads((ROOT.parent / "validated_recovery_20261018/outputs/example_trace.json").read_text())
    trace_csv = pd.read_csv(ROOT / "attachment_case_trace.csv")
    assert recovery["seed"] == first_seed and len(trace_csv) == 39
    for request in ("complete", "complete_relaxed", "optical"):
        rows = recovery["examples"][request + "/stale_producer_output"]["trace"]
        steps = {row["step"]: row for row in rows}
        saved_trace = case["validated_recovery"]["traces"][request]
        assert len(rows) == len(saved_trace) == 13
        for row, saved_row in zip(rows, saved_trace):
            assert all(row[key] == value for key, value in saved_row.items())
            exposure_risk = independent.loc[("exposure", request), "calibration_upper"] <= 0.15
            expected_risk = independent.loc[("baseline", request), "calibration_upper"] <= 0.15 \
                if row["step"] == "baseline_registered" else exposure_risk
            assert row["risk_authorized"] == expected_risk
            assert row["expected_issue"] == bool(row["numerical_origin_valid"] and row["identity_valid"] and
                                                row["active_binding"] and expected_risk)
        assert steps["wrong_attachment"]["state"] == "quarantined"
        assert not steps["wrong_attachment"]["numerical_origin_valid"]
        assert not steps["correct_retry_without_repair"]["expected_issue"]
        assert not steps["rename_without_provenance"]["expected_issue"]
        for step in ("repair_missing", "repair_replayed", "repair_wrong_hash", "repair_wrong_producer",
                     "repair_inactive_calibration"):
            assert not steps[step]["repair_accepted"] and steps[step]["state"] == "quarantined"
        repaired = steps["repair_valid"]
        assert repaired["repair_accepted"] and repaired["state"] == "active" and repaired["revision"] == 2
        assert repaired["expected_issue"] == (request != "complete")
        assert repaired["authoritative_record"]["binding"] == steps["baseline_registered"]["authoritative_record"]["binding"]
        assert repaired["authoritative_record"]["capture"] == steps["baseline_registered"]["authoritative_record"]["capture"]
        assert repaired["certificate"]["body"] == repaired["authoritative_record"]
        old_record = steps["exposure_registered"]["authoritative_record"]
        digest = hashlib.sha256(json.dumps(old_record, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        assert repaired["authoritative_record"]["predecessor"] == digest
        duplicate = steps["repair_duplicate_after_commit"]
        assert not duplicate["repair_accepted"] and duplicate["state"] == "active"
        assert duplicate["expected_issue"] == repaired["expected_issue"]
    selected = independent[independent.calibration_upper <= 0.15]
    result = {"status": "PASS", "independently_recounted_events": 48,
              "independently_recounted_split_event_pairs": 96,
              "independently_reconstructed_contract_allowances": 5,
              "first_heldout_seed": first_seed, "all_first_seed_events_pass": True,
              "selected_test_upper_max": float(selected.test_upper.max()),
              "threshold_requests_verified": 8, "source_hashes_verified": len(provenance["inputs"]),
              "crosschecked_recovery_trace_steps": len(trace_csv)}
    (ROOT / "independent_check.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
