# Executable Evidence Management for CAD-Guided Aircraft Inspection

当前交付只有一份正文 `A20_AEI_Manuscript.pdf`（14 页、8 节、9 幅主图）和一份 `Supplement.pdf`（35 页）。正文按完整研究论文组织；数据来源、基线归因、AI 辅助说明、资助及实施范围集中于补充材料最后一节。可编辑 TeX 和参考文献位于 `paper/`，定量图提供 PDF、SVG 和 300 dpi PNG。正文图 1 将原项目照片与两张开放许可的真实蒙皮照片组合；图 3 和图 7 保留实际仿真输入，重新绘制像素放大、对应标记与曝光强度剖面。两个 PDF 均不使用生成式场景插画。

## 2026-10-18 图像修订

新增 Simon Butler 拍摄的 Vulcan 蒙皮接缝照片（CC BY 2.0）及 Rob Marshall 拍摄的飞机蒙皮铆接照片（美国国防部公有领域作品）。正文背景图使用实拍；原图、完整来源及许可元数据在 `paper/figures/open_photos/`，完整署名说明在补充最后一节。照片仅用于工程背景，定量实验输入仍为实际执行的仿真输出。本轮未更改生产者、实验协议、数值记录或风险卡；176 份实验及来源文件与上一交付逐字节一致。

仅重画和排版本轮图文：依次运行 `python reporting/visual_revision.py`、`python reporting/cad_surface_report.py`、`bash build.sh`、`python reporting/verify_visual_revision.py`。不需要网络重新下载；照片原件已打包。

## 独立新增研究

`studies/cad_surface_20261014/` 实现独立的解析金属 CAD 表面、透视成像、纹理与光照、曝光模糊和强度噪声、紧固件像素提取、CAD 对应及六自由度位姿优化。384 个完整独立场景分成 192 校准和 192 测试输入，独立抽取平面、单曲面或双曲面，六种生产者配置共执行 2,304 次。每场景的像素残差、物理映射误差和覆盖率分别保存。开发输入与正式校准/测试输入使用不同种子；阶段记录也随包保留。

像素位姿优化把基准平移误差中位数从 4.392 mm 降至 0.997 mm。解码器坐标原点改变后，拟合残差中位数仍为 0.261 px，物理映射误差却升到 8.217 mm。48 个生产者/请求事件在相同置信分配下有 44 个可支持上下文。包含精确回退的契约方法保留所有 44 个，完整证据目录实际构建 25 张卡，依赖感知精确更新构建 42 张；包括拒绝决策，记录评估由 8,064 降到 4,800，减少 40.48%。表面场景和误差均为实际执行模型的输出，其物理条件和数据来源详列于补充材料。

完整目录构建与冷启动请求工作分开统计。40 个独立初始化的更新/请求案例中，全生产者工作账本为 7,680 次全图像流程；依赖投影为 5,760 次全流程、768 次纯光学计算和 1,152 次输入保留。该账本表示逻辑计算量，不等同于实测累计运行时间。纯光学实现已与全生产者在全部 1,152 个校准/配置组合上核对一致。

## 保留的补充证据

原数值总体、风险卡、协议、预测器和回放源保持不变，并作为互补研究收入补充材料。保留五源配对重执行、96/192/384 点求解探针、320 个条件相机配置的 2,560 次配对更新、20,480 项数量比较、705 次变更及 15,360 次协议判定。旧诊断标志物图像、Windows/虚拟时钟和 Linux 探针的边界分别说明。这些研究的采样单位与置信分配不同于新的 48 事件表面研究，不能合并作为同一总体。

## 重建

仅编译两个 PDF：`bash build.sh`。

完整打包研究重执行：在 Python 3.12 安装 `requirements-artifacts.txt`，提供 pdflatex/bibtex，再运行 `bash reproduce_artifacts.sh`。可通过 `A20_PYTHON` 指定解释器。脚本逐项核对原协议、五源回放、条件相机更新、新独立表面研究、完整目录构建和纯光学实现，再生成表图、两个 PDF 和一致性检查。默认两名计算工作进程，每进程一条数值线程。原生 CPU 计时保留首次执行档案；数值输出与像素记录独立重算核对。

只重算新研究：运行 `python studies/cad_surface_20261014/run.py --verify --workers 2`、`python studies/cad_surface_20261014/catalogue.py --verify` 和 `python studies/cad_surface_20261014/partial_producer.py`。文稿检验入口为 `python reporting/verify_visual_revision.py`。生成并逐文件校验源码 ZIP：`python reporting/package_delivery.py`。

包内包含全部新研究配置、观察、卡片、工作账本、九份原始像素/坐标记录、原照片、所需 mesh、Linux BVH 库及 C++ 源码、Windows DLL、原生产者、单位编译器和 SHA-256 清单。完整早期总体数据继续由仓库原版本数据发布提供；当前重建入口不重新运行全部早期总体实验。`source/`、`protocol/` 和 `analysis/` 保留历史实现，不用旧导出脚本覆盖当前文稿。

下载分支：<https://github.com/edrisskrah131-lang/A20-AEI-R8/tree/aei-complete-20261014>。原 R8 数据发布为 `r8-handoff-2026-10-12`，R9 来源提交为 `ea1ab710cace4d96257b9d6b42884ee1b52acca3`。GitHub 交付为正文、补充、源码 ZIP 和下载索引，不上传审阅报告。
