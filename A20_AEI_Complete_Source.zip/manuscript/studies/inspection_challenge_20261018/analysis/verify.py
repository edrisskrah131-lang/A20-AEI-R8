"""Independently recount challenge scores, truth separation and surface geometry."""
import inspect
import json
from pathlib import Path
import numpy as np
import pandas as pd
from PIL import Image
from pipeline import ROOT, BASELINE, decode, estimate, prior, project, intersect_mesh
from run import scenes, locate, sha, source_hashes, check_freeze

OUT = ROOT/'outputs'/'test'
freeze = json.loads((ROOT/'freeze.json').read_text())
protocol = json.loads((ROOT/'protocol.json').read_text())
check_freeze(freeze)
frame = pd.read_csv(OUT/'metrics.csv')
processing = json.loads((OUT/'processing.json').read_text())
inventory = scenes(ROOT.parent/processing['input_root_relative_to_study'], 'test')
renderer_protocol = json.loads((ROOT.parent/'rendering'/'protocol.json').read_text())
assert {(s['seed'], s['family']) for _, s in inventory} == {
    (s['seed'], s['family']) for s in renderer_protocol['test_sources']}
assert set(inspect.signature(estimate).parameters) == {'cad', 'camera_prior', 'rotation_prior', 'focal', 'decoded'}
assert frame[['seed', 'condition', 'frontend']].duplicated().sum() == 0
assert set(frame.seed) == {s['seed'] for _, s in inventory}
assert not set(frame.seed) & set(freeze['development_seeds'])
assert frame.groupby('family').seed.nunique().to_dict() == {k: protocol['expected_test_scenes_per_family'] for k in range(4)}
assert set(frame.frontend) == {BASELINE['name'], freeze['selected']['name']}
assert set(frame.condition) == set(protocol['conditions'])
assert len(frame) == len(inventory) * len(protocol['conditions']) * 2


def plane_barycentric_intersection(camera, rays, vertices, faces):
    """Separate plane/barycentric implementation for independent mesh checks."""
    t = vertices[faces]
    p0, u, v = t[:, 0], t[:, 1] - t[:, 0], t[:, 2] - t[:, 0]
    normals = np.cross(u, v)
    numerator = np.einsum('ij,ij->i', p0 - camera, normals)
    uu = np.einsum('ij,ij->i', u, u)
    uv = np.einsum('ij,ij->i', u, v)
    vv = np.einsum('ij,ij->i', v, v)
    determinant = uu * vv - uv * uv
    valid_triangles = np.abs(determinant) > 1e-24
    result = np.full((len(rays), 3), np.nan)
    for i, ray in enumerate(rays):
        denominator = normals @ ray
        good = valid_triangles & (np.abs(denominator) > 1e-14)
        distance = np.full(len(t), np.inf)
        distance[good] = numerator[good] / denominator[good]
        points = camera + distance[:, None] * ray
        w = points - p0
        wu = np.einsum('ij,ij->i', w, u)
        wv = np.einsum('ij,ij->i', w, v)
        alpha = np.zeros(len(t)); beta = np.zeros(len(t))
        alpha[good] = (wu[good] * vv[good] - wv[good] * uv[good]) / determinant[good]
        beta[good] = (wv[good] * uu[good] - wu[good] * uv[good]) / determinant[good]
        good &= (alpha >= -1e-9) & (beta >= -1e-9) & (alpha + beta <= 1 + 1e-9) & (distance > 1e-8)
        if good.any():
            result[i] = camera + distance[good].min() * ray
    return result


largest_estimator_difference = 0.
largest_ray_difference = 0.
maximum_true_pose_surface_error = 0.
independent_ray_cases = 0
recomputed_rows = 0
first_per_family = {f: min(s['seed'] for _, s in inventory if s['family'] == f) for f in range(4)}
for path, scene in inventory:
    mesh = np.load(locate(path, scene['surface_mesh_file']))
    actual = np.asarray(scene['actual'])
    missing = np.asarray(scene['missing'], bool)
    for condition, variant in scene['variants'].items():
        image_path = locate(path, variant['filename'])
        rgb = np.asarray(Image.open(image_path).convert('RGB'))
        truth = project(actual, np.asarray(variant['camera']), np.asarray(variant['rotation']), variant['focal'])
        assert np.max(np.abs(truth - variant['blender_projected_pixels'])) < 1e-3
        # Oracle-pose check measures only mesh tessellation/target surface consistency.
        true_rays = np.c_[truth / variant['focal'], np.ones(len(truth))] @ np.asarray(variant['rotation']).T
        true_rays /= np.linalg.norm(true_rays, axis=1, keepdims=True)
        true_reconstructed = intersect_mesh(np.asarray(variant['camera']), true_rays, mesh['vertices'], mesh['faces'])
        surface_error = np.linalg.norm(true_reconstructed - actual, axis=1)
        assert np.isfinite(surface_error).all(), (scene['seed'], condition, 'true pose mesh miss')
        maximum_true_pose_surface_error = max(maximum_true_pose_surface_error, float(surface_error.max()))
        assert surface_error.max() < protocol['true_pose_mesh_tolerance_m'], (scene['seed'], condition, surface_error.max())
        for config in [BASELINE, freeze['selected']]:
            row = frame[(frame.seed == scene['seed']) & (frame.condition == condition) & (frame.frontend == config['name'])].iloc[0]
            assert row.image_sha256 == sha(image_path)
            assert row.scene_sha256 == sha(path)
            assert row.mesh_sha256 == sha(locate(path, scene['surface_mesh_file']))
            camera, rotation = prior(scene, variant)
            fitted = estimate(scene['cad'], camera, rotation, variant['focal'], decode(rgb, config))
            archived = np.load(OUT/f"{scene['seed']}_{condition}_{config['name']}.npz")
            for key, value in fitted.items():
                assert np.allclose(value, archived[key], atol=1e-11, rtol=1e-10, equal_nan=True), (scene['seed'], condition, key)
                if np.asarray(value).size:
                    difference = np.abs(value - archived[key]); difference = difference[np.isfinite(difference)]
                    if len(difference):
                        largest_estimator_difference = max(largest_estimator_difference, float(difference.max()))
            indices, centers = archived['matched_indices'], archived['matched_centers']
            if len(indices):
                distances = np.linalg.norm(centers[:, None, :] - truth[None, :, :], axis=2)
                identities = distances.argmin(axis=1)
                correct = ((identities == indices) & (distances[np.arange(len(indices)), identities] < 8) &
                           ~missing[indices] & np.asarray(variant['visible'], bool)[indices])
            else:
                correct = np.zeros(0, bool)
            assert int(correct.sum()) == row.correct_matches
            coverage = correct.sum() / len(actual)
            assert np.isclose(coverage, row.coverage, atol=1e-14)
            maximum_mapping = float(archived['mapping_errors_m'].max())
            assert np.isclose(maximum_mapping, row.association_m, atol=1e-12)
            failure = coverage < .8 or float(archived['reprojection_px']) > 8 or maximum_mapping > .008
            screen = len(indices) / len(actual) >= .8 and float(archived['reprojection_px']) <= 8
            assert bool(row.quality_failure) == failure
            assert bool(row.observable_screen_accept) == screen
            assert bool(row.accepted_but_failed) == (screen and failure)
            if scene['seed'] == first_per_family[scene['family']]:
                rays = np.c_[truth / variant['focal'], np.ones(len(truth))] @ archived['rotation'].T
                rays /= np.linalg.norm(rays, axis=1, keepdims=True)
                independent = plane_barycentric_intersection(archived['camera'], rays, mesh['vertices'], mesh['faces'])
                assert np.allclose(independent, archived['reconstructed'], atol=1e-10, rtol=1e-10, equal_nan=True)
                finite = np.isfinite(independent) & np.isfinite(archived['reconstructed'])
                largest_ray_difference = max(largest_ray_difference, float(np.abs(independent - archived['reconstructed'])[finite].max()))
                independent_ray_cases += 1
            recomputed_rows += 1
    print('verified scene', scene['seed'], flush=True)

development = pd.read_csv(ROOT/'development_metrics.csv')
assert sha(ROOT/'development_metrics.csv') == freeze['development_metrics_sha256']
cells = development.groupby(['frontend', 'family', 'condition'])[['quality_failure', 'coverage']].mean()
rank = cells.groupby('frontend').mean().reset_index()
rank = rank[rank.frontend != BASELINE['name']].sort_values(['quality_failure','coverage','frontend'], ascending=[True,False,True])
assert rank.iloc[0].frontend == freeze['selected']['name']
summary = json.loads((OUT/'summary.json').read_text())
assert summary['image_count'] == len(frame)//2
for entry in summary['conditions']:
    subset = frame[(frame.condition == entry['condition']) & (frame.frontend == entry['frontend'])]
    assert entry['quality_failures'] == int(subset.quality_failure.sum())
    assert entry['accepted_but_failed'] == int(subset.accepted_but_failed.sum())
    assert np.isclose(entry['coverage_mean'], subset.coverage.mean())
result = dict(status='PASS', independent_scene_count=len(inventory), raw_images_reprocessed=len(frame)//2,
    frontend_rows_recomputed=recomputed_rows, true_pose_mesh_max_error_m=maximum_true_pose_surface_error,
    independent_mesh_ray_cases=independent_ray_cases, maximum_independent_ray_difference_m=largest_ray_difference,
    maximum_estimator_difference=largest_estimator_difference,
    all_images_and_source_hashes_match=True, development_selection_reproduced=True,
    estimator_truth_free_signature=True, all_failed_cases_retained=True,
    independent_geometry_holdout_families=[2,3])
(ROOT/'verification.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
