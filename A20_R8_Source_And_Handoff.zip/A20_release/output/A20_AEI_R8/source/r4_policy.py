"""Frozen multi-cap forecasts and independently removable operating predicates."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import json,hashlib
import numpy as np
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from r4_protocol import ROOT,D,PROTOCOL,sha,freeze_protocol
from checkpoint import decision
CAPS=np.array([2,4,8,16,25])
def feat(r,s):return np.r_[np.asarray(s['feature'])[:10],r['noise']]
class Forecast:
 def __init__(self,path):
  z=np.load(path);self.left=z['left'];self.right=z['right'];self.feature=z['feature'];self.threshold=z['threshold'];self.value=z['value'];self.roots=z['roots']
 def predict(self,x):
  x=np.asarray(x,np.float32);pred=np.zeros(17)
  for root in self.roots:
   n=int(root)
   while self.left[n]>=0:n=int(self.left[n] if x[self.feature[n]]<=self.threshold[n] else self.right[n])
   pred+=self.value[n]
  return pred/len(self.roots)
def act(r,s,policy,model=None,p=None,load=20.,deadline=.3,paid=0.):
 kind=policy['kind'];it=s['iteration'];eligible=bool(s['eligible']);done=bool(s['done'])
 guard=False;dl=False;detail={'guard':False,'deadline':False,'cap':25}
 if done and kind not in ['multi','old']:return bool(s['accepted']),True,detail
 if kind=='final':return False,False,detail
 if kind=='fixed':halt=it>=policy['cap'];return bool(halt and eligible),halt,detail
 if kind=='residual':halt=bool(eligible and it>=2);return eligible,halt,detail
 if kind=='random':
  u=int(hashlib.sha256(str(r['seed']).encode()).hexdigest()[:8],16)/2**32
  cap=4 if u<policy['probability_4'] else 2;halt=it>=cap;detail['cap']=cap
  return bool(halt and eligible),halt,detail
 if kind=='old':
  old=np.asarray(s['feature']).copy();old[10]=int(r['mesh']=='C172')
  pub,halt,_=decision(model,old,s,1.,.3);return pub,halt,detail
 if p is None:p=model.predict(feat(r,s))
 mismatch=r['noise']>2 or float(s['feature'][0])>.061 or r['mesh']=='ProceduralAirframe'
 guard=bool(policy.get('profile',False) and mismatch);limit=4 if guard else 25
 reachable=np.flatnonzero((CAPS>=it)&(CAPS<=limit))
 if policy.get('deadline',False):
  feasible=np.asarray([a for a in reachable if .05+load*(paid+max(float(p[3*a+2]),0.))<=deadline],int)
  dl=len(feasible)<len(reachable);reachable=feasible
 empty=len(reachable)==0
 if empty:chosen=it
 else:
  values=np.array([4*max(float(p[3*a]),0.)+policy['price']*max(float(p[3*a+2]),0.)+.002*np.clip(p[3*a+1],0,1) for a in reachable])
  chosen=int(CAPS[reachable[int(np.argmin(values))]])
 halt=bool(done or (it>=2 and it>=chosen) or (guard and it>=4) or (policy.get('deadline',False) and empty))
 publish=bool(s['accepted']) if done else bool(eligible and (p[15]<p[16] or halt))
 return publish,halt,{'guard':guard,'deadline':dl,'cap':chosen,'pred_current_mse':float(p[15]),'pred_prior_mse':float(p[16])}
def data(rows):
 X=[];Y=[]
 for r in rows:
  e=np.asarray(r['error']);mse=np.mean(e[:,5:]**2,axis=1);event=np.any(e[:,5:]>.1,axis=1).astype(float)
  for i,s in enumerate(r['trace']):
   target=[]
   for cap in CAPS:
    j=next((j for j,t in enumerate(r['trace']) if t['iteration']>=cap),len(r['trace'])-1);end=r['trace'][j]
    valid=end['accepted'] if end['done'] else end['eligible'];ix=j+1 if valid else 0
    target.extend([mse[ix],event[ix],max(end['cpu_total_s']-s['cpu_total_s'],0.)])
   target.extend([mse[i+1],mse[0]]);X.append(feat(r,s));Y.append(target)
 return np.asarray(X),np.asarray(Y)
def export(model,scale,path):
 trees=model.estimators_ if hasattr(model,'estimators_') else [model];left=[];right=[];feature=[];threshold=[];value=[];roots=[];offset=0
 for m in trees:
  t=m.tree_;roots.append(offset);left.extend(np.where(t.children_left>=0,t.children_left+offset,-1));right.extend(np.where(t.children_right>=0,t.children_right+offset,-1));feature.extend(t.feature);threshold.extend(t.threshold);value.extend(t.value[:,:,0]*scale);offset+=t.node_count
 np.savez_compressed(path,left=left,right=right,feature=feature,threshold=threshold,value=value,roots=roots)
def fit():
 freeze_protocol();rows=[json.loads(x) for x in (ROOT/'data/episodes.jsonl').read_text().splitlines()];assert len(rows)==1120
 train=[r for r in rows if int(hashlib.sha256(str(r['seed']).encode()).hexdigest()[:8],16)%5!=0];val=[r for r in rows if r not in train]
 X,Y=data(train);V,Z=data(val);scale=np.maximum(Y.std(0),np.r_[np.tile([1e-4,.1,.001],5),1e-4,1e-4])
 scores={}
 for name,model in [('cart',DecisionTreeRegressor(max_depth=7,min_samples_leaf=20,random_state=202610114)),('rf',RandomForestRegressor(n_estimators=64,max_depth=8,min_samples_leaf=12,random_state=202610114,n_jobs=1))]:
  model.fit(X,Y/scale);path=D/f'{name}_forecast.npz';export(model,scale,path);compact=Forecast(path)
  pred=np.array([compact.predict(v) for v in V]);assert np.max(np.abs(pred-model.predict(V)*scale))<1e-10
  scores[name]={'sha256':sha(path),'validation_standardized_mse':float(np.mean(((pred-Z)/scale)**2)),'nodes':sum(t.tree_.node_count for t in model.estimators_) if name=='rf' else model.tree_.node_count}
 policies=[]
 for family,model,profile,deadline in [('KG','cart',True,True),('FlatCART','cart',False,False),('FlatRF','rf',False,False),('ContractRF','rf',True,True)]:
  for price in [.3,1.,3.]:
   suffix='' if price==1 and family!='KG' else f'{price:g}'
   policies.append({'id':family+suffix,'kind':'multi','model':model,'price':price,'profile':profile,'deadline':deadline})
 kg=next(p for p in policies if p['id']=='KG1');cart=Forecast(D/'cart_forecast.npz');deeper=[]
 for r in train:
  for s in r['trace']:
   pub,halt,_=act(r,s,kg,cart,paid=s['cpu_total_s'],load=1.)
   if halt or s['done']:deeper.append(s['iteration']>2);break
 probability=float(np.mean(deeper))
 policies.extend([{'id':f'Fixed{cap}','kind':'fixed','model':None,'cap':cap} for cap in [2,4,8,16]])
 policies.extend([{'id':'Final','kind':'final','model':None},{'id':'Residual','kind':'residual','model':None},{'id':'Random2or4','kind':'random','model':None,'probability_4':probability},{'id':'OldRAVC','kind':'old','model':'old'}]);assert len(policies)==20
 ablations=[]
 for p in policies:
  if p['id'].startswith('KG'):
   for mode in ['profile','deadline']:
    q=dict(p,id=p['id']+'_no_'+mode);q[mode]=False;ablations.append(q)
 frozen={'version':'R4-recovery-frozen-family-3','development_train_seeds':[r['seed'] for r in train],'development_validation_seeds':[r['seed'] for r in val], 'n_train':len(train),'n_validation':len(val),'forecasts':scores,'target_scale':scale.tolist(),'policies':policies,'ablations':ablations,'policy_sha256':sha(__file__),'protocol_sha256':sha(D/'protocol.json'),'old_model_sha256':sha(ROOT/'data/checkpoint_model.npz'),'solver_sha256':sha(ROOT/'source/checkpoint.py'),'random_probability_4':probability,'fit_data_sha256':sha(ROOT/'data/episodes.jsonl')}
 (D/'freeze.json').write_text(json.dumps(frozen,indent=2));print(json.dumps(frozen),flush=True)
if __name__=='__main__':fit()
