"""Paired seed-level effects, tails, influence, matching-price mechanism analyses."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import json,time
import numpy as np,pandas as pd
from scipy.stats import binomtest
from r4_protocol import ROOT,D,sha
def tail(x):return float(np.sort(x)[-max(1,int(np.ceil(.05*len(x)))):].mean())
def paired(a,b,rng,B=10000):
 n=len(a);ratios=[];diff=[];td=[]
 for _ in range(B//250):
  ix=rng.integers(0,n,(250,n));aa=a[ix];bb=b[ix]
  ratios.extend(1-aa.mean(1)/bb.mean(1));diff.extend((aa-bb).mean(1))
 return {'improvement':float(1-a.mean()/b.mean()),'improvement_ci':np.quantile(ratios,[.025,.975]).tolist(),'difference':float((a-b).mean()),'difference_ci':np.quantile(diff,[.025,.975]).tolist()}
def main():
 f=pd.read_csv(D/'policy_results.csv');q=f[(f.load==20)&f.phase.str.endswith('confirmation')];rng=np.random.default_rng(202610116);effects=[];influence=[];paths=[]
 for phase in sorted(q.phase.unique()):
  sub=q[q.phase==phase];a=sub[sub.policy=='KG1'].set_index('seed').sort_index()
  for name in ['Fixed2','Fixed4','Final','FlatCART','FlatRF','ContractRF','OldRAVC']:
   b=sub[sub.policy==name].set_index('seed').loc[a.index]
   for metric in ['loss_m2s','cpu_s','rmse_m','capture_success','failure']:
    aa=a[metric].to_numpy();bb=b[metric].to_numpy();eff=paired(aa,bb,rng)
    if metric=='capture_success':eff['improvement']=float(aa.mean()-bb.mean());eff['improvement_ci']=eff['difference_ci']
    effects.append({'phase':phase,'policy':'KG1','control':name,'metric':metric,'n':len(a),**eff})
  b=sub[sub.policy=='Fixed2'].set_index('seed').loc[a.index];gain=(b.loss_m2s-a.loss_m2s).sort_values(ascending=False);total=gain.sum();keep=gain.index[2:]
  influence.append({'phase':phase,'n':len(a),'improved':int((gain>1e-12).sum()),'worse':int((gain<-1e-12).sum()),'equal':int((gain.abs()<=1e-12).sum()),'net_gain_m2s':float(total),'top_two_fraction_of_net':float(gain.iloc[:2].sum()/total) if total else None,'gain_excluding_top_two':float(1-a.loc[keep].loss_m2s.mean()/b.loc[keep].loss_m2s.mean()),'KG_tail_mean':tail(a.loss_m2s.to_numpy()),'Fixed2_tail_mean':tail(b.loss_m2s.to_numpy()),'tail_improvement':float(1-tail(a.loss_m2s.to_numpy())/tail(b.loss_m2s.to_numpy())),'KG_loss_q99':float(a.loss_m2s.quantile(.99)),'Fixed2_loss_q99':float(b.loss_m2s.quantile(.99)),'KG_only_events':int(((a.failure==1)&(b.failure==0)).sum()),'Fixed2_only_events':int(((a.failure==0)&(b.failure==1)).sum())})
  for control in ['KG1_no_profile','KG1_no_deadline','KG1_held','FlatCART']:
   b=sub[sub.policy==control].set_index('seed').loc[a.index]
   changed=(a.stop_iteration!=b.stop_iteration)|(a.publications!=b.publications)
   paths.append({'phase':phase,'control':control,'n':len(a),'changed_jobs':int(changed.sum()),'mean_cpu_difference_ms':float((a.cpu_s-b.cpu_s).mean()*1e3),'mean_loss_difference':float((a.loss_m2s-b.loss_m2s).mean()),'events_KG':int(a.failure.sum()),'events_control':int(b.failure.sum()),'capture_success_KG':int(a.capture_success.sum()),'capture_success_control':int(b.capture_success.sum())})
 pd.DataFrame(influence).to_csv(D/'influence.csv',index=False);pd.DataFrame(paths).to_csv(D/'mechanisms.csv',index=False);(D/'paired_effects.json').write_text(json.dumps(effects,indent=2))
 # Descriptive context strata, never additional calibration units.
 q.groupby(['phase','policy','mesh','sd']).agg(n=('seed','size'),loss=('loss_m2s','mean'),events=('failure','sum'),deep=('stop_iteration',lambda x:int((x>2).sum()))).reset_index().to_csv(D/'context_strata.csv',index=False)
 metadata={'analyzer_sha256':sha(__file__),'bootstrap_resamples':10000,'bootstrap_unit':'paired independent episode seed','main_load':20.,'tail_definition':'mean largest ceil(0.05*n) episode losses; empirical upper-tail mean','influence':'top-two deletion is descriptive; it does not replace the prespecified full-sample comparison'}
 (D/'analysis_manifest.json').write_text(json.dumps(metadata,indent=2));print('R4_ANALYSIS_COMPLETE',flush=True)
if __name__=='__main__':main()
