"""Recount the completed campaign/challenge and verify the final document inputs.

No missing study or pending render is treated as a pass. --campaign-only is an
explicit partial check for use while the independent image study is running.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

import fitz
import numpy as np
import pandas as pd
from scipy.stats import beta

ROOT = Path(__file__).resolve().parents[1]
PAPER = ROOT/'paper'
CAM = ROOT/'studies/lifecycle_campaign_20261018'
CHA = ROOT/'studies/inspection_challenge_20261018'
ANA = CHA/'analysis'
REN = CHA/'rendering'
FIG = PAPER/'figures/visual'

def read(path):
    return json.loads(Path(path).read_text())

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def hashes(root, values):
    for name, digest in values.items():
        path = (root/name).resolve()
        assert path.is_relative_to(ROOT), ('source outside manuscript',name)
        assert sha(path) == digest, ('stale source hash',name)

def close(a, b, label):
    assert np.isclose(a,b,rtol=1e-10,atol=1e-12,equal_nan=True), (label,a,b)

def boolean(series):
    assert series.notna().all(), ('missing Boolean values',series.name)
    assert set(series.unique()) <= {True,False,0,1}, (series.name,series.unique())
    return series.astype(bool)

def campaign_checks():
    spec=read(CAM/'protocol.json'); out=CAM/'outputs'; summary=read(out/'summary.json')
    hashes(CAM,read(CAM/'artifact_manifest.json')['files'])
    for name in ['design_freeze.json','calibration_execution_freeze.json','campaign_execution_freeze.json']:
        hashes(CAM,read(CAM/name)['files'])
    hashes(out,summary['input_hashes'])
    cal=pd.read_csv(out/'calibration_observations.csv')
    decisions=pd.read_csv(out/'decisions.csv'); obs=pd.read_csv(out/'campaign_observations.csv')
    risk=pd.read_csv(out/'exact_risk_cards.csv'); plans=pd.read_csv(out/'family_plans.csv')
    catalogue=pd.read_csv(out/'catalogue_events.csv')
    methods=pd.read_csv(out/'method_summary.csv').set_index('method')
    family=pd.read_csv(out/'family_method_summary.csv').set_index('method')
    n=spec['calibration_scene_count']; count=spec['primary_scene_count']; K=spec['family_K']
    steps=len(spec['steps']); names=spec['methods']; variants=spec['configs']
    assert len(cal)==n*len(variants) and cal[['seed','variant']].duplicated().sum()==0
    assert set(cal.seed)==set(range(spec['calibration_seed_start'],spec['calibration_seed_start']+n))
    assert set(decisions.seed)==set(range(spec['test_seed_start'],spec['test_seed_start']+count))
    assert not set(cal.seed)&set(decisions.seed)
    assert set(cal.variant)==set(variants)
    assert decisions[['seed','method','index']].duplicated().sum()==0
    assert set(decisions.method)==set(names) and len(decisions)==count*steps*len(names)
    sys.path.insert(0,str(ROOT/'studies/lifecycle_20261018'))
    from evidence import REQUESTS
    assert K==len(variants)*len(REQUESTS)==len(risk)
    assert set(zip(risk.variant,risk.request))=={(v,r) for v in variants for r in REQUESTS}
    eligible={}
    for row in risk.itertuples():
        group=cal[cal.variant==row.variant]; good=np.ones(n,dtype=bool)
        for quantity,(lo,hi) in REQUESTS[row.request].items():
            values=group[quantity].to_numpy(); good &= np.isfinite(values)
            if lo is not None: good &= values>=lo
            if hi is not None: good &= values<=hi
        k=int((~good).sum()); alpha=spec['confidence_error']/K
        upper=1. if k==n else beta.isf(alpha,k+1,n-k)
        assert row.k==k and row.n==n
        close(row.alpha,alpha,'CP allocation'); close(row.upper,upper,'CP upper bound')
        assert row.authorized==(upper<=spec['allowance'])
        eligible[row.variant,row.request]=bool(row.authorized)
    assert len(plans)==K*len(names)
    assert plans[['method','variant','request']].duplicated().sum()==0
    for row in plans.itertuples():
        assert row.authorized==eligible[row.variant,row.request]
    for (seed,method),group in decisions.groupby(['seed','method']):
        group=group.sort_values('index')
        assert group['index'].tolist()==list(range(steps))
        assert group.event.tolist()==spec['steps']
        revision=-1
        for row in group.itertuples():
            revision += row.kind in {'numerical','request','rollback','repair'}
            assert row.revision==revision
            expected_eligible=eligible[row.variant,row.request] and row.kind!='population'
            assert row.exact_eligible==expected_eligible
            expected_issue=(expected_eligible and row.state=='active' and row.numerical_binding_valid
                            and row.identity_valid and row.population_compatible)
            assert row.issued==row.oracle_issue==expected_issue
            if row.kind in {'stale','late','invalid_repair','population'}: assert not row.issued
            if row.kind=='repair': assert row.repair_accepted==True and row.state=='active'
            if row.kind in {'invalid_repair','replay'}: assert row.repair_accepted==False
            if method!='Whole renewal' and row.kind=='rollback':
                assert sum(getattr(row,'calls_'+stage) for stage in ['geometry','radiance','sensor','decode','pose','optics'])==0
    pivot=decisions.pivot(index=['seed','index'],columns='method',values='issued')
    assert pivot.eq(pivot[names[0]],axis=0).all().all()
    for _, group in obs.groupby(['seed','population','variant']):
        assert all(group[key].nunique()==1 for key in ['pixel_sha256','observable_sha256','numerical_sha256'])
    assert len(catalogue)==steps*len(names) and catalogue[['method','index']].duplicated().sum()==0
    for name in names:
        g=decisions[decisions.method==name]; m=methods.loc[name]
        c=catalogue[catalogue.method==name]; f=family.loc[name]
        assert m.workflow_decisions==len(g) and m.issued==int(boolean(g.issued).sum())
        assert m.false_issuances==0 and m.authority_oracle_disagreements==0 and m.invalid_binding_issuances==0
        final=g[g['index']==steps-1]
        assert m.final_eligible_sources==int(final.exact_eligible.sum())
        assert m.final_recovered_sources==int(final.issued.sum())
        assert m.successful_repair_commits==int((g.repair_accepted==True).sum())
        assert m.evidence_cards==int(c.new_cards.sum())
        assert m.evidence_record_evaluations==int(c.record_evaluations.sum())==m.evidence_cards*n
        close(m.event_cpu_s,g.cpu_s.sum(),'event CPU sum')
        close(m.event_wall_s,g.wall_s.sum(),'event wall sum')
        for stage in ['geometry','radiance','sensor','decode','pose','optics']:
            assert m['calls_'+stage]==int(g['calls_'+stage].sum())
        assert f.contexts==K and f.supported==sum(eligible.values())
        assert f.record_evaluations==f.constructed_cards*n
        plan=plans[plans.method==name]
        assert f.constructed_cards==int(plan.route.eq('exact_new').sum())
        assert f.containment_routes==int(plan.route.eq('containment').sum())
    for column in ['evidence_cards','evidence_record_evaluations','issued','final_recovered_sources']:
        assert methods.loc['Containment + repair',column]==methods.loc['Rules + registry',column]
    trace_saving=100*(1-methods.loc['Containment + repair','evidence_record_evaluations']/methods.loc['DAG exact + registry','evidence_record_evaluations'])
    family_saving=100*(1-family.loc['Containment + repair','record_evaluations']/family.loc['DAG exact + registry','record_evaluations'])
    cpu_saving=100*(1-methods.loc['DAG exact + registry','event_cpu_s']/methods.loc['Whole renewal','event_cpu_s'])
    close(trace_saving,summary['trace_demand_evidence_record_saving_vs_exact_percent'],'trace evidence saving')
    close(family_saving,summary['full_family_evidence_record_saving_vs_exact_percent'],'family evidence saving')
    close(cpu_saving,summary['dag_event_cpu_saving_vs_whole_percent'],'DAG CPU saving')
    sums=decisions.groupby(['seed','method']).cpu_s.sum().unstack('method')
    whole=sums['Whole renewal'].to_numpy(); dag=sums['DAG exact + registry'].to_numpy()
    rng=np.random.default_rng(summary['bootstrap_seed'])
    indices=rng.integers(0,count,(summary['bootstrap_replicates'],count))
    bootstrap=100*(1-dag[indices].sum(axis=1)/whole[indices].sum(axis=1))
    assert np.allclose(np.quantile(bootstrap,[.025,.975]),summary['dag_paired_source_bootstrap_ci'],rtol=1e-10,atol=1e-12)
    heldout=pd.read_csv(out/'heldout_request_scores.csv')
    nominal=obs[obs.population==spec['population']].drop_duplicates(['seed','variant'])
    assert len(heldout)==nominal.variant.nunique()*len(REQUESTS)==summary['heldout_scored_contexts']
    assert heldout[['variant','request']].duplicated().sum()==0
    for row in heldout.itertuples():
        group=nominal[nominal.variant==row.variant]; good=np.ones(len(group),dtype=bool)
        assert len(group)==row.test_sources==count
        for quantity,(lo,hi) in REQUESTS[row.request].items():
            values=group[quantity].to_numpy(); good &= np.isfinite(values)
            if lo is not None: good &= values>=lo
            if hi is not None: good &= values<=hi
        assert row.test_failures==int((~good).sum()) and row.authorized==eligible[row.variant,row.request]
        reference=risk[(risk.variant==row.variant)&(risk.request==row.request)].iloc[0]
        close(row.calibration_upper,reference.upper,'held-out calibration reference')
    verification=read(out/'verification.json')
    assert verification['status']=='PASS' and verification['workflow_rows_checked']==len(decisions)
    assert verification['calibration_rows_checked']==len(cal) and verification['cold_reexecutions']>0
    assert verification['runtime_truth_labels_used'] is False
    facts={'campaign.independent_calibration_sources':n,'campaign.independent_test_sources':count,
           'campaign.family_contexts':K,'campaign.calibration_outputs':len(cal),
           'campaign.workflow_decisions':len(decisions),'campaign.decisions_per_method':count*steps,
           'campaign.admitted_contexts':sum(eligible.values()),
           'campaign.issued_per_method':int(methods.loc['Containment + repair','issued']),
           'campaign.recovered_sources':int(methods.loc['Containment + repair','final_recovered_sources']),
           'campaign.trace_exact_evaluations':int(methods.loc['DAG exact + registry','evidence_record_evaluations']),
           'campaign.trace_containment_evaluations':int(methods.loc['Containment + repair','evidence_record_evaluations']),
           'campaign.full_exact_evaluations':int(family.loc['DAG exact + registry','record_evaluations']),
           'campaign.full_containment_evaluations':int(family.loc['Containment + repair','record_evaluations']),
           'campaign.trace_evidence_saving_percent':float(trace_saving),
           'campaign.full_evidence_saving_percent':float(family_saving),
           'campaign.dag_cpu_savings_percent':float(cpu_saving),
           'campaign.whole_event_cpu_s':float(methods.loc['Whole renewal','event_cpu_s']),
           'campaign.dag_event_cpu_s':float(methods.loc['DAG exact + registry','event_cpu_s']),
           'campaign.contract_event_cpu_s':float(methods.loc['Containment + repair','event_cpu_s'])}
    # Stable display-ledger names used by completion_report.py.
    aliases={'calibration_sources':'independent_calibration_sources','test_sources':'independent_test_sources',
             'catalogue_exact_evaluations':'full_exact_evaluations','catalogue_reuse_evaluations':'full_containment_evaluations',
             'catalogue_reduction_percent':'full_evidence_saving_percent','sparse_evaluations_exact':'trace_exact_evaluations',
             'sparse_evaluations_reuse':'trace_containment_evaluations','issued':'issued_per_method'}
    facts.update({'campaign.'+key:facts['campaign.'+value] for key,value in aliases.items()})
    facts['campaign.repairs']=int(methods.loc['Containment + repair','successful_repair_commits'])
    return facts

def challenge_checks():
    protocol=read(ANA/'protocol.json'); render=read(REN/'protocol.json')
    freeze=read(ANA/'freeze.json'); out=ANA/'outputs/test'
    frame=pd.read_csv(out/'metrics.csv'); summary=read(out/'summary.json'); processing=read(out/'processing.json')
    hashes(REN,read(REN/'freeze.json')['sha256']); hashes(ROOT,freeze['source_hashes'])
    hashes(ROOT,processing['source_hashes'])
    assert processing['freeze_sha256']==sha(ANA/'freeze.json')
    assert freeze['heldout_images_opened_by_selection'] is False
    assert sha(ANA/'development_metrics.csv')==freeze['development_metrics_sha256']
    hashes(CHA,freeze['development_image_sha256']); hashes(CHA,freeze['development_scene_sha256'])
    for split in ['development','test']:
        hashes(REN,read(REN/f'{split}_manifest.json')['files'])
    expected={(s['seed'],s['family']) for s in render['test_sources']}
    assert set(zip(frame.seed,frame.family))==expected
    assert frame[['seed','condition','frontend']].duplicated().sum()==0
    assert set(frame.condition)==set(protocol['conditions'])
    fronts=[freeze['baseline']['name'],freeze['selected']['name']]
    assert len(set(fronts))==2 and set(frame.frontend)==set(fronts)
    assert len(frame)==len(expected)*len(protocol['conditions'])*2
    assert frame.groupby('family').seed.nunique().to_dict()=={k:protocol['expected_test_scenes_per_family'] for k in range(4)}
    assert not set(frame.seed)&set(freeze['development_seeds'])
    assert boolean(frame.structure_holdout).equals(frame.family.isin(protocol['structure_holdout_families']))
    assert set(frame.image_width)=={render['width']} and set(frame.image_height)=={render['height']}
    for _,row in frame[['image_path','image_sha256']].drop_duplicates().iterrows():
        assert sha(CHA/row.image_path)==row.image_sha256
    assert frame[['seed','condition']].drop_duplicates().shape[0]==summary['image_count']
    assert summary['scene_count']==len(expected) and summary['frontend_evaluations']==len(frame)
    assert frame.projection_check_px.max()<1e-3
    assert (frame.planned_targets>0).all() and (frame.correct_matches<=frame.matched_targets).all()
    assert np.allclose(frame.coverage,frame.correct_matches/frame.planned_targets)
    failure=(frame.coverage<.8)|(frame.reprojection_px>8)|(frame.association_m>.008)
    assert boolean(frame.quality_failure).equals(failure)
    screening=(frame.matched_targets/frame.planned_targets>=.8)&(frame.reprojection_px<=8)
    assert boolean(frame.observable_screen_accept).equals(screening)
    assert boolean(frame.accepted_but_failed).equals(screening&failure)
    assert boolean(frame.coverage_failure).equals(frame.coverage<.8)
    assert boolean(frame.residual_failure).equals(frame.reprojection_px>8)
    assert boolean(frame.mapping_failure).equals(frame.association_m>.008)
    for rows,keys in [(summary['conditions'],['frontend','condition']),(summary['strata'],['frontend','family','condition'])]:
        assert len(rows)==frame.groupby(keys).ngroups
        for row in rows:
            group=frame
            for key in keys: group=group[group[key]==row[key]]
            assert len(group)==row['n_images'] and group.seed.nunique()==row['independent_scenes']
            for key,column in [('quality_failures','quality_failure'),('accepted_but_failed','accepted_but_failed'),
                               ('coverage_failures','coverage_failure'),('mapping_failures','mapping_failure'),
                               ('residual_failures','residual_failure'),('observable_screen_acceptances','observable_screen_accept')]:
                assert row[key]==int(group[column].sum()),(keys,row,key)
            close(row['coverage_mean'],group.coverage.mean(),'coverage summary')
            ordered=np.sort(group.association_m.to_numpy())
            for label,q in [('median',.5),('p95',.95)]:
                value=ordered[int(np.ceil(q*len(ordered)))-1]
                if np.isfinite(value): close(row[f'mapping_{label}_m'],value,'all-image mapping quantile')
                else: assert row[f'mapping_{label}_m'] is None and row[f'mapping_{label}_unbounded']
    development=pd.read_csv(ANA/'development_metrics.csv')
    dev_expected={(s['seed'],s['family']) for s in render['development_sources']}
    assert set(zip(development.seed,development.family))==dev_expected
    assert development[['seed','condition','frontend']].duplicated().sum()==0
    assert len(development)==len(dev_expected)*len(protocol['conditions'])*development.frontend.nunique()
    cells=development.groupby(['frontend','family','condition'])[['quality_failure','coverage']].mean()
    ranking=cells.groupby('frontend').mean().reset_index()
    ranking=ranking[ranking.frontend!=fronts[0]].sort_values(['quality_failure','coverage','frontend'],ascending=[True,False,True])
    assert ranking.iloc[0].frontend==fronts[1]
    # Recount paired, stratified scene bootstrap. Conditions are repeated measures.
    bootstrap=summary['bootstrap']; rng=np.random.default_rng(bootstrap['seed'])
    scene_families=frame[['seed','family']].drop_duplicates().sort_values(['family','seed'])
    draws=np.concatenate([rng.choice(g.seed.to_numpy(),size=(bootstrap['replicates'],len(g)),replace=True)
                          for _,g in scene_families.groupby('family')],axis=1)
    assert len(summary['provider_comparisons'])==len(protocol['conditions'])*3
    for row in summary['provider_comparisons']:
        wide=frame[frame.condition==row['condition']].pivot(index='seed',columns='frontend',values=row['metric'])
        delta=wide[fronts[1]].astype(float)-wide[fronts[0]].astype(float)
        close(row['alternative_minus_frozen_mean'],delta.mean(),'paired provider change')
        values=delta.loc[draws.ravel()].to_numpy().reshape(draws.shape).mean(axis=1)
        assert np.allclose(np.quantile(values,[.025,.975]),row['scene_cluster_percentile_95'],rtol=1e-10,atol=1e-12)
    transitions=pd.read_csv(out/'transitions.csv')
    assert len(transitions)==len(expected)*(len(protocol['conditions'])-1)*2
    for row in summary['paired_condition_changes']:
        group=transitions[(transitions.frontend==row['frontend'])&(transitions.condition==row['condition'])]
        assert row['n_scene_pairs']==len(group)==len(expected)
        assert row['pass_to_failure']==int(group.pass_to_failure.sum())
        assert row['failure_to_pass']==int(group.failure_to_pass.sum())
        close(row['mean_coverage_change'],group.coverage_change.mean(),'condition coverage change')
    verification=read(ANA/'verification.json')
    assert verification['status']=='PASS' and verification['frontend_rows_recomputed']==len(frame)
    assert verification['raw_images_reprocessed']==summary['image_count']
    for key in ['all_images_and_source_hashes_match','development_selection_reproduced','estimator_truth_free_signature','all_failed_cases_retained']:
        assert verification[key] is True
    assert verification['true_pose_mesh_max_error_m']<protocol['true_pose_mesh_tolerance_m']
    renderer_verification=read(REN/'verification.json')
    assert renderer_verification['status']=='PASS'
    assert renderer_verification['development_sources']==len(dev_expected)
    assert renderer_verification['test_sources']==len(expected)
    assert renderer_verification['raw_images']==(len(expected)+len(dev_expected))*len(protocol['conditions'])
    for key in ['source_protocol_and_inventory_hashes_match','source_disjointness','test_analysis_freeze_binding_matches']:
        assert renderer_verification[key] is True
    assert renderer_verification['max_camera_projection_difference_px']<1e-3
    assert renderer_verification['max_highest_skin_height_difference_m']<1e-7
    reproduction=read(REN/'reproduction.json')
    assert reproduction['status']=='PASS' and reproduction['rerendered_images']==len(reproduction['records'])==5
    first={family:min(seed for seed,f in expected if f==family) for family in range(4)}
    rerender_cases={(seed,family,'nominal') for family,seed in first.items()}|{(first[3],3,'occlusion')}
    assert {(r['seed'],r['family'],r['condition']) for r in reproduction['records']}==rerender_cases
    assert all(r['max_pixel_difference']==0 and r['mesh_and_camera_exact'] for r in reproduction['records'])
    legacy=read(ANA/'legacy_compatibility.json'); unit=read(ANA/'unit_checks.json')
    assert legacy['status']=='PASS' and legacy['exact_arrays_match'] and legacy['maximum_difference']==0
    assert legacy['earlier_images']==len(pd.read_csv(ROOT/'studies/physical_render_20261018/outputs/metrics.csv'))
    assert unit['status']=='PASS' and unit['exact_pose_mapping_error_m']<1e-9
    for key in ['nearest_raised_surface_hit','outside_mesh_ray_preserved','occluded_targets_remain_in_denominator',
                'invisible_target_distractors_do_not_count_as_correct','observable_screen_false_acceptance_distinguished']:
        assert unit[key] is True
    facts={'challenge.independent_test_scenes':len(expected),'challenge.images':summary['image_count'],
           'challenge.evaluations':len(frame),'challenge.development_scenes':len(dev_expected),
           'challenge.development_images':len(dev_expected)*len(protocol['conditions']),
           'challenge.family_count':frame.family.nunique(),'challenge.frontends':len(fronts)}
    facts['challenge.frontend_evaluations']=facts['challenge.evaluations']
    for role,name in zip(['baseline','alternative'],fronts):
        for condition,g in frame[frame.frontend==name].groupby('condition'):
            prefix=f'challenge.{role}.{condition}.'
            facts[prefix+'quality_failures']=int(g.quality_failure.sum())
            facts[prefix+'accepted_but_failed']=int(g.accepted_but_failed.sum())
            facts[prefix+'coverage_percent']=float(100*g.coverage.mean())
    return facts

def expand(path):
    return re.sub(r'\\input\{([^}]+)\}',lambda m:expand(PAPER/(m[1]+'.tex')),path.read_text())

def documents_and_figures(facts):
    provenance=read(FIG/'completion_figure_provenance.json')
    hashes(ROOT,provenance['sources'])
    assert any('inspection_challenge_20261018' in k and k.endswith('.png') for k in provenance['sources'])
    assert any('lifecycle_campaign_20261018' in k and k.endswith('.npz') for k in provenance['sources'])
    canvas=read(FIG/'completion_canvas_qa.json')
    assert canvas and len({r['figure'] for r in canvas})==len(canvas)
    for row in canvas:
        assert not row['text_outside_canvas'],row
        assert (FIG/(row['figure']+'.pdf')).is_file()
    docs={}; page_counts={}; figure_counts={}
    for name in ['main','supplement']:
        source=expand(PAPER/(name+'.tex'))
        assert not re.search(r'Appendix\s+Appendix|\bTODO\b|\bFIXME\b',source),name
        log=(PAPER/(name+'.log')).read_text()
        assert not any(x in log for x in ['undefined references','Citation','Overfull','LaTeX Error','multiply defined','Label(s) may have changed']),name
        with fitz.open(PAPER/(name+'.pdf')) as document:
            page_counts[name]=len(document)
            text='\n'.join(p.get_text() for p in document)
            assert '??' not in text and 'Appendix Appendix' not in text,name
            for i,page in enumerate(document):
                for block in page.get_text('dict')['blocks']:
                    for line in block.get('lines',[]):
                        for span in line['spans']:
                            if not span['text'].strip(): continue
                            x0,y0,x1,y1=span['bbox']
                            assert x0>=-.5 and y0>=-.5 and x1<=page.rect.width+.5 and y1<=page.rect.height+.5,(name,i+1,span['text'],span['bbox'])
            if name=='main':
                sequence=re.findall(r'Figure (\d+):',text)
                assert sequence==list(map(str,range(1,len(sequence)+1))) and sequence
                figure_counts[name]=len(sequence)
                assert 'sections/completion_content' in (PAPER/'main.tex').read_text()
            docs[name]=re.sub(r'\s+',' ',text)
    # The generator records display values; this verifier owns their independent
    # numerical derivations above. Each declared document placement is checked.
    claims=read(FIG/'completion_claims.json')
    claims=claims['claims'] if isinstance(claims,dict) else claims
    assert claims and len({r['key'] for r in claims})==len(claims)
    required={'campaign.admitted_contexts','campaign.decisions_per_method',
              'campaign.catalogue_exact_evaluations','campaign.catalogue_reuse_evaluations',
              'campaign.catalogue_reduction_percent','campaign.sparse_evaluations_exact',
              'campaign.sparse_evaluations_reuse','challenge.independent_test_scenes',
              'challenge.images','challenge.evaluations'}
    assert required<={r['key'] for r in claims}
    for row in claims:
        assert row['key'] in facts,('claim has no independent derivation',row['key'])
        close(row['value'],facts[row['key']],row['key'])
        assert row['locations'] and set(row['locations'])<={'main','supplement'}
        formatted=re.sub(r'\s+',' ',str(row['formatted']))
        numeric=formatted.replace(',','').replace('%','').strip()
        assert re.fullmatch(r'[-+]?\d+(?:\.\d+)?',numeric),('non-numerical display claim',row)
        decimals=len(numeric.partition('.')[2])
        close(float(numeric),round(float(facts[row['key']]),decimals),'rounded display value '+row['key'])
        for location in row['locations']:
            assert formatted in docs[location],('claim not present in document',row['key'],location,formatted)
    subprocess.run([sys.executable,str(ROOT/'reporting/verify_citations.py')],check=True,capture_output=True,text=True)
    return {'pages':page_counts,'main_figures':figure_counts['main'],'current_figure_canvases':len(canvas),
            'figure_sources_verified':len(provenance['sources']),'document_claims_verified':len(claims),
            'references':read(ROOT/'audits/citation_qa.json')['active_references']}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign-only',action='store_true')
    parser.add_argument('--data-only',action='store_true')
    args=parser.parse_args()
    facts=campaign_checks()
    if args.campaign_only:
        print(json.dumps({'status':'PARTIAL_CAMPAIGN_CHECKS_PASS','facts':facts},indent=2)); return
    facts.update(challenge_checks())
    if args.data_only:
        print(json.dumps({'status':'PARTIAL_NUMERICAL_CHECKS_PASS','facts':facts},indent=2)); return
    documents=documents_and_figures(facts)
    result={'status':'PASS','facts':facts,'documents':documents,
            'raw_inputs_and_frozen_sources_verified':True,'all_failed_challenge_cases_retained':True,
            'numerical_population_and_protocol_counts_distinguished':True}
    (ROOT/'audits/completion_qa.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__': main()
