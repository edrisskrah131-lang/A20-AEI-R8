"""Bind F1 and the independently sealed attachment amendment before confirmation."""
import json
from datetime import datetime,timezone
from r8_protocol import ROOT,D,sha
from r8_evaluate import assert_freeze

def bind():
    assert_freeze();am=json.loads((D/'claim_layer_freeze.json').read_text())
    for key,p in [('F0_sha256','freeze.json'),('protocol_sha256','protocol.json'),('clock_sha256','clock_profile.json')]:assert am[key]==sha(D/p)
    for p,h in am['components'].items():assert sha(ROOT/p)==h
    assert am['audit_sha256']==sha(ROOT/'qa/r8/claim_layer_audit.json')
    f=json.loads((D/'selection_freeze.json').read_text())
    for p,h in f['files'].items():assert sha(D/p)==h
    for p,h in f['calibration_result_files'].items():assert sha(D/p)==h
    p=D/'attachment_selection_binding.json'
    if p.exists():
        saved=json.loads(p.read_text());assert saved['F1_sha256']==sha(D/'selection_freeze.json')
        assert saved['amendment_sha256']==sha(D/'claim_layer_freeze.json');return
    phases={json.loads(x)['phase'] for x in (D/'episodes.jsonl').read_text().splitlines()}
    assert phases<= {'nominal_calibration','geometry_calibration'},'attachment/F1 binding follows confirmation access'
    obj={'utc':datetime.now(timezone.utc).isoformat(),'F0_sha256':sha(D/'freeze.json'),
         'F1_sha256':sha(D/'selection_freeze.json'),'amendment_sha256':sha(D/'claim_layer_freeze.json'),
         'audit_sha256':sha(ROOT/'qa/r8/claim_layer_audit.json'),'binder_sha256':sha(__file__),
         'purpose':'separate provenance binding; F0 numerical clock and F1 policy/card selection are immutable'}
    p.write_text(json.dumps(obj,indent=2));print('ATTACHMENT_F1_BOUND',obj['utc'],flush=True)
if __name__=='__main__':bind()
