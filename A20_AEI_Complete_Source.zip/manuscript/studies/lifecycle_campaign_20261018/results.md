# Executed campaign results

All four implementations support **54 of the 64 predefined calibration-family
contexts**. Support by configuration is baseline 8, focal 8, exposure 6, ROI 8,
lighting 3, decoder 8, combined exposure/lighting/decoder 5, and combined camera 8.
The calibration data comprise 256 fresh sources and 2,048 genuinely computed
producer outputs. The test campaign uses 64 independent fresh sources, with 16
operations per source and four separately executed implementations.

## Full family and sparse operational demand

| Full 64-context catalogue | Constructed cards | Records evaluated | Cold CPU |
|---|---:|---:|---:|
| Whole renewal |64|16,384|13.483 ms|
| DAG exact + registry |54|13,824|9.577 ms|
| Containment + repair |35|8,960|6.324 ms|
| Rules + registry |35|8,960|6.327 ms|

Containment reduces record evaluations by 35.185% relative to exact cards while
preserving the same 54 supported contexts. The independently implemented rules
produce the same 35 cards and support. The absolute cold-catalogue CPU difference
is about 3.253 ms; it is not presented as the numerical pipeline's runtime saving.
The CPU values are one measured cold construction per method, not a large-sample
benchmark of millisecond performance.

The actual 16-step demand sequence requires only a subset of that catalogue.
Constructing its shared population-level evidence once needs 8 exact cards and
2,048 evaluations, or 6 containment/rule cards and 1,536 evaluations: a 25% reduction.
These counts apply once for the entire 64-source campaign. They are not multiplied
by 64, and the sparse-demand and full-family catalogue counts are separate demand
scenarios, not additive costs.

## Actual numerical and lifecycle work

| All 64 source trajectories | Event CPU | Summed event wall time | Final recovery |
|---|---:|---:|---:|
| Whole renewal |193.617 s|218.024 s|64/64|
| DAG exact + registry |78.773 s|88.192 s|64/64|
| Containment + repair |79.328 s|90.951 s|64/64|
| Rules + registry |79.687 s|91.876 s|64/64|

The ordinary DAG lowers event CPU by 59.315% relative to whole renewal. A paired
bootstrap over 64 source-level totals gives a 95% interval of 58.500–60.124%.
All three strong methods execute the same provider calls and have comparable
numerical cost; this saving belongs to their shared DAG implementation.

Per source, whole renewal executes each of the six providers 10 times. Each strong
method executes geometry 3 times, radiance 4, sensor 6, decode 7, pose 7, and optics 4.
The summed counts are 60 versus 31 provider calls per source. The complete numerical
rollback at registry revision 9 makes **zero** new DAG provider calls because the
baseline output is still available and identified correctly.

All methods issue 704 of 1,024 workflow requests. The other 320 requests comprise
five distinct refused operations per source: the unsupported strict request under
exposure, stale attachment, invalid repair, population mismatch, and late delivery.
Correct statistical refusal leaves the binding active. The two numerical
misattachments quarantine the binding; the two authentic repairs restore all 128
eligible recovery checkpoints across 64 sources. No method issues an incorrectly
bound output, and no strong method has a service advantage over an equivalent
authority implementation.

The first fault is followed by one invalid repair and then a valid repair, so
restoration occurs two scripted operations after quarantine. The second fault is
followed directly by its valid repair. These are the fixed workflow's operation
counts, not an estimate of operator recovery time or a physical minimum latency.

## Representative source and verification

For the first fixed test source 202630100, baseline residual is 0.775989 px, true
coverage 0.914286, maximum mapping error 0.622316 mm, and blur 0.775602 px. Exposure
changes the blur to 1.163402 px. The low-light configuration yields 4.222853 px
residual, while its optical request remains admissible under the independently
calibrated optical event. The combined camera configuration generates an 896×672
raster rather than the 768×576 baseline. Full rasters and feature arrays are stored
for this source and the next preselected source, together with their complete
revision and repair logs. Physical quality values are offline scores, not runtime
ground-truth checks.

The 16-step campaign visits six nominal configurations. Its held-out outputs score
48 request/configuration contexts; the focal-only and ROI-only configurations are
part of the 64-context calibration family but are not separate held-out campaign
cases. There are 448 distinct source/population/configuration outputs,2,560 numerical
evaluation requests including cache hits and method repeats, and 4,096 workflow
decisions. The independent primary test sample size remains 64.

Verification recalculates all 64 confidence bounds, checks every provider-call and
registry transition, verifies identical pixel and numerical hashes across methods,
checks all 22 preserved image archives, and reexecutes 30 selected outputs through
direct geometry→radiance→sensor→decode→pose/optics calls that bypass the DAG cache.
All 30 reproduce their exact pixel, observable-output and numerical hashes.
