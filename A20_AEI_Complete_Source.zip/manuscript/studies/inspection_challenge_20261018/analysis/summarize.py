"""All-scene descriptive summaries with paired, scene-clustered uncertainty."""
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'outputs'/'test'
frame = pd.read_csv(OUT/'metrics.csv')
freeze = json.loads((ROOT/'freeze.json').read_text())
baseline, alternative = freeze['baseline']['name'], freeze['selected']['name']


def describe(group):
    finite_mapping = group.association_m[np.isfinite(group.association_m)]
    # A missed ray remains +infinity in the all-image distribution and in failures.
    ordered = np.sort(group.association_m.to_numpy())
    median = float(ordered[int(np.ceil(.5 * len(ordered))) - 1])
    p95 = float(ordered[int(np.ceil(.95 * len(ordered))) - 1])
    return dict(n_images=len(group), independent_scenes=int(group.seed.nunique()),
                correct_matches=int(group.correct_matches.sum()),
                planned_targets=int(group.planned_targets.sum()),
                coverage_mean=float(group.coverage.mean()),
                coverage_median=float(group.coverage.median()),
                mapping_median_m=median if np.isfinite(median) else None,
                mapping_median_unbounded=not np.isfinite(median),
                mapping_p95_m=p95 if np.isfinite(p95) else None,
                mapping_p95_unbounded=not np.isfinite(p95),
                finite_mapping_images=len(finite_mapping),
                images_with_mesh_miss=int((group.mesh_misses > 0).sum()),
                quality_failures=int(group.quality_failure.sum()),
                coverage_failures=int(group.coverage_failure.sum()),
                mapping_failures=int(group.mapping_failure.sum()),
                residual_failures=int(group.residual_failure.sum()),
                observable_screen_acceptances=int(group.observable_screen_accept.sum()),
                accepted_but_failed=int(group.accepted_but_failed.sum()),
                estimator_cpu_median_s=float(group.estimator_cpu_s.median()))


strata = []
for (frontend, family, condition), group in frame.groupby(['frontend', 'family', 'condition']):
    strata.append(dict(frontend=frontend, family=int(family), condition=condition,
                      structure_holdout=bool(group.structure_holdout.iloc[0]), **describe(group)))
pd.DataFrame(strata).to_csv(OUT/'strata.csv', index=False)
condition_rows = []
for (frontend, condition), group in frame.groupby(['frontend', 'condition']):
    condition_rows.append(dict(frontend=frontend, condition=condition, **describe(group)))
pd.DataFrame(condition_rows).to_csv(OUT/'conditions.csv', index=False)

# Each draw resamples independent source scenes within each fixed geometry family.
# All conditions/providers belonging to that source remain paired in every draw.
rng = np.random.default_rng(2026101805)
scene_families = frame[['seed', 'family']].drop_duplicates().sort_values(['family', 'seed'])
draws = []
for family, group in scene_families.groupby('family'):
    seeds = group.seed.to_numpy()
    draws.append(rng.choice(seeds, size=(4000, len(seeds)), replace=True))
draws = np.concatenate(draws, axis=1)


def interval(series):
    assert series.index.is_unique
    values = series.loc[draws.ravel()].to_numpy().reshape(draws.shape).mean(axis=1)
    return [float(x) for x in np.quantile(values, [.025, .975])]


comparisons = []
for condition in sorted(frame.condition.unique()):
    group = frame[frame.condition == condition]
    wide = group.pivot(index='seed', columns='frontend', values=['coverage', 'quality_failure', 'accepted_but_failed'])
    for metric in ['coverage', 'quality_failure', 'accepted_but_failed']:
        delta = wide[metric][alternative].astype(float) - wide[metric][baseline].astype(float)
        comparisons.append(dict(condition=condition, metric=metric,
                                alternative_minus_frozen_mean=float(delta.mean()),
                                scene_cluster_percentile_95=interval(delta)))

transitions = []
paired_changes = []
for frontend in [baseline, alternative]:
    group = frame[frame.frontend == frontend].set_index(['seed', 'condition'])
    for seed in scene_families.seed:
        nominal = group.loc[(seed, 'nominal')]
        for condition in sorted(frame.condition.unique()):
            if condition == 'nominal':
                continue
            changed = group.loc[(seed, condition)]
            transitions.append(dict(seed=int(seed), family=int(nominal.family), frontend=frontend,
                condition=condition, nominal_quality_failure=bool(nominal.quality_failure),
                changed_quality_failure=bool(changed.quality_failure),
                pass_to_failure=bool(not nominal.quality_failure and changed.quality_failure),
                failure_to_pass=bool(nominal.quality_failure and not changed.quality_failure),
                coverage_change=float(changed.coverage - nominal.coverage),
                changed_screen_accepts_failure=bool(changed.accepted_but_failed)))
    for condition in sorted(frame.condition.unique()):
        if condition == 'nominal':
            continue
        pairs = pd.DataFrame([r for r in transitions if r['frontend'] == frontend and r['condition'] == condition]).set_index('seed')
        paired_changes.append(dict(frontend=frontend, condition=condition,
            n_scene_pairs=len(pairs), pass_to_failure=int(pairs.pass_to_failure.sum()),
            failure_to_pass=int(pairs.failure_to_pass.sum()),
            mean_coverage_change=float(pairs.coverage_change.mean()),
            coverage_change_scene_cluster_95=interval(pairs.coverage_change)))
pd.DataFrame(transitions).to_csv(OUT/'transitions.csv', index=False)

summary = dict(scope='Stratified synthetic geometry and condition challenge. New renderer population; no inherited or newly asserted risk-card guarantee.',
    scene_count=int(frame.seed.nunique()), image_count=len(frame)//2,
    frontend_evaluations=len(frame), geometry_families=4,
    scene_holdout_families=[0, 1], structure_holdout_families=[2, 3],
    baseline=baseline, development_selected_frontend=alternative,
    bootstrap=dict(replicates=4000, seed=2026101805, unit='independent scene, stratified by geometry family; all paired conditions/providers retained',
                   interval='descriptive paired percentile 95%, not a simultaneous certification bound'),
    conditions=condition_rows, strata=strata, provider_comparisons=comparisons,
    paired_condition_changes=paired_changes,
    quality_event=dict(coverage_min=.8, residual_max_px=8., all_planned_site_mapping_max_m=.008),
    observable_screen=dict(matched_fraction_min=.8, residual_max_px=8.,
        interpretation='per-output screening comparator, not evidence of population risk; includes false acceptances where truth reveals incorrect matches or mapping'),
    maximum_blender_projection_error_px=float(frame.projection_check_px.max()))
(OUT/'summary.json').write_text(json.dumps(summary, indent=2, allow_nan=False))
print(json.dumps({k:v for k,v in summary.items() if k not in ('strata','provider_comparisons')}, indent=2))
