"""Paired archive-provider boundary audit; no new statistical observations."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import json,time,shutil
from pathlib import Path
import numpy as np,pandas as pd
from r8_protocol import ROOT,D,PROTOCOL,sha
from r8_evaluate import assert_freeze,runtime_bindings
from r8_contracts import Registry
from r8_service import load_models
from rcp.sensor import Mesh
from r8_policy import policies
from r8_geometry import geometry
from r8_routes import run

def strip_cpu(value):
    if isinstance(value,dict):return {k:strip_cpu(v) for k,v in value.items() if 'cpu_s' not in k}
    if isinstance(value,list):return [strip_cpu(v) for v in value]
    return value

def main():
    assert_freeze();models=load_models();clock=json.loads((D/'clock_profile.json').read_text())
    cards=json.loads((D/'event_cards.json').read_text());runtime=runtime_bindings();ps={p['id']:p for p in policies()}
    cf=pd.read_csv(D/'calibration.csv');table={(r.profile,r.service,r.policy):r.score_m2s for r in cf[cf.event=='trajectory'].itertuples()}
    rows=[];original=np.load;target=ROOT/'qa/r8/provider_audit';target.mkdir(exist_ok=True)
    for mesh,condition,rep,variant in [('B767','ordinary',0,'Fixed2'),('UnfittedAirframe','contention',0,'Full')]:
        source=D/'routes'/f'{mesh}_{condition}_{rep}';outputs=[]
        for mode in ['lazy','hydrated']:
            folder=target/f'{mesh}_{condition}_{rep}_{variant}_{mode}';folder.mkdir(exist_ok=True)
            if not (folder/'inputs.npz').exists():os.link(source/'inputs.npz',folder/'inputs.npz')
            shutil.copy2(source/'inputs_manifest.json',folder/'inputs_manifest.json')
            with original(folder/'inputs.npz') as archive:arrays={k:archive[k] for k in archive.files}
            def provider(path,*args,**kwargs):
                return arrays if Path(path)==folder/'inputs.npz' else original(path,*args,**kwargs)
            try:
                if mode=='hydrated':np.load=provider
                reg=Registry(cards,runtime);run(folder,mesh,condition,rep,variant,models,Mesh(geometry(mesh)).prior,clock,reg,table,ps)
            finally:np.load=original
            outputs.append(json.loads((folder/f'{variant}.json').read_text()))
        assert strip_cpu(outputs[0])==strip_cpu(outputs[1])
        with original(target/f'{mesh}_{condition}_{rep}_{variant}_lazy'/f'{variant}.npz') as a,original(target/f'{mesh}_{condition}_{rep}_{variant}_hydrated'/f'{variant}.npz') as b:
            assert a.files==b.files and all(np.array_equal(a[k],b[k],equal_nan=True) for k in a.files)
        rows.append({'mesh':mesh,'condition':condition,'rep':rep,'variant':variant,'numeric_jobs_publications_events_equal':True,
            'all_trace_capture_arrays_bitwise_equal':True,'input_sha256':sha(source/'inputs.npz'),
            'lazy_direct_online_cpu_s':outputs[0]['result']['direct_online_cpu_s'],
            'hydrated_direct_online_cpu_s':outputs[1]['result']['direct_online_cpu_s']})
    report={'status':'PASS','scope':'two paired implementation fixtures; four repeated executions; zero new independent route inputs',
        'frozen_executor_sha256':sha(ROOT/'source/r8_routes.py'),'provider_orchestrator_sha256':sha(ROOT/'source/r8_parallel_driver.py'),
        'audit_source_sha256':sha(__file__),'comparison_excludes_only_measured_cpu_fields':True,'checks':rows}
    (ROOT/'qa/r8/provider_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
if __name__=='__main__':main()
