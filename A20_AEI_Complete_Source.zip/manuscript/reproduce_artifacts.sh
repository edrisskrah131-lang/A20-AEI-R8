#!/usr/bin/env bash
set -euo pipefail
SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
PYTHON_BIN="${A20_PYTHON:-python}"
PYTHON_BIN="$("$PYTHON_BIN" -c 'import sys; print(sys.executable)')"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
REPRO_WORK="$(mktemp -d "${TMPDIR:-/tmp}/a20-reproduction.XXXXXXXX")"
cleanup() {
    if [[ "${A20_REPRO_KEEP:-0}" == 1 ]]; then
        printf 'Reproduction workspace retained: %s\n' "$REPRO_WORK"
    else
        "$PYTHON_BIN" -c 'import shutil,sys; shutil.rmtree(sys.argv[1])' "$REPRO_WORK"
    fi
}
trap cleanup EXIT
"$PYTHON_BIN" "$SOURCE_DIR/reporting/reproduce_workspace.py" prepare \
    --source "$SOURCE_DIR" --workspace "$REPRO_WORK/manuscript"
cd "$REPRO_WORK/manuscript"

# Recompute current numerical checks from archived inputs. These scripts only
# update verification reports in this isolated copy; original timing trials,
# calibration records, test images and provider-selection freezes are retained.
"$PYTHON_BIN" studies/lifecycle_campaign_20261018/verify.py
"$PYTHON_BIN" studies/inspection_challenge_20261018/rendering/verify.py
"$PYTHON_BIN" studies/inspection_challenge_20261018/analysis/check_legacy.py
"$PYTHON_BIN" studies/inspection_challenge_20261018/analysis/unit_checks.py
"$PYTHON_BIN" studies/inspection_challenge_20261018/analysis/verify.py

# Reprocess the earlier geometric pixels and numerical checks without rerunning
# measured timing trials or recalibrating any historical population.
"$PYTHON_BIN" studies/lifecycle_20261018/cold_check.py
"$PYTHON_BIN" studies/validated_recovery_20261018/verify.py
"$PYTHON_BIN" studies/decision_case_20261018/independent_check.py
"$PYTHON_BIN" studies/physical_render_20261018/verify.py

# Older figure/text recipes remain reproducible. Some rewrite derived metadata,
# which is why the complete workflow runs outside the original study archive.
"$PYTHON_BIN" reporting/build_complete_supplement.py
"$PYTHON_BIN" reporting/build_methodology_supplement.py
"$PYTHON_BIN" reporting/build_change_campaign.py
"$PYTHON_BIN" reporting/visual_revision.py
"$PYTHON_BIN" reporting/cad_surface_report.py
"$PYTHON_BIN" reporting/build_surface_supplement.py
"$PYTHON_BIN" reporting/lifecycle_report.py
"$PYTHON_BIN" reporting/lifecycle_supplement.py
"$PYTHON_BIN" reporting/integrated_report.py
"$PYTHON_BIN" reporting/integrated_supplement.py
"$PYTHON_BIN" reporting/completion_report.py
"$PYTHON_BIN" reporting/completion_supplement.py
bash build.sh
"$PYTHON_BIN" reporting/verify_lifecycle.py
"$PYTHON_BIN" reporting/verify_visual_revision.py
"$PYTHON_BIN" reporting/verify_integrated.py
"$PYTHON_BIN" reporting/verify_citations.py
"$PYTHON_BIN" reporting/verify_completion.py

# Publish documents and their QA only after success; never copy studies back.
"$PYTHON_BIN" reporting/reproduce_workspace.py publish \
    --source "$SOURCE_DIR" --workspace "$REPRO_WORK/manuscript"
