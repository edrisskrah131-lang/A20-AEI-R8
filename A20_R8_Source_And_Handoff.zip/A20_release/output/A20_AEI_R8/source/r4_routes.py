"""Fresh complete closed-loop inspection routes, with deadline task observations."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import json,time,sys
import numpy as np,pandas as pd
from r4_protocol import ROOT,D,PROTOCOL,sha
from checkpoint import WORK,CheckpointICP,CompactTree
from rcp.core import JointState,exp,log,propagate
from rcp.sensor import Mesh
from r4_collect import sensor
from r4_policy import Forecast,act
from train import initial_cov
A19=WORK/'work/a19/RAS_A19';R=D/'routes';R.mkdir(exist_ok=True)
PROTO={'version':'R4-recovery-complete-route-3','geometries':['B767','C172','ProceduralAirframe'],'seed_formula':'5700000 + replicate + 10000*geometry_index','duration_s':600.,'dt_s':.1,'scan_interval_s':2.,'load':20.,'queue_s':.05,'capture_deadline_s':.3,'path':'Full previously declared geometric route resampled over 600s with cyclic seed offset','noise':[1.,2.,2.],'shape_level':[0,1,2],'initial_sd_m':.03,'controls':['selected_KG','KG1','Fixed2','Fixed4','Final','FlatRF','ContractRF','selected_KG_held','selected_KG_no_profile','selected_KG_no_deadline','KG1_held','KG1_no_profile','KG1_no_deadline'],'reliability':'Complete-route descriptive results; episode certificate does not certify the mission'}
def geometry(m):return D/'geometry' if m=='ProceduralAirframe' else A19/f'meshes/{m}'
def route_inputs(m,rep):
 folder=R/f'{m}_{rep}';folder.mkdir(exist_ok=True);p=folder/'inputs.npz'
 if p.exists():return p
 seed=5700000+rep+10000*PROTO['geometries'].index(m);rng=np.random.default_rng(seed);mesh=Mesh(geometry(m)/f'world_discrepancy_{rep}.npz')
 old=np.load(geometry(m)/'route.npz')['pose'];n=6000;idx=(np.arange(n)*len(old)/n+rep*len(old)/3)%len(old);lo=idx.astype(int);hi=(lo+1)%len(old);a=idx-lo
 truth=old[lo]*(1-a[:,None])+old[hi]*a[:,None]
 # interpolate periodic yaw without wrapping through an artificial rotation.
 dy=np.angle(np.exp(1j*(old[hi,5]-old[lo,5])));truth[:,5]=old[lo,5]+a*dy
 inc=np.zeros((n,6))
 for i in range(1,n):inc[i]=np.r_[(truth[i,:3]-truth[i-1,:3])@exp(truth[i-1,3:]),log(exp(truth[i-1,3:]).T@exp(truth[i,3:]))]
 bias=np.zeros((n,6));bias[0]=rng.normal(0,np.r_[np.full(3,.0015),np.full(3,.00015)])
 for i in range(1,n):bias[i]=np.exp(-.1/125)*bias[i-1]+rng.normal(0,np.r_[np.full(3,.0015),np.full(3,.00015)])*np.sqrt(1-np.exp(-.2/125))
 observed=inc+bias*.1+rng.normal(0,np.sqrt(.1)*np.r_[np.full(3,.004),np.full(3,.0004)],(n,6))
 mt=rng.normal(0,.025,3);mR=exp(rng.normal(0,.001,3));prior=JointState(truth[0,:3]+rng.normal(0,.03,3),exp(rng.normal(0,.006,3))@exp(truth[0,3:]),np.zeros(6),np.zeros(3),np.eye(3),initial_cov(.03))
 clouds=[];offsets=[0];raws=[];rawdt=[];raw_offsets=[0];frames=[];front=[]
 for i in range(20,n,20):
  causal=observed[max(1,i-4):i+1].mean(0)/.1
  cloud,cpu,raw,dt=sensor(mesh,truth[i],inc[min(i+1,n-1)]/.1,seed*100000+i,i*.1,mt,mR,causal,PROTO['noise'][rep])
  clouds.append(cloud);offsets.append(offsets[-1]+len(cloud));raws.append(raw);rawdt.append(dt);raw_offsets.append(raw_offsets[-1]+len(raw));frames.append(i);front.append(cpu)
 np.savez_compressed(p,truth=truth,increment=observed,map_t=mt,map_R=mR,xyz=np.concatenate(clouds),offsets=offsets,frames=frames,front_cpu=front,raw=np.concatenate(raws),raw_dt=np.concatenate(rawdt),raw_offsets=raw_offsets,prior_t=prior.t,prior_R=prior.R,prior_bias=prior.bias,prior_mt=prior.mt,prior_mR=prior.mR,prior_P=prior.P)
 (folder/'manifest.json').write_text(json.dumps({'seed':seed,'geometry':m,'level':rep,'noise':PROTO['noise'][rep],'inputs_sha256':sha(p),'generator_sha256':sha(__file__),'sensor_sha256':sha(ROOT/'source/r4_collect.py'),'provenance':'NEW_CAUSAL_GEOMETRIC_SIMULATION'},indent=2));print('R4_ROUTE_INPUT',m,rep,flush=True)
 return p
def error(s,truth,mt,mR):return float(np.linalg.norm((s.t-s.mt)@s.mR-(truth[:3]-mt)@mR))
def registration(prior_map,cloud,s,m,noise,policy,models,front):
 start=time.process_time_ns();solver=CheckpointICP(prior_map,cloud,s,0);pubs=[];dec=0.;trace=[];last=None
 r={'mesh':m,'noise':noise,'seed':0,'front_cpu_s':front}
 while not solver.done:
  post,stats,f=solver.advance();last=stats;ss=dict(**stats,feature=f.tolist(),cpu_total_s=(time.process_time_ns()-start)*1e-9)
  t=time.process_time_ns();pub,halt,details=act(r,ss,policy,models.get(policy['model']),load=20.,paid=front+ss['cpu_total_s']);dec+=(time.process_time_ns()-t)*1e-9
  trace.append(dict(iteration=stats['iteration'],published=pub,halt=halt,**details))
  if pub:pubs.append((post.copy(),front+(time.process_time_ns()-start)*1e-9,stats['iteration']))
  if halt:break
 paid=front+(time.process_time_ns()-start)*1e-9
 if last['done'] and not last['accepted'] and pubs:pubs.append((s.copy(),paid,0))
 return pubs,{'cpu_s':paid,'solver_cpu_s':solver.solver_cpu,'decision_cpu_s':dec,'front_cpu_s':front,'iterations':solver.it,'trace':trace}
def run(m,rep,policy,models,prior_map,held=False):
 name=policy['id']+('_held' if held else '');folder=R/f'{m}_{rep}';out=folder/f'{name}.json'
 if out.exists():return json.loads(out.read_text())['result']
 z=np.load(folder/'inputs.npz');s=JointState(*(z['prior_'+k] for k in ['t','R','bias','mt','mR','P']));truth=z['truth'];inc=z['increment'];mt=z['map_t'];mR=z['map_R']
 cs={int(f):i for i,f in enumerate(z['frames'])};pending=None;jobs=[];captures=[];trace=[];events=[];prop=reg=replay=0.;dropped=0
 for i in range(len(truth)):
  if i:
   t=time.process_time_ns();s=propagate(s,.1,inc[i]);prop+=(time.process_time_ns()-t)*1e-9
  if pending is not None:
   while pending['pubs'] and pending['pubs'][0][0]<=i:
    item=pending['pubs'][0];arrival,post,it,prefix,lasttick=item;t=time.process_time_ns();cur=post.copy()
    for tick in range(lasttick+1,i+1):cur=propagate(cur,.1,inc[tick])
    used=(time.process_time_ns()-t)*1e-9;replay+=used;pending['replay_cpu']+=used
    completed=pending['source']+max(1,int(np.ceil((.05+20*(prefix+pending['replay_cpu']))/.1)))
    if completed>i:
     pending['pubs'][0]=(completed,cur,it,prefix,i);break
    pending['pubs'].pop(0);s=cur;pending['version']=it;events.append([pending['source'],i,it])
   if i==pending['source']+3:
    e=error(s,truth[i],mt,mR);ready=pending['version']>0;captures.append([pending['source'],int(ready),int(ready and e<=.1),e])
   if i>=pending['end'] and not pending['pubs'] and i>=pending['source']+3 and i*.1>=pending['source']*.1+.05+20*(pending['paid']+pending['replay_cpu']):pending=None
  if i in cs:
   if pending is not None:dropped+=1;captures.append([i,0,0,error(s,truth[i],mt,mR)])
   else:
    ix=cs[i];cloud=z['xyz'][z['offsets'][ix]:z['offsets'][ix+1]];front=float(z['front_cpu'][ix])
    pubs,stats=registration(prior_map,cloud,s,m,PROTO['noise'][rep],policy,models,front);reg+=stats['cpu_s']
    if held and pubs:post,c,it=pubs[-1];pubs=[(post,stats['cpu_s'],it)]
    delivered=[(i+max(1,int(np.ceil((.05+20*c)/.1))),post,it,c,i) for post,c,it in pubs]
    pending={'source':i,'end':i+max(1,int(np.ceil((.05+20*stats['cpu_s'])/.1))),'pubs':delivered,'version':0,'replay_cpu':0.,'paid':stats['cpu_s']};jobs.append({'source':i,**stats})
  e=error(s,truth[i],mt,mR);trace.append([i*.1,e,*s.t])
 arr=np.asarray(trace);e=arr[:,1];cap=np.asarray(captures);result={'mesh':m,'rep':rep,'policy':name,'duration_s':600.,'calls':len(jobs),'dropped':dropped,'opportunities':len(cs),'capture_ready':int(cap[:,1].sum()),'capture_success':int(cap[:,2].sum()),'rmse_cm':float(np.sqrt(np.mean(e**2))*100),'p95_cm':float(np.quantile(e,.95)*100),'max_cm':float(e.max()*100),'event_after_5s':int(np.any(e[50:]>.1)), 'loss_m2s':float(np.sum(e**2)*.1),'cpu_s':prop+reg+replay,'prop_cpu_s':prop,'correction_cpu_s':reg,'replay_cpu_s':replay,'front_cpu_s':sum(j['front_cpu_s'] for j in jobs),'decision_cpu_s':sum(j['decision_cpu_s'] for j in jobs),'mean_iterations':float(np.mean([j['iterations'] for j in jobs]))}
 np.savez_compressed(folder/f'{name}.npz',trace=arr,captures=cap)
 out.write_text(json.dumps({'result':result,'jobs':jobs,'publications':events},indent=2));print('R4_ROUTE',m,rep,name,'RMSE_cm',round(result['rmse_cm'],3),'ready',result['capture_ready'],'CPU',round(result['cpu_s'],3),flush=True);return result
def main():
 (D/'route_protocol.json').write_text(json.dumps(PROTO,indent=2))
 if '--collect' in sys.argv:
  for m in PROTO['geometries']:
   for rep in range(3):route_inputs(m,rep)
  return
 freeze=json.loads((D/'freeze.json').read_text());selected='KG1'
 policies=[p for p in freeze['policies'] if p['id'] in [selected,'KG1','Fixed2','Fixed4','Final','FlatRF','ContractRF']]
 policies+= [p for p in freeze['ablations'] if p['id'].startswith(selected+'_') or p['id'].startswith('KG1_')]
 models={'cart':Forecast(D/'cart_forecast.npz'),'rf':Forecast(D/'rf_forecast.npz'),'old':CompactTree(ROOT/'data/checkpoint_model.npz')};maps={m:Mesh(geometry(m)/'world_discrepancy_0.npz') for m in PROTO['geometries']}
 tasks=[(m,rep,p,False) for m in PROTO['geometries'] for rep in range(3) for p in policies];tasks +=[(m,rep,p,True) for m in PROTO['geometries'] for rep in range(3) for p in policies if p['id'] in [selected,'KG1']]
 np.random.default_rng(202610115).shuffle(tasks);results=[]
 for m,rep,p,held in tasks:
  results.append(run(m,rep,p,models,maps[m].prior,held));pd.DataFrame(results).sort_values(['mesh','rep','policy']).to_csv(D/'route_results.csv',index=False)
 print('R4_ROUTES_COMPLETE',len(results),selected,flush=True)
if __name__=='__main__':main()
