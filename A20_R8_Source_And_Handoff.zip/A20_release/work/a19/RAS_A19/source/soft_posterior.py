"""Finite latent-record model with calibrated binary observation likelihoods.

Reliability is a statistical prototype-matching parameter, not sensor accuracy.
At reliability=1 this recovers the hard empirical-posterior model.
"""
from itertools import product
import numpy as np
from sequential import Planner


class SoftPlanner(Planner):
    def __init__(self, *args, reliability=1., **kwargs):
        self.reliability = float(reliability)
        if not .5 <= self.reliability <= 1.:
            raise ValueError('reliability must be between 0.5 and 1')
        super().__init__(*args, **kwargs)

    def masses(self, state):
        w = np.ones(len(self.losses), dtype=float) / len(self.losses)
        r = self.reliability
        for q, z in enumerate(state):
            if z >= 0:
                w *= np.where(self.observations[:, q] == z, r, 1-r)
        return w

    def subset(self, state):
        return np.flatnonzero(self.masses(state) > 0)

    def belief(self, state):
        w = self.masses(state)
        if w.sum() == 0:
            raise ValueError('unsupported observation history')
        return w / w.sum()

    def stop(self, state, ids=None, spent=None):
        spent = self.spent(state) if spent is None else spent
        menu = self.menu(spent)
        # Parent posterior is retained in the inherited unsupported-history path.
        w = self.belief(state)
        means = w @ self.losses[:, menu]
        j = int(np.argmin(means))
        return float(means[j]), int(menu[j])

    def _solve(self, state):
        self.stats['states'] += 1
        w = self.belief(state)
        spent = self.spent(state)
        best, action = self.stop(state, spent=spent)
        decision = ('stop', action)
        for q, z in enumerate(state):
            if z >= 0:
                continue
            after = spent + int(self.query_costs[q])
            menu = self.menu(after)
            if not len(menu) or (self.reserve_full and after+max(self.costs)>self.budget):
                continue
            self.stats['queries'] += 1
            charge = self.price*self.query_costs[q]
            optimistic = charge + w @ self.losses[:, menu].min(axis=1)
            if self.prune and optimistic >= best-1e-14:
                self.stats['pruned'] += 1
                continue
            risk = charge
            for outcome in (0, 1):
                probability = w @ np.where(self.observations[:, q] == outcome,
                                           self.reliability, 1-self.reliability)
                if probability <= 0:
                    continue
                child = list(state); child[q] = outcome; child = tuple(child)
                future = self.stop(child)[0] if self.myopic else self.solve(child)[0]
                risk += probability*future
            if risk < best-1e-14:
                best, decision = float(risk), ('query', q)
        return best, decision

    def fixed_subset(self):
        best, _ = self.stop(self.root)
        chosen = ()
        for bits in range(1, 1 << self.q):
            queries = tuple(q for q in range(self.q) if bits & (1 << q))
            spent = int(self.query_costs[list(queries)].sum())
            if not len(self.menu(spent)):
                continue
            risk = self.price*spent
            for outcomes in product((0, 1), repeat=len(queries)):
                state = [-1]*self.q
                for q, z in zip(queries, outcomes):
                    state[q] = z
                state = tuple(state)
                mass = self.masses(state).sum()
                if mass:
                    risk += mass*self.stop(state)[0]
            if risk < best-1e-14:
                best, chosen = float(risk), queries
        return best, chosen

    def execute_fixed(self, queries, observe):
        state = [-1]*self.q
        for q in queries:
            state[q] = int(observe(q))
        state = tuple(state)
        missing = not len(self.subset(state))
        belief_state = self.root if missing else state
        return self.stop(belief_state, spent=self.spent(state))[1], self.spent(state), list(queries), missing
