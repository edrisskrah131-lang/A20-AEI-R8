"""Procedural aircraft-like mesh; no proprietary CAD or real measurements."""
import numpy as np,json
from r4_protocol import D,sha
def build():
 folder=D/'geometry';folder.mkdir(exist_ok=True)
 if (folder/'world_discrepancy_0.npz').exists():return
 vertices=[];faces=[];names=[]
 def ellipsoid(center,radii,nu=64,nv=64,name='metal'):
  base=len(vertices)
  for i in range(nu):
   u=np.pi*(i+.5)/nu
   for j in range(nv):
    v=2*np.pi*j/nv
    vertices.append(np.asarray(center)+np.asarray(radii)*[np.cos(u),np.sin(u)*np.cos(v),np.sin(u)*np.sin(v)])
  for i in range(nu-1):
   for j in range(nv):
    a=base+i*nv+j;b=base+i*nv+(j+1)%nv;c=a+nv;d=b+nv
    faces.extend([[a,b,c],[b,d,c]]);names.extend([name,name])
  for i in [0,nu-1]:
   for j in range(1,nv-1):
    f=[base+i*nv,base+i*nv+j,base+i*nv+j+1]
    faces.append(f[::-1] if i==0 else f);names.append(name)
 def solid(points,name='metal'):
  # Convex finite-thickness components, outward normals from their centroid.
  from scipy.spatial import ConvexHull
  base=len(vertices);p=np.asarray(points,float);vertices.extend(p);h=ConvexHull(p)
  for f in h.simplices:
   t=p[f];normal=np.cross(t[1]-t[0],t[2]-t[0])
   if normal@(t.mean(0)-p.mean(0))<0:f=f[::-1]
   faces.append((f+base).tolist());names.append(name)
 ellipsoid([0,0,2.65],[14.2,1.85,1.85])
 for sign in [-1,1]:
  solid([[x,sign*y,z] for x,y in [(3,1.3),(-3,1.3),(-6.2,12.5),(-3.5,12.5)] for z in [2.3,2.5]])
  solid([[x,sign*y,z] for x,y in [(-10,1),(-13.5,1),(-13.5,5.2),(-11.7,5.2)] for z in [3,3.2]])
  ellipsoid([-1,sign*5.2,1.6],[2.25,.7,.7],24,48)
 solid([[-9.5,y,3] for y in [-.12,.12]]+[[-13.3,y,3] for y in [-.12,.12]]+[[-12.5,y,7.3] for y in [-.12,.12]]+[[-11.5,y,7.3] for y in [-.12,.12]])
 v=np.asarray(vertices);f=np.asarray(faces,np.int32);t=v[f];n=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);area=np.linalg.norm(n,axis=1)/2;n/=np.maximum(2*area[:,None],1e-15)
 center=np.zeros(3);vn=np.zeros_like(v)
 for j in range(3):np.add.at(vn,f[:,j],n*area[:,None])
 vn/=np.maximum(np.linalg.norm(vn,axis=1)[:,None],1e-12)
 for level in range(3):
  delta=0 if level==0 else (.012 if level==1 else .03)
  warp=delta*(np.sin(v[:,0]*.31)+.6*np.cos(v[:,1]*.41))
  vv=v+warp[:,None]*vn;t=vv[f];nn=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);aa=np.linalg.norm(nn,axis=1)/2;nn/=np.maximum(2*aa[:,None],1e-15)
  np.savez_compressed(folder/f'world_discrepancy_{level}.npz',vertices=vv,faces=f,normals=nn,area=aa,names=np.asarray(names))
 # Dense, unwrapped walk-around trajectory, 1980 seconds at 10 Hz.
 time=np.arange(19800)*.1;theta=2*np.pi*time/500
 pos=np.c_[18*np.cos(theta),16*np.sin(theta),np.ones(len(time))*.85]
 yaw=np.unwrap(np.arctan2(-pos[:,1],-pos[:,0]));pose=np.c_[pos,np.zeros((len(time),2)),yaw]
 np.savez_compressed(folder/'route.npz',pose=pose)
 (folder/'manifest.json').write_text(json.dumps({'vertices':len(v),'faces':len(f),'generation':'procedural ellipsoid and convex finite-thickness airframe components','hashes':{p.name:sha(p) for p in folder.glob('*.npz')},'excluded_from_forecast_fitting':True},indent=2))
if __name__=='__main__':build()
