"""Fit on development data; freeze; calibrate and confirm paired policies."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json,time,hashlib,math,pickle
import numpy as np
import pandas as pd
from scipy.stats import beta
from sklearn.tree import DecisionTreeRegressor
from checkpoint import ROOT,WORK,CompactTree,decision
from rcp.core import JointState,propagate

D=ROOT/'data'
rows=[json.loads(l) for l in (D/'episodes.jsonl').read_text().splitlines()]
assert len(rows)==1120
assert len(set(r['seed'] for r in rows))==len(rows)
expected_phases={'train':480,'validation':120,'calibration':160,'confirmation':240,'stress':120}
assert {p:sum(r['phase']==p for r in rows) for p in expected_phases}==expected_phases
train=[r for r in rows if r['phase']=='train'];val=[r for r in rows if r['phase']=='validation']

def features_and_labels(rr):
    x=[];y=[];groups=[]
    for r in rr:
        errors=np.array(r['error']);mse=(errors[:,5:]**2).mean(1);tail=(errors[:,5:]>.1).any(1).astype(float)
        final=len(errors)-1
        for j,s in enumerate(r['trace'],1):
            x.append(s['feature']);y.append([mse[j],mse[final],tail[j],tail[final],max(r['cpu_s']-s['cpu_total_s'],0.),mse[j]-mse[0]])
            groups.append(r['seed'])
    return np.array(x),np.array(y),np.array(groups)
X,Y,_=features_and_labels(train);V,Z,_=features_and_labels(val)
scale=np.maximum(Y.std(0),[1e-4,1e-4,.1,.1,.001,1e-4]);candidates=[]
for depth in [4,6,8]:
    model=DecisionTreeRegressor(max_depth=depth,min_samples_leaf=24,random_state=20261011)
    model.fit(X,Y/scale);pred=model.predict(V)*scale
    error=float(np.mean(((pred-Z)/scale)**2));candidates.append((error,depth,model))
error,depth,model=min(candidates,key=lambda x:x[0]);t=model.tree_
np.savez_compressed(D/'checkpoint_model.npz',left=t.children_left,right=t.children_right,feature=t.feature,threshold=t.threshold,value=t.value[:,:,0]*scale)
compact=CompactTree(D/'checkpoint_model.npz')
assert np.max(np.abs(np.array([compact.predict(v) for v in V])-model.predict(V)*scale))<1e-10

# Online propagation primitive benchmark excludes offline ground-truth metrics.
times=[]
for r in train[:30]:
    z=np.load(D/f"episode_inputs/{r['seed']}.npz")
    s=JointState(*(z['prior_'+k] for k in ['t','R','bias','mt','mR','P']))
    begin=time.process_time_ns()
    for inc in z['increment']:s=propagate(s,.1,inc)
    times.append((time.process_time_ns()-begin)*1e-9/40)
step_cpu=float(np.median(times))
policies=[]
for price in [.03,.1,.3,1.]:
    for tail in [.05,.15,.3]:policies.append(dict(id=f'learned_p{price:g}_r{tail:g}',method='learned',price=price,tail_limit=tail))
for method in ['fixed_1','fixed_2','fixed_4','fixed_8','fixed_16','final','residual','all_release']:
    policies.append(dict(id=method,method=method,price=0.,tail_limit=1.))
freeze=dict(version='R3-frozen-policy-family-1',n_train=len(train),n_validation=len(val),tree_depth=depth,
    validation_scores=[{'depth':d,'score':e} for e,d,_ in candidates],n_nodes=int(t.node_count),
    model_sha256=hashlib.sha256((D/'checkpoint_model.npz').read_bytes()).hexdigest(),policies=policies,
    solver_sha256=hashlib.sha256((ROOT/'source/checkpoint.py').read_bytes()).hexdigest(),
    evaluation_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    independent_motion_step_cpu_s=step_cpu,decision_latency='measured compact-tree traversal CPU; policy-specific',
    risk_interval_s=[.5,4.],risk_position_m=.1,family_error=.05,context_count=2)
(D/'frozen_policies.json').write_text(json.dumps(freeze,indent=2))

def evaluate(r,policy,multiplier,queue=.05,held=False,no_stop=False):
    publications=[];decision_cpu=0.;current=0;stop_index=len(r['trace'])-1
    for i,stats in enumerate(r['trace']):
        begin=time.process_time_ns();method=policy['method']
        if method=='learned':pub,halt,_=decision(compact,np.asarray(stats['feature']),stats,policy['price'],policy['tail_limit'],stop=not no_stop)
        elif method=='residual':pub=stats['eligible'];halt=bool(stats['done'] or (stats['eligible'] and stats['iteration']>=2))
        elif method.startswith('fixed_'):halt=bool(stats['done'] or stats['iteration']>=int(method.split('_')[1]));pub=bool(halt and stats['eligible'])
        else:halt=stats['done'];pub=bool((method=='all_release' and stats['eligible']) or (stats['done'] and stats['accepted']))
        decision_cpu+=(time.process_time_ns()-begin)*1e-9
        c=stats['cpu_total_s']+decision_cpu
        if pub:current=i+1;publications.append((current,c))
        if halt:stop_index=i;break
    last=r['trace'][stop_index]
    if last['done'] and not last['accepted'] and publications:
        current=0;publications.append((0,last['cpu_total_s']+decision_cpu))
    paid=last['cpu_total_s']+decision_cpu
    if held and publications:publications=[(current,paid)]
    delivery=[]
    for index,c in publications:
        tick=max(1,int(np.ceil((queue+multiplier*c)/.1)));delivery.append((tick,index))
    error=np.array(r['error']);rot=np.array(r['rotation_error']);active=np.zeros(41,dtype=int)
    for tick,index in delivery:
        if tick<=40:active[tick:]=index
    pe=error[active,np.arange(41)];re=rot[active,np.arange(41)]
    replay_ticks=sum(tick for tick,index in delivery if tick<=40)
    # Primitive replay count is exact; its per-step CPU is independently measured.
    propagation_cpu=40*step_cpu;replay_cpu=replay_ticks*step_cpu
    return dict(seed=r['seed'],phase=r['phase'],mesh=r['mesh'],level=r['level'],noise=r['noise'],sd=r['sd'],
        policy=policy['id'],runtime_multiplier=multiplier,solver_cpu_s=last['cpu_total_s'],decision_cpu_s=decision_cpu,
        propagation_cpu_s=propagation_cpu,replay_cpu_s=replay_cpu,cpu_total_s=paid+propagation_cpu+replay_cpu,
        integrated_position_mse_m2s=float(np.sum(pe[1:]**2)*.1),exposure_0p5_m2s=float(np.sum(pe[1:6]**2)*.1),
        episode_rmse_m=float(np.sqrt(np.mean(pe[5:]**2))),rotation_rmse_rad=float(np.sqrt(np.mean(re[5:]**2))),
        failure=int(np.any(pe[5:]>.1)),final_error_m=float(pe[-1]),stop_iteration=last['iteration'],
        checkpoints=stop_index+1,publications=len(publications),delivery_last_s=max([tick*.1 for tick,index in delivery],default=0.),
        provenance='PAIRED_GEOMETRIC_EPISODE_REPLAY')

records=[]
for phase in ['validation','calibration','confirmation','stress']:
    rr=[r for r in rows if r['phase']==phase]
    for r in rr:
        for multiplier in [1.,10.]:
            for policy in policies:records.append(evaluate(r,policy,multiplier))
    print('EVALUATED',phase,len(rr),flush=True)
frame=pd.DataFrame(records);frame.to_csv(D/'policy_episode_results.csv',index=False)
cal=frame[frame.phase=='calibration'];cal_summary=[];K=len(policies)*cal.runtime_multiplier.nunique()
for (mult,policy),g in cal.groupby(['runtime_multiplier','policy']):
    n=len(g);assert n==expected_phases['calibration'] and g.seed.nunique()==n
    k=int(g.failure.sum());u=1. if k==n else float(beta.ppf(1-.05/K,k+1,n-k))
    cal_summary.append(dict(runtime_multiplier=mult,policy=policy,n=n,k=k,failure_rate=k/n,upper_risk=u,mean_cpu_s=float(g.cpu_total_s.mean())))
cal_summary=pd.DataFrame(cal_summary);cal_summary.to_csv(D/'risk_calibration.csv',index=False)
selection=[]
for mult in [1.,10.]:
    c=cal_summary[cal_summary.runtime_multiplier==mult]
    for delta in [.05,.075,.1,.15,.2,.3]:
        for family in ['learned','baseline']:
            q=c[c.policy.str.startswith('learned') if family=='learned' else ~c.policy.str.startswith('learned')]
            q=q[q.upper_risk<=delta]
            if q.empty:selection.append(dict(runtime_multiplier=mult,delta=delta,family=family,policy=None,status='infeasible'))
            else:
                best=q.sort_values(['mean_cpu_s','policy']).iloc[0]
                selection.append(dict(runtime_multiplier=mult,delta=delta,family=family,policy=best.policy,status='certified',upper_risk=float(best.upper_risk)))
(D/'policy_selection.json').write_text(json.dumps(selection,indent=2))

summary=[]
for (phase,mult,mesh,policy),g in frame.groupby(['phase','runtime_multiplier','mesh','policy']):
    summary.append(dict(phase=phase,runtime_multiplier=mult,mesh=mesh,policy=policy,n=len(g),
        mean_cpu_ms=float(g.cpu_total_s.mean()*1000),mean_registration_cpu_ms=float(g.solver_cpu_s.mean()*1000),
        mean_decision_cpu_ms=float(g.decision_cpu_s.mean()*1000),failure_rate=float(g.failure.mean()),
        mean_episode_rmse_m=float(g.episode_rmse_m.mean()),position_loss_m2s=float(g.integrated_position_mse_m2s.mean()),
        exposure_0p5_m2s=float(g.exposure_0p5_m2s.mean()),mean_stop_iteration=float(g.stop_iteration.mean())))
pd.DataFrame(summary).to_csv(D/'policy_summary.csv',index=False)

# Attribution ablations are applied only after selecting the main learned policy;
# they are diagnostic interventions, not extra candidate policies for selection.
ablations=[]
for mult in [1.,10.]:
    chosen=next(s for s in selection if s['runtime_multiplier']==mult and s['delta']==.15 and s['family']=='learned')
    if not chosen['policy']:continue
    p=next(p for p in policies if p['id']==chosen['policy'])
    for r in [r for r in rows if r['phase']=='confirmation']:
        for name,held,no_stop in [('selected',False,False),('hold_publication',True,False),('continue_to_completion',False,True)]:
            z=evaluate(r,p,mult,held=held,no_stop=no_stop);z['ablation']=name;ablations.append(z)
pd.DataFrame(ablations).to_csv(D/'checkpoint_ablations.csv',index=False)

# Held-out calibration quality is source-grouped in reporting and figure code.
Q,R,G=features_and_labels([r for r in rows if r['phase']=='confirmation'])
P=np.array([compact.predict(q) for q in Q]);np.savez_compressed(D/'prediction_confirmation.npz',prediction=P,target=R,seed=G)
audit=dict(new_cases=len(rows),new_independent_seeds=len(set(r['seed'] for r in rows)),
    final_state_max_error=max(r['state_delta'] for r in rows),final_covariance_max_error=max(r['covariance_delta'] for r in rows),
    n_train=480,n_validation=120,n_calibration=160,n_confirmation=240,n_stress=120,
    learned_policy_count=12,baseline_policy_count=8,simultaneous_context_policy_count=40,
    propagation_step_cpu_s=step_cpu,tree_nodes=int(t.node_count),real_robot_trials=0)
(D/'audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps({'audit':audit,'selection':selection},indent=2),flush=True)
