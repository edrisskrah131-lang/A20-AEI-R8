"""Publication figures and tables, generated only from recorded calculations."""
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from PIL import Image,ImageOps
from audit_panel_alignment import require_matplotlib_panel_alignment
from reuse import ReusePlanner,QUANTUM

ROOT=Path(__file__).resolve().parents[1]; F=ROOT/'figures'; F.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8,'axes.titlesize':9,
    'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,'axes.spines.top':False,
    'axes.spines.right':False,'axes.linewidth':.6,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none'})
COL={'full':'#53616D','coarse':'#CA963F','fixed':'#725BA7','joint':'#007F86','myopic':'#B06A40',
     'reserve':'#667366','no_reuse':'#AC5260','oracle':'#333333'}
LABEL={'full':'Full','coarse':'Coarse','fixed':'Fixed','joint':'Reuse-DP','myopic':'Myopic',
       'reserve':'Reserve','no_reuse':'Discard'}
def save(fig,name):
    require_matplotlib_panel_alignment(fig,json_out=F/(name+'.alignment.json'))
    for ext in ['pdf','svg','png']:fig.savefig(F/(name+'.'+ext),dpi=220)
    plt.close(fig)
def panel(ax,letter,title):
    ax.set_title(title,loc='left',pad=10)
    ax.text(-.16,1.065,letter,transform=ax.transAxes,fontweight='bold',fontsize=10,va='bottom')
def grid(nr=1,nc=2,height=2.9):
    fig,axs=plt.subplots(nr,nc,figsize=(7.09,height),squeeze=False)
    fig.subplots_adjust(left=.10,right=.975,bottom=.16 if nr==1 else .10,top=.88 if nr==1 else .92,wspace=.38,hspace=.65)
    return fig,axs

def architecture():
    fig=plt.figure(figsize=(7.09,3.8));ax=fig.add_axes([.01,.02,.98,.96]);ax.set(xlim=(0,10),ylim=(0,6));ax.axis('off')
    def box(x,y,w,h,t,color='#EAF3F3'):
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.05,rounding_size=.06',lw=.7,ec='#59717B',fc=color))
        ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=8)
    def arrow(a,b,color='#4E6570',style='-'):
        ax.annotate('',b,a,arrowprops=dict(arrowstyle='-|>',lw=.85,color=color,linestyle=style))
    ax.text(.1,5.75,'ONE REGISTRATION, TWO PRODUCTS',fontsize=10,fontweight='bold',color='#006F77')
    box(.15,4.35,2.25,.8,'Received cloud + map\nPose / covariance prior')
    box(3.05,4.35,2.35,.8,'Compiled policy\nContext, history, credit')
    box(6.1,4.35,3.65,.8,'Probe a candidate or stop\nStrict / Tempered / Converged')
    arrow((2.45,4.75),(3,4.75));arrow((5.45,4.75),(6.05,4.75))
    box(6.1,2.65,1.62,.95,'Acceptance bit\nUpdate belief')
    box(8.1,2.65,1.65,.95,'Candidate pose\nStore in cache')
    arrow((7,4.3),(6.9,3.65));arrow((8.9,4.3),(8.9,3.65))
    arrow((6.05,3.55),(5.35,4.3))
    box(.15,2.55,4.6,1.0,'Shared computation ledger\nProbe: pay once. Cached terminal: pay zero.\nUncached terminal: reserve its remaining cost.','#F4F0E7')
    box(3.05,.65,3.9,1.0,'Dispatch selected correction\nUse cache or execute uncached action')
    box(7.55,.65,2.2,1.0,'Publish after delivery\nReplay motion increments')
    arrow((8.9,2.6),(6.6,1.7));arrow((4.2,2.5),(4.2,1.7));arrow((7,1.15),(7.5,1.15))
    ax.text(.15,.08,'Offline: paired action outcomes → conditional loss model → exact finite policy table',fontsize=8,color='#53616D')
    save(fig,'architecture')

def platform():
    fig,axs=plt.subplots(2,2,figsize=(7.09,5.5));fig.subplots_adjust(left=.085,right=.985,bottom=.10,top=.94,wspace=.25,hspace=.45)
    for ax,name,letter,title in zip(axs[0],['platform_lab.jpeg','aircraft_field.jpeg'],'ab',['Laboratory platform','Aircraft operating context']):
        im=Image.open(ROOT/'assets'/name);im=ImageOps.fit(im,(1000,650))
        ax.imshow(im,aspect='auto');ax.axis('off');panel(ax,letter,title)
    for ax,mesh,letter in zip(axs[1],['B767','C172'],'cd'):
        v=np.load(ROOT/f'meshes/{mesh}/airframe_mesh.npz')['vertices'];p=np.load(ROOT/f'meshes/{mesh}/route.npz')['pose']
        ax.scatter(v[::3,0],v[::3,1],s=.09,color='#AAB7BE',rasterized=True)
        ax.plot(p[:,0],p[:,1],lw=.9,color=COL['joint']);ax.scatter(*p[0,:2],marker='o',s=20,c='#CA963F',zorder=5)
        ax.set(xlabel='x (m)',ylabel='y (m)');panel(ax,letter,f'{mesh}: 33-minute route')
        # Equal data units within fixed, aligned panels, by adjusting data limits.
        ax.set_aspect('equal',adjustable='datalim')
    save(fig,'platform_routes')

def theory():
    fig,axs=grid(height=2.85);a,b=axs[0]
    d=pd.read_csv(ROOT/'data/reuse_phase.csv');z=d.pivot(index='delta',columns='accuracy',values='gain')
    a.imshow(z.values,origin='lower',extent=[.5,1,.16,.6],aspect='auto',cmap='Blues',vmin=0,vmax=.9)
    delta=np.linspace(.16,.6,100);a.plot((1+delta-.025)/2,delta,'--',c='#BD6A30',lw=1.3)
    a.text(.61,.52,'Stop',ha='center',color='#333');a.text(.9,.3,'Reuse probe',ha='center',color='white')
    a.set(xlabel='Probe accuracy r',ylabel='Prior advantage δ');panel(a,'a','Sharp probe / stop boundary')
    Y=np.array([[10,0,2,100,.65],[10,2,0,100,.65]]);Z=np.array([[0,0,0],[1,0,0]]);c=np.array([0,3,1,99,4])
    for reuse,lab,col in [(True,'Reuse',COL['joint']),(False,'Discard',COL['no_reuse'])]:
        values=[ReusePlanner(Y,Z,c,k,.9,reuse=reuse,price=.05/QUANTUM).solve((-1,)*3)[0] for k in range(1,9)]
        b.step(range(1,9),values,where='post',label=lab,c=col,lw=1.6)
    b.axvline(4,c='#ABB4BA',ls=':',lw=.8);b.set(xlabel='Available reservation units B',ylabel='Optimal model risk',xlim=(1,8),ylim=(0,1.2),xticks=[1,2,3,4,5,6,7,8]);b.legend(frameon=False,loc='upper right')
    panel(b,'b','Feasible-policy budget frontier');save(fig,'theory')

def confirmation():
    s=pd.read_csv(ROOT/'data/confirmation_summary.csv');c=pd.read_csv(ROOT/'data/confirmation_contrasts.csv')
    fig,axs=grid(2,2,5.7)
    for j,mesh in enumerate(['B767','C172']):
        ax=axs[0,j];d=c.query('mesh==@mesh and ratio==1 and price==.3 and metric=="loss"')
        order=['full','coarse','fixed','myopic','reserve','no_reuse']
        for y,k in enumerate(order):
            r=d[d.baseline==k].iloc[0];ax.errorbar(r.difference*1000,y,xerr=[[1000*(r.difference-r.low)],[1000*(r.high-r.difference)]],fmt='o',color=COL['joint'],ms=3,capsize=2,lw=1)
        ax.axvline(0,c='#ABB4BA',lw=.8);ax.set(yticks=range(6),yticklabels=[LABEL[k] for k in order],xlabel='Reuse-DP − comparator risk (×10⁻³)');ax.invert_yaxis();panel(ax,'ab'[j],f'{mesh}: paired differences, 95% CI')
        ax=axs[1,j]
        for method in ['full','coarse','fixed','joint']:
            d=s.query('mesh==@mesh and ratio==1 and method==@method').sort_values('price')
            ax.plot(d.cpu_ms,d.pose_loss*1000,'o-',c=COL[method],lw=.85,ms=4,label=LABEL[method],alpha=.85)
        ax.set(xlabel='Actual registration CPU (ms)',ylabel='Four-second pose loss (×10⁻³)');panel(ax,'cd'[j],f'{mesh}: price sweep at B / cFull = 1')
        if j==0:ax.legend(frameon=False,ncol=2,loc='upper right')
    save(fig,'confirmation')

def robustness():
    d=pd.read_csv(ROOT/'data/confirmation_replay.csv').query('ratio==1 and price==.3')
    fig,axs=grid(height=3.2)
    for ax,mesh,letter in zip(axs[0],['B767','C172'],'ab'):
        z=d.query('mesh==@mesh').groupby(['level','noise','method'])['loss'].mean().unstack('method')
        x=np.arange(6)
        for method in ['full','coarse','joint']:
            ax.plot(x,z[method]*1000,'o-',color=COL[method],label=LABEL[method],ms=4,lw=1)
        oracle=d.query('mesh==@mesh and method=="joint"').groupby(['level','noise'])['oracle_loss'].mean()
        ax.plot(x,oracle*1000,'D--',color='#333333',label='Hindsight bound',ms=3,lw=.8)
        ax.set(xticks=x,xticklabels=['0 / N','0 / +N','1 / N','1 / +N','2 / N','2 / +N'],xlabel='Shape level / return-noise condition',ylabel='Total risk (×10⁻³)')
        panel(ax,letter,f'{mesh}: 40 sources per cell')
        if letter=='a':ax.legend(frameon=False,ncol=2,loc='upper left')
    save(fig,'robustness')

def missions():
    d=pd.read_csv(ROOT/'data/mission_results.csv');assert len(d)==48
    fig,axs=grid(2,2,5.8)
    for j,mesh in enumerate(['B767','C172']):
        ax=axs[0,j]
        for method in ['full','coarse','fixed','joint']:
            z=d.query('mesh==@mesh and ratio==1 and method==@method').sort_values('replicate')
            ax.plot(z.cpu_s,z.rmse_m*100,'-',c=COL[method],label=LABEL[method],lw=.8)
            for r in z.itertuples():ax.scatter(r.cpu_s,r.rmse_m*100,c=COL[method],marker=['o','^','s'][r.level],s=18,zorder=4)
        ax.set(xlabel='Total estimator CPU over 33 min (s)',ylabel='Relative position RMSE (cm)');panel(ax,'ab'[j],f'{mesh}: three complete missions')
        if j==0:ax.legend(frameon=False,ncol=2,loc='upper center',bbox_to_anchor=(.53,.80))
        ax=axs[1,j]
        for method in ['full','joint']:
            a=np.load(ROOT/f'data/missions/{mesh}_mission1/{method}_r1.npz')['trace']
            # Non-overlapping 10-second RMS bins, fixed example replicate 1.
            t=a[:19800,0].reshape(-1,100).mean(axis=1)/60
            y=np.sqrt(np.mean(a[:19800,4].reshape(-1,100)**2,axis=1))*100
            ax.plot(t,y,color=COL[method],lw=.8,label=LABEL[method])
        ax.set(xlabel='Mission time (min)',ylabel='10-second position RMS (cm)',xlim=(0,33));panel(ax,'cd'[j],f'{mesh}: intermediate-shape mission')
    save(fig,'missions')

def tables():
    out=ROOT/'tables';out.mkdir(exist_ok=True)
    s=pd.read_csv(ROOT/'data/confirmation_summary.csv').query('ratio==1 and price==.3')
    lines=[]
    for mesh in ['B767','C172']:
        for k in ['full','coarse','fixed','myopic','reserve','no_reuse','joint']:
            r=s.query('mesh==@mesh and method==@k').iloc[0]
            lines.append(f'{mesh} & {LABEL[k]} & {r.pose_loss*1000:.3f} & {r.cpu_ms:.3f} & {r.loss*1000:.3f} & {r.probes:.3f} \\\\')
        lines.append('\\midrule')
    (out/'confirmation.tex').write_text('\n'.join(lines[:-1])+'\n')
    m=pd.read_csv(ROOT/'data/mission_results.csv');assert len(m)==48
    lines=[]
    for mesh in ['B767','C172']:
        for k in ['full','coarse','fixed','joint']:
            d=m.query('mesh==@mesh and ratio==1 and method==@k');r=d.mean(numeric_only=True)
            lines.append(f'{mesh} & {LABEL[k]} & {r.rmse_m*100:.3f} & {d.rmse_m.min()*100:.3f}--{d.rmse_m.max()*100:.3f} & {r.cpu_s:.3f} & {int(d.overruns.sum())} \\\\')
        lines.append('\\midrule')
    (out/'missions.tex').write_text('\n'.join(lines[:-1])+'\n')
    allrows=[]
    for mesh in ['B767','C172']:
        for price in [.003,.03,.3]:
            for ratio in [1,1.25,1.5]:
                z=pd.read_csv(ROOT/'data/confirmation_summary.csv').query('mesh==@mesh and price==@price and ratio==@ratio').set_index('method')
                allrows.append(f'{mesh} & {price:g} & {ratio:g} & {z.loc["full","loss"]*1000:.3f} & {z.loc["coarse","loss"]*1000:.3f} & {z.loc["fixed","loss"]*1000:.3f} & {z.loc["joint","loss"]*1000:.3f} & {z.loc["joint","cpu_ms"]:.3f} \\\\')
    (out/'grid.tex').write_text('\n'.join(allrows)+'\n')
    metrics={}
    for mesh in ['B767','C172']:
        z=s.query('mesh==@mesh').set_index('method');j=z.loc['joint'];f=z.loc['full'];co=z.loc['coarse'];mm=m.query('mesh==@mesh and ratio==1').groupby('method').mean(numeric_only=True)
        metrics[mesh]=dict(snapshot_cpu_reduction_pct=100*(1-j.cpu_ms/f.cpu_ms),snapshot_risk_reduction_pct=100*(1-j.loss/f.loss),snapshot_pose_reduction_pct=100*(1-j.pose_loss/f.pose_loss),coarse_gain_pct=100*(1-j.loss/co.loss),oracle=j.oracle,joint_risk=j.loss,
            mission_cpu_reduction_pct=100*(1-mm.loc['joint','cpu_s']/mm.loc['full','cpu_s']),mission_rmse_full_cm=100*mm.loc['full','rmse_m'],mission_rmse_joint_cm=100*mm.loc['joint','rmse_m'],mission_overruns=int(m.query('mesh==@mesh and ratio==1 and method=="joint"').overruns.sum()))
    (ROOT/'data/headline_metrics.json').write_text(json.dumps(metrics,indent=2))
    print(json.dumps(metrics,indent=2))

if __name__=='__main__':
    architecture();platform();theory();confirmation();robustness()
    if len(pd.read_csv(ROOT/'data/mission_results.csv'))==48:missions();tables()
