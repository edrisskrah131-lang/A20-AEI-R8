"""Select an image-provider setting on development scenes, then score held-out scenes."""
import argparse
import hashlib
import json
import platform
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from PIL import Image

from pipeline import ROOT, BASELINE, DECODER_GRID, decode, estimate, prior, score, project, intersect_mesh


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def json_write(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False))


def scenes(directory, split):
    directory = Path(directory).resolve()
    result = []
    for path in sorted(directory.rglob('*.json')):
        item = json.loads(path.read_text())
        if isinstance(item, dict) and 'cad' in item and 'variants' in item and item.get('split') == split:
            result.append((path, item))
    assert result, (directory, split)
    identities = [(s['family'], s['seed']) for _, s in result]
    assert len(set(identities)) == len(identities), 'duplicate scene identities'
    return result


def locate(path, filename):
    result = path.parent / filename
    if not result.exists():
        result = path.parents[1] / filename
    assert result.is_file(), result
    return result


def measure(path, scene, variant_name, config, mesh):
    variant = scene['variants'][variant_name]
    image_path = locate(path, variant['filename'])
    rgb = np.asarray(Image.open(image_path).convert('RGB'))
    cpu = time.process_time()
    points = decode(rgb, config)
    camera, rotation = prior(scene, variant)
    fitted = estimate(scene['cad'], camera, rotation, variant['focal'], points)
    estimator_cpu = time.process_time() - cpu
    values, artifacts = score(scene, variant, fitted, mesh['vertices'], mesh['faces'])
    projection_error = np.max(np.abs(project(np.asarray(scene['actual']), np.asarray(variant['camera']),
                                             np.asarray(variant['rotation']), variant['focal']) -
                                     np.asarray(variant['blender_projected_pixels'])))
    row = dict(scene_id=scene.get('scene_id', str(scene['seed'])), seed=scene['seed'],
               family=scene['family'], family_name=scene['family_name'], split=scene['split'],
               structure_holdout=scene['family'] in (2, 3), condition=variant_name,
               frontend=config['name'], image_path=str(image_path.relative_to(ROOT.parent)),
               image_sha256=sha(image_path), scene_sha256=sha(path),
               mesh_sha256=sha(locate(path, scene['surface_mesh_file'])),
               image_width=rgb.shape[1], image_height=rgb.shape[0],
               projection_check_px=float(projection_error), estimator_cpu_s=estimator_cpu,
               **values)
    return row, artifacts


def source_hashes():
    paths = [ROOT/'pipeline.py', ROOT/'run.py', ROOT/'protocol.json',
             ROOT.parent/'rendering'/'render.py', ROOT.parent/'rendering'/'protocol.json',
             ROOT.parents[1]/'lifecycle_20261018'/'imaging.py',
             ROOT.parents[1]/'cad_surface_20261014'/'model.py']
    return {str(p.relative_to(ROOT.parents[2])): sha(p) for p in paths}


def validate_geometry(scene, mesh):
    tolerance = json.loads((ROOT/'protocol.json').read_text())['true_pose_mesh_tolerance_m']
    for condition, variant in scene['variants'].items():
        rotation = np.asarray(variant['rotation'])
        assert np.allclose(rotation.T @ rotation, np.eye(3), atol=1e-10)
        assert np.isclose(np.linalg.det(rotation), 1.)
        truth = project(np.asarray(scene['actual']), np.asarray(variant['camera']), rotation, variant['focal'])
        assert np.max(np.abs(truth - variant['blender_projected_pixels'])) < 1e-3
        rays = np.c_[truth/variant['focal'], np.ones(len(truth))] @ rotation.T
        rays /= np.linalg.norm(rays, axis=1, keepdims=True)
        identity = intersect_mesh(np.asarray(variant['camera']), rays, mesh['vertices'], mesh['faces'])
        error = np.linalg.norm(identity - scene['actual'], axis=1)
        assert np.isfinite(error).all() and error.max() < tolerance, (scene['seed'], condition, error.max())


def check_freeze(freeze):
    assert source_hashes() == freeze['source_hashes'], 'analysis or frozen provider changed'


def select(args):
    development = scenes(args.input, 'development')
    protocol = json.loads((ROOT/'protocol.json').read_text())
    assert pd.Series([s['family'] for _, s in development]).value_counts().to_dict() == {
        k: protocol['expected_development_scenes_per_family'] for k in (0, 1)}
    assert all(set(s['variants']) == set(protocol['conditions']) for _, s in development)
    renderer_protocol = json.loads((ROOT.parent/'rendering'/'protocol.json').read_text())
    assert {(s['seed'], s['family']) for _, s in development} == {
        (s['seed'], s['family']) for s in renderer_protocol['development_sources']}
    rows = []
    for path, scene in development:
        mesh = np.load(locate(path, scene['surface_mesh_file']))
        validate_geometry(scene, mesh)
        for condition in sorted(scene['variants']):
            for config in [BASELINE, *DECODER_GRID]:
                row, _ = measure(path, scene, condition, config, mesh)
                rows.append(row)
        print('development scene', scene['seed'], 'finished', flush=True)
    frame = pd.DataFrame(rows)
    frame.to_csv(ROOT/'development_metrics.csv', index=False)
    # Balanced strata: every family-condition receives the same weight.
    cells = frame.groupby(['frontend', 'family', 'condition'])[['quality_failure', 'coverage']].mean()
    ranking = cells.groupby('frontend').mean().reset_index()
    alternatives = ranking[ranking.frontend != BASELINE['name']].sort_values(
        ['quality_failure', 'coverage', 'frontend'], ascending=[True, False, True])
    selected_name = alternatives.iloc[0].frontend
    selected = next(c for c in DECODER_GRID if c['name'] == selected_name)
    result = dict(selected=selected, baseline=BASELINE,
                  objective='lowest mean full-quality failure over equally weighted development family-condition strata; then greatest mean coverage; then lexical provider name',
                  ranking=ranking.to_dict('records'),
                  development_scene_ids=[s.get('scene_id', str(s['seed'])) for _, s in development],
                  development_seeds=[s['seed'] for _, s in development],
                  development_scene_sha256={str(p.relative_to(ROOT.parent)): sha(p) for p, _ in development},
                  development_image_sha256=dict(zip(frame.image_path, frame.image_sha256)),
                  development_metrics_sha256=sha(ROOT/'development_metrics.csv'),
                  source_hashes=source_hashes(), selected_utc=datetime.now(timezone.utc).isoformat(),
                  environment=dict(python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__, platform=platform.platform()),
                  heldout_images_opened_by_selection=False)
    json_write(ROOT/'freeze.json', result)
    print(json.dumps(result, indent=2))


def process(args):
    freeze = json.loads((ROOT/'freeze.json').read_text())
    check_freeze(freeze)
    inputs = scenes(args.input, args.split)
    if args.split == 'test':
        assert not set(s['seed'] for _, s in inputs) & set(freeze['development_seeds'])
        protocol = json.loads((ROOT/'protocol.json').read_text())
        expected = protocol.get('expected_test_scenes_per_family')
        if expected is not None:
            actual = pd.Series([s['family'] for _, s in inputs]).value_counts().to_dict()
            assert actual == {k: expected for k in range(4)}, actual
        renderer_protocol = json.loads((ROOT.parent/'rendering'/'protocol.json').read_text())
        assert {(s['seed'], s['family']) for _, s in inputs} == {
            (s['seed'], s['family']) for s in renderer_protocol['test_sources']}
        assert all(set(s['variants']) == set(protocol['conditions']) for _, s in inputs)
    output = ROOT/'outputs'/args.split
    output.mkdir(parents=True, exist_ok=True)
    rows = []
    for path, scene in inputs:
        mesh = np.load(locate(path, scene['surface_mesh_file']))
        validate_geometry(scene, mesh)
        for condition in sorted(scene['variants']):
            for config in (BASELINE, freeze['selected']):
                row, arrays = measure(path, scene, condition, config, mesh)
                rows.append(row)
                filename = f"{scene['seed']}_{condition}_{config['name']}.npz"
                np.savez_compressed(output/filename, **arrays)
        print(args.split, 'scene', scene['seed'], 'finished', flush=True)
    pd.DataFrame(rows).to_csv(output/'metrics.csv', index=False)
    json_write(output/'processing.json', dict(utc=datetime.now(timezone.utc).isoformat(),
                split=args.split, independent_scenes=len(inputs), image_count=len(rows)//2,
                frontend_evaluations=len(rows), source_hashes=source_hashes(),
                input_root_relative_to_study=str(args.input.resolve().relative_to(ROOT.parent)),
                freeze_sha256=sha(ROOT/'freeze.json')))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['select', 'process'])
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--split', choices=['development', 'test'], default='test')
    arguments = parser.parse_args()
    (select if arguments.action == 'select' else process)(arguments)
