# Executable Evidence Management for Aircraft Inspection

The current article uses `paper/main.tex`, `paper/sections/completion_content.tex` and the generated `completion_*.tex` sections. `reporting/completion_report.py` and `completion_supplement.py` rebuild the retained CAD campaign and surface challenge. `reporting/real_image_report.py` then generates the current two-case article, real-image figures and real-image supplementary section from executed results. Earlier integrated and historical studies remain in the Supplementary Material and source archive. The repository download index supplies the compiled article and supplement PDFs separately.

## Download and restore the complete archive

Download `A20_AEI_Complete_Source.zip` and **every** `A20_AEI_Data_*.zip` listed in the source package's `DELIVERY_INDEX.json`. Keep the ZIP files together and extract only the Source ZIP initially. From the extracted `manuscript` directory:

```sh
python reporting/restore_data.py --archive-dir ..
python reporting/verify_package.py \
  --source ../A20_AEI_Complete_Source.zip --data-dir .. --restored-root .
```

Replace `..` with the ZIP directory when it is elsewhere. Restoration is offline, checks archive and individual-file SHA256 values, skips already correct files, and rejects unsafe paths or changed destination files. `--overwrite` is available for an intentional replacement of modified data. Every Source and Data ZIP is below 90 MiB. Data volumes retain all original images, numerical arrays and surface meshes; Source retains code, protocols, JSON/CSV results, references and publication figure PDFs. The complete file-to-volume mapping is in `DELIVERY_INDEX.json`; `MANIFEST.json` covers every delivered payload across all volumes. Generated inventories do not hash themselves.

Restore all volumes before checking numerical studies or regenerating figures. Duplicate compiled article PDFs, LaTeX intermediates, bytecode, and regenerable `paper/figures/visual/*.png`/`*.svg` presentation previews are excluded from the source payload. Raw experimental pixels are retained.

## Real-image experiment and detector environment

`studies/real_defects_20261020/` contains the actual Innovation Hangar v2 case. It retains 1,339 representative real images in 222 inferred source groups, with train/development/calibration/test group counts 122/33/33/34. Repeated frames and augmentations are not binomial trials. Four YOLO11n producer configurations execute on 881 development/calibration/test images each, giving 3,524 outputs. `outputs/summary.json` records actual quality admission and report histories; `SOURCE_CREDIT.md` records licenses. All original and converted selected labels, model weights, raw detections and failed outcomes are included.

Use the pinned numerical/reporting environment below for earlier studies. For the detector use a separate Python 3.12 environment:

```sh
python -m venv ../.venv-a20-detector
../.venv-a20-detector/bin/python -m pip install torch==2.8.0+cpu torchvision==0.23.0+cpu --index-url https://download.pytorch.org/whl/cpu
../.venv-a20-detector/bin/python -m pip install -r requirements-real-images.txt --extra-index-url https://download.pytorch.org/whl/cpu
```

Set `A20_DETECTOR_PYTHON` to that interpreter. The archived weights allow offline inference reproduction without GPU, model download or retraining. Refitting and development selection are separate optional operations in the study README. The model uses training/development only; neither calibration nor test selects weights or confidence. Source grouping remains inferred because aircraft identities are not supplied. Per-category detection results remain separate from the reserved pooled group events.

## Retained CAD and surface experiments

**Sequential lifecycle campaign — `studies/lifecycle_campaign_20261018/`.** The fixed 64-context family uses eight producers and eight request events. All producers execute on 256 fresh calibration scenes, giving 2,048 calibration outputs. Each of 64 independent test sources follows 16 successive operations, including combined producer changes, stale delivery, invalid and valid repairs, replay, numerical rollback and population mismatch. Four matched implementations produce 4,096 workflow decisions. Operations and method repetitions are distinguished from independent sources.

All complete methods support 54 of 64 family contexts and issue 704 of 1,024 campaign decisions. The full-family catalogue evaluates 13,824 records with dependency-aware exact evidence and 8,960 with containment plus fallback, a 35.19% reduction. The separate sparse campaign-demand catalogue evaluates 2,048 versus 1,536 records, a 25.00% reduction. Each catalogue is built once per population and method; its cost is not multiplied by the number of test sources. Ordinary dependency caching supplies the measured numerical savings shared by the incremental methods. The first-source example is fixed at seed 202630100.

**Surface and image-provider challenge — `studies/inspection_challenge_20261018/`.** Actual Blender Cycles images cover four structural families: longitudinal lap joint, rounded access hatch, doubly curved diagonal joint and raised repair doubler. Eight development scenes from the first two families select one of six predefined extraction settings. The test protocol has 16 independent scenes per family, each under nominal, raking-light, oblique-view and foreground-occlusion conditions: 64 scenes, 256 raw images and 512 evaluations for two pixel providers. The last two families are held out from provider selection. All successes, missed correspondences, false screen acceptances and failed surface intersections remain in the result tables.

The geometric challenge is a separately identified population. Its images do not inherit the controlled population's calibrated risk cards. Pose estimation receives image-derived centers, nominal CAD and a pose prior; physical truth and visibility enter scoring only. All planned sites remain in the coverage and mapping denominators. Descriptive uncertainty resamples complete independent scenes within each structural family, preserving paired conditions and providers.

The rendering archive includes every development/test image, scene description and exact exterior-surface mesh. The analysis archive includes every fitted camera and correspondence array, development selection, individual results, summary tables and frozen source hashes. The fixed gallery uses the first test source in each family. Fresh-render checks use those four nominal images and the first repair-doubler occlusion image.

## Literature

The article cites 34 sources, including 11 Advanced Engineering Informatics papers. The active bibliography is `paper/references_integrated.bib`. `literature/citation_evidence.json` records verified metadata, reading versions and supported claims, distinguishing full-text reads from abstract-only reads and retained foundational sources. Third-party article PDFs are not redistributed in this package.

## Verify and rebuild without altering study data

Install the Python dependencies in `requirements-artifacts.txt` and a LaTeX distribution providing `pdflatex`, `bibtex`, `elsarticle` and the packages used by `paper/main.tex`. The delivery was built with Python 3.12. The configured workspace interpreter is `/workspace/a20-r9-env/venv/bin/python`; a local installation can use `python` instead. Pixel checks use Pillow, installed as a Matplotlib dependency. Blender is needed only when rendering new pixels.

From `manuscript`:

```sh
python -m pip install -r requirements-artifacts.txt
A20_PYTHON=python A20_DETECTOR_PYTHON="$(pwd)/../.venv-a20-detector/bin/python" bash reproduce_artifacts.sh
```

The entry point creates a temporary copy of the complete restored manuscript. It also reruns all 3,524 detector outputs from archived weights, independently rematches boxes, rebuilds grouped events and checks the report histories. It independently checks the current campaign, renderer inventory and geometric image processing; reprocesses the earlier geometric pixels and selected numerical checks; runs the historical reporting recipes; then runs `completion_report.py`, `completion_supplement.py`, `real_image_report.py`, the LaTeX build and all final QA. It does not rerun measured timing trials, select a new provider, recalibrate the archived populations, or repeat the full render campaign.

Some historical reporting recipes write derived study metadata. They run only in the temporary copy. After all checks pass, `reporting/reproduce_workspace.py` copies generated paper files, PDFs and machine-readable QA back to the original manuscript directory. It never copies study files back and verifies that every original study file remains unchanged. `audits/reproduction_qa.json` records this preservation check. Set `A20_REPRO_KEEP=1` to retain the temporary workspace for inspection; otherwise it is removed at exit.

The main verification entry points, which the reproduction script runs in its isolated copy, are:

```sh
python studies/lifecycle_campaign_20261018/verify.py
python studies/inspection_challenge_20261018/rendering/verify.py
python studies/inspection_challenge_20261018/analysis/check_legacy.py
python studies/inspection_challenge_20261018/analysis/unit_checks.py
python studies/inspection_challenge_20261018/analysis/verify.py
python reporting/verify_completion.py
```

The campaign checker recomputes all family bounds and transition invariants and directly reexecutes fixed numerical examples. The challenge checker reprocesses all 256 test images for both providers, checks development selection and source hashes, and independently checks mesh intersections. These checkers write verification reports rather than new timing trials. Final QA independently recounts the result tables, verifies rounded manuscript claims against their numerical sources, checks figure provenance, and inspects compiled references and page bounds.

## Optional fresh rendering and experiment reruns

Fresh rendering requires Blender **4.3.2** at `/usr/bin/blender`, with its NumPy support, and the Python dependencies above. To reproduce the five fixed render checks in a separate copy:

```sh
A20_FRESH="$(mktemp -d /tmp/a20-fresh.XXXXXXXX)"
cp -a . "$A20_FRESH/manuscript"
python "$A20_FRESH/manuscript/studies/inspection_challenge_20261018/rendering/reproduce_check.py" \
  --out "$A20_FRESH/rendered"
```

Each invocation creates a fresh output subdirectory. It compares decoded pixels and the mesh, CAD, camera, projection and visibility arrays with the archived originals. Container timestamps and elapsed-time metadata are not pixel identity criteria. Results are written to `rendering/reproduction.json` inside the separate manuscript copy.

Full calibration, campaign execution, development selection or test processing can be rerun from the study recipes in a separate manuscript copy. `calibrate.py`, campaign `run.py`, and analysis `run.py select/process` write new records or timing measurements into their own study directory; they are deliberately excluded from the archive-preserving default entry point. Follow the per-study README/method files and keep the archived release intact for comparison.

## Retained earlier evidence

- `studies/lifecycle_20261018/`: the earlier 256-calibration/256-test, six-producer population, fixed 48-event family, cache timing and conditional-change checks.
- `studies/validated_recovery_20261018/`: authenticated repair, replay and independent registry implementations on stored numerical outputs.
- `studies/decision_case_20261018/`: the earlier first-source example, allowance sensitivity and independent test-family bounds.
- `studies/physical_render_20261018/`: the earlier 24-scene/72-image Cycles study, raw pixels and fixed-source fresh-render checks.
- Earlier dated study directories: numerical scheduling, five-template perturbations, change-conformance and controlled surface experiments, with their original populations and allocations.

`audits/completion_qa.json` checks the current results and documents; `audits/integrated_qa.json`, `lifecycle_qa.json` and `visual_revision_qa.json` retain earlier numerical/provenance checks. Citation metadata and compiled links are checked by `audits/citation_qa.json`. Per-study verification files preserve the executed checks. Figure 1 provides credited engineering context. Quantitative inputs include the archived controlled/Cycles outputs and the public real-image representatives. `audits/real_image_qa.json` records current detector, event and document checks. Source declarations, photo credits and implementation context are consolidated at the end of the supplement.
