"""Write the secondary event-dispatch evidence and its reproducible figure."""
import os
os.environ['OPENBLAS_NUM_THREADS'] = '1'
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from r4_protocol import ROOT, D
from r4_results_author import table
from r5_dispatch import OUT


def main():
    frozen = json.loads((OUT/'selector_freeze.json').read_text())
    decisions = frozen['decisions']
    summary = pd.read_csv(OUT/'confirmation_summary.csv')
    effects = json.loads((OUT/'paired_effects.json').read_text())
    report = json.loads((OUT/'analysis_report.json').read_text())
    cost = json.loads((OUT/'dispatch_cost.json').read_text())
    assert report['event_dispatch_admission'] == 15
    def decision(context, load, task):
        return next(d for d in decisions if d['context'] == context and
                    d['load'] == load and d['task'] == task)
    def effect(load, metric):
        return next(e for e in effects if e['load'] == load and e['metric'] == metric)

    rows = []
    for context in ['nominal_calibration', 'geometry_calibration']:
        for load in [1,10,20]:
            ds = [decision(context, load, task) for task in ['trajectory','capture','both_marginals']]
            rows.append(['Nominal' if context.startswith('nominal') else 'Procedural',
                         str(load), ds[0]['policy'], ds[1]['policy'], ds[2]['policy'] or 'Refused'])
    selection = table('Event-driven selection from the same frozen 20-policy catalogue. Each requested marginal has allowance 0.15; the last column requires both marginal bounds, not a joint-event bound of 0.15. No procedural-geometry policy meets both card requirements.',
                      'tab:dispatchchoices', ['Mixture',r'$\alpha$','Trajectory','Observation','Both marginals'], rows)

    gain = effect(20, 'capture_success'); cpu = effect(20, 'cpu_s'); loss = effect(20, 'loss_m2s')
    rows = []
    for load in [1,10,20]:
        x = summary[(summary.context == 'geometry_calibration') &
                    (summary.load == load) & (summary.task == 'capture')].iloc[0]
        e = effect(load,'capture_success')
        rows.append([str(load),x.policy,x.trajectory_choice,
                     f'{int(x.capture_success)}/{int(x.comparator_capture_success)}',
                     f'{100*e["difference"]:+.2f}',
                     f'{100*e["difference_ci"][0]:+.2f}, {100*e["difference_ci"][1]:+.2f}',
                     f'{100*effect(load,"cpu_s")["relative_change"]:+.1f}',
                     f'{100*effect(load,"loss_m2s")["relative_change"]:+.1f}'])
    tradeoffs = table('Secondary observation-request analysis on the same 480 procedural-geometry confirmation inputs at each load. Compare event-selected policy with the trajectory-selected policy. Success counts are event/trajectory choice; changes are event minus trajectory choice. Paired 95\\% intervals use 10,000 seed resamples. The comparator lacks an applicable observation card.',
                      'tab:dispatchoutcomes', [r'$\alpha$','Event choice','Traj. choice','Successes','Change (pp)','95\\% interval','CPU (\\%)',r'$L$ (\%)'], rows,
                      size=r'\scriptsize')
    evaluation = r'''\subsection{Policy selection follows the requested event}\label{sec:dispatch-evaluation}
The event dispatcher is a secondary analysis of the frozen primary records. The question was formulated after primary-study inspection; no new forecast, policy, card or geometric input is added. Selection reads calibration records only. Confirmation outcomes are joined from already executed policies, rather than used to tune the choice. The two applicable mixtures contribute 1,120 independent confirmation inputs, reused across loads and request types.

Table~\ref{tab:dispatchchoices} evaluates 18 declared request configurations: two mixtures, three loads and three event requirements. Reusing a trajectory-certified choice as a policy-level admission label would accept all 18, with six assignments lacking the requested event evidence. Checking that same choice against each event admits 12. Selecting within the event-compatible set admits 15, recovering the three geometry observation configurations and refusing all three geometry requests for both marginals. These are catalogue coverage counts from constructed diagnostics, rather than sampled field reliability or a comparison with a complete published localization system.
'''+selection+r'''
Nominal requests choose FlatCART3 for all three requirements; its trajectory and observation bounds are 0.1136 and 0.0851. Geometry trajectory requests choose Final at load 1 and Fixed16 at loads 10 and 20. Observation requests choose FlatRF0.3 at loads 1 and 10 and KG0.3 at load 20. The same objective therefore changes the selected policy when its event constraints change. The load-20 compatible sets are disjoint (Fig.~\ref{fig:event-feasibility}); a request requiring both marginals has no compatible member.

Table~\ref{tab:dispatchoutcomes} reports the resulting tradeoffs, including the less favorable low-load results. At load 20, KG0.3 has observation upper risk 0.1474 but trajectory upper risk 0.1583; Fixed16 has trajectory upper risk 0.1474 but observation upper risk 0.2055. Observation success changes from 407/480 to 436/480, a gain of '''+f'{100*gain["difference"]:.2f}'+r''' percentage points, with paired 95\% interval '''+f'{100*gain["difference_ci"][0]:.2f}--{100*gain["difference_ci"][1]:.2f}'+r'''. CPU falls from 11.92 to 10.19 ms ('''+f'{-100*cpu["relative_change"]:.1f}'+r'''\%); trajectory loss rises from 0.01429 to 0.01656 m$^2$s ('''+f'{100*loss["relative_change"]:.1f}'+r'''\%), with 49 rather than 37 trajectory failures. At loads 1 and 10, observation success is three lower among 480 episodes, despite lower CPU and an applicable observation card. Calibration eligibility does not imply better realized performance in every confirmation block.
'''+tradeoffs+r'''
The indexed metadata dispatcher has median '''+f'{cost["median_us"]:.2f}'+r''' and 95th-percentile '''+f'{cost["p95_us"]:.2f}'+r''' microseconds process CPU across 2,400 calls cycling through the 18 request configurations. This separate interface benchmark includes candidate filtering and calibration-score selection, excluding startup/component hashing, scan hashing and transport. The numerical CPU and installation outcomes above belong to the executed frozen policies; they do not measure an integrated end-to-end dispatch service.

\begin{figure}[t]\centering\includegraphics[width=.82\linewidth]{r5/events.pdf}
\caption{Simultaneous risk bounds for all 20 frozen policies on procedural geometry at load 20. Dashed lines mark the marginal allowance 0.15. The lower-left region has no member. Trajectory and observation requests select different policies; neither choice satisfies both marginals. Coordinates are reconstructed from the frozen calibration records.}\label{fig:event-feasibility}
\end{figure}
'''
    (ROOT/'sections/r5_evaluation.tex').write_text(evaluation)

    rows = []
    for d in decisions:
        bounds = d.get('bounds', {})
        rows.append(['Nominal' if d['context'].startswith('nominal') else 'Procedural',
                     f'{d["load"]:g}',{'trajectory':'Trajectory','capture':'Observation','both_marginals':'Both marginals'}[d['task']],
                     len(d['eligible_policies']),d['policy'] or 'Refused',
                     f'{bounds["trajectory"]:.5f}' if 'trajectory' in bounds else '---',
                     f'{bounds["capture"]:.5f}' if 'capture' in bounds else '---'])
    complete = table('Complete secondary request catalogue. Each marginal allowance is 0.15. Counts enumerate compatible policies, not independent samples or additional statistical tests.',
                     'supp:dispatchcatalogue',['Mixture',r'$\alpha$','Request','Eligible','Choice',r'$U_{\rm traj}$',r'$U_{\rm obs}$'],rows)
    rows = []
    for load in [1,10,20]:
        for metric in ['capture_success','cpu_s','loss_m2s','failure']:
            e = effect(load,metric)
            scale = 100 if metric in ['capture_success','failure'] else 1000 if metric == 'cpu_s' else 1
            name = {'capture_success':'Obs. success (pp)','cpu_s':'CPU (ms)',
                    'loss_m2s':r'$L$ (m$^2$s)','failure':'Traj. failures (pp)'}[metric]
            rows.append([str(load),name,f'{scale*e["difference"]:+.5f}',
                         f'{scale*e["difference_ci"][0]:+.5f}, {scale*e["difference_ci"][1]:+.5f}'])
    fullfx = table('Event-selected minus trajectory-selected policy on 480 paired procedural inputs. Percentile 95\\% intervals are descriptive secondary analyses, without correction for these comparisons.',
                   'supp:dispatcheffects',[r'$\alpha$','Metric','Difference','95\\% interval'],rows)
    supplement = r'''\FloatBarrier
\section{Secondary event-driven dispatch}\label{supp:dispatch}
The dispatcher forms the compatible policy set from the original 240 simultaneous cards. It minimizes calibration mean loss plus calibration mean CPU, with lexicographic policy-ID tie-breaking. Supported requested allowances are in $[0,0.15]$. Request events and declared profiles are specified before sensing; the selected policy is constant for the entire declared mixture, not conditioned on individual aircraft identity, scan quality or error. Bounds retain their population scope.

This addition was designed after primary results had been inspected. Its selector uses calibration inputs only and is written to \texttt{data/r5\_dispatch/selector\_freeze.json} before this analysis program reads the existing confirmation records. That ordering does not make the additional question prospective. There are no new geometric samples, executed localization policies or risk cards. Confirmation analysis reuses 640 nominal and 480 procedural inputs across all requests and loads. The selector and every input hash are retained.

Both-marginal requests require each upper bound at most 0.15. The original simultaneous-confidence event supports these two marginal statements together; it does not make the probability of their union at most 0.15. Only $\Pr(E_{\rm traj}\cup E_{\rm obs})\le\min\{1,U_{\rm traj}+U_{\rm obs}\}$ follows without a separately calibrated union event. The nominal selected pair therefore has union bound 0.19871. No procedural choice has both bounds at most 0.15.

The two comparison interfaces are constructed diagnostics. Policy-level admission reuses a trajectory-certified policy for any requested event, which gives six unsupported assignments among 18 configurations. Checking its actual event cards eliminates those assignments but provides only 12 feasible services. Event-driven selection gives 15. The six unsupported assignments concern evidence applicability; this count does not show that their true risks exceed 0.15.
'''+complete+fullfx+r'''
The dispatch audit executes '''+str(report['audit']['checks'])+r''' deterministic cases with illustrative source seals, including changed runtime policy/forecast identities, service/profile/artifact mismatches, invalid numeric fields, expired or wrong-instant observation requests, event substitution, stricter allowance and uncalibrated contexts. No unexpected selection occurs. This is a separate metadata prototype, not an online authorization log from the simulated receiver and not a distribution-shift detector. Its indexed-call benchmark stores all scope and source identifiers in \texttt{dispatch\_cost.json}: 2,400 process-CPU calls, median '''+f'{cost["median_us"]:.2f}'+r''' microseconds and 95th percentile '''+f'{cost["p95_us"]:.2f}'+r''' microseconds. Runtime/component initialization, scan hashing and transport are excluded. The benchmark is separate from the frozen numerical installation service; integrated receiver timing has not been measured for this dispatcher.

Run \texttt{python3 source/r5\_dispatch.py} to reconstruct selection, audits and paired outcomes, then \texttt{python3 source/r5\_author.py} to rebuild the tables and risk-feasibility figure. Both programs leave the primary numerical source, forecasts and records unchanged. The primary work--loss figure appears in the main paper.

'''
    (ROOT/'sections/r5_supplement.tex').write_text(supplement)

    target = ROOT/'figures/r5'; target.mkdir(exist_ok=True)
    cf = pd.read_csv(D/'calibration.csv')
    q = cf[(cf.phase == 'geometry_calibration') & (cf.load == 20)]
    plt.rcParams.update({'font.size':10,'font.family':'DejaVu Sans','pdf.fonttype':42})
    fig, ax = plt.subplots(figsize=(6.6,4.4),layout='constrained')
    ax.axvspan(0,.15,color='#d8e8f6',alpha=.6)
    ax.axhspan(0,.15,color='#e1f1e2',alpha=.6)
    ax.scatter(q.upper_risk,q.task_upper_risk,color='#68747d',s=42,zorder=3,label='Other frozen policies')
    for pid,color,offset,name in [('Fixed16','#1c5f96',(-64,14),'Trajectory: Fixed16'),
                                  ('KG0.3','#24713e',(14,-15),'Observation: KG0.3')]:
        x=q[q.policy==pid].iloc[0]
        ax.scatter([x.upper_risk],[x.task_upper_risk],color=color,s=85,zorder=4,edgecolors='white')
        ax.annotate(name,(x.upper_risk,x.task_upper_risk),xytext=offset,textcoords='offset points',
                    fontsize=9,color=color,arrowprops={'arrowstyle':'-','color':color})
    ax.axvline(.15,color='#1c5f96',ls='--',lw=1.2)
    ax.axhline(.15,color='#24713e',ls='--',lw=1.2)
    ax.text(.117,.12,'Both marginals:\nno eligible policy',fontsize=9,color='#24475e')
    ax.set(xlim=(.11,max(q.upper_risk.max(),.25)+.02),
           ylim=(.10,max(q.task_upper_risk.max(),.25)+.02),
           xlabel='Trajectory event upper risk',ylabel='Observation event upper risk')
    ax.grid(alpha=.17);ax.spines[['top','right']].set_visible(False)
    fig.savefig(target/'events.pdf');fig.savefig(target/'events.png',dpi=200)
    plt.close(fig)
    print('R5_AUTHOR_COMPLETE',flush=True)


if __name__ == '__main__':
    main()
