"""Package current and retained figures, original photos and the CNS request."""
from pathlib import Path
import hashlib
import json
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DEST = Path(sys.argv[1]).resolve()

README = '''A20 / AEI complete figure and architecture-input bundle

Main paper: architecture and source-version mechanisms; restored physical
platform/retained-route plate; all five supplied simulation views; all 240
population-card bounds; event-feasibility plot; current matched work--loss
frontier; influence, workload and route results.

Supplement: six original retained result PDFs, plus the two additional
physical-platform views. The original studies keep their own inputs and CPU
ledgers. They are not pooled with the current episode or route study.

All four original physical photographs are in figures/r7/hardware_originals.
All five original simulation screenshots are in figures/r6/simulation_originals.
Original image bytes, natural aspect ratios and pixels are preserved.
Photographs and screenshots provide context; the separately archived geometric
inputs define the numerical localization experiments.

The exact cell_cns_figure skill has been located and installed. The complete
scientific and visual architecture request is:
figures/r7/CNS_Architecture_Request.txt
No paid service order has been submitted. The architecture currently included
is the prior version; it is not cell_cns_figure output. The input requests a
spatial aircraft/robot/LiDAR mechanism, retained checkpoint computation, explicit
source replacement/replay and a separately scoped statistical statement service.

New data/source files and original vector result PDFs are included. Editable
SVG text, embedded-font PDFs, PNGs and 600-dpi TIFF exports are provided for the
recent figure sets. Full manuscripts, numerical inputs and analysis records are
delivered in the companion editable-source package. Existing unused earlier
schematics are retained as reference, not presented as additional experiments.

FILES_SHA256.json covers every bundle member except itself.
'''

def main():
    files = [p for p in (ROOT / 'figures').rglob('*')
             if p.is_file() and not p.name.startswith('.')]
    for name in ['r4_figures.py','r6_visuals.py','r7_restoration.py',
                 'r7_package.py','r4_protocol.py']:
        files.append(ROOT / 'source' / name)
    files += list((ROOT / 'source/figure_qa').glob('*.py'))
    files += [ROOT / 'requirements-R4.txt']
    files += [ROOT / 'sections' / name for name in [
        'r6_architecture.tex','r6_interface.tex','r6_scene.tex',
        'r7_platform.tex','r7_frontier.tex','r7_population_cards.tex',
        'r7_retained_figures.tex']]
    files += [p for p in (ROOT / 'qa').glob('r[67]_*.json')]
    files += [ROOT / 'qa' / name for name in [
        'R6_FIGURE_CONTRACT.md','R6_FINAL_REVIEW.md',
        'R7_FIGURE_CONTRACT.md','R7_FINAL_REVIEW.md']]
    files += [ROOT / 'data/r4_final/calibration.csv',
              ROOT / 'data/r4_final/summary.csv',
              ROOT / 'data/r4_final/influence.csv',
              ROOT / 'data/r4_final/service_stress_summary.csv',
              ROOT / 'data/r4_final/route_results.csv']
    entries = {p.relative_to(ROOT).as_posix(): p.read_bytes()
               for p in sorted(set(files))}
    entries['README.txt'] = README.encode()
    hashes = {n: hashlib.sha256(b).hexdigest() for n,b in entries.items()}
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,b in entries.items(): z.writestr(n,b)
        z.writestr('FILES_SHA256.json',json.dumps(hashes,indent=2,sort_keys=True))
    with zipfile.ZipFile(DEST) as z:
        assert z.testzip() is None
        assert set(z.namelist()) == set(hashes) | {'FILES_SHA256.json'}
        for n,h in hashes.items(): assert hashlib.sha256(z.read(n)).hexdigest() == h
    report = {'status':'PASS','members':len(hashes)+1,
              'bytes':DEST.stat().st_size,
              'sha256':hashlib.sha256(DEST.read_bytes()).hexdigest()}
    (ROOT/'qa/r7_figure_bundle.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report),flush=True)

if __name__ == '__main__': main()
