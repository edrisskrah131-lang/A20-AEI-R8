"""Fresh independently seeded geometric inputs and checkpoint outcome labels."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import json,time
import numpy as np
from r4_protocol import ROOT,D,PROTOCOL,sha,freeze_protocol
from checkpoint import WORK,CheckpointICP
from rcp.core import JointState,exp,log,propagate,register
from rcp.sensor import Mesh
from train import initial_cov
from prospective import rel_error
from r4_geometry import build
from r4_sensor import raw_scan,frontend
A19=WORK/'work/a19/RAS_A19'
def sensor(mesh,pose,velocity,seed,stamp,mt,mR,causal,noise):
 raw,dt,ring=raw_scan(mesh,pose,velocity,seed,stamp,mt,mR,noise)
 cloud,cpu=frontend(raw,dt,np.repeat((causal*.1)[None,:],5,axis=0))
 return cloud,cpu,raw,dt
def main():
 freeze_protocol();build();assert (D/'freeze.json').exists(),'Freeze before generating final inputs'
 out=D/'episode_inputs';out.mkdir(exist_ok=True)
 meshes={};routes={}
 for m in ['B767','C172','ProceduralAirframe']:
  base=D/'geometry' if m=='ProceduralAirframe' else A19/f'meshes/{m}'
  for level in range(3):meshes[m,level]=Mesh(base/f'world_discrepancy_{level}.npz')
  routes[m]=np.load(base/'route.npz')['pose']
 path=D/'episodes.jsonl';done={json.loads(x)['seed'] for x in path.read_text().splitlines()} if path.exists() else set();start=time.perf_counter();count=len(done)
 with path.open('a') as f:
  for phase,(base,n) in PROTOCOL['seed_ranges'].items():
   for i in range(n):
    seed=base+i
    if seed in done:continue
    rng=np.random.default_rng(seed);m='ProceduralAirframe' if phase.startswith('geometry') else str(rng.choice(['B767','C172']));level=int(rng.integers(3))
    noise=float(rng.choice(PROTOCOL['shift_noise'] if phase=='shift_confirmation' else PROTOCOL['nominal_noise']))
    sd=float(rng.choice(PROTOCOL['shift_prior_sd'] if phase=='shift_confirmation' else PROTOCOL['difficult_prior_sd'] if phase=='difficult_confirmation' else PROTOCOL['nominal_prior_sd']))
    route=routes[m];frame=int(rng.integers(100,len(route)-100));truth=route[frame];mt=rng.normal(0,.025,3);mR=exp(rng.normal(0,.001,3))
    def increment(j):return np.r_[(route[j+1,:3]-route[j,:3])@exp(route[j,3:]),log(exp(route[j,3:]).T@exp(route[j+1,3:]))]
    bias=rng.normal(0,np.r_[np.full(3,.0015),np.full(3,.00015)]);dens=np.r_[np.full(3,.004),np.full(3,.0004)]
    past=np.array([increment(j)+bias*.1+rng.normal(0,np.sqrt(.1)*dens) for j in range(frame-5,frame)])
    raw,dt,ring=raw_scan(meshes[m,level],truth,increment(frame)/.1,seed*100,frame*.1,mt,mR,noise)
    cloud,front=frontend(raw,dt,past)
    prior=JointState(truth[:3]+rng.normal(0,sd,3),exp(rng.normal(0,.006,3))@exp(truth[3:]),np.zeros(6),np.zeros(3),np.eye(3),initial_cov(sd))
    future=route[frame:frame+41];inc=np.array([increment(j)+bias*.1+rng.normal(0,np.sqrt(.1)*dens) for j in range(frame,frame+40)])
    startcpu=time.process_time_ns();solver=CheckpointICP(meshes[m,0].prior,cloud,prior,int(m=='C172'));states=[prior.copy()];trace=[]
    while not solver.done:
     post,stats,feature=solver.advance();states.append(post.copy());trace.append(dict(**stats,feature=feature.tolist(),cpu_total_s=(time.process_time_ns()-startcpu)*1e-9))
    errors=[];rotation=[]
    for state in states:
     state=state.copy();e=[];re=[]
     for j in range(41):
      if j:state=propagate(state,.1,inc[j-1])
      p,r=rel_error(state,future[j],mt,mR);e.append(float(np.linalg.norm(p)));re.append(float(np.linalg.norm(r)))
     errors.append(e);rotation.append(re)
    delta=covdelta=None
    if phase=='nominal_calibration' and i<24:
     ref,rs,_,_=register(meshes[m,0].prior,cloud,prior,'converged',cpu_limit=1.)
     final=states[-1] if trace[-1]['accepted'] else prior
     delta=float(np.max(np.abs(final.delta(ref))));covdelta=float(np.max(np.abs(final.P-ref.P)));assert delta<1e-8 and covdelta<1e-8
    np.savez_compressed(out/f'{seed}.npz',cloud=cloud,raw=raw,raw_dt=dt,raw_ring=ring,measured_past=past,future_truth=future,increment=inc,map_t=mt,map_R=mR,prior_t=prior.t,prior_R=prior.R,prior_bias=prior.bias,prior_mt=prior.mt,prior_mR=prior.mR,prior_P=prior.P)
    row={'phase':phase,'seed':seed,'mesh':m,'level':level,'noise':noise,'sd':sd,'frame':frame,'npoints':len(cloud),'front_cpu_s':front,'trace':trace,'cpu_s':trace[-1]['cpu_total_s'],'error':errors,'rotation_error':rotation,'state_delta':delta,'covariance_delta':covdelta,'input_sha256':sha(out/f'{seed}.npz'),'provenance':'NEW_GEOMETRIC_SIMULATION_RECOVERY_BATCH'}
    f.write(json.dumps(row)+'\n');f.flush();count+=1
    if count%100==0:print('R4_COLLECT',count,'elapsed',round(time.perf_counter()-start,1),flush=True)
 checks=[json.loads(x) for x in path.read_text().splitlines() if json.loads(x)['state_delta'] is not None]
 manifest={'episodes':count,'generator_sha256':sha(__file__),'sensor_sha256':sha(ROOT/'source/r4_sensor.py'),'geometry_sha256':sha(ROOT/'source/r4_geometry.py'),'solver_sha256':sha(ROOT/'source/checkpoint.py'),'forecast_freeze_sha256':sha(D/'freeze.json'),'data_sha256':sha(path),'seed_ranges':PROTOCOL['seed_ranges'],'native_equivalence_checks':len(checks),'native_max_state_delta':max(r['state_delta'] for r in checks),'native_max_covariance_delta':max(r['covariance_delta'] for r in checks),'physical_trials':0}
 (D/'collection_manifest.json').write_text(json.dumps(manifest,indent=2));print('R4_COLLECTION_COMPLETE',flush=True)
if __name__=='__main__':main()
