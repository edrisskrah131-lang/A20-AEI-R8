"""Characterize a deterministic CPU-equivalent service clock on pilot inputs.

This model is frozen before final sampling. It is not an embedded timing model
or a WCET certificate. Actual native CPU remains a separately measured ledger.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import json,time
import numpy as np
from scipy.optimize import nnls
from checkpoint import CompactTree
from rcp.core import JointState
from r4_policy import Forecast,feat
from r8_policy import predict_count,policies,decide
from r8_contracts import Source,Transaction,source_from_arrays,payload_seal,prepare_payload,Registry,seal_card,dispatch,authorize_statement
from scipy.stats import beta
from r8_protocol import ROOT,BASE,D,PROTOCOL,sha,digest

def characterize():
    rows=[json.loads(x) for x in (D/'pilot/episodes.jsonl').read_text().splitlines()]
    assert len(rows)==48
    X=[];y=[];front=[];prop=[];pred_time={m:[] for m in ['cart','rf','old']};pred_nodes={m:[] for m in pred_time}
    models={'cart':Forecast(BASE/'cart_forecast.npz'),'rf':Forecast(BASE/'rf_forecast.npz'),'old':CompactTree(ROOT/'data/checkpoint_model.npz')}
    source_cpu=[];source_bytes=[];checker=[];copycost=[];producer=[];metadata=[]
    # In-memory schema fixtures characterize executed checks; they are not
    # calibration observations and never enter the research card catalogue.
    fixture_binding={'execution':'unit-fixture'}
    fixture_cards=[seal_card(dict(id='fixture/'+e,profile='nominal',service='standard',policy='KG1',event=e,
        n=4096,k=0,upper=float(beta.ppf(1-.05/528,1,4096)),K=528,family_error=.05,bindings=fixture_binding)) for e in ['trajectory','observation']]
    fixture_reg=Registry(fixture_cards,fixture_binding)
    fixture_plan=dispatch(fixture_reg,{('nominal','standard','KG1'):0.},dict(profile='nominal',service='standard',task='both_marginals',events=['trajectory','observation'],allowance=.15,elapsed_s=0.,declared_population=True),['KG1'])
    for r in rows:
        front.append(r['front_cpu_s']/max(1,r['nraw']*np.log2(1+r['nraw'])));prop.append(r['stream_cpu_s']/40)
        z=np.load(D/'pilot'/f"{r['seed']}.npz");prior=JointState(*(z['states_'+k][0] for k in ['t','R','bias','mt','mR','P']))
        t=time.process_time_ns();source=source_from_arrays('pilot/'+str(r['seed']),z['cloud'],prior);source_cpu.append((time.process_time_ns()-t)*1e-9)
        source_bytes.append(z['cloud'].nbytes+sum(getattr(prior,k).nbytes for k in ['t','R','bias','mt','mR','P']))
        t=time.process_time_ns();prior.copy();copycost.append((time.process_time_ns()-t)*1e-9)
        t=time.process_time_ns();seal=prepare_payload(prior);producer.append((time.process_time_ns()-t)*1e-9)
        for s in r['trace']:
            X.append([1,s['query_calls'],s['iteration'],s['checkpoint_calls']]);y.append(s['cpu_total_s'])
            for name,model in models.items():
                x=np.asarray(s['feature']) if name=='old' else feat(r,s)
                t=time.process_time_ns();p,n=predict_count(model,x);pred_time[name].append((time.process_time_ns()-t)*1e-9);pred_nodes[name].append(n)
            bindings={k:'pilot' for k in ['solver','frontend','policy','forecasts','clock','protocol','generator','events']}
            transaction=Transaction(source,'KG1','nominal','standard',.3,.012,bindings)
            transaction.register_payload(1,s['iteration'],prior)
            v=dict(source=source.identity,prior=source.prior_seal,data=source.data_seal,sequence=1,iteration=s['iteration'],rollback=False,
                policy='KG1',profile='nominal',service='standard',bindings=bindings,replay_to=2,sender_work_s=.002,payload=seal)
            req={'event':'observation','assessment_s':.3,'active_bindings':bindings,'received_payload_seal':payload_seal(prior)}
            t=time.process_time_ns();transaction.assess(v,.2,2,req);checker.append((time.process_time_ns()-t)*1e-9)
            fixture_tx=Transaction(source,'KG1','nominal','standard',.3,.012,fixture_binding);fixture_tx.install(v,2)
            t=time.process_time_ns()
            fixture_reg.graph.bind('version/pilot/'+str(r['seed'])+'/'+str(s['iteration']),seal,['plan/fixture'])
            for e in ['trajectory','observation']:
                authorize_statement(fixture_reg,fixture_plan,fixture_tx,v,dict(event=e,card_seal=fixture_reg.cards[('nominal','standard','KG1',e)]['seal'],receiver_tick=2,assessment_s=.3 if e=='observation' else 4.),.2)
            metadata.append((time.process_time_ns()-t)*1e-9)
    coef,_=nnls(np.asarray(X),np.asarray(y));fitted=np.asarray(X)@coef
    # Positive numerical floors are resolutions, not independently claimed costs.
    c={'version':'R8-pilot-characterized-operation-clock-1','solver_init_s':max(float(coef[0]),1e-9),
        'query_s':max(float(coef[1]),1e-9),'iteration_s':max(float(coef[2]),1e-9),'checkpoint_s':max(float(coef[3]),1e-9),
        'frontend_nlogn_s':float(np.median(front)),'propagation_step_s':float(np.median(prop)),
        'seal_byte_s':float(np.median(np.asarray(source_cpu)/np.asarray(source_bytes))),
        'publication_s':float(np.median(producer)+np.median(copycost)),
        'receiver_base_s':float(np.median(checker)+np.median(copycost)+np.median(producer)+np.median(metadata)),
        'reserved_statement_slots':2,'statement_fixture_boundary':'in-memory valid-schema fixtures used only for timing; no fixture counts used as observations or evidence',
        'forecast_node_s':{m:float(np.median(np.asarray(pred_time[m])/np.asarray(pred_nodes[m]))) for m in pred_time},
        'forecast_max_s':{},'decision_s':1e-9}
    # Maximum path lengths from the actual frozen trees make budget reservations
    # conservative within this synthetic work clock, independent of future data.
    for name,model in models.items():
        roots=model.roots if hasattr(model,'roots') else [0]
        def depth(n):return 1 if model.left[n]<0 else 1+max(depth(int(model.left[n])),depth(int(model.right[n])))
        c['forecast_max_s'][name]=sum(depth(int(n)) for n in roots)*c['forecast_node_s'][name]
    times=[];kg=next(p for p in policies() if p['id']=='KG1');service=PROTOCOL['services'][1]
    for r in rows:
        for s in r['trace']:
            pred,_=predict_count(models['cart'],feat(r,s));t=time.process_time_ns();decide(r,s,pred,kg,c,service,.002);times.append((time.process_time_ns()-t)*1e-9)
    c['decision_s']=float(np.median(times))
    c['pilot_n']=48;c['pilot_seeds']=[r['seed'] for r in rows]
    c['model_source']='NNLS cumulative native solver CPU vs initialization/query/iteration/checkpoint counts; robust medians for other executed pilot components'
    c['fit_relative_mae']=float(np.mean(np.abs(fitted-y))/np.mean(y));c['fit_r2']=float(1-np.sum((fitted-y)**2)/np.sum((np.asarray(y)-np.mean(y))**2))
    c['pilot_episodes_sha256']=sha(D/'pilot/episodes.jsonl');c['source_sha256']=sha(__file__)
    c['boundary']='frozen deterministic synthetic service-work profile, not measured device latency/WCET; prediction is a mean-work screen'
    (D/'clock_profile.json').write_text(json.dumps(c,indent=2,allow_nan=False))
    np.savez_compressed(D/'pilot/cost_fit.npz',X=X,native_cpu_s=y,model_cpu_s=fitted)
    print(json.dumps(c,indent=2))

if __name__=='__main__':characterize()
