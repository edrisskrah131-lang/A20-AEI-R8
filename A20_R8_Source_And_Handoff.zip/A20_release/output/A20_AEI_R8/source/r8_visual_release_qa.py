"""Read-only numerical evidence; regenerate final visual QA records and previews."""
from pathlib import Path
import json, subprocess, sys, re, hashlib
import fitz
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
Q = ROOT / 'qa/r8'
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    figures = []
    for p in sorted((ROOT/'figures/r8').glob('*.pdf')):
        collision = subprocess.run([sys.executable, str(ROOT/'source/figure_qa/audit_figure_collisions.py'), str(p), '--json'], capture_output=True, text=True, check=True)
        c = json.loads(collision.stdout)
        text = subprocess.run([sys.executable, str(ROOT/'source/figure_qa/audit_pdf_text.py'), str(p), '--min-pt', '5', '--json'], capture_output=True, text=True, check=True)
        t = json.loads(text.stdout)
        (Q/(p.stem+'_collision.json')).write_text(json.dumps(c, indent=2))
        (Q/(p.stem+'_text_audit.json')).write_text(json.dumps(t, indent=2))
        with fitz.open(p) as doc:
            scale = 468/doc[0].rect.width
        row = {'figure':p.stem,'pdf_sha256':sha(p),**c['summary'], 'text_returncode':0,
               'minimum_text_pt_at_export':t['minimum_found_pt'],
               'minimum_text_pt_main_scale':t['minimum_found_pt']*scale}
        assert row['fail']==row['warn']==0 and row['minimum_text_pt_main_scale'] >= 5
        figures.append(row)
    assert len(figures)==13
    (Q/'all_figures_automated_audit.json').write_text(json.dumps(figures, indent=2))
    for source, report in [('r8_figures_data.py','data_figure_source_audit.json'), ('r8_figures_static.py','static_source_audit.json')]:
        x = subprocess.run([sys.executable, str(ROOT/'source/figure_qa/validate_figure.py'), str(ROOT/'source'/source), '--backend','python','--json'], capture_output=True, text=True)
        result=json.loads(x.stdout)
        assert result['summary']['counts']['FAIL']==0
        (Q/report).write_text(json.dumps(result,indent=2))

    pages = Q/'pdf_pages';pages.mkdir(exist_ok=True)
    papers=[]
    # These are QA-only raster previews; delivery retains the vector PDFs.
    for name in ['main','supplement']:
        p=ROOT/(name+'.pdf');doc=fitz.open(p);texts=[];outliers=[]
        for page in doc:
            texts.append(page.get_text())
            for line in [l for b in page.get_text('dict')['blocks'] if 'lines' in b for l in b['lines']]:
                for s in line['spans']:
                    x0,y0,x1,y1=s['bbox']
                    if x0 < -0.5 or y0 < -0.5 or x1 > page.rect.width+0.5 or y1 > page.rect.height+0.5:
                        outliers.append({'page':page.number+1,'bbox':s['bbox'],'text':s['text']})
        assert not outliers
        text='\n'.join(texts)
        assert not re.search(r'\b(?:TODO|TBD|INSERT HERE)\b',text)
        assert not re.search(r'(?<!\w)\[\?\](?!\w)',text)
        (Q/(name+'_extracted_text.txt')).write_text(text)
        for first in range(0,len(doc),12):
            sheet=Image.new('RGB',(1560,1740),'#e9edf0');draw=ImageDraw.Draw(sheet)
            for i in range(first,min(first+12,len(doc))):
                pix=doc[i].get_pixmap(matrix=fitz.Matrix(.7,.7));im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples);im.thumbnail((375,544))
                x=(i-first)%4*390+(390-im.width)//2;y=(i-first)//4*580+24
                sheet.paste(im,(x,y));draw.text(((i-first)%4*390+8,(i-first)//4*580+5),f'{name} page {i+1}',fill='black')
            sheet.save(pages/f'{name}_contact_{first//12+1:02d}.png')
        papers.append({'file':p.name,'pages':len(doc),'sha256':sha(p),'text_outside_page':outliers,'extracted_text_characters':len(text)})
        doc.close()
    build=(Q/'compiled_papers_final.log').read_text()
    assert len(re.findall(r'Output written on main.pdf',build))==3
    assert len(re.findall(r'Output written on supplement.pdf',build))==3
    # Only final passes matter for resolved initial cross-reference warnings.
    for name in ['main','supplement']:
        marker=f'This is pdfTeX'
        passes=[x for x in build.split(marker) if f'(./{name}.tex' in x]
        assert len(passes)==3
        final=passes[-1]
        assert not re.search(r'undefined|Overfull|Fatal|LaTeX Error|multiply defined',final,re.I),name
    (Q/'final_pdf_automated_audit.json').write_text(json.dumps({'status':'PASS','papers':papers,'source':'build stdout final passes plus PDF text-bounds and placeholders checks','figure_minimum_pt':min(x['minimum_text_pt_main_scale'] for x in figures)},indent=2))
    print(json.dumps(papers,indent=2))

if __name__=='__main__':main()
