"""Restore project photographs and display every frozen population event card."""
from pathlib import Path
import hashlib
import json
import shutil
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
NATIVE = ROOT.parents[1] / 'work/a19/RAS_A19'
F = ROOT / 'figures/r7'
Q = ROOT / 'qa'
sys.path.insert(0, str(ROOT / 'source/figure_qa'))
from audit_panel_alignment import require_matplotlib_panel_alignment

plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Helvetica', 'Arial', 'DejaVu Sans'],
    'font.size': 7.2, 'axes.titlesize': 8.2, 'axes.labelsize': 7.2,
    'xtick.labelsize': 7.0, 'ytick.labelsize': 7.0,
    'svg.fonttype': 'none', 'pdf.fonttype': 42,
    'axes.spines.top': False, 'axes.spines.right': False,
})

POLICIES = ['Fixed2','Fixed4','Fixed8','Fixed16','Final','Residual',
            'Random2or4','OldRAVC','FlatCART0.3','FlatCART','FlatCART3',
            'KG0.3','KG1','KG3','FlatRF0.3','FlatRF','FlatRF3',
            'ContractRF0.3','ContractRF','ContractRF3']
WIDTH_IN = 168 / 25.4

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(fig, name, **alignment):
    fig.canvas.draw()
    require_matplotlib_panel_alignment(
        fig, json_out=str(Q / f'r7_{name}_alignment.json'),
        tolerance_pt=1.5, gutter_tolerance_pt=1.5, strict=True, **alignment)
    fig.savefig(F / f'{name}.pdf')
    fig.savefig(F / f'{name}.svg')
    fig.savefig(F / f'{name}.png', dpi=300)
    fig.savefig(F / f'{name}.tiff', dpi=600,
                pil_kwargs={'compression': 'tiff_lzw'})
    plt.close(fig)

def restore_originals():
    originals = F / 'hardware_originals'
    originals.mkdir(parents=True, exist_ok=True)
    expected = json.loads((NATIVE / 'SHA256SUMS.json').read_text())
    records = []
    for name in ['platform_lab.jpeg','platform_side.jpeg',
                 'aircraft_field.jpeg','aircraft_field_portrait.jpeg']:
        src = NATIVE / 'assets' / name
        dst = originals / name
        assert sha(src) == expected['assets/' + name]
        shutil.copyfile(src, dst)
        assert sha(dst) == sha(src)
        records.append({'file': dst.relative_to(ROOT).as_posix(),
                        'bytes': dst.stat().st_size, 'sha256': sha(dst),
                        'size_px': list(Image.open(dst).size),
                        'crop': 'none', 'pixel_adjustment': 'none',
                        'role': 'project hardware/context, no localization measurement'})
    platform = ROOT / 'figures/platform_routes.pdf'
    assert sha(platform) == sha(NATIVE / 'figures/platform_routes.pdf')
    (Q / 'r7_hardware_manifest.json').write_text(json.dumps(
        {'originals': records, 'restored_main_platform_pdf_sha256': sha(platform)},
        indent=2))

def population_cards():
    d = pd.read_csv(ROOT / 'data/r4_final/calibration.csv')
    assert len(d) == 120 and set(d.policy) == set(POLICIES)
    fig, axs = plt.subplots(1, 2, figsize=(WIDTH_IN, 123/25.4), sharey=True)
    fig.subplots_adjust(left=.185, right=.985, bottom=.25, top=.86, wspace=.15)
    cmap = LinearSegmentedColormap.from_list(
        'population_bounds', ['#32749b','#eef3f5','#c98146'])
    norm = TwoSlopeNorm(vmin=0, vcenter=.15, vmax=.35)
    exported = []
    for ax, phase, letter, title, n in zip(
        axs, ['nominal_calibration','geometry_calibration'], 'ab',
        ['Nominal mixture','Unfitted geometry'], [456,240]):
        rows = d[d.phase == phase].set_index(['policy','load'])
        matrix = np.empty((20,6), float)
        for i, policy in enumerate(POLICIES):
            for j, load in enumerate([1,10,20]):
                r = rows.loc[(policy,float(load))]
                assert r['n'] == n
                for k, event, column in [(0,'Trajectory','upper_risk'),
                                         (1,'Observation','task_upper_risk')]:
                    value = float(r[column])
                    matrix[i,2*j+k] = value
                    exported.append({'mixture':phase,'policy':policy,'load':load,
                                     'event':event,'n':n,'upper_bound':value,
                                     'within_allowance': value <= .15})
        assert np.isfinite(matrix).all()
        im = ax.imshow(matrix, cmap=cmap, norm=norm, aspect='auto',
                       interpolation='nearest')
        yy, xx = np.where(matrix <= .15)
        ax.scatter(xx, yy, s=7, color='#182c3a', edgecolors='none')
        ax.set_xticks(range(6), ['T','O'] * 3)
        ax.set_yticks(range(20), POLICIES)
        ax.tick_params(axis='both', length=0, pad=4)
        ax.set_ylim(19.5,-.5)
        ax.set_title(f'{letter}  {title}', loc='left', pad=31, fontweight='bold')
        for j, load in enumerate([1,10,20]):
            ax.text((2*j+1)/6, 1.025, f'Load {load}', transform=ax.transAxes,
                    ha='center', va='bottom', fontsize=7.0)
        for edge in [1.5,3.5]:
            ax.axvline(edge, color='white', lw=1.6)
        for side in ['left','right','top','bottom']:
            ax.spines[side].set_visible(False)
        ax.set_xlabel(f'{len(yy)}/120 bounds within 0.15; n = {n}', labelpad=8)
    cax = fig.add_axes([.30,.071,.40,.024])
    cb = fig.colorbar(im, cax=cax, orientation='horizontal',
                      ticks=[0,.10,.15,.20,.30,.35])
    cb.ax.tick_params(labelsize=6.6, length=2)
    cb.set_label('Simultaneous upper risk bound U', fontsize=7.0, labelpad=4)
    fig.text(.185,.137, 'T: trajectory event   O: observation event   ', fontsize=7.0)
    fig.text(.72,.137, 'Dot: U ≤ 0.15', fontsize=7.0)
    save(fig, 'population_cards', exclude_axes=[cax])
    out = pd.DataFrame(exported)
    assert len(out) == 240 and out.within_allowance.sum() == 125
    out.to_csv(F / 'population_cards_source.csv', index=False)
    (Q / 'r7_population_cards_counts.json').write_text(json.dumps({
        'source_sha256': sha(ROOT / 'data/r4_final/calibration.csv'),
        'displayed_bounds': len(out), 'eligible_bounds': 125,
        'omitted_bounds': 0, 'additional_samples': 0,
        'eligibility_uses_unrounded_values': True}, indent=2))

def additional_hardware_views():
    fig, axs = plt.subplots(1, 2, figsize=(WIDTH_IN, 111/25.4))
    fig.subplots_adjust(left=.015,right=.985,bottom=.03,top=.91,wspace=.08)
    names = ['platform_side.jpeg','aircraft_field_portrait.jpeg']
    titles = ['Platform integration detail','Under-fuselage field context']
    for ax, name, letter, title in zip(axs, names, 'ab', titles):
        a = Image.open(F / 'hardware_originals' / name)
        # Preserve image pixels and natural proportions within equal aligned
        # panel canvases. The unused landscape-canvas area remains white.
        ax.imshow(a, aspect='equal', extent=[0,a.width,a.height,0])
        ax.set_xlim(0,1280)
        ax.set_ylim(1707,0)
        ax.set_anchor('N')
        ax.set_axis_off()
        ax.set_title(f'{letter}  {title}', loc='left', pad=6, fontweight='bold')
    save(fig, 'hardware_details')

def main():
    F.mkdir(parents=True, exist_ok=True)
    restore_originals()
    population_cards()
    additional_hardware_views()
    print('R7_RESTORATION_FIGURES_COMPLETE', flush=True)

if __name__ == '__main__':
    main()
