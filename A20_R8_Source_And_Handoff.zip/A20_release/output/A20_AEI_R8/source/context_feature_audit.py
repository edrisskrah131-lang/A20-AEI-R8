"""Retrospective frozen-context predictor audit from A20 stored episode traces.

No new geometric scans, optimization or physical trials. Fits shallow trees
using training episodes only; fixed settings; reports independent confirmation
scores. Observational and not part of the original certified policy family.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeRegressor

ROOT=Path(__file__).resolve().parents[1]
rows=[json.loads(line) for line in (ROOT/'data/episodes.jsonl').open()]

def to_features(rr):
    x=[]; y=[]; ids=[]
    for r in rr:
        errors=np.array(r['error']);mse=(errors[:,5:]**2).mean(1);tail=(errors[:,5:]>.1).any(1).astype(float)
        final=len(errors)-1
        for j,s in enumerate(r['trace'],1):
            x.append(s['feature']);y.append([mse[j],mse[final],tail[j],tail[final],max(r['cpu_s']-s['cpu_total_s'],0.),mse[j]-mse[0]])
            ids.append(r['seed'])
    return np.array(x),np.array(y),np.array(ids)

train=to_features(r for r in rows if r['phase']=='train')
confirm=to_features(r for r in rows if r['phase']=='confirmation')
X,Y,S=train; XX,YY,SS=confirm
scale=np.maximum(Y.std(0),[1e-4,1e-4,.1,.1,.001,1e-4])
# Full: all 11; no-context: strips engineering prior uncertainty and aircraft identity;
# context-only: keep prior uncertainty, aircraft identity and checkpoint number;
# with fewer observed quality measures, diagnostic only.
configs={
 'full 11-feature state':list(range(11)),
 'without prior/model context':[1,2,3,4,5,6,7,8,9],
 'context and progress only':[0,7,10],
}
out=[]
for name,ids in configs.items():
    model=DecisionTreeRegressor(max_depth=6,min_samples_leaf=24,random_state=20261011)
    model.fit(X[:,ids],Y/scale)
    P=model.predict(XX[:,ids])*scale
    standardized_mse=np.mean(((P-YY)/scale)**2)
    brier_cur=np.mean((np.clip(P[:,2],0,1)-YY[:,2])**2)
    brier_final=np.mean((np.clip(P[:,3],0,1)-YY[:,3])**2)
    # equal-weighted mean over episodes to guard checkpoint pseudoreplication.
    frame=pd.DataFrame({'seed':SS, 'current_brier':(np.clip(P[:,2],0,1)-YY[:,2])**2,
                        'final_brier':(np.clip(P[:,3],0,1)-YY[:,3])**2,
                        'sse':np.mean(((P-YY)/scale)**2,axis=1)})
    ep=frame.groupby('seed',sort=True).mean()
    out.append({'representation':name, 'features':','.join(map(str,ids)),
                'n_episodes':len(ep),'n_checkpoints':len(frame),
                'episode_equal_weight_sse':ep['sse'].mean(),
                'episode_equal_weight_current_brier':ep['current_brier'].mean(),
                'episode_equal_weight_final_brier':ep['final_brier'].mean(),
                'checkpoint_weighted_sse':standardized_mse,
                'checkpoint_weighted_current_brier':brier_cur,
                'checkpoint_weighted_final_brier':brier_final,
                'nodes':model.tree_.node_count})
path=ROOT/'data/aei_context_predictor_ablation.csv';pd.DataFrame(out).to_csv(path,index=False)
print(pd.DataFrame(out).to_string(index=False))
