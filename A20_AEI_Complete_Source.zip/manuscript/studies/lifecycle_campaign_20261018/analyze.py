"""Summarize actual campaign execution, retaining baseline equivalence."""
import csv
import hashlib
import json
import os
import platform
import time
from pathlib import Path
import numpy as np
import pandas as pd
from campaign import ROOT,METHODS,STAGES,EVENTS,CONFIGS,REQUESTS,Planner

OUT=ROOT/'outputs'

def full_family():
    """One fresh catalogue per method across the entire predefined 64-context family.

    This is distinct from the fixed 16-step demand schedule's sparse catalogue.
    Both are built once per population, never multiplied by the 64 test sources.
    """
    if all((OUT/name).exists() for name in ('family_method_summary.csv','family_plans.csv','family_constructed_cards.json')):
        # Preserve recorded timing trials when regenerating derived summaries.
        return pd.read_csv(OUT/'family_method_summary.csv').to_dict('records')
    cal=pd.read_csv(OUT/'calibration_observations.csv')
    groups={v:g[['gsd_m','blur_px','coverage','reprojection_px','association_m']].to_dict('records')
            for v,g in cal.groupby('variant')}
    from scipy.stats import beta
    beta.isf(.05/64,1,256)
    plans=[];summary=[];cards={}
    for method in METHODS:
        planner=Planner(method,groups);start=time.perf_counter_ns();cpu=time.process_time_ns()
        answers=[]
        for variant in CONFIGS:
            for request in REQUESTS:
                answer=planner.plan(variant,request)
                answers.append(dict(method=method,variant=variant,request=request,**answer))
        cpu_s=(time.process_time_ns()-cpu)*1e-9;wall_s=(time.perf_counter_ns()-start)*1e-9
        plans.extend(answers);cards[method]=planner.cards
        summary.append(dict(method=method,contexts=len(answers),supported=sum(x['authorized'] for x in answers),
            constructed_cards=planner.cp_calls,record_evaluations=planner.evaluations,
            containment_routes=sum(x['route']=='containment' for x in answers),
            cpu_s=cpu_s,wall_s=wall_s))
    frame=pd.DataFrame(plans)
    pivot=frame.pivot(index=['variant','request'],columns='method',values='authorized')
    assert pivot.eq(pivot['DAG exact + registry'],axis=0).all().all()
    frame.to_csv(OUT/'family_plans.csv',index=False)
    pd.DataFrame(summary).to_csv(OUT/'family_method_summary.csv',index=False)
    (OUT/'family_constructed_cards.json').write_text(json.dumps(cards,indent=2)+'\n')
    return summary

def main():
    family=full_family()
    d=pd.read_csv(OUT/'decisions.csv');o=pd.read_csv(OUT/'campaign_observations.csv')
    c=pd.read_csv(OUT/'catalogue_events.csv');cal=pd.read_csv(OUT/'calibration_observations.csv')
    risks=pd.read_csv(OUT/'exact_risk_cards.csv');groups=d.groupby('method')
    assert len(cal)==2048 and cal.seed.nunique()==256
    assert len(d)==4096 and d.seed.nunique()==64
    assert d.issued.eq(d.oracle_issue).all()
    pivot=d.pivot(index=['seed','index'],columns='method',values='issued')
    assert pivot.eq(pivot['DAG exact + registry'],axis=0).all().all()
    table=[]
    for method in METHODS:
        g=groups.get_group(method);cat=c[c.method==method]
        repairs=g[g.kind=='repair'];eligible_repair=repairs.exact_eligible
        final=g[g['index']==15];eligible=final.exact_eligible
        numeric=g[g.numerical_cpu_s>0]
        table.append(dict(method=method,workflow_decisions=len(g),issued=int(g.issued.sum()),
            false_issuances=int((g.issued & ~g.oracle_issue).sum()),
            authority_oracle_disagreements=int(g.issued.ne(g.oracle_issue).sum()),
            invalid_binding_issuances=int((g.issued & (~g.numerical_binding_valid | ~g.identity_valid)).sum()),
            final_eligible_sources=int(eligible.sum()),final_recovered_sources=int((final.issued & eligible).sum()),
            eligible_recovery_checkpoints=int(eligible_repair.sum()),
            restored_recovery_checkpoints=int((repairs.issued & eligible_repair).sum()),
            successful_repair_commits=int(g.repair_accepted.fillna(False).astype(bool).sum()),
            evidence_cards=int(cat.new_cards.sum()),evidence_record_evaluations=int(cat.record_evaluations.sum()),
            catalogue_cpu_ms=float(cat.cpu_s.sum()*1000),catalogue_wall_ms=float(cat.wall_s.sum()*1000),
            pipeline_cpu_s=float(g.numerical_cpu_s.sum()),pipeline_wall_s=float(g.numerical_wall_s.sum()),
            event_cpu_s=float(g.cpu_s.sum()),event_wall_s=float(g.wall_s.sum()),
            median_source_event_wall_s=float(g.groupby('seed').wall_s.sum().median()),
            **{f'calls_{s}':int(g['calls_'+s].sum()) for s in STAGES},
            **{f'provider_cpu_{s}':float(g['provider_cpu_'+s].sum()) for s in STAGES}))
    pd.DataFrame(table).to_csv(OUT/'method_summary.csv',index=False)
    per_event=[]
    for (method,index),g in d.groupby(['method','index'],sort=False):
        per_event.append(dict(method=method,index=int(index),event=g.event.iloc[0],sources=len(g),
            issued=int(g.issued.sum()),eligible=int(g.exact_eligible.sum()),
            states=';'.join(sorted(g.state.unique())),revision=int(g.revision.iloc[0]),
            cpu_s=float(g.cpu_s.sum()),wall_s=float(g.wall_s.sum()),
            **{f'calls_{s}':int(g['calls_'+s].sum()) for s in STAGES}))
    pd.DataFrame(per_event).to_csv(OUT/'event_summary.csv',index=False)
    # Paired resampling unit is one independent source, not one event/method.
    sums=d.groupby(['seed','method']).cpu_s.sum().unstack('method')
    a=sums['Whole renewal'].to_numpy();b=sums['DAG exact + registry'].to_numpy()
    saving=(1-b.sum()/a.sum())*100
    rng=np.random.default_rng(202630900);indices=rng.integers(0,len(a),(10000,len(a)))
    boot=(1-b[indices].sum(1)/a[indices].sum(1))*100
    ci=np.quantile(boot,[.025,.975]).tolist()
    t={r['method']:r for r in table}
    exact=t['DAG exact + registry'];contract=t['Containment + repair']
    f={r['method']:r for r in family}
    numerical_unique=o[['seed','population','variant']].drop_duplicates()
    nominal=o[o.population=='four-layout skin mixture v1'].drop_duplicates(['seed','variant'])
    heldout=[]
    for variant,g in nominal.groupby('variant'):
        for request,limits in REQUESTS.items():
            valid=np.ones(len(g),dtype=bool)
            for metric,(lo,hi) in limits.items():
                values=g[metric].to_numpy();valid &= np.isfinite(values)
                if lo is not None:valid &= values>=lo
                if hi is not None:valid &= values<=hi
            bound=risks[(risks.variant==variant)&(risks.request==request)].iloc[0]
            heldout.append(dict(variant=variant,request=request,test_sources=len(g),
                test_failures=int((~valid).sum()),calibration_upper=float(bound.upper),
                authorized=bool(bound.authorized)))
    pd.DataFrame(heldout).to_csv(OUT/'heldout_request_scores.csv',index=False)
    summary=dict(status='PASS',independent_calibration_sources=256,independent_test_sources=64,
        paired_stress_alternatives=64,family_K=64,calibration_outputs=len(cal),
        calibration_numerical_cpu_s=float(cal.cpu_s.sum()),
        calibration_provider_cpu_s=float(cal[['provider_cpu_'+s for s in STAGES]].to_numpy().sum()),
        distinct_campaign_source_population_configurations=len(numerical_unique),
        heldout_nominal_configurations=sorted(nominal.variant.unique()),heldout_scored_contexts=len(heldout),
        calibration_only_configurations=sorted(set(CONFIGS)-set(nominal.variant.unique())),
        numerical_evaluation_requests=len(o),workflow_steps_per_source=16,
        decisions_per_method=1024,total_workflow_decisions=len(d),
        admitted_family_contexts=int(risks.authorized.sum()),family_contexts=64,
        evidence_record_saving_vs_exact_percent=(1-contract['evidence_record_evaluations']/exact['evidence_record_evaluations'])*100,
        trace_demand_evidence_record_saving_vs_exact_percent=(1-contract['evidence_record_evaluations']/exact['evidence_record_evaluations'])*100,
        full_family_evidence_record_saving_vs_exact_percent=(1-f['Containment + repair']['record_evaluations']/f['DAG exact + registry']['record_evaluations'])*100,
        dag_event_cpu_saving_vs_whole_percent=saving,dag_paired_source_bootstrap_ci=ci,
        bootstrap_replicates=10000,bootstrap_seed=202630900,
        strong_method_support_agreement=True,strong_method_numerical_identity=True,
        catalogue_cache_boundary='One shared population-level catalogue per method, reused for every test source. Full64-context and sparse16-step-demand catalogues are separate demand experiments; neither count is multiplied by64.',
        full_family_methods=family,
        methods=table,
        recovery=dict(quarantine_events_per_source=2,valid_repair_commits_per_source=2,
            first_incident_steps_from_quarantine_to_valid_repair=2,
            second_incident_steps_from_quarantine_to_valid_repair=1,
            interpretation='Prescribed workflow transitions, not physical recovery-time estimates; all strong methods equal.'),
        rollback=dict(numerical_variant='baseline',registry_revision_before_rollback=8,
            registry_revision_after_rollback=9,
            actual_dag_provider_calls=int(d[(d.method=='DAG exact + registry') & (d.kind=='rollback')][['calls_'+s for s in STAGES]].to_numpy().sum())),
        population_mismatch=dict(requests_per_method=64,issued_by_any_method=int(d[d.kind=='population'].issued.sum()),
            numerically_executed=True,calibration_card_reuse_allowed=False),
        environment=dict(platform=platform.platform(),python=platform.python_version(),
            cpu_model=next((l.split(':',1)[1].strip() for l in Path('/proc/cpuinfo').read_text().splitlines() if l.startswith('model name')),'unknown'),
            process_workers=2,openblas_threads=os.environ.get('OPENBLAS_NUM_THREADS'),omp_threads=os.environ.get('OMP_NUM_THREADS'),
            cgroup_cpu_max=Path('/sys/fs/cgroup/cpu.max').read_text().strip() if Path('/sys/fs/cgroup/cpu.max').exists() else None,
            host_shared_with_other_tasks=True),
        attribution='Numerical savings belong to ordinary DAG caching shared by all three strong methods. Containment reduces proof construction work relative to exact cards; independent rules reproduce it.',
        scope='Simulated pixels and numerical outputs, trusted control plane, fixed finite campaign. No field-safety or human-labor inference.',
        input_hashes={n:hashlib.sha256((OUT/n).read_bytes()).hexdigest() for n in
            ('calibration_observations.csv','exact_risk_cards.csv','decisions.csv','campaign_observations.csv','catalogue_events.csv','family_method_summary.csv','family_plans.csv','example_traces.json')})
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
