"""Integrated policy execution, publication, replacement/replay and witnesses.

Trace experiments reuse one actually executed common ICP prefix per input.
Every online decision consumes only the revealed checkpoint. Native CPU is
charged from that prefix; rules, sealing and receiver replay actually execute.
Complete routes use the same contracts with a live CountedICP provider.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import time,json
import numpy as np
from checkpoint import CompactTree
from rcp.core import JointState,propagate
from r4_policy import Forecast,feat
from r8_protocol import ROOT,BASE,D,PROTOCOL,digest,sha
from r8_policy import decide,solver_work,stage_reservation,predict_count,prediction_work
from r8_contracts import Transaction,source_from_arrays,authorize_statement,payload_seal,prepare_payload,procedural_version_check,procedural_statement_check,Precommit,events_for

def load_models():
    return {'cart':Forecast(BASE/'cart_forecast.npz'),'rf':Forecast(BASE/'rf_forecast.npz'),'old':CompactTree(ROOT/'data/checkpoint_model.npz')}

def prediction_cache(r,models):
    cache={}
    for name,model in models.items():
        values=[]
        for s in r['trace']:
            x=np.asarray(s['feature']) if name=='old' else feat(r,s)
            t=time.process_time_ns();p,n=predict_count(model,x);cpu=(time.process_time_ns()-t)*1e-9
            values.append((p,n,cpu))
        cache[name]=values
    return cache

def state_from(z,index):return JointState(*(z['states_'+k][index].copy() for k in ['t','R','bias','mt','mR','P']))

def controlled(r,z,policy,cache,clock,service,bindings,plan=None,registry=None,procedural=False):
    if plan is not None and plan.get('status')=='REFUSED':return refused_prior(r,clock,service)
    t0=time.process_time_ns();commit=None
    if plan is not None:
        w=plan['witness'];commit=Precommit(dict(profile=w['profile'],service=w['service'],task=w['task'],
            events=events_for(w['task']),allowance=w['allowance'],elapsed_s=0.,declared_population=True),plan)
    precommit_cpu=(time.process_time_ns()-t0)*1e-9
    prior=state_from(z,0);start=time.process_time_ns();source=source_from_arrays('scan/'+str(r['seed']),z['cloud'],prior)
    seal_cpu=(time.process_time_ns()-start)*1e-9
    if commit is not None:commit.bind_source(source);commit.verify(plan);commit.verify_execution(policy['id'],r['profile'],service['id'])
    tx=Transaction(source,policy['id'],r['profile'],service['id'],service['deadline_s'],service['budget_s'],bindings,commit.identity if commit else None)
    g0=time.process_time_ns()
    if plan is not None and registry is not None and not procedural:
        registry.graph.bind('source/'+source.identity,source.prior_seal+source.data_seal,['component/'+k for k in bindings])
        registry.graph.bind('transaction/'+source.identity,digest({'source':source.identity,'policy':policy['id']}),
            ['source/'+source.identity]+([plan['node']] if 'node' in plan else []))
    graph_source_cpu=(time.process_time_ns()-g0)*1e-9
    front_work=clock['frontend_nlogn_s']*max(1,r['nraw']*np.log2(1+r['nraw']))
    seal_work=clock['seal_byte_s']*(z['cloud'].nbytes+sum(getattr(prior,k).nbytes for k in ['t','R','bias','mt','mR','P']))
    fixed_work=front_work+seal_work;dec_work=0.;dec_cpu=0.;monitor_cpu=graph_source_cpu;pubs=[];decisions=[]
    stop=-1;budget=False;last_it=0;sequence=0;payloads={}
    def produce(index,seq):
        nonlocal monitor_cpu
        t=time.process_time_ns();state=state_from(z,index);seal=tx.register_payload(seq,r['trace'][index-1]['iteration'] if index else 0,state)
        payloads[seq]=seal;monitor_cpu+=(time.process_time_ns()-t)*1e-9
    for i,s in enumerate(r['trace']):
        next_it=[1,2,4,8,16,25][min(i,5)]
        reserve=stage_reservation(last_it,next_it,policy['model'],clock)
        current_solver=solver_work(r['trace'][i-1],clock) if i else clock['solver_init_s']+clock['query_s']
        if seal_work+current_solver+dec_work+reserve>service['budget_s']+1e-12:
            budget=True
            if stop>=0 and r['trace'][stop]['eligible'] and not (r['trace'][stop]['done'] and not r['trace'][stop]['accepted']) and not any(x[0]==stop+1 for x in pubs):
                # A common hard-budget fallback, rather than weakening controls.
                if seal_work+current_solver+dec_work+clock['publication_s']<=service['budget_s']+1e-12:
                    sequence+=1;dec_work+=clock['publication_s'];produce(stop+1,sequence);pubs.append((stop+1,fixed_work+current_solver+dec_work,sequence))
            break
        p,n,forecast_cpu=cache[policy['model']][i] if policy['model'] else (None,0,0.)
        t=time.process_time_ns();pub,halt,detail=decide(r,s,p,policy,clock,service,fixed_work+solver_work(s,clock)+dec_work+prediction_work(policy['model'],n,clock))
        dcpu=(time.process_time_ns()-t)*1e-9;dec_cpu+=forecast_cpu+dcpu
        dec_work+=prediction_work(policy['model'],n,clock)+clock['decision_s'];stop=i;last_it=s['iteration']
        paid=fixed_work+solver_work(s,clock)+dec_work
        if pub:
            sequence+=1;paid+=clock['publication_s'];dec_work+=clock['publication_s'];produce(i+1,sequence);pubs.append((i+1,paid,sequence))
        decisions.append({'iteration':s['iteration'],'publish':bool(pub),'halt':bool(halt),'sender_work_s':paid,**detail})
        if halt:break
    if stop>=0:
        last=r['trace'][stop];paid=fixed_work+solver_work(last,clock)+dec_work;solver_cpu=last['cpu_total_s']
        if last['done'] and not last['accepted'] and pubs:
            sequence+=1;paid+=clock['publication_s'];dec_work+=clock['publication_s'];produce(0,sequence);pubs.append((0,paid,sequence))
    else:
        last={'iteration':0};paid=fixed_work;solver_cpu=0.
    deliveries=[];receiver_work=0.;replay_cpu=0.;active=np.zeros(41,dtype=int);journals=[]
    for index,c,seq in pubs:
        denominator=.1-service['load']*clock['propagation_step_s']
        tick=max(1,int(np.ceil((PROTOCOL['queue_s']+service['load']*(c+receiver_work+clock['receiver_base_s']))/denominator))) if denominator>0 else 41
        if tick>40:continue
        t=time.process_time_ns()
        version={'source':source.identity,'prior':source.prior_seal,'data':source.data_seal,'sequence':seq,
            'iteration':r['trace'][index-1]['iteration'] if index else 0,'rollback':index==0,
            'policy':policy['id'],'profile':r['profile'],'service':service['id'],'bindings':bindings,
            'replay_to':tick,'sender_work_s':c-front_work,'payload':payloads[seq],'commit_id':tx.commit_id}
        # Operational installation remains valid after an observation request
        # expires; only that scheduled statement expires. No late pose counts at D.
        current={k:registry.runtime.get(k) for k in bindings} if registry is not None else bindings
        checkreq={'event':'trajectory','assessment_s':4.,'active_bindings':current,'received_payload_seal':payload_seal(state_from(z,index))}
        if procedural:
            ok=procedural_version_check(source,policy['id'],r['profile'],service['id'],service['deadline_s'],service['budget_s'],bindings,
                version,tick*.1,tick,tx.last_sequence,tx.last_iteration,tx.rollback,checkreq,tx.expected_versions)
            check={'valid':ok,'reasons':[] if ok else ['procedural_validation']}
            if tx.commit_id is not None and version.get('commit_id')!=tx.commit_id:check={'valid':False,'reasons':['precommit_identity']}
        else:check=tx.assess(version,tick*.1,tick,checkreq)
        if plan is not None and registry is not None and (plan.get('status')!='SELECTED' or plan.get('node') in registry.graph.revoked):
            check={'valid':False,'reasons':['revoked_plan']}
        monitor_cpu+=(time.process_time_ns()-t)*1e-9
        if not check['valid']:
            journals.append({'tick':tick,'sequence':seq,'refused':check['reasons']});continue
        t=time.process_time_ns();cur=state_from(z,index)
        for k in range(tick):cur=propagate(cur,.1,z['increment'][k])
        replay_cpu+=(time.process_time_ns()-t)*1e-9
        t=time.process_time_ns();tx.install(version,tick);monitor_cpu+=(time.process_time_ns()-t)*1e-9
        if plan is not None and registry is not None and not procedural:
            t=time.process_time_ns()
            registry.graph.bind('version/'+source.identity+'/'+str(seq),payloads[seq],['transaction/'+source.identity])
            monitor_cpu+=(time.process_time_ns()-t)*1e-9
        if plan is not None and registry is not None:
            t=time.process_time_ns();statements=[]
            for event in plan['witness']['bounds']:
                c0=registry.cards[(r['profile'],service['id'],policy['id'],event)]
                req={'event':event,'card_seal':c0['seal'],'receiver_tick':tick,'assessment_s':service['deadline_s'] if event!='trajectory' else 4.}
                if procedural:
                    ok=procedural_statement_check(registry,plan,tx,version,req,tick*.1)
                    a={'authorized':ok,'upper':c0['upper'] if ok else None}
                else:a=authorize_statement(registry,plan,tx,version,req,tick*.1)
                statements.append({'event':event,'authorized':a['authorized'],'upper':a['upper']})
            monitor_cpu+=(time.process_time_ns()-t)*1e-9
        else:statements=[]
        active[tick:]=index;receiver_work+=clock['receiver_base_s']+tick*clock['propagation_step_s']
        deliveries.append((tick,index));journals.append(dict(tx.journal[-1],statements=statements))
        # Independently recompute the installed state error to validate replay,
        # rather than merely appending an illustrative source seal.
        truth=z['future_truth'][tick];e=float(np.linalg.norm((cur.t-cur.mt)@cur.mR-(truth[:3]-z['map_t'])@z['map_R']))
        assert abs(e-r['error'][index][tick])<2e-9
    pe=np.asarray(r['error'])[active,np.arange(41)];deadline_tick=int(round(service['deadline_s']/.1))
    ready=bool(active[deadline_tick]>0);success=bool(ready and pe[deadline_tick]<=.1)
    trajectory=int(np.any(pe[5:]>.1));observation=int(not success)
    total_work=paid+40*clock['propagation_step_s']+receiver_work
    total_cpu=r['front_cpu_s']+seal_cpu+solver_cpu+dec_cpu+r['stream_cpu_s']+replay_cpu+monitor_cpu+precommit_cpu
    return {'seed':r['seed'],'phase':r['phase'],'profile':r['profile'],'mesh':r['mesh'],'level':r['level'],
        'noise':r['noise'],'sd':r['sd'],'policy':policy['id'],'service':service['id'],'load':service['load'],
        'deadline_s':service['deadline_s'],'budget_s':service['budget_s'],'work_s':total_work,'sender_work_s':paid-front_work,
        'sender_total_work_s':paid,
        'native_charged_cpu_s':total_cpu,'front_cpu_s':r['front_cpu_s'],'seal_cpu_s':seal_cpu,'solver_cpu_s':solver_cpu,
        'decision_cpu_s':dec_cpu,'stream_cpu_s':r['stream_cpu_s'],'receiver_cpu_s':replay_cpu+monitor_cpu,'precommit_cpu_s':precommit_cpu,
        'loss_m2s':float(np.sum(pe[1:]**2)*.1),'rmse_m':float(np.sqrt(np.mean(pe[5:]**2))),
        'p95_m':float(np.quantile(pe[5:],.95)),'max_m':float(pe[5:].max()),
        'trajectory_failure':trajectory,'observation_failure':observation,'union_failure':int(trajectory or observation),
        'capture_ready':int(ready),'capture_success':int(success),'capture_error_m':float(pe[deadline_tick]),
        'stop_iteration':last['iteration'],'publications':len(pubs),'installed':len(deliveries),'budget_stop':int(budget),
        'profile_guard':int(any(x['guard'] for x in decisions)),'deadline_guard':int(any(x['deadline'] for x in decisions)),
        'first_delivery_s':min([t*.1 for t,ix in deliveries if ix>0],default=4.1),
        'trace':json.dumps({'decisions':decisions,'installations':journals},separators=(',',':'))}

def refused_prior(r,clock,service):
    # Admission occurs before scan processing; no registered version or card is
    # published. Common odometry continues with an explicitly unsupported pose.
    pe=np.asarray(r['error'][0]);trajectory=int(np.any(pe[5:]>.1));tick=int(round(service['deadline_s']/.1))
    base={k:r[k] for k in ['seed','phase','profile','mesh','level','noise','sd']}
    base.update(policy='REFUSED_PRIOR',service=service['id'],load=service['load'],deadline_s=service['deadline_s'],budget_s=service['budget_s'],
        work_s=40*clock['propagation_step_s'],sender_work_s=0.,sender_total_work_s=0.,native_charged_cpu_s=r['stream_cpu_s'],
        front_cpu_s=0.,seal_cpu_s=0.,solver_cpu_s=0.,decision_cpu_s=0.,stream_cpu_s=r['stream_cpu_s'],receiver_cpu_s=0.,precommit_cpu_s=0.,
        loss_m2s=float(np.sum(pe[1:]**2)*.1),rmse_m=float(np.sqrt(np.mean(pe[5:]**2))),p95_m=float(np.quantile(pe[5:],.95)),max_m=float(pe[5:].max()),
        trajectory_failure=trajectory,observation_failure=1,union_failure=1,capture_ready=0,capture_success=0,capture_error_m=float(pe[tick]),
        stop_iteration=0,publications=0,installed=0,budget_stop=0,profile_guard=0,deadline_guard=0,first_delivery_s=4.1,
        trace=json.dumps({'decisions':[],'installations':[],'admission':'REFUSED','risk_statement':None},separators=(',',':')))
    return base
