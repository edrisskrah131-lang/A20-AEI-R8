"""Structural-prior correction core."""
