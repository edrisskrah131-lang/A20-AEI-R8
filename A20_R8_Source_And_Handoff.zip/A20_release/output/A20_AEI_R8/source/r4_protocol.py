"""Frozen reconstruction of the audited R4 scientific protocol.

New seed ranges deliberately exclude all lost R4 and retained A19/R3 inputs.
"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'data/r4_final';D.mkdir(parents=True,exist_ok=True)
PROTOCOL={'version':'A20-AEI-R4-recovery-3','seed_ranges':{
 'nominal_calibration':[5100000,480],'nominal_confirmation':[5200000,640],
 'difficult_confirmation':[5300000,480],'shift_confirmation':[5400000,360],
 'geometry_calibration':[5500000,240],'geometry_confirmation':[5600000,480]},
 'nominal_prior_sd':[.015,.03,.06],'difficult_prior_sd':[.04,.06,.08,.1],
 'shift_prior_sd':[.07,.14],'nominal_noise':[1.,2.],'shift_noise':[3.,4.],
 'caps':[2,4,8,16,25],'loads':[1.,10.,20.],'queue_s':.05,'dt_s':.1,
 'capture_deadline_s':.3,'horizon_s':4.,'position_threshold_m':.1,
 'development_inputs':'all 1120 retained R3 episodes; source-grouped 80/20 split',
 'family_error':.05,'risk_limit':.15,'prices':[.3,1.,3.],
 'geometry':'new procedural closed triangular aircraft-like surface; excluded from fitting',
 'truth_use':'offline sensor generation and outcome labels only',
 'recovery':'Original active scratch was unexpectedly cleared after audited R4 completion. Recovered exact theory/evaluation source; reconstructed remaining modules and generated this entirely new final batch. Lost results are not used in this batch.'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def freeze_protocol():
 p=D/'protocol.json'
 if p.exists():assert json.loads(p.read_text())==PROTOCOL
 else:p.write_text(json.dumps(PROTOCOL,indent=2))
