"""Restore the unchanged retained release to the relative input path."""
from pathlib import Path
import zipfile
ROOT=Path(__file__).resolve().parents[1];WORK=ROOT.parents[1]
archive=ROOT/'preserved/A19_source_and_results.zip';destination=WORK/'work/a19'
required=destination/'RAS_A19/data/missions/B767_mission0/inputs.npz'
if required.exists():
    print('Retained aircraft inputs already available:',destination/'RAS_A19')
else:
    destination.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        for name in z.namelist():
            assert name.startswith('RAS_A19/')
            assert (destination/name).resolve().is_relative_to(destination.resolve())
        z.extractall(destination)
    print('Restored retained aircraft inputs:',destination/'RAS_A19')
