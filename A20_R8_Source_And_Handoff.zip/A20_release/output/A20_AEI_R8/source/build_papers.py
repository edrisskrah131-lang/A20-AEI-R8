"""Compile the publisher sources with the supplied official numerical style."""
import subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def run(*args):subprocess.run(args,cwd=ROOT,check=True)
for name in ['main','supplement']:
    # Discard transient files from an interrupted previous TeX run. Keep the
    # supplied bibliography and scientific source; rebuild cross-references.
    for suffix in ['.aux','.out','.toc']:
        (ROOT/(name+suffix)).unlink(missing_ok=True)
    run('pdflatex','-interaction=nonstopmode','-halt-on-error',name+'.tex')
    if name=='main':run('bibtex',name)
    run('pdflatex','-interaction=nonstopmode','-halt-on-error',name+'.tex')
    run('pdflatex','-interaction=nonstopmode','-halt-on-error',name+'.tex')
