"""Blender Cycles physical geometry/material render; no generated photographic assets."""
import bpy,sys,json,time,math,argparse,random,platform
from bpy_extras.object_utils import world_to_camera_view
from pathlib import Path
from mathutils import Vector,Matrix
import numpy as np
P=argparse.ArgumentParser();P.add_argument('--seed',type=int,default=202618701);P.add_argument('--out',required=True);P.add_argument('--samples',type=int,default=48);P.add_argument('--variants',default='baseline,exposure,lighting');P.add_argument('--save-blend',action='store_true');P.add_argument('--pilot',action='store_true');P.add_argument('--threads',type=int,default=4);args=P.parse_args(sys.argv[sys.argv.index('--')+1:]);out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
r=np.random.default_rng(args.seed)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=args.samples;scene.cycles.use_denoising=False;scene.cycles.seed=args.seed%65536;scene.render.threads_mode='FIXED';scene.render.threads=args.threads;scene.cycles.max_bounces=6
scene.render.resolution_x=768;scene.render.resolution_y=576;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.image_settings.color_depth='8';scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.view_settings.exposure=0
scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.15,.19,.25,1);scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.28
# Independent material properties, camera and layout sampled from the integer seed.
a=float(r.uniform(.18,.38));b=float(r.uniform(.07,.18));painted=bool(r.integers(2));layout=int(r.integers(3));radius=float(r.uniform(.0028,.0035));rough=float(r.uniform(.28,.44));focal=float(r.uniform(1250,1450));camera=np.array([r.uniform(-.09,.09),r.uniform(-.06,.06),r.uniform(.75,.90)])
forward=-camera/np.linalg.norm(camera);right=np.cross(forward,[0,1,0]);right/=np.linalg.norm(right);down=np.cross(forward,right);rotation=np.column_stack([right,down,forward])
def z(x,y):return .5*(a*x*x+b*y*y)
def mesh(name,verts,faces,mat):
 m=bpy.data.meshes.new(name);m.from_pydata(verts,[],faces);m.update();o=bpy.data.objects.new(name,m);bpy.context.collection.objects.link(o);o.data.materials.append(mat)
 for f in o.data.polygons:f.use_smooth=True
 return o

def material(name,base,metal,roughness,paint=False):
 m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF');p.inputs['Base Color'].default_value=(*base,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=roughness
 tc=n.new('ShaderNodeTexCoord');mapping=n.new('ShaderNodeVectorMath');mapping.operation='MULTIPLY';mapping.inputs[1].default_value=(1,20,3);l.new(tc.outputs['Generated'],mapping.inputs[0]);noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=140;noise.inputs['Detail'].default_value=2;l.new(mapping.outputs[0],noise.inputs['Vector']);bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.17 if paint else .25;bump.inputs['Distance'].default_value=.000025;l.new(noise.outputs['Fac'],bump.inputs['Height']);l.new(bump.outputs['Normal'],p.inputs['Normal'])
 roughmap=n.new('ShaderNodeMapRange');roughmap.inputs['From Min'].default_value=0;roughmap.inputs['From Max'].default_value=1;roughmap.inputs['To Min'].default_value=max(.1,roughness-.08);roughmap.inputs['To Max'].default_value=roughness+.12;l.new(noise.outputs['Fac'],roughmap.inputs[0]);l.new(roughmap.outputs[0],p.inputs['Roughness']);coarse=n.new('ShaderNodeTexNoise');coarse.inputs['Scale'].default_value=18;coarse.inputs['Detail'].default_value=5;l.new(tc.outputs['Generated'],coarse.inputs['Vector']);ramp=n.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].position=.1;ramp.color_ramp.elements[0].color=(*(x*.55 for x in base),1);ramp.color_ramp.elements[1].position=.9;ramp.color_ramp.elements[1].color=(*(x*1.05 for x in base),1);l.new(coarse.outputs['Fac'],ramp.inputs[0]);l.new(ramp.outputs['Color'],p.inputs['Base Color']);return m
skin=material('painted_aluminium' if painted else 'brushed_aluminium',(.52,.57,.60) if painted else (.49,.52,.55),.12 if painted else .85,rough,painted)
head=material('flush_rivet_oxidised_aluminium',(.08,.10,.12),.75,.38)
ring=material('rivet_countersink_metal',(.38,.40,.42),.92,.27)
seammat=material('panel_joint_sealant',(.035,.042,.045),0,.83)
# The external skin is a curved triangulated surface, split into overlapping manufactured panels.
for j,(x0,x1) in enumerate([(-.42,-.0007),(.0007,.42)]):
 xs=np.linspace(x0,x1,58);ys=np.linspace(-.34,.34,65);verts=[(float(x),float(y),z(x,y)+(j*.00025)) for y in ys for x in xs];nx=len(xs);faces=[(i+q*nx,i+1+q*nx,i+1+(q+1)*nx,i+(q+1)*nx) for q in range(len(ys)-1) for i in range(nx-1)];mesh('curved_skin_'+str(j),verts,faces,skin)
# Thin dark joints are actual geometry with recessed depth, not image masks.
verts=[(-.0007,-.34,-.0003),(.0007,-.34,-.0003),(.0007,.34,z(0,.34)-.0003),(-.0007,.34,z(0,.34)-.0003)];mesh('sealant_joint',verts,[(0,1,2,3)],seammat)
# Three deterministic construction patterns, with independent spacing and small manufacturing variation.
spacing=float(r.uniform(.027,.034))
if layout==0:
 y=np.arange(-4,5)*spacing;xy=np.vstack([np.c_[np.full(len(y),v),y] for v in [-.019,.019]]+[np.c_[np.arange(-5,6)*spacing,np.full(11,v)] for v in [-.108,.108]])
elif layout==1:
 xs=np.arange(-5,6)*spacing;xy=np.vstack([np.c_[xs,np.full(len(xs),v)] for v in [-.075,-.05,.05,.075]])
else:
 xs=np.linspace(-.15,.15,11);ys=np.linspace(-.105,.105,8);xy=np.vstack([np.c_[xs,np.full(len(xs),v)] for v in [-.105,.105]]+[np.c_[np.full(6,v),ys[1:-1]] for v in [-.15,.15]])
xy+=r.normal(0,.00010,xy.shape);cad=np.c_[xy,[z(x,y)+(.00025 if x>0 else 0) for x,y in xy]];actual=cad.copy();actual[:,:2]+=r.normal(0,.00005,(len(cad),2));actual[:,2]=[z(x,y)+(.00025 if x>0 else 0) for x,y in actual[:,:2]]
missing=r.random(len(cad))<.025
for i,(x,y,zz) in enumerate(actual):
 if missing[i]:continue
 normal=Vector((-a*x,-b*y,1));normal.normalize();q=normal.to_track_quat('Z','Y')
 # Recess rim is a ring mesh. Head is a shallow domed disk, formed with concentric rings.
 segments=48;rr=[0,radius*.4,radius*.85,radius];heights=[.00032,.00029,.00014,.00002];verts=[(0,0,heights[0])]
 for rad,h in zip(rr[1:],heights[1:]):verts += [(rad*math.cos(k*2*math.pi/segments),rad*math.sin(k*2*math.pi/segments),h) for k in range(segments)]
 faces=[(0,1+k,1+(k+1)%segments) for k in range(segments)]
 for band in range(2):
  lo=1+band*segments;hi=lo+segments;faces += [(lo+k,hi+k,hi+(k+1)%segments,lo+(k+1)%segments) for k in range(segments)]
 o=mesh('rivet_head_'+str(i),verts,faces,head);o.location=(x,y,zz+.00003);o.rotation_mode='QUATERNION';o.rotation_quaternion=q
 bpy.ops.mesh.primitive_torus_add(major_radius=radius+.00012,minor_radius=.00012,major_segments=48,minor_segments=8,location=(x,y,zz+.00003));o=bpy.context.object;o.name='flush_countersink_'+str(i);o.rotation_mode='QUATERNION';o.rotation_quaternion=q;o.data.materials.append(ring)
 for p in o.data.polygons:p.use_smooth=True
# Long shallow seams between panel pieces, with fastener rows in context.
for y0 in [-.135,.135]:
 xs=np.linspace(-.42,.42,70);verts=[(float(x),y0+dy,z(x,y0)+.00005+(.00025 if x>0 else 0)) for dy in [-.00035,.00035] for x in xs];mesh('transverse_panel_seam',verts,[(k,k+1,k+1+len(xs),k+len(xs)) for k in range(len(xs)-1)],seammat)
# Geometrically modeled shallow scratches; physically registered, thin and sparse.
scratchmat=material('abrasion_aluminium',(.62,.64,.65),.95,.42)
for k in range(10):
 x=float(r.uniform(-.20,.20));y=float(r.uniform(-.13,.13));length=float(r.uniform(.006,.025));ang=float(r.uniform(-.5,.5));dx=length*math.cos(ang);dy=length*math.sin(ang);w=float(r.uniform(.000025,.00006));points=[(x,y),(x+dx,y+dy),(x+dx,y+dy+w),(x,y+w)];mesh('abrasion_'+str(k),[(px,py,z(px,py)+(.00025 if px>0 else 0)+.000012) for px,py in points],[(0,1,2,3)],scratchmat)
# Calibrated pinhole camera: Blender -Z forward, +Y image up.
bpy.ops.object.camera_add(location=camera);cam=bpy.context.object;scene.camera=cam;cam.rotation_euler=Matrix(np.column_stack([right,-down,-forward]).tolist()).to_euler();cam.data.type='PERSP';cam.data.sensor_fit='HORIZONTAL';cam.data.sensor_width=36;cam.data.lens=focal*36/768;cam.data.clip_start=.01;cam.data.clip_end=100
lights=[]
for name,pos,energy,size,color in [('inspection_softbox',(-.4,-.3,.8),float(r.uniform(45,65)),.55,(1,.95,.88)),('hangar_fill',(.35,.4,.65),float(r.uniform(18,30)),.35,(.8,.88,1)),('raking_strip',(.2,-.55,.3),float(r.uniform(12,20)),.6,(1,1,1))]:
 bpy.ops.object.light_add(type='AREA',location=pos);o=bpy.context.object;o.name=name;o.rotation_euler=(-o.location).to_track_quat('-Z','Y').to_euler();o.data.energy=energy*.22;o.data.shape='RECTANGLE';o.data.size=size;o.data.size_y=.12 if name=='raking_strip' else size*.6;o.data.color=color;lights.append((o,energy*.22))
bpy.context.view_layer.update()
blender_uv=[world_to_camera_view(scene,cam,Vector(x)) for x in actual]
metadata={'blender_projected_pixels':[[float(p.x*768-384),float((1-p.y)*576-288)] for p in blender_uv],'threads':args.threads,'platform':platform.platform(),'seed':args.seed,'pilot':args.pilot,'renderer':'Blender Cycles CPU','blender_version':bpy.app.version_string,'samples':args.samples,'denoising':False,'width':768,'height':576,'a':a,'b':b,'painted':painted,'layout':layout,'head_radius_m':radius,'roughness':rough,'camera':camera.tolist(),'rotation':rotation.tolist(),'focal':focal,'cad':cad.tolist(),'actual':actual.tolist(),'missing':missing.tolist(),'translation_error':r.normal(0,.003,3).tolist(),'rotation_error':r.normal(0,.001,3).tolist(),'variants':{},'stages':'path-traced radiance followed by display transform; no sensor noise or motion blur assumed in this supplementary benchmark'}
for variant in args.variants.split(','):
 scene.view_settings.exposure=1.3 if variant=='exposure' else 0
 for obj,energy in lights:obj.data.energy=energy*(.10 if variant=='lighting' else 1)
 scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.028 if variant=='lighting' else .28
 scene.render.filepath=str(out/(str(args.seed)+'_'+variant+'.png'));start=time.time();start_cpu=time.process_time();bpy.ops.render.render(write_still=True);metadata['variants'][variant]={'filename':str(Path(scene.render.filepath).name),'exposure_stops':scene.view_settings.exposure,'light_scale':.10 if variant=='lighting' else 1,'elapsed_s':time.time()-start,'cpu_s':time.process_time()-start_cpu}
 if args.save_blend and variant=='baseline':bpy.ops.wm.save_as_mainfile(filepath=str(out/(str(args.seed)+'.blend')))
(out/(str(args.seed)+'.json')).write_text(json.dumps(metadata,indent=2))
