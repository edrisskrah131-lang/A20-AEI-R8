"""Reconstruct the numerical claims from delivered records."""
from pathlib import Path
import json,hashlib,importlib.metadata
import numpy as np
import pandas as pd
from scipy.stats import beta
from checkpoint import ROOT,WORK
D=ROOT/'data';Q=ROOT/'qa'
rows=[json.loads(l) for l in (D/'episodes.jsonl').read_text().splitlines()]
assert len(rows)==1120 and len({r['seed'] for r in rows})==1120
counts={p:sum(r['phase']==p for r in rows) for p in ['train','validation','calibration','confirmation','stress']}
assert list(counts.values())==[480,120,160,240,120]
assert all(r['state_delta']==0 and r['covariance_delta']==0 for r in rows)
freeze=json.loads((D/'frozen_policies.json').read_text())
assert hashlib.sha256((D/'checkpoint_model.npz').read_bytes()).hexdigest()==freeze['model_sha256']
f=pd.read_csv(D/'policy_episode_results.csv');assert len(f)==25600
for (phase,mult,policy),g in f.groupby(['phase','runtime_multiplier','policy']):
    assert len(g)==counts[phase] and g.seed.nunique()==len(g)
cal=pd.read_csv(D/'risk_calibration.csv');assert len(cal)==40
for r in cal.to_dict('records'):
    g=f[(f.phase=='calibration')&(f.runtime_multiplier==r['runtime_multiplier'])&(f.policy==r['policy'])]
    n=len(g);k=int(g.failure.sum());u=1. if k==n else float(beta.ppf(1-.05/40,k+1,n-k))
    assert n==r['n'] and k==r['k'] and abs(u-r['upper_risk'])<1e-12
selection=json.loads((D/'policy_selection.json').read_text())
for s in selection:
    g=cal[cal.runtime_multiplier==s['runtime_multiplier']]
    g=g[g.policy.str.startswith('learned') if s['family']=='learned' else ~g.policy.str.startswith('learned')]
    g=g[g.upper_risk<=s['delta']]
    if g.empty:assert s['policy'] is None
    else:assert s['policy']==g.sort_values(['mean_cpu_s','policy']).iloc[0].policy
route=pd.read_csv(D/'route_results.csv');native=pd.read_csv(D/'native_route_results.csv')
assert len(route)==36 and len(native)==6
route=pd.concat([route,native],ignore_index=True);max_delta=0.
for r in route.to_dict('records'):
    z=np.load(D/f"route_execution/{r['route']}_{r['method']}.npz")['trace'];e=z[:,7]
    rmse=float(np.sqrt(np.mean(e**2)));max_delta=max(max_delta,abs(rmse-r['rmse_m']))
    assert abs(rmse-r['rmse_m'])<1e-12 and len(z)==19800
    assert abs(r['cpu_s']-r['correction_cpu_s']-r['propagation_cpu_s']-r['replay_cpu_s'])<1e-10
    assert int(np.any(e[50:]>.1))==r['route_event_after_5s']
assert len(route[['route','method']].drop_duplicates())==42
envelope=pd.read_csv(D/'deployment_envelope.csv')
for r in envelope.to_dict('records'):
    lag=r['delivery_delay_ms']/1000
    expected=np.sqrt((r['anchor_rmse_cm']/100)**2+(r['extra_map_rms_cm']/100)**2+.000048*lag+(np.sqrt(3)*.0015*lag)**2)*100
    assert abs(expected-r['predicted_rmse_cm'])<1e-10
report=dict(passed=True,independent_episode_count=1120,split_counts=counts,
    policy_episode_rows=25600,simultaneous_calibration_pairs=40,new_complete_route_executions=42,
    retained_independent_route_inputs=6,route_rmse_reconstruction_max_delta=max_delta,
    max_episode_delivery_s=float(f.delivery_last_s.max()),episode_horizon_accounting_fix_affected_rows=int(sum(f.delivery_last_s>4)),
    model_hash_match=True,final_state_and_covariance_equivalence=True,physical_robot_trials=0)
(Q/'release_audit.json').write_text(json.dumps(report,indent=2))
environment={'python':__import__('sys').version,'libraries':{p:importlib.metadata.version(p) for p in ['numpy','scipy','pandas','matplotlib','scikit-learn']}}
(ROOT/'environment.json').write_text(json.dumps(environment,indent=2))
patches=dict(policy_family_changed=False,predictor_refit_after_confirmation=False,
    fixes=[dict(file='source/evaluate.py',change='Exclude replay of publications outside the four-second accounting window; add seed/group count assertions.',affected_episode_outcomes=0),
           dict(file='source/checkpoint.py',change='Distinguish terminal acceptance from a transient/rollback publication in returned metadata.',affected_trajectory_outcomes=0),
           dict(file='source/collect.py',change='Resume compatibility checks scientific settings while retaining original generation hashes.')],
    original_freeze_evaluation_sha256=freeze['evaluation_sha256'],
    frozen_evaluation_snapshot_sha256=hashlib.sha256((Q/'evaluate_frozen_original.py').read_bytes()).hexdigest(),
    current_evaluation_sha256=hashlib.sha256((ROOT/'source/evaluate.py').read_bytes()).hexdigest(),
    original_freeze_solver_sha256=freeze['solver_sha256'],
    frozen_solver_snapshot_sha256=hashlib.sha256((Q/'checkpoint_frozen_original.py').read_bytes()).hexdigest(),
    current_solver_sha256=hashlib.sha256((ROOT/'source/checkpoint.py').read_bytes()).hexdigest())
assert patches['original_freeze_evaluation_sha256']==patches['frozen_evaluation_snapshot_sha256']
assert patches['original_freeze_solver_sha256']==patches['frozen_solver_snapshot_sha256']
(Q/'corrections.json').write_text(json.dumps(patches,indent=2));print(json.dumps(report,indent=2))
