"""Fresh fixed-family calibration, distinct from all earlier samples."""
from concurrent.futures import ProcessPoolExecutor
import csv
import hashlib
import json
from pathlib import Path
from campaign import ROOT,CONFIGS,Pipeline,draw,REQUESTS,numerical_failure
from numerics import execute,archive_image

OUT=ROOT/'outputs'
SPEC=json.loads((ROOT/'protocol.json').read_text())

def one(seed):
    pipeline=Pipeline(draw(seed));rows=[]
    for variant in CONFIGS:
        row,payload,images=execute(pipeline,variant);rows.append(row)
        if seed==SPEC['calibration_seed_start']:
            archive_image(OUT/'representative_calibration'/f'{seed}_{variant}.npz',images,row,payload)
    return rows

def write_csv(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    frozen=json.loads((ROOT/'design_freeze.json').read_text())
    for name,sha in frozen['files'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha,name
    rows=[]
    seeds=range(SPEC['calibration_seed_start'],SPEC['calibration_seed_start']+SPEC['calibration_scene_count'])
    with ProcessPoolExecutor(max_workers=2) as pool:
        for i,result in enumerate(pool.map(one,seeds,chunksize=1)):
            rows.extend(result)
            if (i+1)%16==0:print('FRESH_CALIBRATION',i+1,len(seeds),flush=True)
    write_csv(OUT/'calibration_observations.csv',rows)
    from scipy.stats import beta
    cards=[]
    for variant in CONFIGS:
        group=[r for r in rows if r['variant']==variant]
        for request in REQUESTS:
            k=sum(numerical_failure(r,request) for r in group);n=len(group)
            upper=1. if k==n else float(beta.isf(.05/64,k+1,n-k))
            cards.append(dict(variant=variant,request=request,n=n,k=k,alpha=.05/64,upper=upper,authorized=upper<=.15))
    write_csv(OUT/'exact_risk_cards.csv',cards)
    print('DONE',len(rows),'executed calibration outputs',flush=True)

if __name__=='__main__':main()
