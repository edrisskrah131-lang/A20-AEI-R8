"""Numerical, provenance and support checks for the new primary study."""
from pathlib import Path
import sys,json,hashlib
import numpy as np,pandas as pd
from scipy.stats import beta
ROOT=Path(__file__).resolve().parents[1];STUDY=ROOT/'studies/lifecycle_20261018';OUT=STUDY/'outputs'
sys.path.insert(0,str(STUDY));from evidence import REQUESTS,METHODS,COMPILED,projection
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen=json.loads((STUDY/'freeze.json').read_text())
for name,h in frozen['files'].items():assert sha(STUDY/name)==h,name
for name,h in frozen['external_files'].items():assert sha(ROOT/name)==h,name
ob=pd.read_csv(OUT/'observations.csv');configs=pd.read_csv(OUT/'configurations.csv');cards=pd.read_csv(OUT/'risk_cards.csv');plans=pd.read_csv(OUT/'plans.csv');cost=pd.read_csv(OUT/'catalogue_cost.csv')
assert len(ob)==3200 and len(configs)==640
assert configs.groupby('phase').size().to_dict()=={'calibration':256,'stress':128,'test':256}
assert configs.seed.nunique()==640
assert ob.query('phase!="stress"').groupby('seed').variant.nunique().eq(6).all()
for row in cards.itertuples():
 def count(phase):
  frame=ob[(ob.phase==phase)&(ob.variant==row.variant)];valid=np.ones(len(frame),bool)
  for metric,(lo,hi) in REQUESTS[row.request].items():
   x=frame[metric].to_numpy();valid &= np.isfinite(x)
   if lo is not None:valid &= x>=lo
   if hi is not None:valid &= x<=hi
  return int((~valid).sum())
 assert count('calibration')==row.k and count('test')==row.test_failures
 upper=1. if row.k==256 else beta.isf(.05/48,row.k+1,256-row.k)
 assert abs(upper-row.upper)<1e-12 and row.n==row.test_n==256
 assert bool(row.authorized)==(upper<=.15)
assert cards.authorized.sum()==41
assert cost.constructed_cards.tolist()==[48,42,26,26]
assert cost.record_evaluations.tolist()==[12288,10752,6656,6656]
assert cost.supported.eq(41).all()
pivot=plans.pivot(index=['variant','request'],columns='method',values='authorized');assert pivot.eq(pivot['Whole renewal'],axis=0).all().all()
contract=plans.query('method=="Contract + fallback"');assert ((contract.route=='cover')&contract.authorized).sum()==38
assert ((contract.route=='exact')&contract.authorized).sum()==3
inv=json.loads((OUT/'evidence_inventory.json').read_text());assert len(inv)==48
for item in inv:
 assert item['event_identity']==COMPILED[item['request']].event.identity
 assert item['calibration_records_sha256']==sha(OUT/'calibration_records.csv')
 assert len(item['calibration_selector']['seeds'])==256
 assert item['population']=='four-layout skin mixture v1'
 assert item['projection']==[list(p) for p in projection(item['variant'],item['request'])]
timing=pd.read_csv(OUT/'pipeline_timing.csv');assert len(timing)==2560 and timing.seed.nunique()==16
assert timing.groupby('method').size().eq(640).all()
assert timing[['cpu_s','wall_s']].gt(0).all().all()
for (seed,v,q),group in timing.groupby(['seed','variant','request']):
 assert len(group)==4
 for metric in REQUESTS[q]:assert np.allclose(group[metric],group.iloc[0][metric],atol=1e-9,rtol=1e-10,equal_nan=True)
 assert group.event_failure.nunique()==1
counts=timing.groupby('method')[[k for k in timing if k.startswith('calls_')]].sum()
assert counts.loc['Whole renewal'].eq(640).all()
for m in METHODS[1:]:assert counts.loc[m].tolist()==[192,288,384,480,480,192]
reg=pd.read_csv(OUT/'regression.csv');assert len(reg)==192 and reg.seed.nunique()==64
assert reg.active.eq(reg.veto).all() and reg.clean_veto.sum()==0 and reg.active.sum()==86
life=pd.read_csv(OUT/'lifecycle.csv');assert len(life)==81920 and life.seed.nunique()==256
full=life.query('mode=="contract"');assert full.issued.eq(full.expected).all()
wrong=life.assign(wrong=lambda d:d.issued&~d.expected).groupby('mode').wrong.sum().to_dict()
assert wrong=={'contract':0,'no_integrity':4096,'snapshot':6144,'stateless':10240}
cache=json.loads((OUT/'cold_cache_equivalence.json').read_text());assert cache['status']=='PASS' and cache['cold_producer_runs']==192
fig=ROOT/'paper/figures/visual';provenance=json.loads((fig/'lifecycle_figure_provenance.json').read_text())
for name,h in provenance['sources'].items():assert sha(ROOT/name)==h,name
qa=json.loads((fig/'lifecycle_canvas_qa.json').read_text());assert len(qa)==7 and all(not x['text_outside_canvas'] for x in qa)
result=dict(status='PASS',primary_scenes=512,primary_outputs=3072,stress_scenes=128,cards=48,supported=41,record_evaluation_reduction_percent=100*(1-6656/10752),measured_pipeline_cases=2560,conditional_regression_pairs=192,source_trace_decisions=81920,cold_cache_equivalence=cache)
(ROOT/'audits/lifecycle_qa.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
