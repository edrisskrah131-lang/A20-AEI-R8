"""Publication figures derived only from completed prospective result tables."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import sys,json
import numpy as np,pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator,FormatStrFormatter
from matplotlib.patches import FancyArrowPatch,Rectangle
from r8_protocol import ROOT,D,sha
sys.path.insert(0,str(ROOT/'source/figure_qa'))
from audit_panel_alignment import require_matplotlib_panel_alignment

A=D/'analysis';F=ROOT/'figures/r8';F.mkdir(exist_ok=True)
mpl.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans','Arial','Helvetica'],'font.size':8,
 'axes.titlesize':8,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,
 'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65,
 'legend.frameon':False,'lines.linewidth':1.2})
COLOR={'KG1':'#168677','FlatCART':'#227E9E','CART_Time':'#77A8B5','FlatRF':'#CF8B2D','ContractRF':'#8C673A',
 'Fixed2':'#19394D','Fixed4':'#6A7790','Final':'#BA5B54','OldRAVC':'#845D9E','Full':'#2F998F','TaskAwareFlatValidated':'#845D9E','KG1_Held':'#AB9280'}
MARK={'KG1':'o','FlatCART':'s','FlatRF':'^','ContractRF':'v','Fixed2':'D','Fixed4':'P','Final':'X','OldRAVC':'*'}
MAIN=list(MARK);SERVICES=['relaxed','standard','tight','contended'];PROFILES=['nominal','unfitted']
def table(name):return pd.read_csv(A/(name+'.csv'))
def save(fig,name):
    fig.canvas.draw();require_matplotlib_panel_alignment(fig,json_out=F/(name+'.alignment.json'),overlay_svg=F/(name+'.alignment.svg'),strict=True)
    fig.savefig(F/(name+'.pdf'));fig.savefig(F/(name+'.svg'));fig.savefig(F/(name+'.png'),dpi=300)
    fig.savefig(F/(name+'.tiff'),dpi=600,pil_kwargs={'compression':'tiff_lzw'});plt.close(fig)
def panel(ax,letter,title):
    ax.annotate(letter,(0,1),xycoords='axes fraction',xytext=(-15,8),textcoords='offset points',fontsize=10,fontweight='bold',va='bottom')
    ax.set_title(title,loc='left',pad=9)
def legend(fig,methods=MAIN,y=.02,ncol=4):
    handles=[Line2D([],[],color=COLOR[m],marker=MARK.get(m,'o'),lw=1 if m not in MARK else 0,markersize=4,label=m) for m in methods]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,y),ncol=ncol)
def ablations():
    d=table('module_ablations');fig,ax=plt.subplots(2,3,figsize=(6.69,4.95),gridspec_kw={'left':.095,'right':.985,'bottom':.15,'top':.90,'wspace':.38,'hspace':.6})
    modules=['Time/CART','Profile/CART','Time/RF','Profile/RF'];styles=['o','s','^','v'];colors=['#227E9E','#168677','#CF8B2D','#8C673A']
    for i,profile in enumerate(PROFILES):
        phase=profile+'_confirmation' if profile=='nominal' else 'geometry_confirmation'
        g=d[d.phase==phase]
        for j,(metric,title,scale) in enumerate([('stop_changed','Changed stopping (%)',100/2048),('loss_delta','Paired loss change (m² s)',1),('observation_delta','Observation failure change (pp)',100)]):
            aa=ax[i,j];panel(aa,chr(97+i*3+j),(profile.capitalize()+' · ' if j==0 else '')+['Stopping changes','Loss change','Obs. failure change'][j]);aa.set_ylabel(title)
            for m,c,mk in zip(modules,colors,styles):
                h=g[g.module==m].set_index('service').reindex(SERVICES)
                aa.plot(np.arange(4),h[metric]*scale,marker=mk,color=c,markersize=3,label=m)
            aa.set_xticks(np.arange(4),['R','S','T','C'])
            aa.axhline(0,color='#999999',lw=.5);aa.grid(axis='y',alpha=.15);aa.ticklabel_format(axis='y',style='plain',useOffset=False)
    fig.legend(*ax[0,0].get_legend_handles_labels(),loc='lower center',ncol=4,bbox_to_anchor=(.5,.01))
    save(fig,'ablations')

def pareto():
    s=table('controlled_summary');p=table('pareto');cal=table('certificate_margins');fig,axs=plt.subplots(2,4,figsize=(6.69,4.5),gridspec_kw={'left':.09,'right':.985,'bottom':.23,'top':.90,'wspace':.48,'hspace':.5})
    for i,profile in enumerate(PROFILES):
        for j,service in enumerate(SERVICES):
            a=axs[i,j];panel(a,chr(97+4*i+j),profile.capitalize()+' · '+service)
            g=s[(s.profile==profile)&(s.service==service)];h=p[(p.profile==profile)&(p.service==service)&(p.pareto==1)].sort_values('work_s')
            a.scatter(g.work_s*1000,g.loss_m2s*1000,color='#C6CDD1',s=9,zorder=1)
            certified=cal[(cal.profile==profile)&(cal.service==service)&(cal.event=='union')&(cal.upper<=.15)].policy
            hcert=g[g.policy.isin(certified)]
            a.scatter(hcert.work_s*1000,hcert.loss_m2s*1000,s=45,facecolors='none',edgecolors='#168677',linewidths=.7,zorder=2)
            a.plot(h.work_s*1000,h.loss_m2s*1000,color='#8A949A',lw=.8,zorder=1)
            for m in MAIN:
                r=g[g.policy==m].iloc[0];a.scatter(r.work_s*1000,r.loss_m2s*1000,c=COLOR[m],marker=MARK[m],s=22,zorder=3)
            a.yaxis.set_major_locator(MaxNLocator(3));a.yaxis.set_major_formatter(FormatStrFormatter('%.2f'));a.xaxis.set_major_locator(MaxNLocator(3));a.grid(alpha=.12)
            if i==1:a.set_xlabel('Total work (ms)')
            if j==0:a.set_ylabel('Loss (10⁻³ m² s)')
    handles=[Line2D([],[],color=COLOR[m],marker=MARK[m],lw=0,markersize=4,label=m) for m in MAIN]
    handles.append(Line2D([],[],marker='o',markerfacecolor='none',markeredgecolor='#168677',color='none',markersize=6,label='Union certified'))
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,.006),ncol=4)
    save(fig,'pareto_services')

def binding_stress():
    d=table('module_ablations');phases=['occlusion_stress','degeneracy_stress','prior_shift_stress','map_shift_stress']
    fig,ax=plt.subplots(2,4,figsize=(6.69,4.3),gridspec_kw={'left':.09,'right':.985,'bottom':.2,'top':.9,'wspace':.48,'hspace':.6})
    for j,phase in enumerate(phases):
        for i,(metric,title,scale) in enumerate([('stop_changed','Changed stopping (%)',100/384),('loss_delta','Loss change (m² s)',1)]):
            a=ax[i,j];panel(a,chr(97+i*4+j),phase.replace('_stress','').replace('_',' ').capitalize())
            for m,c,mk in [('Time/CART','#227E9E','o'),('Profile/CART','#168677','s'),('Time/RF','#CF8B2D','^'),('Profile/RF','#8C673A','v')]:
                g=d[(d.phase==phase)&(d.module==m)].set_index('service').reindex(SERVICES)
                a.plot(range(4),g[metric]*scale,color=c,marker=mk,markersize=3,label=m)
            a.set_xticks(range(4),['R','S','T','C']);a.axhline(0,color='#999999',lw=.5);a.grid(alpha=.12)
            if j==0:a.set_ylabel(title)
            if i==1:a.set_xlabel('Service R / S / T / C')
    fig.legend(*ax[0,0].get_legend_handles_labels(),loc='lower center',bbox_to_anchor=(.5,.01),ncol=4)
    save(fig,'binding_stress')

def certificate_boundary():
    d=table('certificate_sensitivity');c=table('certificate_margins')
    fig,axs=plt.subplots(2,2,figsize=(6.69,4.3),gridspec_kw={'left':.11,'right':.985,'bottom':.24,'top':.91,'wspace':.35,'hspace':.6})
    for i,(profile,pid) in enumerate([('nominal','FlatCART3'),('unfitted','OldRAVC')]):
        a=axs[i,0];panel(a,chr(97+i*2),profile.capitalize()+' · '+pid+' union')
        for conf,color,mk in [(.90,'#77A8B5','o'),(.95,'#227E9E','s'),(.99,'#19394D','^')]:
            g=d[(d.profile==profile)&(d.service=='standard')&(d.policy==pid)&(d.event=='union')&(d.confidence==conf)&(d.allowance==.15)].sort_values('n')
            a.plot(g.n,g.upper,color=color,marker=mk,markersize=3,label=f'Confidence {conf:.2f}')
        for delta,style in [(.10,':'),(.15,'--'),(.20,'-.')]:a.axhline(delta,color='#BA5B54',ls=style,lw=.7)
        a.set_xscale('log',base=2);a.set_xticks([128,512,2048,4096],['128','512','2048','4096']);a.set_xlabel('Calibration inputs');a.set_ylabel('Simultaneous risk bound');a.grid(alpha=.12)
        b=axs[i,1];panel(b,chr(98+i*2),profile.capitalize()+' · '+pid+' at n = 4,096')
        for event,color,mk in [('trajectory','#227E9E','o'),('observation','#168677','s'),('union','#CF8B2D','^')]:
            g=c[(c.profile==profile)&(c.policy==pid)&(c.event==event)].set_index('service').reindex(SERVICES)
            b.plot(range(4),.15-g.upper,color=color,marker=mk,markersize=3,label=event)
        b.axhline(0,color='#BA5B54',ls='--',lw=.7);b.set_xticks(range(4),['Relaxed','Standard','Tight','Contended'],rotation=25,ha='right',rotation_mode='anchor');b.set_ylabel('Margin 0.15 − upper risk');b.grid(alpha=.12)
    for j in range(2):fig.legend(*axs[0,j].get_legend_handles_labels(),loc='lower center',bbox_to_anchor=((j+.5)/2,.005),ncol=1,fontsize=6.5)
    save(fig,'certificate_boundary')

def feasibility():
    f=table('request_feasibility');tasks=['trajectory','observation','both_marginals','union'];risks=[.10,.15,.20]
    rows=[(p,s) for p in PROFILES for s in SERVICES];cols=[(t,r) for t in tasks for r in risks]
    matrix=np.array([[f[(f.profile==p)&(f.service==s)&(f.task==t)&(abs(f.allowance-r)<1e-10)].iloc[0].eligible for t,r in cols] for p,s in rows])
    fig,ax=plt.subplots(figsize=(6.69,3.6));fig.subplots_adjust(left=.22,right=.985,bottom=.16,top=.80)
    ax.imshow(matrix,cmap='Blues',vmin=0,vmax=22,aspect='auto')
    for i in range(8):
        for j in range(12):
            text='R' if matrix[i,j]==0 else str(int(matrix[i,j]));ax.text(j,i,text,ha='center',va='center',fontsize=7,color='white' if matrix[i,j]>12 else '#19394D')
    ax.set_yticks(range(8),[p.capitalize()+' / '+s for p,s in rows]);ax.set_xticks(range(12),[f'{r:.2f}' for t,r in cols],fontsize=7)
    for x,label in zip([1,4,7,10],['Trajectory','Observation','Two marginals','Union']):ax.text(x,1.035,label,transform=ax.get_xaxis_transform(),ha='center',va='bottom',fontsize=7.5)
    ax.set_xlabel('Risk allowance within each requested-event group');ax.set_title('Feasible policies from the common 22-policy catalogue (R = refused)',loc='left',pad=27)
    for j in [2.5,5.5,8.5]:ax.axvline(j,color='white',lw=1.5)
    ax.axhline(3.5,color='white',lw=1.5);save(fig,'task_feasibility')

def certificates():
    s=table('certificate_sensitivity');counts=table('certified_policy_counts');c=table('certificate_margins')
    fig,axs=plt.subplots(2,3,figsize=(6.69,5.1),gridspec_kw={'left':.095,'right':.985,'bottom':.23,'top':.9,'wspace':.43,'hspace':.53})
    methods=['KG1','FlatRF','Fixed2','Fixed4','Final']
    for i,profile in enumerate(PROFILES):
        a=axs[i,0];panel(a,chr(97+3*i),profile.capitalize()+' · union bound')
        for m in methods:
            g=s[(s.profile==profile)&(s.service=='standard')&(s.policy==m)&(s.event=='union')&(s.confidence==.95)&(s.allowance==.15)].sort_values('n')
            a.plot(g.n,g.upper,marker=MARK.get(m,'o'),markersize=3,color=COLOR[m],label=m)
        a.axhline(.15,color='#BA5B54',ls='--',lw=.9);a.set_xscale('log',base=2);a.set_xticks([128,512,2048,4096],['128','512','2048','4096']);a.set_ylabel('Simultaneous upper risk');a.set_xlabel('Calibration inputs');a.grid(alpha=.12)
        b=axs[i,1];panel(b,chr(98+3*i),profile.capitalize()+' · certified count')
        for sid,col,mk in zip(SERVICES,['#6A7790','#227E9E','#CF8B2D','#BA5B54'],['o','s','^','D']):
            g=counts[(counts.profile==profile)&(counts.service==sid)&(counts.task=='union')&(counts.confidence==.95)&(counts.allowance==.15)].sort_values('n')
            b.plot(g.n,g.certified_policies,color=col,marker=mk,markersize=3,label=sid)
        b.set_xscale('log',base=2);b.set_xticks([128,512,2048,4096],['128','512','2048','4096']);b.set_ylim(-.5,22.5);b.set_ylabel('Number of policies');b.set_xlabel('Calibration inputs');b.grid(alpha=.12)
        d=axs[i,2];panel(d,chr(99+3*i),profile.capitalize()+' · risk margin')
        for e,col,mk in [('trajectory','#227E9E','o'),('observation','#168677','s'),('union','#CF8B2D','^')]:
            g=c[(c.profile==profile)&(c.service=='standard')&(c.event==e)].set_index('policy').reindex(methods)
            d.plot(np.arange(5),g.margin,color=col,marker=mk,markersize=3,label=e)
        d.axhline(0,color='#BA5B54',ls='--',lw=.9);d.set_xticks(range(5),methods,rotation=35,ha='right',rotation_mode='anchor');d.set_ylabel('0.15 − upper risk');d.grid(alpha=.12)
    for col in range(3):
        handles,labels=axs[0,col].get_legend_handles_labels();fig.legend(handles,labels,ncol=1,loc='lower center',bbox_to_anchor=((col+.5)/3,.008),fontsize=6.5)
    save(fig,'certificate_stability')

def primary_intervals():
    d=table('primary_intervals');fig,axs=plt.subplots(2,2,figsize=(6.69,3.8),gridspec_kw={'left':.24,'right':.985,'bottom':.16,'top':.9,'wspace':.43,'hspace':.55})
    labels=['Full-ValidatedFlat','KG1-FlatCART','KG1-FlatRF','KG1-Fixed2']
    for i,p in enumerate(PROFILES):
        for j,(metric,title,scale) in enumerate([('loss_m2s','Loss difference (m² s)',1),('observation_failure','Observation failure difference (pp)',100)]):
            a=axs[i,j];panel(a,chr(97+2*i+j),p.capitalize())
            g=d[(d.profile==p)&(d.metric==metric)].set_index('contrast').reindex(labels)
            for k,row in enumerate(g.itertuples()):
                a.plot([row.lo_family*scale,row.hi_family*scale],[k,k],color='#A9BCC4',lw=3)
                a.plot([row.lo95*scale,row.hi95*scale],[k,k],color='#227E9E',lw=1.3)
                a.scatter(row.mean*scale,k,color='#19394D',s=14,zorder=3)
            a.axvline(0,color='#BA5B54',lw=.8,ls='--');a.set_yticks(range(4),labels if j==0 else ['']*4);a.invert_yaxis();a.set_xlabel(title);a.grid(axis='x',alpha=.12)
    fig.text(.5,.02,'N = 2,048 paired inputs/profile · dark 95% / pale 16-interval adjusted bootstrap',ha='center',fontsize=7)
    save(fig,'primary_intervals')

def tails():
    # Exact empirical distributions; no downsampling or deletion.
    from r8_evaluate import read_results
    d=read_results(['nominal_confirmation','geometry_confirmation'],['profile','service','policy','seed','max_m','loss_m2s'])
    fig,axs=plt.subplots(1,2,figsize=(6.69,2.8),gridspec_kw={'left':.095,'right':.985,'bottom':.25,'top':.84,'wspace':.3})
    methods=['KG1','FlatCART','FlatRF','Fixed2','Fixed4','Final']
    for i,p in enumerate(PROFILES):
        a=axs[i];panel(a,chr(97+i),p.capitalize()+' · complete error distribution')
        for m in methods:
            x=np.sort(d[(d.profile==p)&(d.service=='standard')&(d.policy==m)].max_m.to_numpy()*100);assert len(x)==2048 and np.all(x>0)
            a.step(x,np.arange(1,len(x)+1)/len(x),where='post',color=COLOR[m],label=m)
        a.axvline(10,color='#999999',ls='--',lw=.9);a.set_xscale('log');a.tick_params(axis='x',labelsize=8);a.set_xlabel('Episode maximum error (cm; log scale)');a.set_ylabel('Empirical cumulative fraction');a.grid(alpha=.12)
    legend(fig,methods=methods,ncol=6);save(fig,'tail_distributions')

def route_fronts():
    d=table('route_summary');raw=pd.read_csv(D/'route_results.csv');fig,axs=plt.subplots(2,3,figsize=(6.69,4.3),gridspec_kw={'left':.095,'right':.985,'bottom':.20,'top':.90,'wspace':.35,'hspace':.50})
    methods=['KG1','Fixed2','Fixed4','Final','FlatCART','FlatRF','ContractRF','OldRAVC']
    for i,c in enumerate(['ordinary','geometric_stress']):
        for j,msh in enumerate(['B767','C172','UnfittedAirframe']):
            a=axs[i,j];panel(a,chr(97+3*i+j),msh.replace('Airframe','')+' · '+c.replace('_',' '))
            g=d[(d.mesh==msh)&(d.condition==c)]
            for m in methods:
                r=g[g.variant==m].iloc[0];r0=raw[(raw.mesh==msh)&(raw.condition==c)&(raw.variant==m)]
                a.scatter(r0.direct_online_cpu_s,r0.rmse_cm,s=9,marker=MARK.get(m,'o'),color=COLOR[m],alpha=.3,zorder=1)
                a.scatter(r.direct_online_cpu_s,r.rmse_cm,s=25,marker=MARK.get(m,'o'),color=COLOR[m],zorder=3)
            a.set_xlabel('Online CPU (s / route)');a.set_ylabel('Position RMSE (cm)');a.grid(alpha=.12)
    legend(fig,methods);save(fig,'route_frontiers')

def route_series():
    # Predeclared diagnostic case, not the most favorable observed route.
    folder=D/'routes/UnfittedAirframe_contention_0';methods=['KG1','Fixed2','Final','FlatRF','Full','TaskAwareFlatValidated']
    fig,axs=plt.subplots(3,1,figsize=(6.69,5.6),gridspec_kw={'left':.16,'right':.985,'bottom':.24,'top':.93,'hspace':.8})
    for m in methods:
        with np.load(folder/(m+'.npz')) as z:t=z['trace'];cap=z['captures']
        assert np.all(t[:,1]>0)
        axs[0].plot(t[:,0],t[:,1]*100,color=COLOR[m],label=m,lw=.9,ls='--' if m=='TaskAwareFlatValidated' else '-')
        k=methods.index(m);success=cap[:,2].astype(bool)
        axs[1].scatter(cap[success,0]*.1,np.full(success.sum(),k),marker='|',s=17,color=COLOR[m])
        axs[1].scatter(cap[~success,0]*.1,np.full((~success).sum(),k),marker='x',s=6,color='#BA5B54',alpha=.55)
    panel(axs[0],'a','Unfitted geometry · contention · replicate 0');axs[0].set_yscale('log');axs[0].tick_params(axis='y',labelsize=8);axs[0].set_ylabel('Error (cm; log)');axs[0].axhline(10,color='#999999',ls=':',lw=.9);axs[0].grid(alpha=.12)
    panel(axs[1],'b','Timely correction outcomes (× = failure)');axs[1].set_yticks(range(6),['KG1','Fixed2','Final','FlatRF','Full','Validated Flat']);axs[1].set_ylim(-.6,5.6);axs[1].grid(axis='x',alpha=.12)
    from r8_routes import service_at
    ts=np.arange(0,600,.1);sid=[service_at('contention',int(x*10)) for x in ts]
    axs[2].step(ts,[s['load'] for s in sid],where='post',color='#227E9E',label='Load factor')
    axs[2].set_ylabel('Declared load α');axs[2].set_xlabel('Route time (s)');axs[2].set_ylim(0,70)
    panel(axs[2],'c','Exogenous service schedule; route evidence remains provisional')
    for a in axs:a.set_xlim(0,600)
    legend(fig,methods,ncol=3,y=.005);save(fig,'route_timeseries')

def fault_mechanism():
    audit=json.loads((ROOT/'qa/r8/claim_layer_audit.json').read_text())
    fig,ax=plt.subplots(3,1,figsize=(6.69,4.4),gridspec_kw={'left':.08,'right':.985,'bottom':.15,'top':.92,'hspace':.82})
    for a in ax[:2]:a.set(xlim=(0,100),ylim=(0,10));a.axis('off')
    panel(ax[0],'a','Matched modules separate numerical decisions from evidence attachment')
    stages=[(7,'Flat predictor'),(28,'Time + profile'),(50,'Same source pose'),(72,'Evidence match'),(92,'History latch')]
    for x,label in stages:ax[0].text(x,5,label,ha='center',va='center',fontsize=7.5,color='#19394D')
    for x,y in zip(stages[:-1],stages[1:]):ax[0].add_patch(FancyArrowPatch((x[0]+8,5),(y[0]-8,5),arrowstyle='-|>',mutation_scale=8,color='#73818B'))
    panel(ax[1],'b','A detected invalid attempt permanently withdraws the source statement')
    ax[1].plot([5,35],[6,6],color='#168677',lw=2);ax[1].plot([35,95],[2,2],color='#BA5B54',lw=2);ax[1].plot([35,35],[2,6],color='#BA5B54',lw=1)
    ax[1].text(18,8,'Valid receipt',ha='center',fontsize=7.5,color='#168677');ax[1].text(36,8,'Invalid attempt',ha='center',fontsize=7.5,color='#BA5B54')
    ax[1].text(73,4,'Later valid pose / rebuilt plan: PROVISIONAL, upper = empty',ha='center',fontsize=7,color='#19394D')
    ax[1].text(50,-.1,f"{audit['pilot_paired_paths']:,} pilot paths + {audit['calibration_chunk_paths']:,} chunk paths: numerical/clock/event projection unchanged",ha='center',fontsize=7)
    real=json.loads((ROOT/'qa/r8/real_card_fault_audit.json').read_text())
    panel(ax[2],'c','Constructed applicability violations with actual F1 cards (16 cases)')
    names=['No checks','Match','Current version','History','Validated Flat'];keys=['none','matching','full','history_full','validated_procedural']
    vals=[real['summaries'][k]['incorrect_attachments'] for k in keys]
    ax[2].bar(np.arange(5),vals,color=['#C6CDD1','#77A8B5','#227E9E','#168677','#845D9E'],width=.55)
    for i,v in enumerate(vals):ax[2].text(i,v+.6,str(v),ha='center',fontsize=7)
    ax[2].set_xticks(range(5),names,fontsize=7);ax[2].set_ylim(0,19);ax[2].set_ylabel('Incorrect attachments');ax[2].set_yticks([0,8,16]);ax[2].grid(axis='y',alpha=.12)
    save(fig,'contract_mechanism')

if __name__=='__main__':
    ablations();pareto();feasibility();certificates();certificate_boundary();binding_stress();primary_intervals();tails();route_fronts();route_series();fault_mechanism()
    files={str(p.relative_to(ROOT)):sha(p) for p in sorted(A.glob('*.csv'))}
    (F/'data_figure_provenance.json').write_text(json.dumps({'script_sha256':sha(__file__),'tables':files,
        'route_case':'predeclared UnfittedAirframe/contention/0','all_result_points_retained':True},indent=2))
