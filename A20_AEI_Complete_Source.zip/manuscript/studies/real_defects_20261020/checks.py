"""Independent scoring edge cases and source-partition integrity checks."""
from pathlib import Path
from collections import defaultdict
import hashlib,json
import numpy as np
from scipy.stats import binom
from evaluate import score,iou_matrix
from analyze import upper,covers,catalogue
ROOT=Path(__file__).resolve().parent

def main():
    row=dict(uid='edge',group='g',split='test',targets=[[0,.5,.5,.5,.5],[1,.2,.2,.1,.1]])
    # Perfect box plus a lower-confidence duplicate, wrong category and background box.
    raw=np.array([[160,160,480,480,.99,0],[160,160,480,480,.8,0],
                  [96,96,160,160,.9,0],[0,0,20,20,.7,2]],dtype=np.float32)
    result=score(row,raw,.25,.5)
    assert (result['tp'],result['fp'],result['fn'])==(1,3,1)
    assert result['by_class'][0]['tp']==1 and result['by_class'][1]['fn']==1
    assert result['by_class'][2]['fp']==1
    assert score(row,raw,1.,.5)['fn']==2
    empty=dict(row,targets=[])
    assert score(empty,np.zeros((0,6)))['recall']==1
    assert score(row,np.zeros((0,6)))['recall']==0
    assert iou_matrix([[0,0,10,10]],[[10,0,20,10]])[0,0]==0
    assert iou_matrix([[0,0,0,0]],[[0,0,0,0]])[0,0]==0
    for n in [1,24,33,256]:
        bounds=[upper(k,n,.05/16) for k in range(n+1)]
        assert all(a<=b for a,b in zip(bounds,bounds[1:]))
        for k,u in enumerate(bounds[:-1]):assert abs(binom.cdf(k,n,u)-.05/16)<1e-10
    assert upper(0,0,.05)==1 and np.isclose(upper(0,1,.05),.95)
    strong=dict(group_recall_min=.75,false_positives_per_image_max=.5)
    weak=dict(group_recall_min=.5,false_positives_per_image_max=1.)
    assert covers(strong,weak) and not covers(weak,strong)
    # A stricter failed card cannot prevent exact fallback admitting a weaker event.
    spec=dict(producers=[dict(name='p')],requests=[dict(name=n,group_recall_min=v,false_positives_per_image_max=f) for n,v,f in [('triage',.25,2),('review',.5,1),('coverage',.75,.5),('strict',.9,.25)]])
    cards=[dict(producer='p',request=n,upper=u,identity=n) for n,u in [('triage',.15),('review',.2),('coverage',.5),('strict',.8)]]
    plans,built=catalogue(cards,spec,.25)
    assert sum(p['authorized'] for p in plans)==2 and len(built)==3
    assert next(p for p in plans if p['request']=='triage')['route']=='containment'
    manifest=json.loads((ROOT/'manifest.json').read_text());seen=defaultdict(set);pixels=defaultdict(set);count=0
    for r in manifest['records']:
        seen[r['group']].add(r['split']);pixels[r['pixel_sha256']].add(r['split'])
        for key,hashkey in [('image','image_sha256'),('label','converted_label_sha256')]:
            assert hashlib.sha256((ROOT/r[key]).read_bytes()).hexdigest()==r[hashkey]
        assert np.isfinite(r['targets']).all()
        saved=np.array([[float(x) for x in line.split()] for line in (ROOT/r['label']).read_text().splitlines() if line.strip()]).reshape(-1,5)
        original=np.array(r['targets']).reshape(-1,5)
        assert saved.shape==original.shape and np.allclose(saved,original,rtol=0,atol=1e-8)
        assert np.all((original[:,0]>=0)&(original[:,0]<5))
        assert np.all((original[:,1:]>=0)&(original[:,1:]<=1))
        count+=1
    assert all(len(v)==1 for v in seen.values())
    assert all(len(v)==1 for v in pixels.values())
    assert len(seen)==manifest['retained_groups']==222 and count==1339
    result=dict(status='PASS',canonical_images_checked=count,source_groups_checked=len(seen),group_split_overlap=0,decoded_pixel_split_overlap=0,
                duplicate_and_wrong_class_detections_exercised=True,empty_annotations_exercised=True,cp_binomial_tail_inversion_checked=True,exact_fallback_exercised=True)
    (ROOT/'checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
