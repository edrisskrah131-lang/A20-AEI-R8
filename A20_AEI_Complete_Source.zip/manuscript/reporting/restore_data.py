"""Verify and restore original data volumes beside an extracted Source ZIP."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tempfile
import zipfile

DEFAULT_ROOT = Path(__file__).resolve().parents[1]
SOURCE_NAME = "A20_AEI_Complete_Source.zip"
GENERATED = {"MANIFEST.json", "DELIVERY_INDEX.json", "DELIVERY.md"}
SHA256 = re.compile(r"[0-9a-f]{64}")
DATA_NAME = re.compile(r"A20_AEI_Data_[0-9]{3,}\.zip")

def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()

def validate_relative(name: str) -> str:
    if not isinstance(name, str) or not name or "\\" in name or ":" in name or "\x00" in name:
        raise ValueError(f"Unsafe relative path: {name!r}")
    path = PurePosixPath(name)
    if path.is_absolute() or str(path) != name or any(part in {"", ".", ".."} for part in path.parts):
        raise ValueError(f"Unsafe relative path: {name!r}")
    return name

def validate_index(index: dict, manifest: dict) -> dict:
    if index.get("schema") != "a20-delivery-v1" or index.get("source_archive") != SOURCE_NAME:
        raise ValueError("Unsupported delivery inventory")
    files, archives = index.get("files"), index.get("data_archives")
    if not isinstance(files, dict) or not files or not isinstance(archives, dict):
        raise ValueError("Malformed delivery inventory")
    if not isinstance(manifest, dict) or set(manifest) != set(files):
        raise ValueError("MANIFEST and DELIVERY_INDEX payload sets differ")
    limit = index.get("archive_limit_bytes")
    if not isinstance(limit, int) or not 0 < limit < 100 * 1024**2:
        raise ValueError("Invalid archive size limit")
    seen = set()
    for name, record in files.items():
        validate_relative(name)
        if name in GENERATED or name.casefold() in seen:
            raise ValueError(f"Reserved or case-colliding payload name: {name}")
        seen.add(name.casefold())
        if not isinstance(record, dict) or not SHA256.fullmatch(record.get("sha256", "")):
            raise ValueError(f"Invalid payload hash: {name}")
        if manifest[name] != record["sha256"]:
            raise ValueError(f"Inventory hash mismatch: {name}")
        if not isinstance(record.get("size"), int) or record["size"] < 0:
            raise ValueError(f"Invalid payload size: {name}")
        if record.get("archive") not in {SOURCE_NAME, *archives}:
            raise ValueError(f"Unknown payload archive: {name}")
    used = {r["archive"] for r in files.values()} - {SOURCE_NAME}
    if set(archives) != used:
        raise ValueError("Empty or missing data archive entries")
    for name, record in archives.items():
        if not DATA_NAME.fullmatch(name) or not isinstance(record, dict):
            raise ValueError(f"Unsafe data archive name: {name!r}")
        if not SHA256.fullmatch(record.get("sha256", "")) or not isinstance(record.get("size"), int) or not 0 < record["size"] < limit:
            raise ValueError(f"Invalid data archive metadata: {name}")
    for name in files:
        if any(str(parent).casefold() in seen for parent in PurePosixPath(name).parents if str(parent) != "."):
            raise ValueError(f"File/directory collision: {name}")
    return index

def reject_symlink_path(path: Path) -> None:
    absolute = path.absolute()
    for candidate in [*reversed(absolute.parents), absolute]:
        if candidate.is_symlink():
            raise ValueError(f"Refusing a symlink in the restoration path: {candidate}")

def verify_zip_members(zipped: zipfile.ZipFile, expected: dict, extra: set[str] | None = None) -> None:
    names = [info.filename for info in zipped.infolist()]
    required = {"manuscript/" + name for name in expected} | {"manuscript/" + name for name in (extra or set())}
    if len(names) != len(set(names)) or set(names) != required:
        raise ValueError("Archive members do not exactly match its inventory")
    for info in zipped.infolist():
        validate_relative(info.filename)
        mode = info.external_attr >> 16
        if info.is_dir() or stat.S_ISLNK(mode) or (stat.S_IFMT(mode) not in {0, stat.S_IFREG}):
            raise ValueError(f"Unsupported archive member type: {info.filename}")
        relative = info.filename.removeprefix("manuscript/")
        if relative in expected and info.file_size != expected[relative]["size"]:
            raise ValueError(f"Archive member size mismatch: {relative}")

def verify_member(zipped: zipfile.ZipFile, name: str, record: dict, output=None) -> None:
    digest, length = hashlib.sha256(), 0
    with zipped.open("manuscript/" + name) as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            length += len(chunk)
            if length > record["size"]:
                raise ValueError(f"Archive member exceeds declared size: {name}")
            digest.update(chunk)
            if output is not None:
                output.write(chunk)
    if length != record["size"] or digest.hexdigest() != record["sha256"]:
        raise ValueError(f"Payload integrity mismatch: {name}")

def verified_data_archives(index: dict, archive_dir: Path) -> list[tuple[Path, dict]]:
    result = []
    missing = [name for name in index["data_archives"] if not (archive_dir / name).is_file()]
    if missing:
        raise FileNotFoundError("Download all required data volumes first: " + ", ".join(missing))
    for name, record in index["data_archives"].items():
        path = archive_dir / name
        if path.stat().st_size != record["size"] or sha256_file(path) != record["sha256"]:
            raise ValueError(f"Data archive integrity mismatch: {name}")
        expected = {key: value for key, value in index["files"].items() if value["archive"] == name}
        with zipfile.ZipFile(path) as zipped:
            verify_zip_members(zipped, expected)
        result.append((path, expected))
    return result

def restore(root: Path, archive_dir: Path, overwrite: bool = False) -> dict:
    root = root.absolute()
    reject_symlink_path(root)
    index = json.loads((root / "DELIVERY_INDEX.json").read_text())
    manifest = json.loads((root / "MANIFEST.json").read_text())
    validate_index(index, manifest)
    archives = verified_data_archives(index, archive_dir)
    for _, expected in archives:
        for name, record in expected.items():
            destination = root / name
            reject_symlink_path(destination)
            if destination.exists() and not destination.is_file():
                raise ValueError(f"Restoration target is not a regular file: {name}")
            if destination.exists() and not overwrite and sha256_file(destination) != record["sha256"]:
                raise ValueError(f"Changed file already exists; use --overwrite only intentionally: {name}")
    restored = skipped = 0
    for archive, expected in archives:
        with zipfile.ZipFile(archive) as zipped:
            for name, record in expected.items():
                destination = root / name
                if destination.is_file() and destination.stat().st_size == record["size"] and sha256_file(destination) == record["sha256"]:
                    skipped += 1
                    continue
                destination.parent.mkdir(parents=True, exist_ok=True)
                reject_symlink_path(destination)
                descriptor, temporary_name = tempfile.mkstemp(prefix=".a20-restore-", dir=destination.parent)
                temporary = Path(temporary_name)
                try:
                    with os.fdopen(descriptor, "wb") as output:
                        verify_member(zipped, name, record, output)
                    temporary.replace(destination)
                    restored += 1
                finally:
                    temporary.unlink(missing_ok=True)
    for name, record in index["files"].items():
        path = root / name
        reject_symlink_path(path)
        if not path.is_file() or path.stat().st_size != record["size"] or sha256_file(path) != record["sha256"]:
            raise ValueError(f"Restored delivery integrity mismatch: {name}")
    return {"status": "PASS", "restored": restored, "already_correct": skipped,
            "verified_payload_files": len(index["files"]), "data_volumes": len(archives)}

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    parser.add_argument("--archive-dir", type=Path)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    print(json.dumps(restore(args.root, args.archive_dir or args.root.parent, args.overwrite), indent=2))

if __name__ == "__main__":
    main()
