# A fixed campaign of producer, requirement, and evidence changes

This experiment joins image computation, calibration decisions, provenance checks,
and repair into one executable sequence. It uses the existing verified image model
and recovery primitives, with entirely fresh calibration and test inputs. The code
and data live in this new directory; no earlier experiment is replaced or edited.

## Sampling and family definition

The protocol reserves eight complete producer configurations and the eight existing
request events, for a new family of 64 contexts. The two added combinations are an
exposure/lighting/decoder update and a focal-length/ROI camera update. Each event
selects a named **complete configuration**, not an accumulated patch to whichever
configuration happened to precede it. The camera combination changes focal length
by a factor of 1.15 and raster dimensions from 768×576 to 896×672.

The same four-layout scene distribution supplies 256 new calibration sources
(seeds 202629100–202629355) and 64 new test sources (202630100–202630163). Two separate
pilot sources were used only to estimate execution time. All eight configurations
are numerically executed on every fresh calibration source, producing 2,048 outputs.
No earlier calibration observations enter the new family. The original request
thresholds and confidence allocation are fixed before these fresh data are run:
the family error is 0.05, per-event alpha is 0.05/64, and the service allowance is 0.15.

The simultaneous confidence statement concerns the 64 marginal request-failure
probabilities in this declared population. Reusing each source across producer
configurations induces dependence, which the Bonferroni allocation permits. It
does **not** turn a marginal allowance into a bound on the probability that an
entire 16-step trajectory has no failure. The test sequence is fixed, rather than
selected after inspecting image-quality outcomes.

## Fixed sequence and actual computation

Each test source follows 16 operations:

1. Register the baseline with the strict complete request.
2. Relax the requirement without changing numerical producers.
3. Change exposure while retaining the relaxed request.
4. Tighten the requirement under the new exposure.
5. Switch to the lighting configuration and request optical quality.
6. Switch to the decoder configuration and the relaxed complete request.
7. Apply the combined exposure/lighting/decoder configuration.
8. Apply the combined focal-length/ROI camera configuration.
9. Deliver the source's old baseline attachment.
10. Attempt a repair with an out-of-order revision.
11. Commit a valid repair with authentic source/output provenance.
12. Replay that repair transaction.
13. Roll back numerically to baseline at a new monotonic registry revision.
14. Present an explicitly different population's output.
15. Deliver the earlier camera-version attachment after rollback.
16. Commit a valid repair of the rollback binding.

All ordinary producer, request, and rollback evaluations request a complete output
packet from the actual geometry, radiance, sensor, decoder, pose, and optics
providers. The three strong methods use a persistent ordinary DAG cache scoped to
one physical-scene input. Request changes and numerical rollback can therefore reuse
already computed values. Fault, repair, and replay operations authenticate stored
outputs; they do not require a new image computation when the correct stored output
is intact. The whole-renewal reference discards numerical caches for each ordinary
evaluation and serves only as a cost reference.

Population mismatch is not implemented as a step-name override. A paired stress
alternative is actually rendered and solved, and a common runtime predicate compares
the output's declared population with the calibration family's population. Mismatched
population evidence is refused before registry admission. This demonstrates correct
handling of an **explicit known population change**, not automatic detection of
unobserved distribution shift in real photographs. The 64 stress alternatives share
the primary seeds and are paired interventions, not 64 more independent test sources.

## Runtime integrity and independent comparisons

The runtime packet authenticates hashes of the actual RGB raster, decoded pixel
coordinates and predicted coordinates, together with the residual, matched/planned
counts, source identity, population, and numerical configuration. Physical mapping
error, true match coverage and optical scoring values remain separate offline
measurements. A mismatch is detected through the reusable registry validation API,
which quarantines the affected binding. Statistical refusal does not quarantine a
correct binding.

An authentic repair binds the current predecessor, next revision, intended producer,
active calibration and trusted observable output. Ordinary registration cannot
bypass quarantine. Duplicate repair commands do not create a new revision and do
not poison an already repaired output. A legitimate numerical rollback keeps the
earlier numerical output identity while issuing a **new registry revision**.

The principal comparisons are exact evidence renewal with the ordinary DAG and an
authoritative registry; containment planning with the same DAG and verified repair;
and independently implemented interval/provider rules with the same DAG and
event-sourced authority. The equivalent strong implementations are expected to
agree on legal service. Their equivalence is reported rather than hidden. The
whole-renewal reference quantifies caching cost only and is not the principal
scientific opponent.

## Catalogue boundary and engineering cost

Evidence cards describe a population and event, not one particular test image.
Accordingly, each method constructs **one shared population-level catalogue** for
the fixed campaign's request schedule and reuses it across all 64 test sources.
It does not rebuild the same card 64 times. A separate cold-catalogue calculation
covers **all 64 predefined family contexts**, including configurations or requests
not demanded by the selected 16-step trace. These two demand patterns have separate
counts and timing tables and are never added together as if both were needed for
the same service initialization.

The 16-step test sequence visits six nominal producer configurations; standalone
focal-only and ROI-only configurations belong to the 64-context calibration family
but are not separately visited by the test campaign. All eight request events can
be scored on each visited configuration's held-out outputs, giving 48 held-out
context scores. Complete-family support is a calibration decision across 64 contexts,
not a claim that all 64 received separate held-out numerical execution.

The campaign records actual per-stage calls, provider CPU, numerical evaluation
CPU/wall time and complete-event CPU/wall time. Method order rotates across sources.
All timing uses two worker processes and single-threaded BLAS. Source generation,
process startup, CSV serialization and representative-image export are outside the
event timing boundary. The host is shared, so reported wall times describe this
execution environment rather than a dedicated robot controller. Scene-level paired
bootstrap intervals use 64 independent sources; individual operations are not
independent timing samples.

Numerical cost reductions belong to the DAG shared by the three strong methods.
Containment's incremental benefit is the measured reduction in evidence construction
relative to exact cards. The rule-equivalent method supplies an implementation
control for those semantics. No operator labor, aircraft downtime, real-camera
acquisition latency or field safety improvement is inferred from these CPU results.

## Reproduction and preserved examples

`calibrate.py` performs fresh calibration. `run.py` builds the shared demand
catalogues and executes the 64 campaigns. `analyze.py` reports both complete-family
and trace-demand results. `verify.py` independently recomputes the family bounds,
checks every registry transition and actual stage-call count, checks hash equality
between methods, and directly reexecutes selected images without the Pipeline cache.

Every calibration and campaign output includes pixel, observable-payload and full
numerical digests. The first calibration source's eight configurations are archived
as full arrays. Both first test sources have complete 16-step traces, all method
decisions and audit logs, and full image/decoded/predicted arrays for every visited
configuration and paired population alternative. These fixed examples were selected
by source index before observing their results. Other inputs are reconstructable
from the fixed seeds, exact configurations and hashed implementation.

`design_freeze.json` records the design before calibration and test execution.
Separate execution manifests record implementation hashes. An independent review
replaced a scenario-label-based population refusal with the runtime population
comparison before the first test source was executed; this correction is recorded
with both implementation hashes. It did not change sampling, thresholds or the
predeclared sequence.
