"""Check the closed manuscript, preserved numerical evidence and software study."""
from pathlib import Path
import json, hashlib, re
import numpy as np, pandas as pd, fitz
from scipy.stats import beta

ROOT=Path(__file__).resolve().parents[1]
FIG=ROOT/'paper/figures/visual'
DATA=FIG/'data'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
provenance=json.loads((FIG/'figure_provenance.json').read_text())
for name,value in provenance['sources'].items():assert sha(ROOT/name)==value,name
qa=json.loads((FIG/'figure_canvas_qa.json').read_text())
assert len(qa)==12 and all(not q['text_outside_canvas'] for q in qa)

plans=pd.read_csv(DATA/'r9_all_frozen_plans.csv')
primary=plans.query('allowance==.15')
rows=[]
for study in ['A','B']:
 for method in ['ContractCover','ProceduralCoverValidated','DirectRecertCached','ExactCard']:
  g=primary.query('study==@study and method==@method')
  unique=g.drop_duplicates(['profile','service','event_id'])
  rows.append({'study':study,'method':method,'request_labels':len(g),
   'supported_labels':int((g.status=='AUTHORIZED').sum()),
   'unique_compiled_request_contexts':len(unique),
   'supported_unique_compiled_contexts':int((unique.status=='AUTHORIZED').sum())})
actual=pd.DataFrame(rows)
pd.testing.assert_frame_equal(actual,pd.read_csv(DATA/'audit_unique_support.csv'),check_dtype=False)
assert len(plans)==6144

cards=pd.read_csv(ROOT/'tables/all_risk_cards.csv')
mask=cards.k<cards.n
upper=np.ones(len(cards));upper[mask]=beta.isf(cards.loc[mask,'alpha'],cards.loc[mask,'k']+1,cards.loc[mask,'n']-cards.loc[mask,'k'])
cp_error=float(np.max(np.abs(upper-cards.upper)))
assert cp_error<1e-12 and len(cards)==3072
assert np.allclose(cards.alpha, .05/4608, rtol=1e-12, atol=0)
timing=pd.read_csv(DATA/'audit_report_timing.csv')
bad=timing[timing.full_report_necessarily_fails_timing]
assert len(bad)==5
report=cards.query('task=="report" and variant=="full"')
forced=pd.concat([report.query('study==@r.study and service==@r.service') for r in bad.itertuples()])
assert len(forced)==80 and (forced.k==forced.n).all() and (forced.upper==1).all()

summary=pd.read_csv(DATA/'r8_controlled_summary.csv')
effects={}
for profile in ['nominal','unfitted']:
 g=summary.query('profile==@profile and service=="standard"').set_index('policy')
 assert g.loc['Fixed2','n']==2048
 for metric in ['loss_m2s','work_s','observation_failure','union_failure']:
  assert g.loc['KG1',metric]==g.loc['FlatCART',metric]
 effects[profile]={'loss_reduction_pct':float(100*(1-g.loc['KG1','loss_m2s']/g.loc['Fixed2','loss_m2s'])),
                  'work_increase_pct':float(100*(g.loc['KG1','work_s']/g.loc['Fixed2','work_s']-1))}
assert round(effects['nominal']['loss_reduction_pct'],2)==15.68
assert round(effects['unfitted']['loss_reduction_pct'],2)==12.61
intervals=pd.read_csv(DATA/'r8_primary_intervals.csv')
assert len(intervals)==16 and (intervals.n==2048).all() and (intervals.resamples==32000).all()
routes=pd.read_csv(DATA/'r8_route_summary.csv')
assert len(routes)==108 and routes.groupby(['mesh','variant']).condition.nunique().eq(3).all()
assert set(routes.condition)=={'ordinary','contention','geometric_stress'}
assert routes.groupby(['mesh','condition']).variant.nunique().eq(12).all()
benchmark=pd.read_csv(DATA/'r9_preparation_benchmark.csv')
cold=benchmark.query('stage=="cold_event_preparation"').groupby('method').first()
reduction=100*(1-cold.loc['ContractCover','record_evaluations']/cold.loc['DirectRecertCached','record_evaluations'])
assert round(reduction,2)==53.66

study=ROOT/'studies/change_recovery_20261013'
freeze=json.loads((study/'freeze.json').read_text())
for name,value in freeze['files'].items():assert sha(study/name)==value,name
changes=pd.read_csv(study/'outputs/change_cases.csv')
results=json.loads((study/'outputs/results.json').read_text())
case=json.loads((study/'outputs/illustrated_case.json').read_text())
assert results['status']=='PASS' and results['freeze_sha256']==sha(study/'freeze.json')
assert results['new_independent_population_inputs']==results['newly_calibrated_event_cards']==0
assert len(changes)==15360 and changes.groupby('method').size().eq(5120).all()
assert changes.groupby(['study','profile','service','event_id','method']).edit.nunique().eq(16).all()
assert changes[['missed_invalidation','unnecessary_refusal','restore_mismatch']].eq(0).all().all()
assert changes.after_authorized.eq(changes.expected_authorized).all()
pivot=changes.pivot(index=['study','profile','service','event_id','edit'],columns='method',values='after_authorized')
assert pivot.ContractCover.eq(pivot.ProceduralCoverValidated).all()
assert case['source_sha256']==sha(study/'inputs/14300000.json')
source=json.loads((study/'inputs/14300000.json').read_text())
for name,value in source['files'].items():assert sha(study/'inputs'/name)==value
assert case['outcome']['active_index']==2 and case['capture_tick']==2
assert case['observed_full_report_pass'] and case['plan']['k']==229 and case['plan']['n']==2048
assert abs(case['plan']['upper']-0.14397310714093464)<1e-15
journey={x['stage']:x for x in case['journey'] if x['method']=='ContractCover'}
assert journey['decoder_v2_full_association']['status']=='REFUSED'
assert journey['decoder_v2_optical_component']['status']=='REFUSED'
assert journey['decoder_v2_readiness_component']['status']=='AUTHORIZED'
assert journey['original_full_association']['card']==journey['restore_decoder_full_association']['card']
assert all(x['new_calibration_records']==0 for x in case['journey'])
assert len(case['faults'])==24 and all(x['false_authorizations']==0 and x['reconstructed_history_refused'] and x['independent_successor_admitted'] for x in case['faults'])
costs=pd.read_csv(study/'outputs/matched_support_cost.csv').query('study=="combined"').set_index('method')
assert costs.matched_unique_requests.eq(47).all()
matched_reduction=100*(1-costs.loc['Anchor reuse','required_record_evaluations']/costs.loc['Direct event preparation','required_record_evaluations'])
assert round(matched_reduction,8)==20
eligible=changes[(changes.method=='ContractCover') & changes.before_authorized & (changes.edit!='unchanged')]
assert len(eligible)==705 and eligible.edit.nunique()==15
assert int((~eligible.after_authorized).sum())==489 and int(eligible.after_authorized.sum())==216
assert eligible.recovered.all()
corecost_text='\n'.join(p.get_text() for p in fitz.open(FIG/'09_boundaries.pdf'))
assert all(x in corecost_text for x in ['13.89%', '63,488', '73,728', 'Same 59 contexts', '0.143973'])
change_text='\n'.join(p.get_text() for p in fitz.open(FIG/'12_conformance.pdf'))
assert all(x in change_text for x in ['705', '489', '216', '705 / 705 restored', 'Stale plan', 'Whole producer'])
overview_text='\n'.join(p.get_text() for p in fitz.open(FIG/'01_overview.pdf'))
assert all(x in overview_text for x in ['Offline calibration', 'Typed request', 'Compile and match', 'Receipt monitor', 'Producer change audit'])
assert len(pd.read_csv(ROOT/'tables/confirmation_geometry_statistics.csv'))==192
assert len(pd.read_csv(ROOT/'tables/unsupported_stress_statistics.csv'))==512

methodology=ROOT/'studies/methodology_review_20261014'
for name,value in json.loads((methodology/'freeze.json').read_text())['files'].items():
 assert sha(methodology/name)==value,name
methodology_results=json.loads((methodology/'outputs/results.json').read_text())
assert methodology_results['status']=='PASS'
assert methodology_results['new_population_inputs']==methodology_results['new_calibration_cards']==0
assert len(methodology_results['archived_baselines'])==5
assert all(x['rgb_equal'] and x['metrics_match_archive'] for x in methodology_results['archived_baselines'])
assert sum(x['undeclared_quantity_changes'] for x in methodology_results['producer_audit'])==14
assert sum(x['flagged_source_pairs'] for x in methodology_results['producer_audit'])==10
hybrid_cost=pd.read_csv(methodology/'outputs/hybrid_cost.csv').query('study=="combined"').set_index('method')
assert hybrid_cost.supported_contexts.eq(59).all()
assert hybrid_cost.loc['Reuse plus direct fallback','event_record_evaluations']==63488
assert hybrid_cost.loc['Direct fixed policy','event_record_evaluations']==73728
assert methodology_results['compiler']['task_variant_roundtrips']==24

main=fitz.open(ROOT/'paper/main.pdf');supp=fitz.open(ROOT/'paper/supplement.pdf')
alltext='\n'.join(p.get_text() for p in main)
supptext='\n'.join(p.get_text() for p in supp)
captions=re.findall(r'Figure (\d+):',alltext)
assert captions==list(map(str,range(1,10))),captions
assert all(x in alltext for x in ['53.66%','geometric','13.89%'])
assert re.search(r'229/2,\s*048',alltext) and re.search(r'103/1,\s*024',alltext)
assert re.search(r'15,\s*360',alltext) and re.search(r'5,?\s*120',supptext) and '20%' in alltext
boundary_position=alltext.index('Appendix A. Evidence scope')
references_position=alltext.rfind('\nReferences\n',0,boundary_position)
assert references_position>0 and boundary_position>references_position
reference_labels=re.findall(r'(?m)^\[(\d+)\]',alltext[references_position:boundary_position])
bibitems=re.findall(r'\\bibitem(?:\[[^\]]*\])?\{([^}]+)\}',(ROOT/'paper/main.bbl').read_text())
assert reference_labels==list(map(str,range(1,len(bibitems)+1)))
fronttext=alltext[:boundary_position]
for phrase in ['Baseline equivalence and attribution','the same gains occur with FlatCART',
               'Full and complete procedure have identical outcomes',
               'Contract = complete procedure','Physical deployment needs']:
 assert phrase not in fronttext,phrase
assert 'Baseline equivalence and attribution' in alltext[boundary_position:]
assert 'Physical implementation requires' in alltext[boundary_position:]
assert all(x in alltext for x in ['Typed task','Reference contract procedure','Coverage of an authorized event'])
content=(ROOT/'paper/sections/visual_content.tex').read_text()
table=content[content.index('\\label{tab:localization}'):content.index('\\label{fig:performance}')]
table_rows={}
for line in table.splitlines():
 parts=[p.strip() for p in line.split('&')]
 if len(parts)==7 and re.fullmatch(r'[0-9.]+',parts[1]):
  table_rows[{'Contract-CART':'KG1','Earlier CART':'OldRAVC'}.get(parts[0],parts[0])]=[float(p.removesuffix('\\\\').strip()) for p in parts[1:]]
integrated=pd.read_csv(DATA/'r8_integrated_summary.csv')
for method in ['Fixed2','Fixed4','Final','FlatCART','KG1','FlatRF','ContractRF','OldRAVC','Full','Complete procedure']:
 expected=[]
 for profile in ['nominal','unfitted']:
  if method in ['Full','Complete procedure']:
   variant='Full' if method=='Full' else 'TaskAwareFlatValidated'
   row=integrated.query('profile==@profile and service=="standard" and task=="union" and variant==@variant').iloc[0]
  else:row=summary.query('profile==@profile and service=="standard" and policy==@method').iloc[0]
  expected += [float(f'{row.loss_m2s*1000:.3f}'),float(f'{row.work_s*1000:.3f}'),float(f'{row.union_failure*100:.2f}')]
 assert table_rows[method]==expected,(method,table_rows[method],expected)
supptext='\n'.join(p.get_text() for p in supp)
assert all(x in supptext for x in ['Complete localization confirmation catalogue','Executed change and recovery validation','Theorem 3'])
assert 'Preserved earlier study' not in supptext
assert len(re.findall(r'\\section\{', (ROOT/'paper/sections/visual_content.tex').read_text()))==8
assert 'Positioning by engineering operation' in alltext
assert content.index('Reuse-first routing and evidence-preparation work') < content.index('Localization accuracy, work and availability')
for name in ['main','supplement']:
 log=(ROOT/'paper'/f'{name}.log').read_text()
 assert not any(x in log for x in ['undefined references','Citation','Overfull','LaTeX Error','multiply defined'])
result={'status':'PASS','main_pages':len(main),'supplement_pages':len(supp),'main_figures':len(captions),
 'source_snapshots_verified':len(provenance['sources']),'cards_verified':len(cards),
 'max_binomial_inversion_error':cp_error,'unique_support':rows,'numerical_effects':effects,
 'record_evaluation_reduction_pct':float(reduction),'necessarily_failing_report_cards':len(forced),
 'matched_support_record_reduction_pct':float(matched_reduction),
 'change_recovery_decisions_verified':len(changes),'receipt_faults_verified':len(case['faults']),
 'change_study_freeze_sha256':sha(study/'freeze.json'),
 'evidence_boundary_after_all_references':True,'baseline_table_values_preserved':True,
 'typed_model_and_reference_procedure_present':True,'authorized_event_theorem_present':True,
 'all_route_conditions_and_methods_retained':True,'canvas_qa':'PASS',
 'primary_results_rendered_from_preserved_inputs':True,'conceptual_positioning_table_present':True,
 'change_edits':705,'selective_withdrawals':489,'retained_statements':216,'restored_contexts':705,
 'scope':'Preserved primary numerical evidence, paired producer re-execution, fixed-policy reuse/fallback routing and alternative-family sensitivity; zero new population inputs or primary calibrated cards.'}
assert 'AI-assisted concept' not in alltext
assert not (FIG/'inspection_concept.png').exists()
assert 'T=4' in content and 'request-grammar' in content and 'admission-rule' in content
result.update(methodology_verification='PASS',producer_reexecution_sources=5,hidden_coupling_classes=2,hybrid_supported_contexts=59,hybrid_proof_record_evaluations=63488,exact_proof_record_evaluations=73728,submitted_figures_use_original_photos_rasters_and_vector_graphics=True,post_reference_scope_is_numbered_appendix=True)
(ROOT/'audits/visual_revision_qa.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:result[k] for k in ['status','main_pages','supplement_pages','main_figures','max_binomial_inversion_error','all_route_conditions_and_methods_retained']},indent=2))
