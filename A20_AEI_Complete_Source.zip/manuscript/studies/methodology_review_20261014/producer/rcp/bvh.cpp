#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <vector>
struct V {double x,y,z; double operator[](int i)const{return i==0?x:i==1?y:z;} V operator-(const V&b)const{return{x-b.x,y-b.y,z-b.z};}};
static V cross(V a,V b){return{a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
static double dot(V a,V b){return a.x*b.x+a.y*b.y+a.z*b.z;}
struct Triangle{V a,e1,e2,center,lo,hi;int id;};
struct Node{V lo,hi;int left=-1,right=-1,start,count;};
struct Scene{std::vector<Triangle>tri;std::vector<Node>node;
 int build(int start,int end){Node n;n.start=start;n.count=end-start;n.lo={INFINITY,INFINITY,INFINITY};n.hi={-INFINITY,-INFINITY,-INFINITY};
  for(int i=start;i<end;++i){auto&t=tri[i];n.lo={std::min(n.lo.x,t.lo.x),std::min(n.lo.y,t.lo.y),std::min(n.lo.z,t.lo.z)};n.hi={std::max(n.hi.x,t.hi.x),std::max(n.hi.y,t.hi.y),std::max(n.hi.z,t.hi.z)};}
  int id=node.size();node.push_back(n);if(end-start<=8)return id;
  V size=n.hi-n.lo;int axis=size.x>size.y?(size.x>size.z?0:2):(size.y>size.z?1:2);int mid=(start+end)/2;
  std::nth_element(tri.begin()+start,tri.begin()+mid,tri.begin()+end,[axis](auto&a,auto&b){return a.center[axis]<b.center[axis];});
  int l=build(start,mid),r=build(mid,end);node[id].left=l;node[id].right=r;return id;
 }
 bool box(const Node&n,V o,V d,double best){double lo=0,hi=best;
  for(int j=0;j<3;++j){if(std::abs(d[j])<1e-14){if(o[j]<n.lo[j]||o[j]>n.hi[j])return false;}else{double a=(n.lo[j]-o[j])/d[j],b=(n.hi[j]-o[j])/d[j];if(a>b)std::swap(a,b);lo=std::max(lo,a);hi=std::min(hi,b);if(lo>hi)return false;}}return true;
 }
 void cast(int id,V o,V d,double&best,int&face){const Node&n=node[id];if(!box(n,o,d,best))return;
  if(n.left>=0){cast(n.left,o,d,best,face);cast(n.right,o,d,best,face);return;}
  for(int i=n.start;i<n.start+n.count;++i){auto&t=tri[i];V p=cross(d,t.e2);double det=dot(t.e1,p);if(std::abs(det)<1e-12)continue;double inv=1/det;V s=o-t.a;double u=dot(s,p)*inv;if(u<0||u>1)continue;V q=cross(s,t.e1);double v=dot(d,q)*inv;if(v<0||u+v>1)continue;double range=dot(t.e2,q)*inv;if(range>1e-7&&range<best){best=range;face=t.id;}}
 }
};
extern "C" void* build_mesh(double*vertices,int*faces,int count){auto*s=new Scene;s->tri.reserve(count);
 for(int i=0;i<count;++i){int*a=faces+3*i;V p[3];for(int j=0;j<3;++j){double*v=vertices+3*a[j];p[j]={v[0],v[1],v[2]};}Triangle t;t.a=p[0];t.e1=p[1]-p[0];t.e2=p[2]-p[0];t.center={(p[0].x+p[1].x+p[2].x)/3,(p[0].y+p[1].y+p[2].y)/3,(p[0].z+p[1].z+p[2].z)/3};t.lo={std::min({p[0].x,p[1].x,p[2].x}),std::min({p[0].y,p[1].y,p[2].y}),std::min({p[0].z,p[1].z,p[2].z})};t.hi={std::max({p[0].x,p[1].x,p[2].x}),std::max({p[0].y,p[1].y,p[2].y}),std::max({p[0].z,p[1].z,p[2].z})};t.id=i;s->tri.push_back(t);}s->build(0,count);return s;
}
extern "C" void cast_rays(void*handle,double*origin,double*directions,int count,double*ranges,int*faces){Scene&s=*(Scene*)handle;V o={origin[0],origin[1],origin[2]};for(int i=0;i<count;++i){double*d=directions+3*i;V dir={d[0],d[1],d[2]};double best=80;int face=-1;s.cast(0,o,dir,best,face);ranges[i]=face>=0?best:INFINITY;faces[i]=face;}}

extern "C" void cast_rolling(void*handle,double*origins,double*directions,int count,double*ranges,int*faces){Scene&s=*(Scene*)handle;for(int i=0;i<count;++i){double*oo=origins+3*i;V o={oo[0],oo[1],oo[2]};double*d=directions+3*i;V dir={d[0],d[1],d[2]};double best=80;int face=-1;s.cast(0,o,dir,best,face);ranges[i]=face>=0?best:INFINITY;faces[i]=face;}}
extern "C" void free_mesh(void*handle){delete static_cast<Scene*>(handle);}
