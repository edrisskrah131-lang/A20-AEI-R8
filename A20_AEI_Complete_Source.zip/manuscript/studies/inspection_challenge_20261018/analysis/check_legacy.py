"""Confirm the extracted pixel/pose provider equals the frozen earlier provider."""
import json
from pathlib import Path
import numpy as np
from PIL import Image
from pipeline import ROOT, BASELINE, decode, estimate, prior
from imaging import fit, configuration

directory = ROOT.parents[1]/'physical_render_20261018'/'outputs'/'test'
largest = 0.
images = 0
for path in sorted(directory.glob('*.json')):
    scene = json.loads(path.read_text())
    if 'cad' not in scene:
        continue
    for key in ('camera','rotation','translation_error','rotation_error','cad','actual','missing'):
        scene[key] = np.asarray(scene[key])
    for name, variant in scene['variants'].items():
        pixels = np.asarray(Image.open(directory/variant['filename']).convert('RGB'))
        detections = decode(pixels, BASELINE)
        _, previous = fit(scene, configuration('baseline'), detections)
        c, r = prior(scene, scene)
        current = estimate(scene['cad'], c, r, scene['focal'], detections)
        for key in ('decoded', 'predicted', 'matched_indices', 'matched_centers'):
            assert np.array_equal(previous[key], current[key]), (path.name, name, key)
            if previous[key].size:
                largest = max(largest, float(np.max(np.abs(previous[key] - current[key]))))
        images += 1
result = dict(status='PASS', earlier_images=images,
              maximum_difference=largest, exact_arrays_match=True,
              fields=['decoded','predicted','matched_indices','matched_centers'])
(ROOT/'legacy_compatibility.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
