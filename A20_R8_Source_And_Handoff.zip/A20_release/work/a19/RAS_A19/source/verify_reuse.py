"""Independent history-tree checks and a closed-form noisy reusable-probe family."""
from itertools import product
import json
import numpy as np
import pandas as pd
from reuse import ReusePlanner,QUANTUM
from prospective import ROOT

def independent(Y,Z,c,b,rho,price,reuse=True):
    def go(w,balance,remaining,cached):
        terminal=[w@Y[:,a]+price*(0 if reuse and a in cached else c[a])
                  for a in range(5) if (0 if reuse and a in cached else c[a])<=balance]
        best=min(terminal)
        for q in remaining:
            if c[q+1]>balance:continue
            value=price*c[q+1]
            for bit in [0,1]:
                ww=w*np.where(Z[:,q]==bit,rho,1-rho);p=ww.sum()
                if p:value+=p*go(ww/p,balance-c[q+1],[j for j in remaining if j!=q],cached|{q+1})
            best=min(best,value)
        return best
    return go(np.ones(len(Y))/len(Y),b,list(range(3)),set())

def main():
    rng=np.random.default_rng(18261);errors=[];dominance=[];concavity=[]
    for case in range(96):
        Y=rng.uniform(0,2,(4,5));Z=rng.integers(0,2,(4,3));c=np.r_[0,rng.integers(1,5,3),6]
        for b,rho in product([6,8,10,12],[.65,1.]):
            p=ReusePlanner(Y,Z,c,b,rho,price=.05/QUANTUM)
            v=p.solve(p.root)[0];r=independent(Y,Z,c,b,rho,.05)
            errors.append(abs(v-r))
            nr=ReusePlanner(Y,Z,c,b,rho,reuse=False,price=.05/QUANTUM).solve((-1,)*3)[0]
            dominance.append(nr-v)
        vv=[ReusePlanner(Y,Z,c,8,.8,price=q/QUANTUM).solve((-1,)*3)[0] for q in [0,.05,.2]]
        concavity.append((vv[1]-vv[0])/.05-(vv[2]-vv[1])/.15)
    phase=[]
    for delta,r in product(np.linspace(.16,.6,45),np.linspace(.5,1,101)):
        lam=.05;Y=np.array([[10,0,2,100,1-delta],[10,2,0,100,1-delta]])
        Z=np.array([[0,0,0],[1,0,0]]);c=np.array([0,3,1,99,4])
        val=ReusePlanner(Y,Z,c,4,r,price=lam/QUANTUM).solve((-1,)*3)[0]
        analytic=min(1-delta+4*lam,2*(1-r)+3.5*lam)
        phase.append(dict(delta=delta,accuracy=r,reuse_risk=val,reserve_risk=1-delta+4*lam,
                          gain=1-delta+4*lam-val,error=abs(val-analytic)))
    pd.DataFrame(phase).to_csv(ROOT/'data/reuse_phase.csv',index=False)
    assert max(errors)<1e-12 and min(dominance)>-1e-12 and min(concavity)>-1e-12
    assert max(x['error'] for x in phase)<1e-12
    # Feasible query/terminal plans change only at a summed reservation boundary.
    n=0;maxfront=0.
    for case in range(12):
        Y=rng.uniform(0,2,(6,5));Z=rng.integers(0,2,(6,3));c=np.array([0,3,5,7,11])
        boundaries={0}
        for bits in product([0,1],repeat=3):
            cache={q+1 for q,x in enumerate(bits) if x};spent=sum(c[q] for q in cache)
            for a in range(5):boundaries.add(spent+(0 if a in cache else c[a]))
        boundaries=sorted(boundaries)
        for lo,hi in zip(boundaries,boundaries[1:]):
            v=ReusePlanner(Y,Z,c,lo,.8,price=.05/QUANTUM).solve((-1,)*3)[0]
            for b in range(lo,hi):
                v2=ReusePlanner(Y,Z,c,b,.8,price=.05/QUANTUM).solve((-1,)*3)[0]
                maxfront=max(maxfront,abs(v-v2));n+=1
    assert maxfront<1e-12
    out=dict(independent_history_checks=len(errors),history_max_error=max(errors),
             reuse_dominance_checks=len(dominance),smallest_discard_minus_reuse=min(dominance),
             price_concavity_checks=len(concavity),minimum_slope_difference=min(concavity),
             phase_cases=len(phase),phase_max_error=max(x['error'] for x in phase),
             budget_frontier_checks=n,budget_frontier_max_error=maxfront)
    (ROOT/'data/theory_checks.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

if __name__=='__main__':main()
