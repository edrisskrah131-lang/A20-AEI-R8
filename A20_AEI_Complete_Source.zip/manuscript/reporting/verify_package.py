"""Independently read every source/data archive and optionally its restored tree."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import zipfile
from restore_data import (DEFAULT_ROOT, GENERATED, reject_symlink_path, sha256_file,
                          validate_index, verified_data_archives, verify_member, verify_zip_members)

def verify_delivery(source: Path, data_dir: Path, restored_root: Path | None = None,
                    allow_unlisted: bool = False) -> dict:
    with zipfile.ZipFile(source) as zipped:
        index = json.loads(zipped.read("manuscript/DELIVERY_INDEX.json"))
        manifest = json.loads(zipped.read("manuscript/MANIFEST.json"))
        validate_index(index, manifest)
        if source.stat().st_size >= index["archive_limit_bytes"]:
            raise ValueError("Source archive exceeds its declared size limit")
        expected = {name: record for name, record in index["files"].items() if record["archive"] == index["source_archive"]}
        verify_zip_members(zipped, expected, GENERATED)
        for name, record in expected.items():
            verify_member(zipped, name, record)
    archives = verified_data_archives(index, data_dir)
    for archive, expected in archives:
        with zipfile.ZipFile(archive) as zipped:
            for name, record in expected.items():
                verify_member(zipped, name, record)
    if restored_root is not None:
        reject_symlink_path(restored_root)
        for name, record in index["files"].items():
            path = restored_root / name
            reject_symlink_path(path)
            if not path.is_file() or path.stat().st_size != record["size"] or sha256_file(path) != record["sha256"]:
                raise ValueError(f"Restored payload mismatch: {name}")
        if not allow_unlisted:
            actual = {p.relative_to(restored_root).as_posix() for p in restored_root.rglob("*")
                      if p.is_file() and "__pycache__" not in p.relative_to(restored_root).parts}
            extra = actual - set(index["files"]) - GENERATED
            if extra:
                raise ValueError("Unexpected restored payload files: " + ", ".join(sorted(extra)))
    return {"status": "PASS", "payload_files": len(index["files"]),
            "data_volumes": len(archives), "restored_tree_verified": restored_root is not None}

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=DEFAULT_ROOT.parent / "A20_AEI_Complete_Source.zip")
    parser.add_argument("--data-dir", type=Path)
    parser.add_argument("--restored-root", type=Path)
    parser.add_argument("--allow-unlisted", action="store_true", help="Permit generated build files in an existing working tree")
    args = parser.parse_args()
    print(json.dumps(verify_delivery(args.source, args.data_dir or args.source.parent,
                                     args.restored_root, args.allow_unlisted), indent=2))

if __name__ == "__main__":
    main()
