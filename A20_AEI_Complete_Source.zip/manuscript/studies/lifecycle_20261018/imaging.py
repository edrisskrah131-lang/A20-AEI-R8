"""Diverse procedural aircraft-skin scenes; pixels and CAD are independent inputs.

This is a controlled simulation, with measured CPU/wall time. No photograph is
converted into experimental ground truth. Pose fitting never receives truth.
"""
from pathlib import Path
import importlib.util,hashlib,json,time
import numpy as np
from scipy.ndimage import gaussian_filter,label,sum_labels,center_of_mass
from scipy.spatial import cKDTree
from scipy.optimize import linear_sum_assignment,least_squares
from scipy.spatial.transform import Rotation
oldpath=Path(__file__).parents[1]/'cad_surface_20261014/model.py'
spec=importlib.util.spec_from_file_location('archived_surface',oldpath);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
VARIANTS=('baseline','focal','exposure','wide_roi','lighting','decoder')
STAGES=('geometry','radiance','sensor','decode','pose','optics')
PARENTS={'geometry':(),'radiance':('geometry',),'sensor':('radiance',),'decode':('sensor',),'pose':('decode',),'optics':()}
DIRECT={'geometry':('focal','roi','geometry'), 'radiance':('lighting',), 'sensor':('exposure','motion'), 'decode':('decoder',), 'pose':('cad','prior'), 'optics':('focal','exposure','motion','geometry')}
QUANTITIES={'gsd_m':'optics','blur_px':'optics','coverage':'pose','reprojection_px':'pose','association_m':'pose'}
# GSD has a finer projection than the joint optics implementation.
QDEPS={'gsd_m':{'focal','geometry'},'blur_px':{'focal','geometry','exposure','motion'},
       'coverage':{'focal','roi','geometry','lighting','exposure','motion','decoder','cad','prior'},
       'reprojection_px':{'focal','roi','geometry','lighting','exposure','motion','decoder','cad','prior'},
       'association_m':{'focal','roi','geometry','lighting','exposure','motion','decoder','cad','prior'}}
CHANGES={'baseline':set(),'focal':{'focal'},'exposure':{'exposure'},'wide_roi':{'roi'},'lighting':{'lighting'},'decoder':{'decoder'}}

def configuration(variant):
 return dict(focal=1.15 if variant=='focal' else 1.,exposure=1.5 if variant=='exposure' else 1.,roi=(896,672) if variant=='wide_roi' else (768,576),lighting=.45 if variant=='lighting' else 1.,decoder=10. if variant=='decoder' else 18.,geometry='skin-v1',motion=1.,cad='cad-v1',prior='prior-v1')

def draw(seed,stress=False):
 s=old.draw(seed);r=np.random.default_rng(seed+91200000);layout=int(r.integers(4));spacing=r.uniform(.028,.040)
 if layout==0:
  x,y=np.meshgrid(np.arange(-4,5)*spacing,np.array([-.035,-.018,.018,.035]));xy=np.c_[x.ravel(),y.ravel()]
 elif layout==1:
  t=np.linspace(-1.1,1.1,14);xy=np.vstack([np.c_[radius*np.sin(t),radius*np.cos(t)-.115] for radius in [.105,.128]])
 elif layout==2:
  x,y=np.meshgrid(np.arange(-3,4)*spacing,np.arange(-2,3)*spacing);x[::2]+=spacing*.33;xy=np.c_[x.ravel(),y.ravel()]
 else:
  x=np.linspace(-.12,.12,10);y=np.linspace(-.065,.065,6);xy=np.vstack([np.c_[x,np.full(10,v)] for v in [-.065,.065]]+[np.c_[np.full(4,v),y[1:-1]] for v in [-.12,.12]])
 angle=r.uniform(-.3,.3);xy=xy@np.array([[np.cos(angle),-np.sin(angle)],[np.sin(angle),np.cos(angle)]])+r.normal(0,.00025,xy.shape)
 cad=np.c_[xy,.5*(s['a']*xy[:,0]**2+s['b']*xy[:,1]**2)]
 offset=r.normal(0,.0004 if not stress else .002,2);physical=xy+offset+r.normal(0,.00015 if not stress else .0006,xy.shape)
 actual=np.c_[physical,.5*(s['a']*physical[:,0]**2+s['b']*physical[:,1]**2)]
 s.update(layout=layout,cad=cad,actual=actual,head_radius=r.uniform(.0020,.0034,len(cad)),missing=r.random(len(cad))<(.025 if not stress else .14),
  occlusion=r.uniform(0,.10 if not stress else .35),roughness=r.uniform(.22,.48),painted=bool(r.integers(2)),
  tint=r.uniform(.85,1.05,3),stain_center=r.uniform([-.10,-.06],[.10,.06]),stain_size=r.uniform(.012,.035),stress=stress)
 s['noise']=r.uniform(1.5,4.0 if not stress else 8.0);s['translation_error']=r.normal(0,.003 if not stress else .007,3)
 return s

def geometry(s,c):
 w,h=c['roi'];f=s['focal']*c['focal'];u,v=np.meshgrid(np.arange(w)+.5-w/2,np.arange(h)+.5-h/2)
 rays=np.stack([u/f,v/f,np.ones_like(u)],axis=-1)@s['rotation'].T;rays/=np.linalg.norm(rays,axis=-1,keepdims=True)
 xyz=old.intersect(s['camera'],rays,s['a'],s['b']);x,y=xyz[:,:,0],xyz[:,:,1]
 radius,nearest=cKDTree(s['actual'][:,:2]).query(xyz[:,:,:2].reshape(-1,2));radius=radius.reshape(h,w);nearest=nearest.reshape(h,w)
 n=np.stack([-s['a']*x,-s['b']*y,np.ones_like(x)],axis=-1);n/=np.linalg.norm(n,axis=-1,keepdims=True)
 head=s['head_radius'][nearest];exists=~s['missing'][nearest];disk=(radius<head)&exists
 rim=(radius>=head)&(radius<head+.0006)&exists
 # A normal-map countersink gives flush fastener rims a view-dependent highlight.
 radial=(xyz[:,:,:2]-s['actual'][nearest,:2])/np.maximum(radius[...,None],1e-9)
 n[:,:,:2]+=radial*(rim*.38)[...,None];n/=np.linalg.norm(n,axis=-1,keepdims=True)
 return dict(x=x,y=y,rays=rays,n=n,disk=disk,rim=rim,nearest=nearest,width=w,height=h,focal=f)

def radiance(s,c,g):
 x,y,n=g['x'],g['y'],g['n'];light=s['light']/np.linalg.norm(s['light']);view=-g['rays'];half=view+light;half/=np.linalg.norm(half,axis=-1,keepdims=True)
 ndl=np.maximum(n@light,0);ndh=np.maximum(np.sum(n*half,axis=-1),0);ndv=np.maximum(np.sum(n*view,axis=-1),.05)
 a=s['roughness']**2;distribution=a*a/(np.pi*((ndh*ndh)*(a*a-1)+1)**2)
 specular=np.minimum(distribution/(4*ndv*np.maximum(ndl,.08)),8)
 brushed=2*np.sin(x*2400+s['texture_phase'])+1.2*np.sin(y*5000+x*70)
 base=(105 if s['painted'] else 76)+(75 if s['painted'] else 48)*ndl+(8 if s['painted'] else 18)*specular+brushed
 # Panel joints, grime and shallow scratches are geometry-registered distractors.
 seam=np.minimum(np.abs(y-.083-.06*x),np.abs(x-.145))<.0007;base[seam]*=.42
 stain=np.exp(-((x-s['stain_center'][0])**2+(y-s['stain_center'][1])**2)/s['stain_size']**2);base-=12*stain
 scratches=(np.abs(np.sin(400*x+17*np.sin(y*30)))<.006)&(x<-.02);base[scratches]+=8
 base[g['disk']]*=.25;base[g['rim']]+=35
 cutoff=np.quantile(x,1-s['occlusion']);mask=x>cutoff;base[mask]=54+4*np.sin(y[mask]*80)
 return np.clip(base*s['brightness']*c['lighting'],0,255)

def optical(s,c):
 q=s['actual'];normal=np.c_[-s['a']*q[:,0],-s['b']*q[:,1],np.ones(len(q))];normal/=np.linalg.norm(normal,axis=1,keepdims=True)
 d=s['camera']-q;distance=np.linalg.norm(d,axis=1);cos=np.abs(np.sum(normal*d/distance[:,None],axis=1));gsd=distance/(s['focal']*c['focal']*cos)
 return dict(gsd_m=float(gsd.max()),blur_px=float((s['speed']*c['motion']*s['exposure']*c['exposure']/gsd).max()),gsds=gsd)

def sensor(s,c,raw):
 # A spatially invariant exposure kernel; latent radiance is a cached stage.
 op=optical(s,c);sigma=op['blur_px']/np.sqrt(12)
 z=gaussian_filter(raw,sigma=(.18,sigma));r=np.random.default_rng(s['seed']+70000000);z=z+r.normal(0,s['noise'],z.shape)
 return np.clip(np.rint(z[:,:,None]*s['tint']),0,255).astype(np.uint8)

def decode(rgb,threshold):
 gray=rgb.mean(2);contrast=gaussian_filter(gray,3)-gray;regions,n=label(contrast>threshold)
 if n==0:return np.empty((0,2))
 ids=np.arange(1,n+1);areas=sum_labels(np.ones_like(gray),regions,ids);ids=ids[(areas>=5)&(areas<=240)]
 if not len(ids):return np.empty((0,2))
 pts=np.asarray(center_of_mass(np.maximum(contrast,0),regions,ids));return pts[:,::-1]+.5-[rgb.shape[1]/2,rgb.shape[0]/2]

def fit(s,c,decoded):
 f=s['focal']*c['focal'];pc=s['camera']+s['translation_error'];pr=s['rotation']@Rotation.from_rotvec(s['rotation_error']).as_matrix();q=s['cad']
 predicted=old.project(q,pc,pr,f)
 if len(decoded):
  i,j=linear_sum_assignment(np.linalg.norm(predicted[:,None,:]-decoded[None,:,:],axis=2));keep=np.linalg.norm(predicted[i]-decoded[j],axis=1)<30;i,j=i[keep],j[keep]
 else:i=np.array([],int);j=np.array([],int)
 camera=pc.copy();rotation=pr.copy()
 if len(i)>=6:
  def residual(d):return np.r_[(old.project(q[i],pc+d[:3],pr@Rotation.from_rotvec(d[3:]).as_matrix(),f)-decoded[j]).ravel()/.5,d[:3]/.003,d[3:]/.001]
  solution=least_squares(residual,np.zeros(6),loss='huber',f_scale=2,max_nfev=60,ftol=1e-8,xtol=1e-8,gtol=1e-8)
  camera=pc+solution.x[:3];rotation=pr@Rotation.from_rotvec(solution.x[3:]).as_matrix()
 predicted=old.project(q,camera,rotation,f)
 residual_px=float(np.max(np.linalg.norm(predicted[i]-decoded[j],axis=1))) if len(i) else np.inf
 # Scoring only: all physical sites are mapped, rather than filtering fitted residuals by truth.
 truth=old.project(s['actual'],s['camera'],s['rotation'],f)
 if len(i):
  distance,identity=cKDTree(truth).query(decoded[j]);correct=(identity==i)&(distance<8)&~s['missing'][i];coverage=correct.sum()/len(q)
 else:coverage=0.
 rays=np.c_[truth/f,np.ones(len(truth))]@rotation.T;rays/=np.linalg.norm(rays,axis=1,keepdims=True)
 reconstructed=old.intersect(camera,rays,s['a'],s['b']);mapping=np.linalg.norm(reconstructed-s['actual'],axis=1)
 return dict(coverage=float(coverage),reprojection_px=residual_px,association_m=float(mapping.max()),prior_translation_error_m=float(np.linalg.norm(pc-s['camera'])),posterior_translation_error_m=float(np.linalg.norm(camera-s['camera'])),matched_targets=len(i),planned_targets=len(q)),dict(decoded=decoded,predicted=predicted,true_pixels=truth,matched_indices=i,matched_centers=decoded[j],targets=q)

class Pipeline:
 """Ordinary content-addressed DAG cache; node keys include parent fingerprints."""
 def __init__(self,scene):self.s=scene;self.cache={};self.calls={k:0 for k in STAGES};self.cpu={k:0. for k in STAGES}
 def key(self,node,c):return (node,tuple((k,str(c[k])) for k in DIRECT[node]),tuple(self.key(p,c) for p in PARENTS[node]))
 def get(self,node,c):
  key=self.key(node,c)
  if key in self.cache:return self.cache[key]
  args=[self.get(p,c) for p in PARENTS[node]];start=time.process_time_ns();s=self.s
  if node=='geometry':value=geometry(s,c)
  elif node=='radiance':value=radiance(s,c,args[0])
  elif node=='sensor':value=sensor(s,c,args[0])
  elif node=='decode':value=decode(args[0],c['decoder'])
  elif node=='pose':value=fit(s,c,args[0])
  else:value=optical(s,c)
  self.cpu[node]+=(time.process_time_ns()-start)*1e-9;self.calls[node]+=1;self.cache[key]=value;return value
 def evaluate(self,c,metrics=None):
  metrics=set(metrics or QUANTITIES);v={}
  if metrics&{'gsd_m','blur_px'}:v.update({k:x for k,x in self.get('optics',c).items() if k!='gsds'})
  if metrics&{'coverage','reprojection_px','association_m'}:v.update(self.get('pose',c)[0])
  return v
 def image(self,c):
  d=dict(self.get('pose',c)[1]);d['rgb']=self.get('sensor',c);return d
