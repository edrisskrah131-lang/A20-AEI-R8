"""Execute the fixed multi-step campaign, including real image pipelines."""
from concurrent.futures import ProcessPoolExecutor
from copy import deepcopy
import csv
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np
from campaign import (ROOT,CONFIGS,METHODS,EVENTS,POPULATION,OTHER_POPULATION,
                      STAGES,Pipeline,draw,Planner,REQUESTS,stable_hash)
from numerics import execute,archive_image,clean
sys.path.insert(0,str(ROOT.parent/'validated_recovery_20261018'))
from model import Registry,QuarantineGate,snapshot_issue,event_sourced_issue

OUT=ROOT/'outputs';SPEC=json.loads((ROOT/'protocol.json').read_text())
PLANS=None;EXACT=None

def read_csv(path):
    with path.open() as handle:return list(csv.DictReader(handle))

def write_csv(path,rows):
    with path.open('w',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

def catalogue():
    from scipy.stats import beta
    beta.isf(.05/64,1,256) # Warm import and inverse-beta initialization outside measurements.
    rows=read_csv(OUT/'calibration_observations.csv')
    groups={v:[] for v in CONFIGS}
    for r in rows:
        groups[r['variant']].append({m:float(r[m]) for m in
            ('gsd_m','blur_px','coverage','reprojection_px','association_m')})
    measured=[];plans={};inventories={}
    for method in METHODS:
        planner=Planner(method,groups);last=None;plans[method]=[]
        for index,event in enumerate(EVENTS):
            cpu=time.process_time_ns();wall=time.perf_counter_ns()
            old_calls,old_evals=planner.cp_calls,planner.evaluations
            if event['kind'] in ('numerical','request','rollback'):
                answer=planner.plan(event['variant'],event['request']);last=answer
            elif event['kind']=='population':
                answer=dict(identity='unavailable-population',authorized=False,upper=None,
                            proof_variant='',proof_request='',route='population_refused')
            else:answer=dict(last,route='existing_binding')
            duration_cpu=(time.process_time_ns()-cpu)*1e-9;duration_wall=(time.perf_counter_ns()-wall)*1e-9
            plans[method].append(answer)
            measured.append(dict(method=method,index=index,event=event['name'],
                **answer,new_cards=planner.cp_calls-old_calls,record_evaluations=planner.evaluations-old_evals,
                cpu_s=duration_cpu,wall_s=duration_wall))
        inventories[method]=planner.cards
    reference=plans['DAG exact + registry']
    for method in METHODS:
        assert [x['authorized'] for x in plans[method]]==[x['authorized'] for x in reference],method
    write_csv(OUT/'catalogue_events.csv',measured)
    (OUT/'plans.json').write_text(json.dumps(plans,indent=2)+'\n')
    (OUT/'constructed_cards.json').write_text(json.dumps(inventories,indent=2)+'\n')
    return plans

def initialize():
    global PLANS,EXACT
    PLANS=json.loads((OUT/'plans.json').read_text())
    EXACT={(r['variant'],r['request']):r['authorized']=='True' for r in read_csv(OUT/'exact_risk_cards.csv')}

def attachment_facts(envelope,registry):
    r=registry.record
    actual=registry.payloads[r['producer']]
    numerical=(envelope['payload']==actual)
    identity=all(envelope[k]==r[k] for k in ('binding','capture','revision','producer','calibration'))
    return numerical,identity

def one(seed):
    scene=draw(seed);rows=[];observations=[];examples={}
    rotation=(seed-SPEC['test_seed_start'])%len(METHODS)
    order=METHODS[rotation:]+METHODS[:rotation]
    reference_outputs={}
    for order_index,method in enumerate(order):
        pipeline=Pipeline(scene);registry=Registry(f'capture-{seed}/campaign',f'capture-{seed}',{}, {})
        gate=QuarantineGate();saved={};trace=[];last_cert=None;last_repair_envelope=None
        for index,event in enumerate(EVENTS):
            kind,variant,request=event['kind'],event['variant'],event['request']
            start=time.perf_counter_ns();cpu=time.process_time_ns()
            observation=None;images=None;cert=None;repair_accepted=None
            plan=PLANS[method][index]
            calls={s:0 for s in STAGES};provider_cpu={s:0. for s in STAGES}
            numeric_cpu=numeric_wall=0.
            if kind in ('numerical','request','rollback','population'):
                if kind=='population':current_pipeline=Pipeline(draw(seed,stress=True));population=OTHER_POPULATION
                else:current_pipeline=Pipeline(scene) if method=='Whole renewal' else pipeline;population=POPULATION
                observation,payload,images=execute(current_pipeline,variant,population)
                numeric_cpu,numeric_wall=observation['cpu_s'],observation['wall_s']
                calls={s:observation['calls_'+s] for s in STAGES}
                provider_cpu={s:observation['provider_cpu_'+s] for s in STAGES}
                reference_key=(population,variant)
                equality=(observation['pixel_sha256'],observation['observable_sha256'],observation['numerical_sha256'])
                if reference_key in reference_outputs:assert reference_outputs[reference_key]==equality,(seed,index,method)
                else:reference_outputs[reference_key]=equality
                if kind!='population':
                    registry.payloads[variant]=payload
                    registry.cards[variant]=dict(plan)
                    registry.register(variant)
                    envelope=registry.envelope()
                    assert registry.validate_attachment(envelope)
                    saved[event['name']]=deepcopy(envelope)
                else:
                    envelope=registry.envelope(payload=payload)
                    # Population is an admission condition, not a guessed online
                    # image-quality test. This external population is explicit.
                    assert payload['population']!=POPULATION
            elif kind in ('stale','late'):
                envelope=deepcopy(saved['baseline'] if kind=='stale' else saved['camera_update'])
                assert not registry.validate_attachment(envelope)
            elif kind=='invalid_repair':
                envelope=registry.envelope(revision=registry.record['revision']+1)
                cert=registry.issue_certificate(revision=registry.record['revision'])
                repair_accepted=registry.repair(envelope,cert)
                assert not repair_accepted
            elif kind=='repair':
                envelope=registry.envelope(revision=registry.record['revision']+1)
                cert=registry.issue_certificate();repair_accepted=registry.repair(envelope,cert)
                assert repair_accepted
                last_cert,last_repair_envelope=deepcopy(cert),deepcopy(envelope)
            elif kind=='replay':
                cert,envelope=deepcopy(last_cert),deepcopy(last_repair_envelope)
                repair_accepted=registry.repair(envelope,cert)
                assert not repair_accepted
            else:raise AssertionError(kind)

            snapshot=registry.snapshot()
            population_compatible=envelope['payload'].get('population')==POPULATION
            if not population_compatible:issued=False
            elif method=='Containment + repair':issued=gate.issue(envelope,snapshot)
            elif method=='Rules + registry':issued=event_sourced_issue(envelope,registry.log,registry.cards)
            else:issued=snapshot_issue(envelope,snapshot)
            numerical_valid,identity_valid=attachment_facts(envelope,registry)
            exact_eligible=EXACT[variant,request] and envelope['payload'].get('population')==POPULATION
            oracle_issue=bool(exact_eligible and numerical_valid and identity_valid and registry.status=='active')
            assert issued==oracle_issue,(seed,index,method,issued,oracle_issue)
            row=dict(seed=seed,method=method,method_order=order_index,index=index,event=event['name'],
                     variant=variant,request=request,kind=kind,state=registry.status,revision=registry.record['revision'],
                     issued=issued,exact_eligible=exact_eligible,oracle_issue=oracle_issue,
                     numerical_binding_valid=numerical_valid,identity_valid=identity_valid,
                     population_compatible=population_compatible,
                     repair_accepted=repair_accepted,route=plan['route'],
                     proof_variant=plan['proof_variant'],proof_request=plan['proof_request'],
                     source_payload_sha256=stable_hash(envelope['payload']),
                     active_payload_sha256=registry.record['payload_digest'],
                     numerical_cpu_s=numeric_cpu,numerical_wall_s=numeric_wall,
                     **{'calls_'+s:calls[s] for s in STAGES},
                     **{'provider_cpu_'+s:provider_cpu[s] for s in STAGES})
            row['cpu_s']=(time.process_time_ns()-cpu)*1e-9
            row['wall_s']=(time.perf_counter_ns()-start)*1e-9
            rows.append(row)
            if observation is not None:
                observations.append(dict(method=method,index=index,event=event['name'],**observation))
            if seed<SPEC['test_seed_start']+2:
                trace.append(dict(**row,envelope=deepcopy(envelope),certificate=deepcopy(cert),
                    authoritative_record=deepcopy(registry.record),risk_plan=deepcopy(plan),
                    offline_numerical_scores=None if observation is None else clean({
                        k:observation[k] for k in ('gsd_m','blur_px','coverage','reprojection_px','association_m')})))
                if images is not None and method=='DAG exact + registry':
                    archive_image(OUT/'representative_campaigns'/f'{seed}_{observation["population"].split()[0]}_{variant}.npz',
                                  images,observation,envelope['payload'])
        if seed<SPEC['test_seed_start']+2:
            examples[method]=dict(trace=trace,event_log=registry.log)
    return rows,observations,examples

def main():
    for file in ('design_freeze.json','calibration_execution_freeze.json','campaign_execution_freeze.json'):
        frozen=json.loads((ROOT/file).read_text())
        for name,sha in frozen['files'].items():
            assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha,(file,name)
    catalogue();rows=[];observations=[];examples={}
    seeds=range(SPEC['test_seed_start'],SPEC['test_seed_start']+SPEC['primary_scene_count'])
    with ProcessPoolExecutor(max_workers=2,initializer=initialize) as pool:
        for i,(r,o,e) in enumerate(pool.map(one,seeds,chunksize=1)):
            rows.extend(r);observations.extend(o)
            if e:examples[str(SPEC['test_seed_start']+i)]=e
            if (i+1)%8==0:print('CAMPAIGN',i+1,len(seeds),flush=True)
    write_csv(OUT/'decisions.csv',rows);write_csv(OUT/'campaign_observations.csv',observations)
    (OUT/'example_traces.json').write_text(json.dumps(examples,indent=2)+'\n')
    print('DONE',len(rows),'workflow decisions and',len(observations),'evaluated source requests',flush=True)

if __name__=='__main__':main()
