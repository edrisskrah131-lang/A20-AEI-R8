"""Render the prespecified independent scenes, building each once for four conditions."""
from pathlib import Path
import argparse,datetime,hashlib,json,subprocess,time
ROOT=Path(__file__).parent
P=argparse.ArgumentParser();P.add_argument('--phase',choices=['development','test'],required=True);P.add_argument('--threads',type=int,default=2);args=P.parse_args()
protocol=json.loads((ROOT/'protocol.json').read_text());freeze=json.loads((ROOT/'freeze.json').read_text())
for name,value in freeze['sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==value,name
if args.phase=='test':
 gate=ROOT.parent/'analysis'/'freeze.json';assert gate.exists(),'Analysis must be fixed from development sources before test rendering.'
 analysis_freeze_sha=hashlib.sha256(gate.read_bytes()).hexdigest()
else:analysis_freeze_sha=None
folder=ROOT/args.phase;folder.mkdir(exist_ok=True);logs=ROOT/'logs';logs.mkdir(exist_ok=True);begin=time.time();sources=protocol[args.phase+'_sources']
for i,s in enumerate(sources):
 seed=s['seed'];target=folder/(str(seed)+'.json')
 if target.exists() and all((folder/(str(seed)+'_'+v+'.png')).exists() for v in protocol['conditions']):
  print(f'{args.phase} {i+1}/{len(sources)} already complete {seed}',flush=True);continue
 command=['/usr/bin/blender','-b','-t',str(args.threads),'--python',str(ROOT/'render.py'),'--','--seed',str(seed),'--family',str(s['family']),'--split',args.phase,'--out',str(folder),'--samples',str(protocol['samples_max']),'--threads',str(args.threads)]
 if i<(2 if args.phase=='development' else 4):command+=['--save-blend']
 with (logs/(str(seed)+'.log')).open('w') as f:subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=True)
 assert target.exists(),f'Failed renderer source {seed}'
 print(f'{args.phase} {i+1}/{len(sources)} complete {seed} family{s["family"]}; wall{time.time()-begin:.1f}s',flush=True)
manifest={'phase':args.phase,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'invocation_threads':args.threads,'wall_s':time.time()-begin,'analysis_freeze_sha256':analysis_freeze_sha,'sources':len(sources),'images':4*len(sources),'files':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(folder.iterdir()) if p.is_file()}}
(ROOT/(args.phase+'_manifest.json')).write_text(json.dumps(manifest,indent=2))
