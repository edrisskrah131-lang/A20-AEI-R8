"""Constructed fault attribution with actual F1 cards, outside calibration.

These deliberately stripped validators are mechanism ablations. The primary
fair comparator retains every predicate and the source-history latch.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import copy,json
import numpy as np,pandas as pd
from r8_protocol import ROOT,D,PROTOCOL,sha
from r8_evaluate import assert_freeze,runtime_bindings,relevant_bindings
from r8_policy import policies
from r8_service import state_from
from r8_contracts import Registry,dispatch,procedural_dispatch,Transaction,source_from_arrays,authorize_statement,procedural_statement_check
from r8_claim_layer import ClaimLedger

def main():
    assert_freeze();runtime=runtime_bindings();cards=json.loads((D/'event_cards.json').read_text())
    policy={p['id']:p for p in policies()}['Fixed2'];service=PROTOCOL['services'][0]
    bindings=relevant_bindings(runtime,'nominal',service,policy)
    with np.load(D/'pilot/8200000.npz') as archive:z={k:archive[k] for k in archive.files}
    prior=state_from(z,0);source=source_from_arrays('software-real-card-source',z['cloud'],prior)
    request={'profile':'nominal','service':'relaxed','task':'union','events':['union'],'allowance':.15,'elapsed_s':0.,'declared_population':True}
    cf=pd.read_csv(D/'calibration.csv');table={(r.profile,r.service,r.policy):r.score_m2s for r in cf[cf.event=='trajectory'].itertuples()}
    records=[]
    def setup(name):
        full=Registry(cards,runtime);flat=Registry(cards,runtime)
        plan=dispatch(full,table,request,['Fixed2']);manual=procedural_dispatch(flat.cards,table,request,['Fixed2'],runtime)
        assert plan['status']==manual['status']=='SELECTED'
        tx=Transaction(source,'Fixed2','nominal','relaxed',service['deadline_s'],service['budget_s'],bindings)
        payload=tx.register_payload(1,2,prior)
        version=dict(source=source.identity,prior=source.prior_seal,data=source.data_seal,sequence=1,iteration=2,rollback=False,
            policy='Fixed2',profile='nominal',service='relaxed',bindings=bindings,replay_to=2,sender_work_s=.001,payload=payload)
        tx.install(version,2);card=full.cards[('nominal','relaxed','Fixed2','union')]
        assessment=dict(event='union',card_seal=card['seal'],receiver_tick=2,assessment_s=.5)
        ledger=ClaimLedger(full,plan,name);ledger.bind(tx)
        manual_ledger=ClaimLedger(flat,manual,name,True);manual_ledger.bind(tx)
        return full,flat,plan,manual,tx,version,assessment,ledger,manual_ledger
    mutations=[('wrong_policy',{'policy':'Final'},{}),('wrong_profile',{'profile':'unsupported'},{}),
        ('wrong_source',{'source':'other'},{}),('wrong_prior',{'prior':'0'*64},{}),('wrong_data',{'data':'0'*64},{}),
        ('wrong_payload',{'payload':'0'*64},{}),('wrong_card',{}, {'card_seal':'0'*64}),
        ('wrong_requested_event',{}, {'event':'observation'}),('wrong_assessment',{}, {'assessment_s':.3}),
        ('wrong_replay',{'replay_to':3},{}),('wrong_receiver_tick',{}, {'receiver_tick':3})]
    for name,vchange,qchange in mutations:
        full,flat,plan,manual,tx,v,q,ledger,ml=setup(name);v.update(vchange);q.update(qchange)
        choices={layer:authorize_statement(full,plan,tx,v,q,.2,layer)['authorized'] for layer in ['none','matching','full']}
        choices['history_full']=authorize_statement(full,ledger.claim_plan,tx,v,q,.2)['authorized']
        choices['validated_procedural']=procedural_statement_check(flat,manual,tx,v,q,.2) and ml.manual_history_valid
        assert not choices['full'] and not choices['history_full'] and not choices['validated_procedural'],(name,choices)
        records.append(dict(case=name,invalid=True,**choices))
    for name in ['stale_version','model_dependency','clock_dependency','invalid_history_then_valid','reconstructed_fault_scope','normal','legal_rollback']:
        full,flat,plan,manual,tx,v,q,ledger,ml=setup(name)
        invalid=name not in ['normal','legal_rollback']
        if name=='stale_version':
            tx.register_payload(2,4,prior);tx.install(dict(v,sequence=2,iteration=4),2)
        elif name in ['model_dependency','clock_dependency']:
            key='policy_implementation' if name=='model_dependency' else 'clock'
            full.change(key,'changed');flat.change(key,'changed')
        elif name in ['invalid_history_then_valid','reconstructed_fault_scope']:
            ledger.observe(False,dict(v,source='forged'),['lineage']);ml.observe(False,dict(v,source='forged'),['lineage'])
            if name=='reconstructed_fault_scope':
                plan=dispatch(full,table,request,['Fixed2']);manual=procedural_dispatch(flat.cards,table,request,['Fixed2'],flat.runtime)
                ledger=ClaimLedger(full,plan,name);ledger.bind(tx);ml=ClaimLedger(flat,manual,name,True);ml.bind(tx)
        elif name=='legal_rollback':
            tx.register_payload(2,0,prior);v=dict(v,sequence=2,iteration=0,rollback=True);tx.install(v,2)
        choices={layer:authorize_statement(full,plan,tx,v,q,.2,layer)['authorized'] for layer in ['none','matching','full']}
        choices['history_full']=authorize_statement(full,ledger.claim_plan,tx,v,q,.2)['authorized']
        choices['validated_procedural']=procedural_statement_check(flat,manual,tx,v,q,.2) and ml.manual_history_valid
        assert choices['history_full']==choices['validated_procedural']==(not invalid),(name,choices)
        records.append(dict(case=name,invalid=invalid,**choices))
    frame=pd.DataFrame(records);frame.to_csv(ROOT/'qa/r8/real_card_fault_cases.csv',index=False)
    summaries={layer:{'incorrect_attachments':int(frame.loc[frame.invalid,layer].sum()),'invalid_cases':int(frame.invalid.sum()),
        'correct_normal_attachments':int(frame.loc[~frame.invalid,layer].sum()),'normal_cases':int((~frame.invalid).sum())}
        for layer in ['none','matching','full','history_full','validated_procedural']}
    report={'status':'PASS','scope':'18 constructed software cases using actual frozen F1 cards; not random fault rates, not calibration, not independent simulation inputs',
        'summaries':summaries,'source_sha256':sha(__file__),'F1_sha256':sha(D/'selection_freeze.json'),
        'primary_fair_comparator':'validated_procedural, including all matching, lifecycle and history predicates',
        'current_receipt_semantics':'dependency eligibility is checked at issuance/use; old serialized receipts are historical assessment snapshots, not self-updating remote capabilities'}
    (ROOT/'qa/r8/real_card_fault_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
if __name__=='__main__':main()
