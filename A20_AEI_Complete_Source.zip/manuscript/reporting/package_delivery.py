"""Package the editable article and verify every shipped file."""
from pathlib import Path
import json,hashlib,zipfile

ROOT=Path(__file__).resolve().parents[1]
target=ROOT.parent/'A20_AEI_Complete_Source.zip'
excluded={'.aux','.out','.bbl','.blg','.pyc','.toc','.lof','.lot'}
compiled_pdfs={'A20_AEI_Manuscript.pdf','Supplement.pdf','paper/main.pdf','paper/supplement.pdf'}
def payload(p):
    relative=p.relative_to(ROOT)
    if not p.is_file() or '__pycache__' in p.parts or p.suffix in excluded or p.name=='MANIFEST.json':return False
    if relative.as_posix() in compiled_pdfs:return False
    if p.suffix=='.log' and 'studies' not in relative.parts:return False
    # Publication PDFs and editable recipes remain; omit reproducible preview exports.
    if relative.parent.as_posix()=='paper/figures/visual' and p.suffix in ('.png','.svg'):return False
    return True
files=[p for p in sorted(ROOT.rglob('*')) if payload(p)]
manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(ROOT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
temp=target.with_suffix('.zip.tmp')
with zipfile.ZipFile(temp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[ROOT/'MANIFEST.json']:z.write(p,'manuscript/'+str(p.relative_to(ROOT)))
assert temp.stat().st_size<100*1024*1024
with zipfile.ZipFile(temp) as z:
    assert z.testzip() is None
    for name,value in manifest.items():
        assert hashlib.sha256(z.read('manuscript/'+name)).hexdigest()==value,name
temp.replace(target)
print(json.dumps({'status':'PASS','files':len(files),'zip_mib':target.stat().st_size/1024**2,
                  'sha256':hashlib.sha256(target.read_bytes()).hexdigest()},indent=2))
