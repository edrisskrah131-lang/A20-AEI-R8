"""Resumable, single-source-prior ICP and online checkpoint decisions."""
from pathlib import Path
import sys,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
WORK=ROOT.parents[1]
sys.path.insert(0,str(WORK/'work/a19/RAS_A19/source'))
from rcp.core import thin,left_jacobian_inverse,psd

class CheckpointICP:
    def __init__(self,prior_map,cloud,prior,mesh_id=0,points=96,checkpoints=(1,2,4,8,16,25)):
        self.map=prior_map;self.points=thin(cloud,points);self.prior=prior.copy();self.cur=prior.copy()
        self.precision=np.linalg.inv(prior.P);self.it=0;self.stages=iter(checkpoints)
        self.done=False;self.converged=False;self.gate=False;self.last_step=np.zeros(18)
        self.mesh_id=mesh_id;self.solver_cpu=0.;self.solver_wall=0.;self.initial_obj=self.terms(self.cur)[4]
        self.latest=None
    def terms(self,s):
        r,H,ix,si=self.map.pairs(self.points,s)
        sigma=.025;hub=.0625
        w=np.minimum(1.,hub/np.maximum(np.abs(r),1e-12))/sigma**2
        d=s.delta(self.prior);G=np.eye(18)
        G[3:6,3:6]=left_jacobian_inverse(d[3:6]);G[15:18,15:18]=left_jacobian_inverse(d[15:18])
        N=G.T@self.precision@G+H.T@(H*w[:,None]);g=G.T@self.precision@d+H.T@(w*r)
        obj=d@self.precision@d+(np.sum(np.where(np.abs(r)<=hub,r*r,2*hub*np.abs(r)-hub**2))+(len(self.points)-len(r))*(2*hub*.8-hub**2))/sigma**2
        return r,H,N,g,float(obj)
    def advance(self):
        if self.done:raise StopIteration
        begin=time.process_time_ns();wall=time.perf_counter_ns();cap=next(self.stages)
        while self.it<cap:
            r,H,N,g,obj=self.terms(self.cur)
            if len(r)<12:self.done=True;break
            step=-np.linalg.solve(N,g);cand=self.cur.retract(step)
            descent=self.terms(cand)[4]<=obj+1e-9
            if not descent:
                for fraction in (.5,.25,.125,.0625):
                    cand=self.cur.retract(step*fraction)
                    if self.terms(cand)[4]<=obj+1e-9:
                        step=step*fraction;descent=True;break
            self.it+=1
            if not descent:self.done=True;break
            self.cur=cand;self.last_step=step;self.gate=True
            self.converged=bool(np.linalg.norm(step[:3])<.001 and np.linalg.norm(step[3:6])<.0005)
            if self.converged:self.done=True;break
        if self.it>=25:self.done=True
        r,H,N,g,obj=self.terms(self.cur)
        residual=float(np.sqrt(np.mean(np.minimum(r*r,.1**2)))) if len(r) else 1.
        inlier=float(np.mean(np.abs(r)<.1)) if len(r) else 0.
        eligible=bool(self.gate and len(r)>=12 and residual<.065 and inlier>.6)
        accepted=bool(eligible and self.converged)
        post=self.cur.copy();post.P=psd(np.linalg.inv(N))
        A=H[:,:6]*np.r_[np.ones(3),np.full(3,1/1.5)]
        weak=float(np.linalg.eigvalsh(A.T@A/max(len(r),1))[0])
        displacement=self.cur.delta(self.prior)
        feature=np.array([np.sqrt(np.trace(self.prior.P[:3,:3])/3),np.log(max(weak,1e-12)),
            residual,inlier,np.linalg.norm(self.last_step[:3]),np.linalg.norm(self.last_step[3:6]),
            obj/max(self.initial_obj,1e-12),self.it,np.log1p(len(r)),np.linalg.norm(displacement[:3]),self.mesh_id])
        self.solver_cpu+=(time.process_time_ns()-begin)*1e-9
        self.solver_wall+=(time.perf_counter_ns()-wall)*1e-9
        stats=dict(iteration=self.it,eligible=eligible,accepted=accepted,converged=self.converged,
            done=self.done,residual=residual,inlier=inlier,weak=weak,cpu_s=self.solver_cpu,wall_s=self.solver_wall)
        self.latest=(post,stats,feature)
        return self.latest

class CompactTree:
    """Exported CART traversal avoids library prediction setup on every checkpoint."""
    def __init__(self,path):
        z=np.load(path);self.left=z['left'];self.right=z['right'];self.feature=z['feature'];self.threshold=z['threshold'];self.value=z['value']
    def predict(self,x):
        # Match the float32 feature conversion used by sklearn's tree predictor.
        x=np.asarray(x,dtype=np.float32)
        node=0
        while self.left[node]>=0:
            node=int(self.left[node] if x[self.feature[node]]<=self.threshold[node] else self.right[node])
        return self.value[node]

def decision(model,feature,stats,price,tail_limit,horizon=4.,release=True,stop=True):
    # Targets: current MSE, final MSE, current tail rate, final tail rate,
    # remaining solver CPU, current MSE minus prior MSE. All are development labels.
    pred=model.predict(feature)
    publish=bool(release and stats['eligible'] and pred[2]<=tail_limit and pred[5]<0.)
    # Final, converged registration retains the established acceptance semantics.
    if stats['done']:return bool(stats['accepted']),True,pred
    gain=horizon*(pred[0]-pred[1])
    stop_now=bool(stop and stats['eligible'] and stats['iteration']>=2 and pred[2]<=tail_limit and gain<=price*max(pred[4],0.))
    if stop_now:publish=True
    return publish,stop_now,pred

def run_registration(prior_map,cloud,prior,mesh_id,method,model=None,price=0.,tail_limit=.15,release=True,stop=True):
    begin=time.process_time_ns();wall=time.perf_counter_ns()
    solver=CheckpointICP(prior_map,cloud,prior,mesh_id)
    trace=[];publications=[];decision_cpu=0.;last=None
    while not solver.done:
        post,stats,feature=solver.advance();last=(post,stats)
        t=time.process_time_ns()
        if method=='learned':publish,halt,pred=decision(model,feature,stats,price,tail_limit,release=release,stop=stop)
        elif method=='residual':
            publish=stats['eligible'];halt=bool(stats['done'] or (stats['eligible'] and stats['iteration']>=2));pred=None
        elif method.startswith('fixed_'):
            cap=int(method.split('_')[1]);halt=bool(stats['done'] or stats['iteration']>=cap);publish=bool(halt and stats['eligible']);pred=None
        else:
            publish=bool((method=='all_release' and stats['eligible']) or (stats['done'] and stats['accepted']));halt=stats['done'];pred=None
        decision_cpu+=(time.process_time_ns()-t)*1e-9
        item=dict(**stats,decision_cpu_cumulative_s=decision_cpu,feature=feature.tolist(),published=publish,stopped=halt,
            cpu_total_s=(time.process_time_ns()-begin)*1e-9,wall_total_s=(time.perf_counter_ns()-wall)*1e-9)
        if pred is not None:item['prediction']=pred.tolist()
        trace.append(item)
        if publish:publications.append((post.copy(),item['cpu_total_s'],item['wall_total_s'],stats['iteration']))
        if halt:break
    # If a completed rejected final candidate follows transient publications,
    # restore the immutable source prior; it replaces, rather than fuses.
    if last[1]['done'] and not last[1]['accepted'] and publications:
        publications.append((prior.copy(),(time.process_time_ns()-begin)*1e-9,(time.perf_counter_ns()-wall)*1e-9,last[1]['iteration']))
    cpu=(time.process_time_ns()-begin)*1e-9;wall_s=(time.perf_counter_ns()-wall)*1e-9
    return publications,dict(cpu_s=cpu,wall_s=wall_s,solver_cpu_s=solver.solver_cpu,decision_cpu_s=decision_cpu,
            checkpoints=len(trace),iterations=solver.it,
            accepted=bool(last[1]['accepted'] if last[1]['done'] else publications),
            has_publications=bool(publications),trace=trace)
