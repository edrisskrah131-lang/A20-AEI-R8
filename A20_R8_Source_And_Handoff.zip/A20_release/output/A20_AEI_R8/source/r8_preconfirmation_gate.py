"""Explicit pre-confirmation inventory audit plus immutable F1 attachment binding."""
import json
from datetime import datetime,timezone
from r8_protocol import ROOT,D,PROTOCOL,sha,digest
from r8_bind_attachment import bind

def gate():
    target=ROOT/'qa/r8/preconfirmation_inventory.json'
    if target.exists():
        old=json.loads(target.read_text())
        assert old['F1_sha256']==sha(D/'selection_freeze.json') and old['amendment_sha256']==sha(D/'claim_layer_freeze.json')
        bind();return
    allowed=['nominal_calibration','geometry_calibration']
    rows=[json.loads(x) for x in (D/'episodes.jsonl').read_text().splitlines()]
    assert {x['phase'] for x in rows}<=set(allowed)
    paths=sorted((D/'episode_inputs').glob('*.npz'));seeds=[int(p.stem) for p in paths]
    assert len(seeds)==len(set(seeds))==8192
    for seed in seeds:
        assert any(PROTOCOL['blocks'][p]['base']<=seed<PROTOCOL['blocks'][p]['base']+PROTOCOL['blocks'][p]['n'] for p in allowed)
    assert len(rows)==8192 and {x['seed'] for x in rows}==set(seeds)
    assert not list((D/'routes').glob('*/inputs.npz'))
    obj={'utc':datetime.now(timezone.utc).isoformat(),'independent_calibration_inputs':8192,'noncalibration_raw_inputs':0,
        'registered_phases':allowed,'seed_inventory_digest':digest(seeds),'F0_sha256':sha(D/'freeze.json'),
        'F1_sha256':sha(D/'selection_freeze.json'),'amendment_sha256':sha(D/'claim_layer_freeze.json'),
        'gate_sha256':sha(__file__),'status':'PASS; confirmation/stress/route inputs absent'}
    target.write_text(json.dumps(obj,indent=2));bind();print('PRECONFIRMATION_GATE_PASS',obj['utc'],flush=True)
if __name__=='__main__':gate()
