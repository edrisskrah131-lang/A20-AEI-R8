"""Package the editable figures, unmodified scene originals and rendering code."""
from pathlib import Path
import hashlib
import json
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DEST = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / 'output/A20_AEI_Figures.zip'

README = '''A20 / AEI figure bundle

Figure 1: architecture (main paper page 3)
Figure 2: source_versions (main paper page 8)
Figure 3: simulation_views (main paper page 13)

Each figure has editable-text SVG, embedded-font PDF, PNG preview and 600 dpi
TIFF. The five scene originals are preserved in simulation_originals. Scene
images are uncropped and unretouched, with their original aspect ratios; they
provide qualitative application context. Quantitative localization inputs and
results are in the complete reproducibility package.

Open SVG in a vector editor to edit labels, objects or connector positions.
For code-based regeneration, install the Python dependencies in requirements-
R4.txt and run: python source/r6_visuals.py
The source applies renderer-based card containment and panel-alignment checks.
Further glyph-size and collision auditors are provided in source/figure_qa.
Caption sources, original-image hashes and final QA reports are included.
'''


def main():
    DEST.parent.mkdir(parents=True, exist_ok=True)
    files = [p for p in (ROOT / 'figures/r6').rglob('*')
             if p.is_file() and not p.name.startswith('.')]
    files += [ROOT / 'source/r6_visuals.py', ROOT / 'source/r6_package.py',
              ROOT / 'requirements-R4.txt']
    files += [p for p in (ROOT / 'source/figure_qa').glob('*.py')]
    files += [p for p in (ROOT / 'sections').glob('r6_*.tex')]
    files += [p for p in (ROOT / 'qa').glob('r6_*.json')]
    files += [ROOT / 'qa/R6_FIGURE_CONTRACT.md', ROOT / 'qa/R6_FINAL_REVIEW.md']
    entries = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in sorted(set(files))}
    entries['README.txt'] = README.encode()
    hashes = {n:hashlib.sha256(b).hexdigest() for n,b in entries.items()}
    with zipfile.ZipFile(DEST, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for n,b in entries.items(): archive.writestr(n,b)
        archive.writestr('FILES_SHA256.json', json.dumps(hashes, indent=2, sort_keys=True))
    with zipfile.ZipFile(DEST) as archive:
        assert archive.testzip() is None
        for n,h in hashes.items(): assert hashlib.sha256(archive.read(n)).hexdigest() == h
    report = {'status':'PASS', 'members':len(entries)+1, 'bytes':DEST.stat().st_size,
              'sha256':hashlib.sha256(DEST.read_bytes()).hexdigest()}
    (ROOT / 'qa/r6_figure_bundle.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report),flush=True)


if __name__ == '__main__': main()
