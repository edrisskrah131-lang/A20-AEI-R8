"""Frozen paired execution, simultaneous calibration, deadline task scoring."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import json,time
import numpy as np,pandas as pd
from scipy.stats import beta
from r4_protocol import ROOT,D,PROTOCOL,sha
from checkpoint import CompactTree,WORK
from rcp.core import JointState,propagate
from r4_policy import Forecast,act,feat
def primitive():
 times=[]
 base=PROTOCOL['seed_ranges']['nominal_calibration'][0]
 for p in [D/'episode_inputs'/f'{base+i}.npz' for i in range(24)]:
  z=np.load(p);s=JointState(*(z['prior_'+k] for k in ['t','R','bias','mt','mR','P']));t=time.process_time_ns()
  for inc in z['increment']:s=propagate(s,.1,inc)
  times.append((time.process_time_ns()-t)*1e-9/40)
 return float(np.median(times))
def predict_cache(r,models):
 cache={}
 for name in ['cart','rf']:
  series=[]
  for s in r['trace']:
   times=[]
   for _ in range(3):
    t=time.process_time_ns();p=models[name].predict(feat(r,s));times.append((time.process_time_ns()-t)*1e-9)
   series.append((p,float(np.median(times))))
  cache[name]=series
 return cache
def evaluate(r,policy,models,cache,load,step,held=False):
 pubs=[];cpu_dec=0.;decisions=[];stop_ix=len(r['trace'])-1;lastsource=0
 for i,s in enumerate(r['trace']):
  name=policy['model'];p,forecast_cpu=cache[name][i] if name in cache else (None,0.)
  t=time.process_time_ns();pub,halt,detail=act(r,s,policy,models.get(name),p,load,PROTOCOL['capture_deadline_s'],s['cpu_total_s']+r['front_cpu_s']+cpu_dec+forecast_cpu)
  cpu_dec+=forecast_cpu+(time.process_time_ns()-t)*1e-9;paid=r['front_cpu_s']+s['cpu_total_s']+cpu_dec
  decisions.append({'iteration':s['iteration'],'pub':pub,'halt':halt,**detail})
  if pub:lastsource=i+1;pubs.append((lastsource,paid))
  if halt:stop_ix=i;break
 last=r['trace'][stop_ix];paid=r['front_cpu_s']+last['cpu_total_s']+cpu_dec
 if last['done'] and not last['accepted'] and pubs:pubs.append((0,paid));lastsource=0
 if held and pubs:pubs=[(lastsource,paid)]
 # Installation includes every earlier replay and this version's replay to the installation tick.
 deliveries=[];spent_replay=0.
 for index,c in pubs:
  tick=max(1,int(np.ceil((.05+load*(c+spent_replay))/(.1-load*step))))
  deliveries.append((tick,index));spent_replay+=tick*step
 active=np.zeros(41,dtype=int)
 for tick,index in deliveries:
  if tick<=40:active[tick:]=index
 e=np.asarray(r['error']);pe=e[active,np.arange(41)];replay=sum(t for t,index in deliveries if t<=40)*step
 capturetick=3;ready=any(t<=capturetick and ix>0 for t,ix in deliveries) and active[capturetick]>0
 return {'seed':r['seed'],'phase':r['phase'],'mesh':r['mesh'],'sd':r['sd'],'noise':r['noise'],'level':r['level'],'policy':policy['id'],'load':load,
 'front_cpu_s':r['front_cpu_s'],'solver_cpu_s':last['cpu_total_s'],'decision_cpu_s':cpu_dec,'prop_cpu_s':40*step,'replay_cpu_s':replay,'cpu_s':paid+40*step+replay,
 'loss_m2s':float(np.sum(pe[1:]**2)*.1),'rmse_m':float(np.sqrt(np.mean(pe[5:]**2))),'failure':int(np.any(pe[5:]>.1)), 'max_m':float(pe[5:].max()),'early_loss_m2s':float(np.sum(pe[1:6]**2)*.1),
 'capture_ready':int(ready),'capture_success':int(ready and pe[capturetick]<=.1),'capture_error_m':float(pe[capturetick]),'stop_iteration':last['iteration'],'publications':len(pubs),'first_delivery_s':min([t*.1 for t,ix in deliveries if ix>0],default=4.1),
 'profile_guard':int(any(x['guard'] for x in decisions)), 'deadline_guard':int(any(x['deadline'] for x in decisions)), 'scope_valid':int(r['mesh'] in ['B767','C172'] and r['sd']<=.061 and r['noise']<=2),
 'decision_path':json.dumps(decisions,separators=(',',':'))}
def run():
 freeze=json.loads((D/'freeze.json').read_text());assert freeze['policy_sha256']==sha(ROOT/'source/r4_policy.py')
 assert freeze['protocol_sha256']==sha(D/'protocol.json')
 for name in ['cart','rf']:assert freeze['forecasts'][name]['sha256']==sha(D/f'{name}_forecast.npz')
 assert freeze['old_model_sha256']==sha(ROOT/'data/checkpoint_model.npz')
 assert freeze['solver_sha256']==sha(ROOT/'source/checkpoint.py')
 models={'cart':Forecast(D/'cart_forecast.npz'),'rf':Forecast(D/'rf_forecast.npz'),'old':CompactTree(ROOT/'data/checkpoint_model.npz')}
 rows=[json.loads(x) for x in (D/'episodes.jsonl').read_text().splitlines()];assert len(rows)==2680 and len(set(r['seed'] for r in rows))==2680
 for phase,(base,n) in PROTOCOL['seed_ranges'].items():assert {r['seed'] for r in rows if r['phase']==phase}==set(range(base,base+n))
 oldseeds=set(freeze['development_train_seeds']+freeze['development_validation_seeds']);assert not oldseeds.intersection(r['seed'] for r in rows)
 step=primitive();policies=freeze['policies'];records=[];start=time.perf_counter()
 for i,r in enumerate(rows):
  cache=predict_cache(r,models)
  for load in PROTOCOL['loads']:
   for p in policies+freeze['ablations']:records.append(evaluate(r,p,models,cache,load,step))
   p=next(p for p in policies if p['id']=='KG1');q=evaluate(r,p,models,cache,load,step,held=True);q['policy']='KG1_held';records.append(q)
  if (i+1)%200==0:print('R4_EVALUATE',i+1,'elapsed_s',round(time.perf_counter()-start,1),flush=True)
 frame=pd.DataFrame(records);frame.to_csv(D/'policy_results.csv',index=False)
 report(frame,step)
def report(frame,step):
 # The first 24 nominal seeds estimate the receiver primitive. They are
 # benchmark inputs, not independent Bernoulli calibration observations.
 base=PROTOCOL['seed_ranges']['nominal_calibration'][0]
 benchmark=set(range(base,base+24))
 calibration=frame[~frame.seed.isin(benchmark)]
 policies=json.loads((D/'freeze.json').read_text())['policies']
 K=len(policies)*len(PROTOCOL['loads'])*2*2;cal=[]
 for (phase,load,policy),g in calibration[calibration.phase.str.endswith('calibration') & calibration.policy.isin([p['id'] for p in policies])].groupby(['phase','load','policy']):
  n=len(g);k=int(g.failure.sum());u=1. if k==n else float(beta.ppf(1-.05/K,k+1,n-k))
  kt=int(n-g.capture_success.sum());ut=1. if kt==n else float(beta.ppf(1-.05/K,kt+1,n-kt))
  cal.append({'phase':phase,'load':load,'policy':policy,'n':n,'k':k,'upper_risk':u,'task_k':kt,'task_upper_risk':ut,'cpu_s':float(g.cpu_s.mean()),'loss_m2s':float(g.loss_m2s.mean()),'utility':float((g.loss_m2s+g.cpu_s).mean())})
 cf=pd.DataFrame(cal);cf.to_csv(D/'calibration.csv',index=False);selected=[]
 assert len(cf)==len(policies)*len(PROTOCOL['loads'])*2
 assert set(cf.phase)=={'nominal_calibration','geometry_calibration'}
 for (phase,load),g in cf.groupby(['phase','load']):
  valid=g[g.upper_risk<=.15]
  best=valid.sort_values(['utility','policy']).iloc[0].to_dict() if len(valid) else {'policy':None}
  kg=valid[valid.policy.str.startswith('KG')]
  bestkg=kg.sort_values(['utility','policy']).iloc[0].to_dict() if len(kg) else {'policy':None}
  # If no KG candidate meets the risk contract, a utility-selected KG remains explicitly uncertified.
  kgemp=g[g.policy.str.startswith('KG')].sort_values(['utility','policy']).iloc[0].to_dict()
  selected.append({'context':phase,'load':load,'global':best,'certified_KG':bestkg,'empirical_KG':kgemp})
 (D/'selection.json').write_text(json.dumps(selected,indent=2))
 pd.DataFrame([dict(phase=a,load=b,policy=c,n=len(g),cpu_ms=g.cpu_s.mean()*1e3,decision_us=g.decision_cpu_s.mean()*1e6,loss=g.loss_m2s.mean(),rmse_cm=g.rmse_m.mean()*100,events=int(g.failure.sum()),ready=int(g.capture_ready.sum()),success=int(g.capture_success.sum()),mean_iterations=g.stop_iteration.mean(),tail_mean=g.loss_m2s.nlargest(max(1,int(np.ceil(.05*len(g))))).mean()) for (a,b,c),g in frame.groupby(['phase','load','policy'])]).to_csv(D/'summary.csv',index=False)
 old=json.loads((D/'evaluation_manifest.json').read_text()) if (D/'evaluation_manifest.json').exists() else {}
 (D/'evaluation_manifest.json').write_text(json.dumps({'evaluator_sha256':sha(__file__),'numeric_executor_sha256':old.get('numeric_executor_sha256',old.get('evaluator_sha256',sha(__file__))),'family_pairs':K,'record_count':len(frame),'step_cpu_s':step,'primitive_benchmark_seeds':sorted(benchmark),'nominal_risk_calibration_n':456,'geometry_risk_calibration_n':240,'calibration_amendment':'Excluded primitive-benchmark seeds after independent review; no policy or numeric execution changed.','capture_definition':'positive scan-source version ACTIVE at 0.3s after installations and rollbacks, including receiver replay, AND position norm at 0.3s <=0.1m', 'installation_latency':'ceil((queue + load*(frontend+solver+decision+earlier_replay))/(dt-load*primitive_step)) ticks', 'joint_events':['trajectory_0.5_4s','capture_0.3s'],'new_episode_count':int(frame.seed.nunique()),'selection':selected},indent=2))
 print('R4_EVALUATION_COMPLETE',json.dumps(selected),flush=True)
if __name__=='__main__':
 import sys
 if '--recalibrate' in sys.argv:
  report(pd.read_csv(D/'policy_results.csv'),json.loads((D/'evaluation_manifest.json').read_text())['step_cpu_s'])
 else:run()
