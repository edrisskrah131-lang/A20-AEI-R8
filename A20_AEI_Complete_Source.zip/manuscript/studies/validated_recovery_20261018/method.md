# Validated repair of an evidence binding

The old irreversible latch made an invalid attachment a lifetime ban on its source.
That rule is unnecessary for integrity and suppresses service after a trustworthy
repair. This study replaces it with **binding-scoped quarantine and an authenticated
revision transaction**. The physical input retains its identity, the rejected
attempt remains in the audit history, and a verified repair can restore service.

## State and repair rule

A binding identifies a capture, request, and update workflow. Its current immutable
revision records the producer, observable-output digest, active calibration identity,
and predecessor revision digest. Its state is active or quarantined. The calibration
decision is separate: an unsupported request does not corrupt the binding history.

An output-origin mismatch quarantines the affected binding. A corrective transaction
must establish all of the following: (i) authenticated control-plane provenance;
(ii) the same registered capture and binding; (iii) the next monotonic revision and
the current predecessor digest; (iv) the intended producer; (v) the currently active
calibration identity; and (vi) equality with the trusted stored output for that
capture and producer. A compare-and-swap commit installs the revision and reactivates
the binding. This is a repair of an attachment, not a claim that an untested producer
can be certified by changing its name. A producer behavioral change still requires
its separately defined numerical regression and calibration checks.

A retry without repair provenance, a new display name, a replayed transaction, a
wrong output hash, a wrong producer, or a retired calibration cannot restore a
quarantined binding. Once a valid repair has committed, submitting that same repair
again is an inert rejected transaction: it cannot create another revision or destroy
the already valid output. Rejected attempts remain in the append-only event log.

## Evidence used by the executable study

All inputs come from the immutable `lifecycle_20261018` output archive. We use its
256 held-out scene identities and eight fixed requests. A baseline-to-exposure
change supplies two genuinely computed numerical outputs per source. Two fault
scopes are evaluated independently: attaching the source's earlier baseline output
to its exposure revision, and attaching the next source's actual exposure output.
Both interventions substitute existing computed data; they do not generate new
observations or alter the original study.

The authenticated runtime payload contains the observable reprojection residual,
matched and planned site counts, and an archive locator consisting of the CSV hash,
source seed, and producer variant. True match coverage, physical mapping error, and
optical model quantities are kept in separate post-hoc scoring fields. **No per-image
ground-truth quality value is consulted by an admission gate.** Calibration is the
existing offline aggregate risk decision, with the event family unchanged.

For each source/request/fault scope, a 13-step workflow includes baseline and
exposure registration, a numerical misattachment, a direct retry, an alias attempt,
five invalid repairs, one valid repair, a duplicate repair, and a subsequent request.
The 2,048 unique source/request contexts produce 4,096 fault scopes and 53,248
deterministic workflow decisions per implementation. These are repeated operations
on 256 sources, **not 53,248 independent experimental inputs**.

## Fair comparisons and result

The new gate is compared with an irreversible latch, a stateless local gate that
reads a fresh authoritative registry snapshot, an independently implemented
event-sourced gate, and a metadata-only ablation. The strong stateless baseline has
the same trusted persistent authority as the new method; its lack of a *local*
latch does not make its control plane stateless.

The authoritative-snapshot, quarantine/repair, and event-sourced implementations
agree on every decision and issue no mismatched numerical outputs. All restore the
3,072 statistically eligible fault scopes, corresponding to 1,536 unique
source/request contexts across all 256 sources. The irreversible latch restores
none. The metadata-only ablation issues 3,072 numerically misbound outputs. That
ablation demonstrates the need to authenticate source/output binding; it does not
establish superiority over the strong registry or event-sourced baselines.

There are 4,096 valid repair commits and 24,576 rejected repair transactions in the
scripted workload. Restoring an intact trusted output uses its existing archive
record and performs no new image evaluation, capture, or statistical calibration.
This operation count is not a wall-clock or physical-robot speedup. Each repair
preserves the original capture identity. The three post-repair checkpoints yield
9,216 availability disagreements for the irreversible latch; the primary availability
comparison is the final checkpoint, 0/3,072 versus 3,072/3,072 eligible scopes.

## Engineering meaning and trust boundary

History supplies auditability, transaction replay detection, and an explicit repair
path. It does not create a safety advantage over a fresh authoritative snapshot
implementing the same state and provenance facts. The independent numerical oracle
matches payload values and archive origins directly, rather than trusting a
method's Boolean validity label. The strong baselines' equivalence is expected and
reported openly.

The archive, active calibration registry, and control-plane signer are trusted.
The fixed HMAC key in `model.py` emulates authentication for this deterministic test
fixture; it is not a deployable credential or a cryptographic evaluation. This
study does not cover a compromised authority, forged trusted measurements, unknown
physical producer effects, or denial-of-service by a malicious client. Quarantine
is scoped to the affected evidence binding; deployments should authenticate the
actor allowed to initiate a quarantine and avoid turning an arbitrary malformed
request into a global source ban. If the correct output is absent or the producer
itself is suspect, authoritative reexecution or recapture is required; that case is
outside the stored-output repair experiment.

## Reproduction

Run `python manuscript/studies/validated_recovery_20261018/run.py`, followed by
`python manuscript/studies/validated_recovery_20261018/verify.py`. For exact replay
without changing archived results, run `run.py --verify`. Only the Python standard
library is required. `outputs/source_inventory.json` ties every observable payload
to the prior study. `outputs/example_trace.json` provides the complete first-source
trace, including separate runtime payloads and offline quality values.

Verification exercises authentic-but-wrong certificates, missing or invalid
signatures, same-revision mutation, rollback, skipped revisions, broken predecessor
links, source aliases, wrong producer and payload, retired calibration, valid repair,
duplicate transaction idempotence, immutable rejection history, and the separation
of statistical refusal from integrity history. It also reconstructs numerical fault
deltas from the archived CSV and checks every stored workflow decision.
