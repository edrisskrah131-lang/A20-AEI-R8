"""Pixel/CAD estimation and separate truth scoring for the challenge study.

The estimator has no access to physical target locations, visibility labels or
rendering geometry. It transcribes the frozen lifecycle estimator unchanged.
Only scoring receives those data. Mapping uses the actual CAD surface mesh,
rather than applying the earlier quadratic-surface approximation to new parts.
"""
from pathlib import Path
import sys
import numpy as np
from scipy.ndimage import gaussian_filter, label, sum_labels, center_of_mass
from scipy.optimize import linear_sum_assignment, least_squares
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation

ROOT = Path(__file__).resolve().parent
sys.path.append(str(ROOT.parents[1] / 'lifecycle_20261018'))
from imaging import decode as frozen_decode

DECODER_GRID = [dict(name=f'normalized_z{z:g}_a{a:g}', z=z, absolute=a)
                for z in (1.0, 1.6, 2.2) for a in (4., 8.)]
BASELINE = dict(name='frozen_dark_contrast', threshold=18.)


def project(points, camera, rotation, focal):
    coordinates = (np.asarray(points) - camera) @ rotation
    return focal * coordinates[:, :2] / coordinates[:, 2, None]


def decode(rgb, config):
    if config['name'] == BASELINE['name']:
        return frozen_decode(rgb, 18.)
    gray = np.asarray(rgb, float).mean(2)
    background = gaussian_filter(gray, 3.)
    contrast = background - gray
    local_mean = gaussian_filter(gray, 8.)
    scale = np.sqrt(np.maximum(gaussian_filter(gray * gray, 8.) - local_mean ** 2, 0.))
    regions, count = label((contrast > config['absolute']) &
                           (contrast > config['z'] * np.maximum(scale, 1.)))
    if not count:
        return np.empty((0, 2))
    ids = np.arange(1, count + 1)
    areas = sum_labels(np.ones_like(gray), regions, ids)
    ids = ids[(areas >= 5) & (areas <= 240)]
    if not len(ids):
        return np.empty((0, 2))
    centroids = np.asarray(center_of_mass(np.maximum(contrast, 0), regions, ids))
    return centroids[:, ::-1] + .5 - [rgb.shape[1] / 2, rgb.shape[0] / 2]


def estimate(cad, camera_prior, rotation_prior, focal, decoded):
    """Frozen CAD assignment and regularized Huber pose fit; no truth arguments."""
    q, pc, pr = np.asarray(cad), np.asarray(camera_prior), np.asarray(rotation_prior)
    predicted = project(q, pc, pr, focal)
    if len(decoded):
        i, j = linear_sum_assignment(np.linalg.norm(predicted[:, None, :] - decoded[None, :, :], axis=2))
        keep = np.linalg.norm(predicted[i] - decoded[j], axis=1) < 30
        i, j = i[keep], j[keep]
    else:
        i, j = np.array([], int), np.array([], int)
    camera, rotation = pc.copy(), pr.copy()
    if len(i) >= 6:
        def residual(d):
            return np.r_[(project(q[i], pc + d[:3], pr @ Rotation.from_rotvec(d[3:]).as_matrix(), focal) - decoded[j]).ravel() / .5,
                         d[:3] / .003, d[3:] / .001]
        solution = least_squares(residual, np.zeros(6), loss='huber', f_scale=2,
                                 max_nfev=60, ftol=1e-8, xtol=1e-8, gtol=1e-8)
        camera = pc + solution.x[:3]
        rotation = pr @ Rotation.from_rotvec(solution.x[3:]).as_matrix()
    predicted = project(q, camera, rotation, focal)
    reprojection = float(np.max(np.linalg.norm(predicted[i] - decoded[j], axis=1))) if len(i) else np.inf
    return dict(camera=camera, rotation=rotation, predicted=predicted,
                matched_indices=i, matched_centers=decoded[j], decoded=decoded,
                reprojection_px=np.asarray(reprojection))


def intersect_mesh(camera, directions, vertices, faces):
    """Double-sided Moller-Trumbore intersections; first positive hit per ray."""
    triangles = vertices[faces]
    v0 = triangles[:, 0]
    e1, e2 = triangles[:, 1] - v0, triangles[:, 2] - v0
    origin = camera - v0
    q = np.cross(origin, e1)
    result = np.full((len(directions), 3), np.nan)
    for k, direction in enumerate(directions):
        p = np.cross(direction, e2)
        determinant = np.einsum('ij,ij->i', e1, p)
        usable = np.abs(determinant) > 1e-14
        reciprocal = np.zeros_like(determinant)
        reciprocal[usable] = 1 / determinant[usable]
        u = np.einsum('ij,ij->i', origin, p) * reciprocal
        v = (q @ direction) * reciprocal
        t = np.einsum('ij,ij->i', e2, q) * reciprocal
        usable &= (u >= -1e-9) & (v >= -1e-9) & (u + v <= 1 + 1e-9) & (t > 1e-8)
        if usable.any():
            result[k] = camera + t[usable].min() * direction
    return result


def prior(scene, variant):
    camera = np.asarray(variant['camera'], float)
    rotation = np.asarray(variant['rotation'], float)
    return (camera + np.asarray(scene['translation_error']),
            rotation @ Rotation.from_rotvec(scene['rotation_error']).as_matrix())


def score(scene, variant, fitted, vertices, faces):
    actual = np.asarray(scene['actual'], float)
    missing = np.asarray(scene['missing'], bool)
    visible = np.asarray(variant['visible'], bool)
    truth = project(actual, np.asarray(variant['camera']), np.asarray(variant['rotation']), variant['focal'])
    indices, centers = fitted['matched_indices'], fitted['matched_centers']
    correct = np.zeros(len(indices), bool)
    if len(indices):
        distances, identity = cKDTree(truth).query(centers)
        correct = (identity == indices) & (distances < 8) & ~missing[indices] & visible[indices]
    directions = np.c_[truth / variant['focal'], np.ones(len(truth))] @ fitted['rotation'].T
    directions /= np.linalg.norm(directions, axis=1, keepdims=True)
    reconstructed = intersect_mesh(fitted['camera'], directions, vertices, faces)
    mapping = np.linalg.norm(reconstructed - actual, axis=1)
    mapping[~np.isfinite(mapping)] = np.inf
    estimated_truth_projection = project(actual, fitted['camera'], fitted['rotation'], variant['focal'])
    pixel_mapping = np.linalg.norm(estimated_truth_projection - truth, axis=1)
    coverage = float(correct.sum() / len(actual))
    residual = float(fitted['reprojection_px'])
    mapping_max = float(mapping.max())
    matched_fraction = len(indices) / len(actual)
    # This is an observable per-output screening rule, not a calibrated risk card.
    screening_accept = bool(matched_fraction >= .8 and residual <= 8.)
    failure = bool(coverage < .8 or residual > 8. or mapping_max > .008)
    values = dict(candidates=len(fitted['decoded']), matched_targets=len(indices),
                  correct_matches=int(correct.sum()), planned_targets=len(actual),
                  visible_targets=int(visible.sum()), coverage=coverage,
                  matched_fraction=matched_fraction, reprojection_px=residual,
                  association_m=mapping_max, mapping_median_m=float(np.median(mapping)),
                  pixel_mapping_max_px=float(pixel_mapping.max()),
                  mesh_misses=int(np.isinf(mapping).sum()),
                  prior_translation_error_m=float(np.linalg.norm(scene['translation_error'])),
                  posterior_translation_error_m=float(np.linalg.norm(fitted['camera'] - variant['camera'])),
                  coverage_failure=coverage < .8, mapping_failure=mapping_max > .008,
                  residual_failure=residual > 8., quality_failure=failure,
                  observable_screen_accept=screening_accept,
                  accepted_but_failed=screening_accept and failure)
    arrays = dict(**fitted, true_pixels=truth, correct_matches=correct,
                  mapping_errors_m=mapping, reconstructed=reconstructed,
                  pixel_mapping_errors_px=pixel_mapping)
    return values, arrays
