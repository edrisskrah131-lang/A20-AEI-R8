"""Independent invariants, adversarial transactions, and source-value checks."""
from copy import deepcopy
import csv
from hashlib import sha256
import json
from pathlib import Path

from model import (Registry, QuarantineGate, PermanentLatch, certificate, digest,
                   snapshot_issue, event_sourced_issue)
from run import ROOT, SOURCE, OUT, inputs


def main():
    checks=[]
    records,cards,payloads,scores=inputs()
    seed=202619100; request='complete_relaxed'
    local_payloads={v:payloads[seed,v] for v in ('baseline','exposure')}
    local_cards={v:cards[v,request] for v in ('baseline','exposure')}

    def setup():
        reg=Registry('binding',f'capture-{seed}',local_payloads,local_cards)
        reg.register('baseline');reg.register('exposure')
        return reg

    reg=setup()
    correct=reg.envelope()
    assert snapshot_issue(correct,reg.snapshot())
    # Runtime cannot see the physical mapping error or true match coverage.
    assert set(correct['payload'])=={'record_locator','reprojection_px','matched_targets','planned_targets'}
    assert 'association_m' not in json.dumps(correct)
    checks.append('runtime payload excludes latent image-quality labels')

    # Test exact numerical integrity before authority has been quarantined.
    bad=reg.envelope(payload=local_payloads['baseline'])
    assert reg.status=='active'
    assert not snapshot_issue(bad,reg.snapshot())
    assert not event_sourced_issue(bad,reg.log,local_cards)
    checks.append('wrong numerical output rejected independently of quarantine state')

    # Exercise the reusable input-validation API, rather than telling the
    # controller that this scripted attachment is invalid.
    reg=setup();before=deepcopy(reg.log)
    assert reg.validate_attachment(reg.envelope())
    assert reg.status=='active' and reg.log==before
    reg.cards['exposure']['authorized']=False
    assert reg.validate_attachment(reg.envelope())
    assert reg.status=='active' and reg.log==before
    assert not snapshot_issue(reg.envelope(),reg.snapshot())
    bad_envelope=reg.envelope(payload=local_payloads['baseline'])
    assert not reg.validate_attachment(bad_envelope)
    assert reg.status=='quarantined' and len(reg.log)==len(before)+1
    quarantined_log=deepcopy(reg.log)
    assert not reg.validate_attachment(bad_envelope)
    assert reg.validate_attachment(reg.envelope())
    assert reg.status=='quarantined' and reg.log==quarantined_log
    checks.append('controller detects actual attachment mismatch; valid or statistically refused inputs do not quarantine; retries are idempotent')

    reg=setup()
    correct=reg.envelope()

    mutations=[('binding','unregistered-alias'),('capture','capture-other'),
               ('revision',0),('revision',2),('producer','baseline'),
               ('calibration','unknown-card')]
    for field,value in mutations:
        altered=deepcopy(correct);altered[field]=value
        assert not snapshot_issue(altered,reg.snapshot()),(field,value)
    checks.append('unknown aliases, wrong source, stale/future revision, producer and card rejected')

    # A malicious caller can recompute a payload digest, but cannot alter the
    # authoritative root. The direct value oracle does not use digest equality.
    altered=deepcopy(correct);altered['payload']['reprojection_px']+=1
    assert not snapshot_issue(altered,reg.snapshot())
    checks.append('self-consistent altered payload cannot replace authoritative root')

    # Ordinary producer registration must not bypass a quarantined binding.
    # Its rejected invocation leaves both state and event log unchanged, and
    # the event-folded verifier must also reject an unapproved recovery commit.
    reg=setup();reg.quarantine(reg.envelope(payload=local_payloads['baseline']))
    old_record,old_log=deepcopy(reg.record),deepcopy(reg.log)
    for producer in ('baseline','exposure'):
        try:reg.register(producer)
        except ValueError:pass
        else:raise AssertionError('ordinary registration bypassed quarantine')
        assert reg.record==old_record and reg.log==old_log and reg.status=='quarantined'
        assert not snapshot_issue(reg.envelope(),reg.snapshot())
        assert not event_sourced_issue(reg.envelope(),reg.log,local_cards)
    forged_log=old_log+[dict(kind='commit',record=deepcopy(old_record))]
    assert not event_sourced_issue(reg.envelope(),forged_log,local_cards)
    repair_envelope=reg.envelope(revision=2)
    assert reg.repair(repair_envelope,reg.issue_certificate())
    assert snapshot_issue(repair_envelope,reg.snapshot())
    assert event_sourced_issue(repair_envelope,reg.log,local_cards)
    assert old_log[-1] in reg.log
    checks.append('ordinary registration and an unapproved commit cannot bypass quarantine; valid repair still restores')

    # Enumerate signed but semantically wrong repair certificates. An authentic
    # channel alone does not authorize an incorrect binding or output.
    invalid_fields=[('binding','binding/renamed'),('capture','capture-other'),
        ('revision',0),('revision',1),('revision',3),('predecessor',None),
        ('predecessor','wrong-root'),('producer','baseline'),
        ('payload_digest',digest(local_payloads['baseline'])),
        ('calibration','retired-card')]
    for field,value in invalid_fields:
        reg=setup();reg.quarantine(reg.envelope(payload=local_payloads['baseline']))
        old=deepcopy(reg.record)
        cert=reg.issue_certificate(**{field:value})
        assert not reg.repair(reg.envelope(revision=2),cert),(field,value)
        assert reg.record==old and reg.status=='quarantined'
    checks.append(f'{len(invalid_fields)} signed-but-invalid repair mutations rejected without state change')

    for altered in ('missing','bad_signature','wrong_payload'):
        reg=setup();reg.quarantine(reg.envelope(payload=local_payloads['baseline']))
        cert=reg.issue_certificate();env=reg.envelope(revision=2)
        if altered=='missing':cert=None
        if altered=='bad_signature':cert['signature']='0'*64
        if altered=='wrong_payload':env['payload']=local_payloads['baseline']
        assert not reg.repair(env,cert)
        assert reg.record['revision']==1 and reg.status=='quarantined'
    checks.append('missing proof, altered signature and wrong repair payload rejected')

    reg=setup();gate=QuarantineGate();gate.issue(reg.envelope(),reg.snapshot())
    old=deepcopy(reg.record)
    reg.quarantine(reg.envelope(payload=local_payloads['baseline']))
    assert not gate.issue(reg.envelope(),reg.snapshot())
    invalid_log=deepcopy(reg.log[-1])
    cert=reg.issue_certificate();env=reg.envelope(revision=2)
    assert reg.repair(env,cert)
    assert reg.record['predecessor']==digest(old) and reg.capture==f'capture-{seed}'
    assert gate.issue(env,reg.snapshot())
    assert invalid_log in reg.log
    assert not reg.repair(env,cert)
    assert gate.issue(env,reg.snapshot())
    assert reg.record['revision']==2
    checks.append('same-source repair restores service and preserves anomaly; duplicate commit is inert')

    # Check rollback and same-revision mutation independently of certificate path.
    for mutation in ('rollback','same_revision_mutation','broken_parent','skipped_revision'):
        snap=reg.snapshot()
        if mutation=='rollback':snap['record']['revision']=1
        if mutation=='same_revision_mutation':snap['record']['payload_digest']='wrong'
        if mutation=='broken_parent':snap['record'].update(revision=3,predecessor='wrong')
        if mutation=='skipped_revision':snap['record'].update(revision=4,predecessor=digest(reg.record))
        try:gate.sync(snap)
        except ValueError:pass
        else:raise AssertionError(mutation)
    checks.append('local verifier rejects authority rollback, root rewrite, skipped and broken revisions')

    # Unsupported calibration is a service decision; it cannot damage lineage.
    reg=setup();latch=PermanentLatch();reg.cards['exposure']['authorized']=False
    assert not latch.issue(reg.envelope(),reg.snapshot()) and latch.intact
    reg.cards['exposure']['authorized']=True
    assert latch.issue(reg.envelope(),reg.snapshot())
    checks.append('statistical refusal does not poison integrity history')

    # Verify output provenance directly from archived CSV rows, without trusting
    # the registry or either gate's equality function.
    inventory=json.loads((OUT/'source_inventory.json').read_text())
    assert inventory['sources']['observations.csv']==sha256((SOURCE/'observations.csv').read_bytes()).hexdigest()
    for item in inventory['observable_payloads']:
        raw=records[item['seed'],item['variant']];p=item['payload']
        assert p['reprojection_px']==float(raw['reprojection_px'])
        assert p['matched_targets']==int(raw['matched_targets'])
        assert p['planned_targets']==int(raw['planned_targets'])
        assert p['record_locator']['seed']==item['seed']
        assert p['record_locator']['variant']==item['variant']
        assert item['digest']==digest(p)
    checks.append(f'{len(inventory["observable_payloads"])} observable records independently linked to archived solver outputs')

    with (OUT/'decisions.csv').open() as handle:rows=list(csv.DictReader(handle))
    summary=json.loads((OUT/'summary.json').read_text())
    assert len(rows)==summary['decisions_per_method']==53248
    for row in rows:
        assert row['authoritative_snapshot']==row['quarantine_repair']==row['event_sourced']==row['expected_issue']
        if row['step']=='wrong_attachment':
            original=scores[int(row['seed']),'exposure']
            attached=scores[int(row['attached_seed']),row['attached_variant']]
            for key,field,scale in [('reprojection_px','residual_delta_px',1),
                                    ('coverage','coverage_delta',1),
                                    ('association_m','mapping_delta_mm',1000),
                                    ('blur_px','blur_delta_px',1)]:
                assert abs(float(row[field])-(attached[key]-original[key])*scale)<1e-12
    checks.append('all 53,248 decisions independently checked; numerical deltas reconstructed from source values')
    evidence=dict(status='PASS',checks=checks,check_groups=len(checks),
                  source_hashes=summary['sources'],workflow_rows=len(rows))
    (OUT/'verification.json').write_text(json.dumps(evidence,indent=2)+'\n')
    print(json.dumps(evidence,indent=2))


if __name__=='__main__':main()
