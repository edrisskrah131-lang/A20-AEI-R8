"""Procedural CAD-surface imaging and pixel-based rivet association.

All scenes are synthetic. No aircraft photograph supplies quantitative data.
Independent surface curvature, camera pose, illumination, exposure and prior
uncertainty are sampled before rendering. The decoder sees only image pixels;
CAD-predicted positions are used subsequently for assignment, not segmentation.
"""
import numpy as np
from scipy.ndimage import gaussian_filter,label,center_of_mass,sum_labels
from scipy.optimize import linear_sum_assignment
from scipy.spatial.transform import Rotation

VARIANTS=('baseline','focal','exposure','wide_roi','lighting','decoder')
CHANGED={'baseline':(), 'focal':('focal',),'exposure':('exposure',),
         'wide_roi':('roi',),'lighting':('lighting',),'decoder':('decoder',)}
DEPENDENCIES={
 'gsd_m':('surface','focal','capture'),
 'blur_px':('surface','focal','capture','exposure','motion'),
 'coverage':('surface','focal','capture','exposure','motion','roi','lighting','decoder'),
 'reprojection_px':('surface','focal','capture','exposure','motion','roi','lighting','decoder','pose'),
 'association_m':('surface','focal','capture','exposure','motion','roi','lighting','decoder','pose')}

def draw(seed):
    r=np.random.default_rng(seed);family=int(r.integers(3))
    a=0. if family==0 else 1/r.uniform(2.5,5.0)
    b=0. if family<2 else 1/r.uniform(4.0,8.0)
    distance=r.uniform(.70,1.15)
    c=np.array([r.uniform(-.20,.20),r.uniform(-.10,.10),distance])
    forward=-c/np.linalg.norm(c);right=np.cross(forward,[0,1,0]);right/=np.linalg.norm(right)
    down=np.cross(forward,right);rotation=np.column_stack([right,down,forward])
    translation_error=r.normal(0,.0010,3)
    if r.random()<.02:translation_error+=r.normal(0,.005,3)
    rotation_error=r.normal(0,.0004,3)
    return {'seed':int(seed),'family':family,'a':float(a),'b':float(b),'camera':c,
            'rotation':rotation,'translation_error':translation_error,'rotation_error':rotation_error,
            'focal':r.uniform(1200,1600),'exposure':r.uniform(.003,.007),
            'speed':r.uniform(.06,.18),'brightness':r.uniform(.85,1.15),
            'light':np.array([r.uniform(-.4,.4),r.uniform(-.3,.3),1.]),'noise':r.uniform(1.5,3.),
            'texture_phase':r.uniform(0,2*np.pi)}

def targets(scene):
    x,y=np.meshgrid(np.arange(-3,4)*.035,np.arange(-2,3)*.035)
    x=x.ravel();y=y.ravel()
    return np.column_stack([x,y,.5*(scene['a']*x*x+scene['b']*y*y)])

def intersect(c,directions,a,b):
    dx,dy,dz=directions[...,0],directions[...,1],directions[...,2]
    aa=.5*(a*dx*dx+b*dy*dy)
    bb=a*c[0]*dx+b*c[1]*dy-dz
    cc=.5*(a*c[0]**2+b*c[1]**2)-c[2]
    disc=np.maximum(bb*bb-4*aa*cc,0)
    distance=-2*cc/np.maximum(bb+np.sqrt(disc),1e-12)
    return c+directions*distance[...,None]

def project(points,c,r,focal):
    local=(points-c)@r
    return focal*local[:,:2]/local[:,2,None]

def parameters(scene,variant):
    f=scene['focal']*(1.15 if variant=='focal' else 1)
    e=scene['exposure']*(1.5 if variant=='exposure' else 1)
    w,h=(896,672) if variant=='wide_roi' else (640,480)
    bright=scene['brightness']*(.45 if variant=='lighting' else 1)
    return f,e,w,h,bright

def render(scene,variant):
    focal,exposure,width,height,brightness=parameters(scene,variant)
    u,v=np.meshgrid(np.arange(width)+.5-width/2,np.arange(height)+.5-height/2)
    rays=np.stack([u/focal,v/focal,np.ones_like(u)],axis=-1)@scene['rotation'].T
    rays/=np.linalg.norm(rays,axis=-1,keepdims=True)
    xyz=intersect(scene['camera'],rays,scene['a'],scene['b']);x=xyz[:,:,0];y=xyz[:,:,1]
    normal=np.stack([-scene['a']*x,-scene['b']*y,np.ones_like(x)],axis=-1)
    normal/=np.linalg.norm(normal,axis=-1,keepdims=True)
    lighting=scene['light']/np.linalg.norm(scene['light'])
    diffuse=np.maximum(normal@lighting,0)
    camera_direction=-rays
    half=lighting+camera_direction;half/=np.linalg.norm(half,axis=-1,keepdims=True)
    highlight=np.maximum(np.sum(normal*half,axis=-1),0)**36
    brush=2.0*np.sin(x*1800+scene['texture_phase'])+1.0*np.sin(y*2200)
    intensity=brightness*(80+85*diffuse+30*highlight+brush)
    # Panel joints and rivet heads are defined in CAD surface coordinates.
    seam=(np.abs(x-.16)<.0007)|(np.abs(y+.115)<.0007)
    intensity[seam]*=.55
    gx=np.round(x/.035)*.035;gy=np.round(y/.035)*.035
    within=(np.abs(gx)<=.1051)&(np.abs(gy)<=.0701)
    radius=np.sqrt((x-gx)**2+(y-gy)**2)
    heads=(radius<.0025)&within;rim=(radius>=.0025)&(radius<.0032)&within
    intensity[heads]*=.22;intensity[rim]=brightness*210
    planned=targets(scene);normals=np.c_[-scene['a']*planned[:,0],-scene['b']*planned[:,1],np.ones(len(planned))]
    normals/=np.linalg.norm(normals,axis=1,keepdims=True)
    vectors=scene['camera']-planned;distance=np.linalg.norm(vectors,axis=1)
    incidence=np.abs(np.sum(normals*vectors/distance[:,None],axis=1))
    gsd=distance/(focal*np.maximum(incidence,1e-8));blur=scene['speed']*exposure/gsd
    sigma=float(np.median(blur)/np.sqrt(12))
    if sigma>.02:intensity=gaussian_filter(intensity,sigma=(.18,sigma))
    rng=np.random.default_rng(scene['seed']+70000000)
    intensity+=rng.normal(0,scene['noise'],intensity.shape)
    rgb=np.clip(np.rint(intensity[:,:,None]*np.array([.92,.97,1.03])),0,255).astype(np.uint8)
    return {'rgb':rgb,'width':width,'height':height,'focal':focal,'gsd':gsd,'blur':blur,
            'true_pixels':project(planned,scene['camera'],scene['rotation'],focal),'targets':planned}

def decode(rgb):
    gray=rgb.mean(axis=2);contrast=gaussian_filter(gray,3)-gray
    regions,n=label(contrast>18)
    if not n:return np.empty((0,2))
    ids=np.arange(1,n+1);areas=sum_labels(np.ones_like(gray),regions,ids)
    ids=ids[(areas>=5)&(areas<=240)]
    if not len(ids):return np.empty((0,2))
    centers=np.asarray(center_of_mass(np.maximum(contrast,0),regions,ids))
    return centers[:,::-1]+.5-np.array([rgb.shape[1]/2,rgb.shape[0]/2])

def execute(scene,variant):
    image=render(scene,variant);decoded=decode(image['rgb'])
    if variant=='decoder':decoded=decoded+np.array([4.,0.])
    c=scene['camera']+scene['translation_error']
    r=scene['rotation']@Rotation.from_rotvec(scene['rotation_error']).as_matrix()
    predicted=project(image['targets'],c,r,image['focal'])
    if len(decoded):
        costs=np.linalg.norm(predicted[:,None,:]-decoded[None,:,:],axis=2)
        i,j=linear_sum_assignment(costs);keep=costs[i,j]<30;i=i[keep];j=j[keep]
        correctness=np.linalg.norm(decoded[j]-image['true_pixels'][i],axis=1)<np.maximum(4,.004/image['gsd'][i])
        ii=i[correctness];jj=j[correctness]
    else:ii=np.array([],dtype=int);jj=np.array([],dtype=int)
    count=len(ii);coverage=count/len(image['targets'])
    if count:
        rays=np.c_[decoded[jj]/image['focal'],np.ones(count)]@r.T
        rays/=np.linalg.norm(rays,axis=1,keepdims=True)
        reconstructed=intersect(c,rays,scene['a'],scene['b'])
        reprojection=float(np.max(np.linalg.norm(predicted[ii]-decoded[jj],axis=1)))
        association=float(np.max(np.linalg.norm(reconstructed-image['targets'][ii],axis=1)))
    else:reprojection=association=np.inf
    values={'gsd_m':float(np.max(image['gsd'])),'blur_px':float(np.max(image['blur'])),
            'coverage':float(coverage),'reprojection_px':reprojection,'association_m':association,
            'decoded_candidates':len(decoded),'matched_targets':count,'planned_targets':len(image['targets'])}
    image.update(decoded=decoded,predicted=predicted,matched_indices=ii,matched_centers=decoded[jj])
    return values,image
