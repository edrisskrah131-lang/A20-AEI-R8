from pathlib import Path
import json,numpy as np
from PIL import Image
from model import draw,execute,VARIANTS
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'pilot';OUT.mkdir(exist_ok=True)
rows=[]
for i in range(8):
    scene=draw(202610900+i)
    for v in VARIANTS:
        values,image=execute(scene,v);rows.append({'seed':scene['seed'],'variant':v,**values})
        if i<3 and v in ['baseline','lighting']:Image.fromarray(image['rgb']).save(OUT/f'{i}_{v}.png')
    print(scene['seed'],scene['family'],rows[-6]['matched_targets'],rows[-6]['reprojection_px'],flush=True)
(OUT/'results.json').write_text(json.dumps(rows,indent=2))
