# Executable Evidence Management for CAD-Guided Aircraft Inspection

当前交付：正文 `A20_AEI_Manuscript.pdf`（15 页、8 节、9 图），补充 `Supplement.pdf`（39 页），完整可编辑源码包。数据来源、旧基线归因、AI 辅助说明、资助及实施范围集中于补充材料最后一节。正文明确说明实际使用的仿真方法。照片来源与许可见 `paper/figures/open_photos/`。

## 2026-10-18 整稿修订

主线统一为工程变更后的证据保留、更新与输出附着。普通依赖图缓存负责数值计算复用；契约增加事件包含、精确回退和持续来源历史。新增支持保持命题，加入依赖图精确缓存及独立规则实现对照，分别归因计算收益与证据评估收益。扫描配准、规则网格和 12 像素位移等早期研究作为受控补充研究保留。

新研究目录 `studies/lifecycle_20261018/`：

- 256 个校准输入、256 个独立测试输入，四种布局，包含缺失、遮挡、材质和 CAD 偏差。六种配置实际输出 3,072 条记录；另有 128 个压力输入。
- 四种完整方法均支持 41/48 个上下文。契约及独立规则实现构建 26 张卡，DAG 精确缓存构建 42 张。记录评估从 10,752 降至 6,656，减少 38.10%；精确回退恢复了锚点单独复用丢失的三个上下文。
- 16 个独立计时输入、每方法 640 个实际执行案例。完整重算累计 CPU 183.993 秒，DAG 精确缓存 80.486 秒，契约 80.279 秒，规则实现 79.757 秒。三种 DAG 方法的数值阶段次数完全相同；数值收益不归为契约独有。证据目录处理另行计时。
- 64 个独立回归输入、三类条件耦合，86 个激活案例均被数值回归发现，192 个干净更新对照均通过。
- 256 个测试来源与八种请求构成 2,048 个来源/请求上下文，验证变更、恢复、无效附着、计划重建及独立后继。四种完整/消融实现共 81,920 个协议判定，属于一致性验证，不能当作新的独立统计样本。
- 压力总体平均覆盖率 72.69%，映射误差 p95 为 13.095 mm；正常测试总体相应为 96.14% 与 1.052 mm。压力总体与主校准总体分开报告。

原 176 份实验/来源文件与上一交付逐字节一致。独立目录重新计算全部 3,200 条主/压力输出及示例像素；另有 32 输入、192 次不经过缓存的直接流水线执行，与归档值的最大数量差为 3.56e-15。源码保留实现修订说明及未编译元数据时的原计时，场景生成、阈值和采样种子未随结果调整。

## 重建

仅编译 PDF：`bash build.sh`。

只重建当前图文：依次执行 `python reporting/lifecycle_report.py`、`python reporting/lifecycle_supplement.py`、`bash build.sh`、`python reporting/verify_lifecycle.py`、`python reporting/verify_visual_revision.py`。图像原件与数值记录已打包，无需网络下载。

完整重执行：Python 3.12 安装 `requirements-artifacts.txt`，提供 pdflatex/bibtex，再运行 `bash reproduce_artifacts.sh`。可用 `A20_PYTHON` 指定解释器。脚本验证早期独立研究，重算新总体、计时、回归和来源轨迹，核对直接流水线，再生成表图及两个 PDF。数值线程为 1，默认工作进程为 2。复算忽略机器相关计时差异，保留首次归档计时，并核对数值、决定和阶段次数。

新研究单独验证：`python studies/lifecycle_20261018/run.py --verify --workers 2`；也可用 `--stage population|analysis|timing|regression|lifecycle` 选择阶段。独立直接流水线检查为 `python studies/lifecycle_20261018/cold_check.py`。打包并逐文件校验：`python reporting/package_delivery.py`。

`outputs/evidence_inventory.json` 保存事件身份、生产者投影、校准记录哈希、样本选择、失败数和置信上界；`calibration_records.csv` 仅含校准记录。`pipeline_timing.csv` 保存每次实际执行的 CPU、墙钟与阶段次数。所有新数值均来自实际执行的模拟模型，不是飞机实测。

## 保留资料与交付

原始项目照片、两张开放航空蒙皮照片、所有可编辑 TeX/Bib、PDF/SVG/PNG 图、渲染器、解码器、位姿优化、单位编译器、阶段缓存、规则对照、所有观察和风险卡、完整来源轨迹及 SHA-256 清单均在包内。早期总体资产仍由原版本数据发布提供；当前重建入口不会重新运行整个早期总体。

下载分支：<https://github.com/edrisskrah131-lang/A20-AEI-R8/tree/aei-complete-20261014>。GitHub 交付为两份 PDF、源码 ZIP 和下载索引；不另上传审阅报告。`source/`、`protocol/` 和 `analysis/` 为保留的历史实现，不用旧导出脚本覆盖当前稿。
