"""Execute deterministic binding recovery on existing held-out image outputs."""
import argparse
from collections import Counter
from copy import deepcopy
import csv
from hashlib import sha256
import json
from pathlib import Path

from model import (Registry, PermanentLatch, QuarantineGate, digest,
                   snapshot_issue, event_sourced_issue, metadata_only_issue)

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'lifecycle_20261018' / 'outputs'
OUT = ROOT / 'outputs'
METHODS = ('authoritative_snapshot', 'permanent_latch', 'quarantine_repair',
           'event_sourced', 'metadata_only_ablation')


def read_csv(name):
    return list(csv.DictReader((SOURCE / name).open()))


def inputs():
    observations_hash = sha256((SOURCE / 'observations.csv').read_bytes()).hexdigest()
    records = {(int(r['seed']), r['variant']): r for r in read_csv('observations.csv')
               if r['phase'] == 'test' and r['variant'] in ('baseline', 'exposure')}
    inventory = {(r['variant'], r['request']): r for r in
                 json.loads((SOURCE / 'evidence_inventory.json').read_text())}
    cards = {}
    for r in read_csv('plans.csv'):
        if r['method'] == 'Contract + fallback' and r['variant'] in ('baseline', 'exposure'):
            selected = inventory[r['proof_variant'], r['proof_request']]
            cards[r['variant'], r['request']] = dict(identity=digest(selected),
                    authorized=r['authorized'] == 'True', upper=float(r['upper']),
                    proof_request=r['proof_request'], proof_variant=r['proof_variant'])
    payloads = {}
    scores = {}
    for (seed, variant), r in records.items():
        payloads[seed, variant] = dict(
            record_locator=dict(archive_sha256=observations_hash, phase='test',
                                seed=seed, variant=variant),
            reprojection_px=float(r['reprojection_px']),
            matched_targets=int(r['matched_targets']), planned_targets=int(r['planned_targets']))
        scores[seed, variant] = {k: float(r[k]) for k in
            ('coverage', 'association_m', 'gsd_m', 'blur_px', 'reprojection_px')}
    return records, cards, payloads, scores


class NumericalOracle:
    """Uses source archive values directly, not method decisions or method labels.

    The authority's commit status is a trusted control-plane fact. Its transaction
    validator is checked separately in verify.py; active status is not a numerical
    safety measurement. Exact output-origin matching is the independent numerical
    identity test. Current episode ground truth never determines admission.
    """
    def __init__(self, binding, capture, payloads, cards):
        self.binding, self.capture = binding, capture
        self.payloads, self.cards = payloads, cards

    def check(self, envelope, authority):
        record = authority['record']
        producer = record['producer']
        payload_ok = envelope['payload'] == self.payloads[producer]
        identity_ok = (envelope['binding'] == self.binding and
                       envelope['capture'] == self.capture and
                       envelope['revision'] == record['revision'] and
                       envelope['producer'] == producer and
                       envelope['calibration'] == self.cards[producer]['identity'])
        current = authority['status'] == 'active'
        risk = self.cards[producer]['authorized']
        return dict(numerical_origin_valid=payload_ok, identity_valid=identity_ok,
                    active_binding=current, risk_authorized=risk,
                    expected_issue=payload_ok and identity_ok and current and risk)


def workflow(seed, request, fault, cards, payloads, scores, donor):
    binding = f'capture-{seed}/{request}/{fault}'
    capture = f'capture-{seed}'
    local_payloads = {v: payloads[seed, v] for v in ('baseline', 'exposure')}
    local_cards = {v: cards[v, request] for v in ('baseline', 'exposure')}
    registry = Registry(binding, capture, local_payloads, local_cards)
    latch, gate = PermanentLatch(), QuarantineGate()
    oracle = NumericalOracle(binding, capture, local_payloads, local_cards)
    rows, trace = [], []

    def observe(step, envelope, repair_accepted=None, cert=None):
        snapshot = registry.snapshot()
        truth = oracle.check(envelope, snapshot)
        decisions = dict(authoritative_snapshot=snapshot_issue(envelope, snapshot),
            permanent_latch=latch.issue(envelope, snapshot),
            quarantine_repair=gate.issue(envelope, snapshot),
            event_sourced=event_sourced_issue(envelope, registry.log, local_cards),
            metadata_only_ablation=metadata_only_issue(envelope, snapshot))
        locator = envelope['payload']['record_locator']
        attached_score = scores[locator['seed'], locator['variant']]
        true_score = scores[seed, snapshot['record']['producer']]
        row = dict(seed=seed, request=request, fault=fault, step=step,
                   revision=snapshot['record']['revision'], state=snapshot['status'],
                   **truth, **decisions, repair_accepted=repair_accepted,
                   attached_seed=locator['seed'], attached_variant=locator['variant'],
                   residual_delta_px=attached_score['reprojection_px']-true_score['reprojection_px'],
                   coverage_delta=attached_score['coverage']-true_score['coverage'],
                   mapping_delta_mm=(attached_score['association_m']-true_score['association_m'])*1000,
                   blur_delta_px=attached_score['blur_px']-true_score['blur_px'])
        rows.append(row)
        trace.append(dict(**row, envelope=deepcopy(envelope),
                          authoritative_record=deepcopy(snapshot['record']),
                          certificate=deepcopy(cert), attached_offline_scores=attached_score,
                          intended_offline_scores=true_score,
                          audit_entries=len(registry.log)))

    registry.register('baseline')
    observe('baseline_registered', registry.envelope())
    registry.register('exposure')
    observe('exposure_registered', registry.envelope())
    offending = local_payloads['baseline'] if fault == 'stale_producer_output' else payloads[donor, 'exposure']
    bad = registry.envelope(payload=offending)
    # The mismatch is established against the stored observable output, not a
    # ground-truth safety label; it triggers quarantine of this binding scope.
    assert not registry.validate_attachment(bad)
    observe('wrong_attachment', bad)
    observe('correct_retry_without_repair', registry.envelope())
    observe('rename_without_provenance', registry.envelope(binding=binding+'/renamed'))

    def try_repair(step, cert, env=None):
        env = registry.envelope(revision=registry.record['revision']+1) if env is None else env
        accepted = registry.repair(env, cert)
        observe(step, env, accepted, cert)
        return env

    try_repair('repair_missing', None)
    try_repair('repair_replayed', registry.issue_certificate(revision=1, predecessor=None))
    try_repair('repair_wrong_hash', registry.issue_certificate(payload_digest=digest(offending)))
    try_repair('repair_wrong_producer', registry.issue_certificate(producer='baseline'))
    try_repair('repair_inactive_calibration', registry.issue_certificate(calibration='retired-card'))
    valid_cert = registry.issue_certificate()
    repaired_envelope = try_repair('repair_valid', valid_cert)
    # An identical transaction cannot create another revision. The already
    # repaired output remains usable; a rejected command does not poison it.
    try_repair('repair_duplicate_after_commit', valid_cert, repaired_envelope)
    observe('post_repair_request', registry.envelope())
    assert len(registry.log) == 11
    return rows, trace, registry.log


def write_csv(path, rows):
    with path.open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def main(verify=False):
    records, cards, payloads, scores = inputs()
    seeds = sorted({seed for seed, variant in records})
    requests = sorted({q for v, q in cards})
    rows, examples = [], {}
    for i, seed in enumerate(seeds):
        for request in requests:
            for fault in ('stale_producer_output', 'substituted_source_output'):
                out, trace, log = workflow(seed, request, fault, cards, payloads, scores,
                                           seeds[(i+1) % len(seeds)])
                rows.extend(out)
                if seed == seeds[0] and request in ('complete', 'complete_relaxed', 'optical'):
                    examples[request+'/'+fault] = dict(trace=trace, event_log=log)
    metrics = []
    for method in METHODS:
        recovery = [r for r in rows if r['step'] == 'post_repair_request' and r['risk_authorized']]
        invalid_numeric = [r for r in rows if not r['numerical_origin_valid']]
        invalid_identity = [r for r in rows if not r['identity_valid']]
        metric = dict(method=method, decisions=len(rows), issued=sum(r[method] for r in rows),
            oracle_disagreements=sum(r[method] != r['expected_issue'] for r in rows),
            incorrect_numerical_origin_issuances=sum(r[method] for r in invalid_numeric),
            invalid_identity_issuances=sum(r[method] for r in invalid_identity),
            quarantined_binding_issuances=sum(r[method] and not r['active_binding'] for r in rows),
            eligible_recovery_scopes=len(recovery), recovered_scopes=sum(r[method] for r in recovery),
            repaired_source_count=len({r['seed'] for r in recovery if r[method]}),
            repaired_unique_source_request_contexts=len({(r['seed'],r['request']) for r in recovery if r[method]}))
        metrics.append(metric)
    per_step = []
    for step in dict.fromkeys(r['step'] for r in rows):
        subset = [r for r in rows if r['step']==step]
        per_step.append(dict(step=step, scopes=len(subset),
            supported=sum(r['risk_authorized'] for r in subset),
            repair_commands_accepted=sum(r['repair_accepted'] is True for r in subset),
            **{m:sum(r[m] for r in subset) for m in METHODS}))
    stats = dict(status='PASS', design='deterministic workflow replay of stored simulation outputs',
        independent_image_sources=len(seeds), requests=len(requests),
        unique_source_request_contexts=len(seeds)*len(requests), fault_scopes=len(seeds)*len(requests)*2,
        workflow_steps=13, decisions_per_method=len(rows), methods=list(METHODS),
        new_image_observations=0, new_calibration_events=0,
        supported_exposure_requests=[q for q in requests if cards['exposure',q]['authorized']],
        valid_repairs=sum(r['repair_accepted'] is True for r in rows),
        additional_image_executions_for_restore=0,
        rejected_repair_commands=sum(r['repair_accepted'] is False for r in rows),
        numerical_faults_with_changed_values=sum(r['step']=='wrong_attachment' and
            any(abs(r[k])>1e-12 for k in ('residual_delta_px','coverage_delta','mapping_delta_mm','blur_delta_px')) for r in rows),
        metrics=metrics, per_step=per_step,
        scope='Authority and archive are trusted; no claim against compromised authority or undeclared producer behavior. Quarantine is binding scoped.',
        truth_separation='Runtime envelope contains only record locator, reprojection residual and matched/planned counts. Coverage, mapping error and optical quantities are post-hoc scores only.',
        sources={name:sha256((SOURCE/name).read_bytes()).hexdigest() for name in
                 ('observations.csv','plans.csv','evidence_inventory.json')})
    assert all(m['oracle_disagreements']==0 for m in metrics if m['method'] in
               ('authoritative_snapshot','quarantine_repair','event_sourced'))
    assert stats['valid_repairs']==stats['fault_scopes']
    assert stats['numerical_faults_with_changed_values']==stats['fault_scopes']
    if verify:
        assert json.loads((OUT/'summary.json').read_text())==stats
        with (OUT/'decisions.csv').open() as handle:
            old = list(csv.DictReader(handle))
        assert len(old)==len(rows)
        for a,b in zip(old,rows):
            assert a=={k:'' if v is None else str(v) for k,v in b.items()}
        print('PASS: deterministic replay exactly matches all archived decisions')
    else:
        OUT.mkdir(exist_ok=True)
        write_csv(OUT/'decisions.csv',rows)
        write_csv(OUT/'repair_metrics.csv',metrics)
        write_csv(OUT/'steps.csv',per_step)
        (OUT/'summary.json').write_text(json.dumps(stats,indent=2)+'\n')
        (OUT/'example_trace.json').write_text(json.dumps(dict(seed=seeds[0], examples=examples),indent=2)+'\n')
        (OUT/'source_inventory.json').write_text(json.dumps(dict(
            sources=stats['sources'], observable_payloads=[dict(seed=s,variant=v,payload=p,digest=digest(p))
                for (s,v),p in sorted(payloads.items())]),indent=2)+'\n')
        print(json.dumps(stats,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--verify',action='store_true')
    main(parser.parse_args().verify)
