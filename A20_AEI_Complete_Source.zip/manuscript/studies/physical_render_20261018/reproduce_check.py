"""Independent fresh rendering of the first held-out painted and metallic sources."""
from pathlib import Path
import json,sys,subprocess,argparse
import numpy as np
import pandas as pd
from PIL import Image
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT.parent/'lifecycle_20261018'))
from imaging import decode,fit,configuration
P=argparse.ArgumentParser();P.add_argument('--out',type=Path,default=Path('/tmp/a20-physical-reproduction'));args=P.parse_args();args.out.mkdir(parents=True,exist_ok=True)
p=json.loads((ROOT/'protocol.json').read_text());chosen={}
for seed in p['held_out_seeds']:
 m=json.loads((ROOT/'outputs'/'test'/(str(seed)+'.json')).read_text());chosen.setdefault('painted' if m['painted'] else 'metal',seed)
frame=pd.read_csv(ROOT/'outputs'/'metrics.csv')
records=[]
for kind,seed in chosen.items():
 cmd=['/usr/bin/blender','-b','-t','4','--python',str(ROOT/'render.py'),'--','--seed',str(seed),'--out',str(args.out),'--samples','32','--threads','4']
 with (args.out/(str(seed)+'.log')).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 s=json.loads((args.out/(str(seed)+'.json')).read_text());original=json.loads((ROOT/'outputs'/'test'/(str(seed)+'.json')).read_text())
 for k in ('camera','rotation','translation_error','rotation_error','cad','actual','missing','blender_projected_pixels'):assert np.array_equal(s[k],original[k]),k
 for k in ('camera','rotation','translation_error','rotation_error','cad','actual','missing'):s[k]=np.asarray(s[k])
 for variant in p['variants']:
  x=np.asarray(Image.open(args.out/(str(seed)+'_'+variant+'.png')).convert('RGB'));y=np.asarray(Image.open(ROOT/'outputs'/'test'/(str(seed)+'_'+variant+'.png')).convert('RGB'));assert np.array_equal(x,y),(seed,variant,int(np.max(np.abs(x.astype(int)-y))))
  values,arrays=fit(s,configuration('baseline'),decode(x,18.));oldarrays=np.load(ROOT/'outputs'/(str(seed)+'_'+variant+'_correspondences.npz'))
  assert all(np.array_equal(v,oldarrays[k]) for k,v in arrays.items())
  row=frame[(frame.seed==seed)&(frame.variant==variant)].iloc[0]
  assert all(np.isclose(v,row[k],rtol=1e-11,atol=1e-12) for k,v in values.items())
  records.append(dict(kind=kind,seed=seed,variant=variant,max_pixel_difference=0,correspondence_arrays_exact=True,metrics_match=True))
result={'status':'PASS','selection':'first held-out painted and first held-out metal source, by seed order','rerendered_images':len(records),'same_source_geometry_camera_and_protocol':True,'records':records,'PNG_byte_hash_scope':'PNG embeds timestamp and timing strings; reproducibility is checked on exact decoded pixels and arrays.'}
(ROOT/'reproduction.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
