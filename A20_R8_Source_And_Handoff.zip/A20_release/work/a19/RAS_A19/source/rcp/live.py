"""ROS-independent causal adapter. External odometry/deskewed clouds are required.
The adapter uses no truth. A pending job returns a source posterior; delivery replays
all increments and replaces revised history, without changing first-publication logs.
"""
from collections import deque
from dataclasses import dataclass
from time import process_time_ns,thread_time_ns,perf_counter_ns
import numpy as np
from .core import *
from .sensor import forecast_scan,forecast_state

@dataclass
class Entry:
    stamp:float
    raw_t:np.ndarray
    raw_R:np.ndarray
    increment:np.ndarray
    dt:float
    state:JointState

class LiveEngine:
    def __init__(self,mesh,model,policy='rcp',rate=.03,keep_s=20.,period=4.,fixed='full',lam=.3,decision_period=None,runtime=None,rollout=False):
        runtime={} if runtime is None else runtime
        self.mesh=mesh;self.model=model;self.policy=policy;self.planner=Planner(model,policy,period,fixed,lam=lam,overhead_rate=runtime.get('propagation_rate',.002),decision_cost=runtime.get(policy+'_decision_cost',.004))
        self.rollout=rollout
        if rollout:
            from .rollout import RolloutPlanner
            self.planner=RolloutPlanner(model,policy,period,fixed,lam=lam,overhead_rate=runtime.get('propagation_rate',.002),decision_cost=runtime.get(policy+'_decision_cost',.004))
        self.decision_period=(4. if policy=='rcp' else 1.) if decision_period is None else decision_period
        self.decision_reservation=runtime.get(policy+'_decision_cost',.004 if policy in ('rcp','greedy') else 0.)
        self.bucket=TokenBucket(rate);self.history=deque();self.keep_s=keep_s;self.last_decision=-np.inf;self.last_accept=0.;self.last_corrected=-np.inf;self.pending=False;self.version=0;self._cpu_last=process_time_ns();self._cpu_origin=self._cpu_last
        self.planner.costs={a:float(np.quantile(model.cost[model.action==a],.99)*1.5) for a in ACTIONS[1:]}
    def charge_process_cpu(self):
        now=process_time_ns();self.bucket.charge(max(0.,(now-self._cpu_last)*1e-9));self._cpu_last=now
    def observe(self,stamp,t,R):
        if not np.isfinite(stamp) or not np.isfinite(t).all() or not np.isfinite(R).all():raise ValueError('odometry must be finite')
        if self.history and stamp<=self.history[-1].stamp:raise ValueError('odometry stamps must strictly increase')
        start=process_time_ns();self.bucket.advance(stamp)
        if not self.history:
            P=np.diag(np.r_[np.full(3,.045**2),np.full(3,.006**2),np.full(3,.0015**2),np.full(3,.00015**2),np.full(3,.025**2),np.full(3,.001**2)])
            state=JointState(t.copy(),R.copy(),np.zeros(6),np.zeros(3),np.eye(3),P);inc=np.zeros(6);dt=0.;self.last_accept=stamp
        else:
            last=self.history[-1];dt=stamp-last.stamp
            if dt<=0:raise ValueError('odometry stamps must strictly increase')
            inc=np.r_[last.raw_R.T@(t-last.raw_t),log(last.raw_R.T@R)];state=propagate(last.state,dt,inc)
        self.history.append(Entry(stamp,t.copy(),R.copy(),inc,dt,state))
        while self.history[0].stamp<stamp-self.keep_s:self.history.popleft()
        self.charge_process_cpu();return state.copy()
    def prepare(self,stamp,points):
        start=process_time_ns()
        self.charge_process_cpu()
        if self.pending:return None,{'reason':'worker_busy'}
        if stamp<=self.last_corrected:return None,{'reason':'already_conditioned'}
        if stamp-self.last_decision<self.decision_period:return None,{'reason':'decision_cadence'}
        entries=list(self.history);matches=[e for e in entries if abs(e.stamp-stamp)<1e-6]
        if not matches:return None,{'reason':'source_requires_exact_or_resampled_odom'}
        source=matches[0];s=source.state.copy();self.last_decision=stamp
        moves=[e.increment/e.dt for e in entries[-50:] if e.dt>0];velocity=np.mean(moves,axis=0) if moves else np.zeros(6)
        age=max(0.,stamp-self.last_accept);floor_due=self.policy in ('rcp','greedy') and age>=12.;reservation=0. if floor_due else self.decision_reservation
        if self.policy in ('rcp','greedy') and self.bucket.tokens<reservation:
            self.charge_process_cpu();return None,{'reason':'decision_reservation_denied','tokens':self.bucket.tokens}
        future=None
        if floor_due or self.policy in ('periodic','age'):f=np.zeros(9);J=np.zeros((18,18))
        else:f,J,_=observe(self.mesh.prior,points,s,age)
        if self.policy=='rcp' and not floor_due:
            future=[(f,s.P,J)]
            for lag in ((4.,8.,12.) if self.rollout else (4.,12.)):
                fs=forecast_state(s,velocity,lag);ff,fJ,_=observe(self.mesh.prior,forecast_scan(self.mesh,fs),fs,max(0.,stamp-self.last_accept)+lag)
                if self.rollout:ff[4:7]=f[4:7]
                future.append((ff,fs.P,fJ))
        action,diagnostic=self.planner.choose(OnlineInput(stamp,s,points,velocity,age,max(0.,self.bucket.tokens-reservation),self.bucket.rate),f,J,future)
        cpu=(process_time_ns()-start)*1e-9;self.charge_process_cpu()
        if action=='skip' or self.bucket.tokens<self.planner.costs[action]:return None,{'reason':'skip_or_budget',**diagnostic,'decision_cpu_s':cpu}
        self.pending=True;return {'stamp':stamp,'source':s,'scan':points.copy(),'action':action,'decision_cpu_s':cpu},diagnostic
    def solve(self,job):
        start=thread_time_ns();wall=perf_counter_ns();post,stats,ix,si=register(self.mesh.prior,job['scan'],job['source'],job['action']);return {**job,'post':post,'stats':stats,'worker_thread_cpu_s':(thread_time_ns()-start)*1e-9,'job_wall_s':(perf_counter_ns()-wall)*1e-9}
    def deliver(self,job):
        start=process_time_ns();self.pending=False;self.charge_process_cpu();entries=list(self.history)
        if not entries or job['stamp']<entries[0].stamp or job['stamp']<=self.last_corrected:reason='stale_delivery'
        elif not job['stats']['accepted']:reason='solver_rejected'
        else:
            ids=[i for i,e in enumerate(entries) if abs(e.stamp-job['stamp'])<1e-6]
            if not ids:reason='source_evicted'
            else:
                i=ids[0];state=job['post'];entries[i].state=state.copy()
                for e in entries[i+1:]:state=propagate(state,e.dt,e.increment);e.state=state.copy()
                self.history=deque(entries);self.last_corrected=job['stamp'];self.last_accept=entries[-1].stamp;self.version+=1;reason='accepted'
        cpu=(process_time_ns()-start)*1e-9;self.charge_process_cpu();return {'source_stamp':job['stamp'],'delivery_odom_stamp':entries[-1].stamp if entries else None,'worker_wall_s':job.get('job_wall_s'),'reason':reason,'version':self.version,'replay_cpu_s':cpu,'tokens':self.bucket.tokens,**job['stats']}
