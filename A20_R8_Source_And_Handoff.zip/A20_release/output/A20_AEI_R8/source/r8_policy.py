"""Frozen forecasts; same numerical policies and budget wrapper for every selector."""
import numpy as np
from r4_policy import CAPS,Forecast,act as old_act,feat
from r8_protocol import BASE,PROTOCOL
import json

def policies():
    ps=json.loads((BASE/'freeze.json').read_text())['policies']
    for name,model in [('CART_Time','cart'),('RF_Time','rf')]:
        ps.append(dict(id=name,kind='multi',model=model,price=1.,profile=False,deadline=True))
    assert [p['id'] for p in ps]==PROTOCOL['policy_ids']
    return ps

def decide(r,s,pred,policy,clock,service,paid_work):
    # All observed/declared quantities; no error/true pose/future increment input.
    if policy['kind']=='old':
        publish=bool(s['eligible'] and pred[2]<=.3 and pred[5]<0.)
        if s['done']:return bool(s['accepted']),True,{'guard':False,'deadline':False,'cap':25}
        halt=bool(s['eligible'] and s['iteration']>=2 and pred[2]<=.3 and 4*(pred[0]-pred[1])<=max(pred[4],0.))
        return bool(publish or halt),halt,{'guard':False,'deadline':False,'cap':s['iteration'] if halt else 25}
    if policy['kind']!='multi':return old_act(r,s,policy,p=pred)
    it=s['iteration'];eligible=bool(s['eligible']);done=bool(s['done'])
    mismatch=r['noise']>2 or float(s['feature'][0])>.061 or r['mesh'] not in ['B767','C172']
    limit=4 if policy.get('profile') and mismatch else 25
    reachable=np.flatnonzero((CAPS>=it)&(CAPS<=limit))
    # Compute predicates for all ablations; apply their designated interventions.
    timing=[]
    for a in reachable:
        sender=paid_work+max(float(pred[3*a+2]),0.)
        tick=max(1,int(np.ceil((PROTOCOL['queue_s']+service['load']*(sender+clock['receiver_base_s']))/(.1-service['load']*clock['propagation_step_s']))))
        timing.append(tick*.1<=service['deadline_s']+1e-12)
    admitted=reachable[np.asarray(timing,bool)] if policy.get('deadline') else reachable
    empty=len(admitted)==0
    if empty:chosen=it
    else:
        values=np.array([4*max(float(pred[3*a]),0)+policy['price']*max(float(pred[3*a+2]),0)+PROTOCOL['omega_m2s']*np.clip(pred[3*a+1],0,1) for a in admitted])
        chosen=int(CAPS[admitted[int(np.argmin(values))]])
    halt=bool(done or (it>=2 and it>=chosen) or (policy.get('profile') and mismatch and it>=4)
        or (policy.get('deadline') and empty))
    pub=bool(s['accepted']) if done else bool(eligible and (pred[15]<pred[16] or halt))
    return pub,halt,{'guard':bool(policy.get('profile') and mismatch),
        'deadline':bool(policy.get('deadline') and len(admitted)<len(reachable)),
        'cap':chosen,'pred_current_mse':float(pred[15]),'pred_prior_mse':float(pred[16])}

def solver_work(s,clock):
    return (clock['solver_init_s']+clock['query_s']*s['query_calls']+
        clock['iteration_s']*s['iteration']+clock['checkpoint_s']*s['checkpoint_calls'])

def stage_reservation(current_iteration,next_iteration,model,clock):
    delta=max(0,next_iteration-current_iteration)
    return ((6*delta+1)*clock['query_s']+delta*clock['iteration_s']+clock['checkpoint_s']+
        clock['forecast_max_s'].get(model,0)+clock['decision_s']+clock['publication_s'])

def predict_count(model,x):
    x=np.asarray(x,np.float32);pred=np.zeros(model.value.shape[-1]);visits=0
    roots=model.roots if hasattr(model,'roots') else [0]
    for root in roots:
        node=int(root)
        while model.left[node]>=0:
            visits+=1;node=int(model.left[node] if x[model.feature[node]]<=model.threshold[node] else model.right[node])
        visits+=1;pred+=model.value[node]
    return pred/len(roots),visits

def prediction_work(model,visits,clock):
    return clock['forecast_node_s'].get(model,0)*visits
