"""Verify executable optical-only renewal against the full pixel producer."""
from pathlib import Path
import numpy as np,pandas as pd,json
from model import draw,targets,parameters
ROOT=Path(__file__).resolve().parent
def optical(scene,variant):
    focal,exposure,_,_,_=parameters(scene,variant);points=targets(scene)
    normals=np.c_[-scene['a']*points[:,0],-scene['b']*points[:,1],np.ones(len(points))]
    normals/=np.linalg.norm(normals,axis=1,keepdims=True)
    vectors=scene['camera']-points;distance=np.linalg.norm(vectors,axis=1)
    incidence=np.abs(np.sum(normals*vectors/distance[:,None],axis=1))
    gsd=distance/(focal*np.maximum(incidence,1e-8))
    return float(np.max(gsd)),float(np.max(scene['speed']*exposure/gsd))
frame=pd.read_csv(ROOT/'outputs/observations.csv').query('phase=="calibration"')
error=0.
for row in frame.itertuples():
    g,b=optical(draw(row.seed),row.variant)
    error=max(error,abs(g-row.gsd_m),abs(b-row.blur_px))
assert error<1e-10
print(json.dumps({'status':'PASS','optical_only_comparisons':len(frame),'max_error':error}))
