"""Exact vector schematics and uncropped retained photographs for the R8 paper."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import sys,json
from pathlib import Path
import numpy as np
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,Ellipse,FancyArrowPatch,Rectangle,Polygon
from matplotlib.collections import PolyCollection
from PIL import Image
from r8_protocol import ROOT,D,sha
from r8_geometry import geometry
sys.path.insert(0,str(ROOT/'source/figure_qa'))
from audit_panel_alignment import require_matplotlib_panel_alignment

F=ROOT/'figures/r8';F.mkdir(exist_ok=True)
C={'navy':'#19394D','blue':'#227E9E','teal':'#168677','gold':'#BB7D28','red':'#BA5B54','grey':'#73818B','pale':'#EAF1F4','ink':'#23333D'}
mpl.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans','Arial','Helvetica'],'font.size':8,'axes.titlesize':9,'axes.labelsize':8,'xtick.labelsize':7.5,'ytick.labelsize':7.5,
 'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.7,'legend.frameon':False})

def save(fig,name,**opts):
    fig.canvas.draw();require_matplotlib_panel_alignment(fig,json_out=F/(name+'.alignment.json'),overlay_svg=F/(name+'.alignment.svg'),strict=True,**opts)
    fig.savefig(F/(name+'.pdf'));fig.savefig(F/(name+'.svg'))
    fig.savefig(F/(name+'.png'),dpi=300);fig.savefig(F/(name+'.tiff'),dpi=600,pil_kwargs={'compression':'tiff_lzw'})
    plt.close(fig)

def panel(ax,letter,title):
    ax.set(xlim=(0,100),ylim=(0,100));ax.axis('off')
    ax.annotate(letter,(0,1),xycoords='axes fraction',xytext=(-12,8),textcoords='offset points',fontsize=10,fontweight='bold',va='bottom',color=C['ink'])
    ax.annotate(title,(0,1),xycoords='axes fraction',xytext=(2,8),textcoords='offset points',fontsize=9,fontweight='bold',va='bottom',color=C['ink'])

def txt(ax,x,y,t,color='ink',size=8,ha='center',weight='normal'):
    return ax.text(x,y,t,ha=ha,va='center',fontsize=size,color=C.get(color,color),fontweight=weight,linespacing=1.35,zorder=6)
def arrow(ax,a,b,color='grey',style='-|>',rad=0,lw=1.2):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle=style,mutation_scale=9,color=C[color],lw=lw,connectionstyle=f'arc3,rad={rad}',zorder=3))
def node(ax,x,y,label,r=6,color='blue',size=8):
    height_pt=ax.get_position().height*ax.figure.get_figheight()*72
    height=max(2*r,(size+5)/height_pt*100)
    ax.add_patch(Ellipse((x,y),2*r,height,fc=C[color],ec='none',zorder=4));txt(ax,x,y,label,'white',size,weight='bold')

def architecture():
    fig=plt.figure(figsize=(170/25.4,154/25.4));gs=fig.add_gridspec(3,1,height_ratios=[1.05,1.7,1.05],left=.055,right=.985,bottom=.035,top=.94,hspace=.34)
    a,b,c=[fig.add_subplot(gs[i]) for i in range(3)]
    panel(a,'a','Engineering requirements become executable knowledge')
    a.add_patch(Rectangle((0,10),24,76,fc=C['pale'],ec='none'))
    txt(a,12,71,'Task request',weight='bold');txt(a,12,47,'event · risk allowance\nD · sender budget',size=8)
    txt(a,12,19,'exogenous precommit',size=7.5,color='blue')
    for x,y,l,r,cl in [(39,66,'g',5,'blue'),(55,82,'π',5,'navy'),(55,47,'v',5,'teal'),(72,66,'U',5,'gold')]:node(a,x,y,l,r,cl)
    arrow(a,(25,52),(33,61));arrow(a,(44,68),(49,78));arrow(a,(59,80),(67,69));arrow(a,(60,49),(67,62));arrow(a,(43,62),(49,51))
    txt(a,39,39,'Profile',size=7.5);txt(a,55,99,'Policy',size=7.5);txt(a,55,23,'Dependencies',size=7.5);txt(a,72,40,'Event card',size=7.5)
    arrow(a,(78,65),(84,65),color='blue');node(a,93,65,'∩',6,'teal',12)
    txt(a,91,35,'Feasible catalogue',size=8,weight='bold');txt(a,90,15,'select or refuse',size=7.5,color='teal')
    panel(b,'b','A pose is produced by a monitored source-version transaction')
    r=json.loads((D/'pilot/episodes.jsonl').read_text().splitlines()[0]);z=np.load(D/'pilot'/f"{r['seed']}.npz");m=np.load(geometry(r['mesh']),allow_pickle=True)
    v=m['vertices'];faces=m['faces'];projection=np.array([[.85,-.55],[.72,.37],[0,.9]]);q=v@projection
    q[:,0]=(q[:,0]-q[:,0].min())/np.ptp(q[:,0])*28;q[:,1]=(q[:,1]-q[:,1].min())/np.ptp(q[:,1])*50+40
    depth=v[:,0]*.1+v[:,1]*.5+v[:,2];order=np.argsort(depth[faces].mean(1));shade=depth[faces].mean(1)[order]
    rgba=mpl.colormaps['Greys'](.15+.3*(shade-shade.min())/max(np.ptp(shade),1e-9));rgba[:,3]=1
    b.add_collection(PolyCollection(q[faces[order]],facecolors=rgba,edgecolors='none',zorder=1))
    cloud=z['cloud'];prior_t=z['states_t'][0];prior_R=z['states_R'][0];pc=((cloud@prior_R.T+prior_t-z['map_t'])@z['map_R'])@projection
    pc[:,0]=(pc[:,0]-(v@projection)[:,0].min())/np.ptp((v@projection)[:,0])*28;pc[:,1]=(pc[:,1]-(v@projection)[:,1].min())/np.ptp((v@projection)[:,1])*50+40
    b.scatter(pc[:,0],pc[:,1],s=.8,color=C['gold'],alpha=.5,rasterized=False,zorder=2)
    txt(b,14,29,'Geometric prior + scan',size=7.5,weight='bold');txt(b,14,13,'18-D source prior sealed',size=7.5,color='blue')
    arrow(b,(27,61),(35,61),color='blue');node(b,43,61,'ICP',7,'blue',8)
    txt(b,43,36,'Retained solver',size=7.5,weight='bold');txt(b,43,20,'stop · continue · publish',size=7.5)
    for y,label in [(88,'1'),(65,'2'),(42,'4')]:
        node(b,61,y,label,4,'teal');arrow(b,(49,65),(56, y),color='teal',rad=.1 if y>65 else -.1)
    txt(b,61,18,'same source\ncorrelated versions',size=7.5,color='teal')
    arrow(b,(67,65),(75,65),color='blue');node(b,84,65,'x, P',8,'navy',8)
    txt(b,84,88,'Live estimate',size=8,weight='bold');txt(b,84,37,'replace + causal replay',size=7.5,weight='bold')
    for x in [78,84,90]:b.plot([x,x],[13,24],color=C['grey'],lw=1)
    arrow(b,(74,17),(94,17),color='grey');txt(b,85,4,'measured increments',size=7.5)
    panel(c,'c','Evidence is admitted, revoked or refused in the task context')
    for x,label,cl in [(10,'g, π, U','gold'),(40,'source / v','teal'),(70,'D / B','blue')]:
        c.add_patch(Rectangle((x-9,46),18,32,fc=C[cl],ec='none'));txt(c,x,62,label,'white',7.5,weight='bold')
    arrow(c,(20,62),(29,62));arrow(c,(50,62),(59,62));arrow(c,(80,62),(86,62),color='blue')
    txt(c,10,32,'card applicability',size=7.5);txt(c,40,32,'active version',size=7.5);txt(c,70,32,'clock + work',size=7.5)
    txt(c,93,74,'Admit',color='teal',size=8,weight='bold');txt(c,93,48,'Refuse',color='red',size=8,weight='bold')
    arrow(c,(92,29),(10,9),color='grey',rad=-.05,lw=1)
    txt(c,56,-4,'task feedback → replan or recalibrate',size=7.5,color='grey')
    save(fig,'architecture',panel_ids=['a','b','c']);z.close()
    (F/'architecture_provenance.json').write_text(json.dumps({'geometry':r['mesh'],'geometry_sha256':sha(geometry(r['mesh'])),
        'illustrative_pilot_seed':r['seed'],'cloud_sha256':r['input_sha256'],'meaning':'exact geometry/observations with code-drawn transaction schematic; no metric inferred'},indent=2))

def physical_plate():
    names=['platform_lab.jpeg','platform_side.jpeg','aircraft_field.jpeg','aircraft_field_portrait.jpeg']
    labels=['Laboratory platform','Platform side view','Aircraft field context','Aircraft field context (portrait)']
    fig,axes=plt.subplots(2,2,figsize=(170/25.4,135/25.4),gridspec_kw={'left':.04,'right':.98,'bottom':.03,'top':.95,'hspace':.24,'wspace':.12})
    for i,(ax,name,label) in enumerate(zip(axes.ravel(),names,labels)):
        path=ROOT/'figures/r7/hardware_originals'/name;im=Image.open(path);arr=np.asarray(im)
        # Canvas preserves each full original photograph and its aspect ratio.
        ax.imshow(arr);ax.set_aspect('equal',adjustable='datalim');ax.axis('off')
        ax.annotate(chr(97+i)+'  '+label,(0,1),xycoords='axes fraction',xytext=(0,6),textcoords='offset points',fontsize=8,fontweight='bold',va='bottom')
    save(fig,'physical_platforms',panel_ids=['a','b','c','d'])
    (F/'physical_platforms_provenance.json').write_text(json.dumps({'files':{n:sha(ROOT/'figures/r7/hardware_originals'/n) for n in names},
        'crop':'none','adjustment':'none','meaning':'provided real platform/context photos; no localization experiment is inferred'},indent=2))

if __name__=='__main__':architecture();physical_plate()
