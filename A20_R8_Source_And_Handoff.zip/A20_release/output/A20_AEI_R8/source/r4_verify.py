"""Recompute release claims from immutable outcome records; no re-simulation."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import json,time,copy
import numpy as np,pandas as pd
from scipy.stats import beta
from r4_protocol import ROOT,D,PROTOCOL,sha
from r4_contracts import check

def main():
    freeze=json.loads((D/'freeze.json').read_text())
    episodes=[json.loads(x) for x in (D/'episodes.jsonl').read_text().splitlines()]
    assert len(episodes)==2680 and len({e['seed'] for e in episodes})==2680
    train=set(freeze['development_train_seeds']);val=set(freeze['development_validation_seeds'])
    assert len(train)==926 and len(val)==194 and not train&val
    assert not (train|val)&{e['seed'] for e in episodes}
    for phase,(start,n) in PROTOCOL['seed_ranges'].items():
        assert {e['seed'] for e in episodes if e['phase']==phase}==set(range(start,start+n))
    for e in episodes:
        assert sha(D/f"episode_inputs/{e['seed']}.npz")==e['input_sha256']
    for model in ['cart','rf']:
        assert sha(D/f'{model}_forecast.npz')==freeze['forecasts'][model]['sha256']
    assert sha(ROOT/'source/r4_policy.py')==freeze['policy_sha256']
    assert sha(ROOT/'source/checkpoint.py')==freeze['solver_sha256']
    assert sha(D/'protocol.json')==freeze['protocol_sha256']
    collect=json.loads((D/'collection_manifest.json').read_text())
    assert collect['data_sha256']==sha(D/'episodes.jsonl')
    assert collect['forecast_freeze_sha256']==sha(D/'freeze.json')
    assert collect['native_equivalence_checks']==24
    assert collect['native_max_state_delta']==0 and collect['native_max_covariance_delta']==0
    df=pd.read_csv(D/'policy_results.csv')
    assert len(df)==217080 and not df.duplicated(['seed','policy','load']).any()
    components=['front_cpu_s','solver_cpu_s','decision_cpu_s','prop_cpu_s','replay_cpu_s']
    assert np.allclose(df[components].sum(axis=1),df.cpu_s,rtol=0,atol=2e-14)
    cf=pd.read_csv(D/'calibration.csv');assert len(cf)==120
    max_cp=0.
    bench=set(range(5100000,5100024))
    for r in cf.itertuples():
        x=df[(df.phase==r.phase)&(df.policy==r.policy)&(df.load==r.load)&~df.seed.isin(bench)]
        assert len(x)==r.n and int(x.failure.sum())==r.k
        assert int(len(x)-x.capture_success.sum())==r.task_k
        for k,u in [(r.k,r.upper_risk),(r.task_k,r.task_upper_risk)]:
            calc=1. if k==r.n else beta.ppf(1-.05/240,k+1,r.n-k)
            max_cp=max(max_cp,abs(calc-u));assert abs(calc-u)<2e-14
    cards=json.loads((D/'event_cards.json').read_text())
    assert len(cards)==240 and sum(c['certified'] for c in cards)==125
    audit=pd.read_csv(D/'contract_audit.csv');assert len(audit)==9000
    assert (audit.authorized==audit.expected).all()
    route=pd.read_csv(D/'route_results.csv');assert len(route)==81
    assert len(route[['mesh','rep']].drop_duplicates())==9
    max_route=0.
    for r in route.itertuples():
        folder=D/f'routes/{r.mesh}_{r.rep}';z=np.load(folder/f'{r.policy}.npz')
        logs=json.loads((folder/f'{r.policy}.json').read_text())
        e=z['trace'][:,1];caps=z['captures']
        assert e.shape==(6000,) and caps.shape==(299,4)
        recal={'rmse_cm':100*np.sqrt(np.mean(e**2)), 'loss_m2s':.1*np.sum(e**2),
               'p95_cm':100*np.quantile(e,.95),'max_cm':100*np.max(e),
               'capture_ready':int(caps[:,1].sum()),'capture_success':int(caps[:,2].sum())}
        for key,value in recal.items():
            delta=abs(value-getattr(r,key));max_route=max(max_route,delta)
            assert delta<2e-10,(r.mesh,r.rep,r.policy,key,delta)
        assert abs(r.cpu_s-r.prop_cpu_s-r.correction_cpu_s-r.replay_cpu_s)<2e-12
        for source,ready,success,err in caps:
            events=[v for s,t,v in logs['publications'] if s==source and t<=source+3]
            active=events[-1] if events else 0
            assert bool(ready)==(active>0)
            assert bool(success)==bool(ready and err<=.1)
        assert len(logs['jobs'])==r.calls==299 and r.dropped==0
    stress=pd.read_csv(D/'service_stress_results.csv')
    assert len(stress)==35280 and set(stress.seed)==set(df[df.phase.str.endswith('confirmation')].seed)
    assert set(stress.load)=={40.,60.}
    sample=next(c for c in cards if c['certified'] and c['kind']=='capture')
    source={'source_id':'benchmark/1','source_prior_seal':'sealed-prior'}
    req={k:sample[k] for k in ['kind','policy_id','policy_hash','forecast_hash','event_hash','profile_id','load','queue_s','frontend_hash','installation_model','service_hash']}
    req.update(source,mesh_hash=next(iter(sample['mesh_hashes'].values())),declared_profile_assumption=True,assessment_s=.3,elapsed_s=.3,risk_allowance=.15)
    assert check(sample,req,source)['authorized']
    times=[]
    for _ in range(2400):
        start=time.process_time_ns();answer=check(sample,req,source);times.append((time.process_time_ns()-start)*1e-3)
        assert answer['authorized']
    cost={'calls':len(times),'median_us':float(np.median(times)),'p95_us':float(np.quantile(times,.95)),
          'scope':'separate matching-metadata request; excluded from numerical CPU; does not measure transport or hashing a fresh scan'}
    (D/'interface_cost.json').write_text(json.dumps(cost,indent=2))
    report={'status':'PASS','fresh_episodes':2680,'independent_confirmation_episodes':1960,
            'native_equivalence_checks':24,'primary_policy_records':len(df),'risk_bounds':240,
            'max_risk_recomputation_delta':max_cp,'semantic_requests':len(audit),'certified_cards':125,
            'complete_route_executions':81,'independent_route_inputs':9,'max_route_recomputation_delta':max_route,
            'additional_workload_rows':len(stress),'new_workload_geometric_inputs':0,'verifier_sha256':sha(__file__)}
    (D/'release_verification.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report),flush=True)
if __name__=='__main__':main()
