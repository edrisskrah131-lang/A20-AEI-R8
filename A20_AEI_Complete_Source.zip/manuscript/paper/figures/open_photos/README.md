# Aircraft-surface photographs

These two downloaded originals are used as engineering context in main-article Figure 1. They are not observations or calibration inputs in the CAD-surface benchmark. The figure script scales them without retouching or altering image content.

- `vulcan_surface_detail.jpg`: Simon Butler, Avro Vulcan XM655 under-fuselage detail, 17 September 2023. [Original](https://www.flickr.com/photos/antonov22/53196103492/). [CC BY 2.0](https://creativecommons.org/licenses/by/2.0/). Copyright remains with the photographer.
- `aircraft_patch_riveting.jpg`: TSGT Rob Marshall, aircraft sheet-metal patch, NIGHT TRAIN/GLOBAL SHIELD '84, 2 April 1984. U.S. Department of Defense; public domain. [National Archives record 6390063](https://catalog.archives.gov/id/6390063).

`sources.json` preserves the exact Commons source pages, original download URLs, author and license metadata, acquisition timestamps, original dimensions and SHA-256 checksums. Attribution appears in Figure 1 and in the supplement's final section. The licenses apply to these photographs independently of the manuscript and software.
