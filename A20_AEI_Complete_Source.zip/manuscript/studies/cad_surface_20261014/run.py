"""Execute independent CAD-surface scenes and calibrated update comparisons."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import argparse,json,hashlib,time
from concurrent.futures import ProcessPoolExecutor
import numpy as np,pandas as pd
from scipy.stats import beta
from model import draw,execute,VARIANTS,DEPENDENCIES,CHANGED

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'outputs';OUT.mkdir(exist_ok=True)
SPEC=json.loads((ROOT/'protocol.json').read_text())
REQUESTS=SPEC['requests'];ANCHORS=SPEC['anchors'];VERIFY=False
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def event(values,spec):
    okay=np.ones(len(values),dtype=bool)
    for metric,(lo,hi) in spec.items():
        x=np.asarray(values[metric]);okay&=np.isfinite(x)
        if lo is not None:okay&=x>=lo
        if hi is not None:okay&=x<=hi
    return ~okay

def contains(anchor,request):
    for metric,(lo,hi) in request.items():
        if metric not in anchor:return False
        al,ah=anchor[metric]
        if lo is not None and (al is None or al<lo):return False
        if hi is not None and (ah is None or ah>hi):return False
    return True

def invariant(request,variant):
    providers={p for m in request for p in DEPENDENCIES[m]}
    return not (providers & set(CHANGED[variant]))

def worker(job):
    phase,seed,illustrate=job;scene=draw(seed);rows=[]
    for variant in VARIANTS:
        begin=time.process_time_ns();values,image=execute(scene,variant)
        cpu=(time.process_time_ns()-begin)*1e-9
        rows.append({'phase':phase,'seed':seed,'family':scene['family'],'variant':variant,**values,'cpu_s':cpu})
        if illustrate and variant in ['baseline','exposure','wide_roi']:
            path=OUT/f'example_{seed}_{variant}.npz'
            payload={k:image[k] for k in ['rgb','decoded','predicted','true_pixels','matched_indices','matched_centers','targets']}
            if VERIFY:
                old=np.load(path)
                for k,v in payload.items():assert np.allclose(v,old[k],rtol=1e-12,atol=1e-10),str(path)+k
            else:np.savez_compressed(path,**payload)
    config={'phase':phase,'seed':seed,'family':scene['family'],'a':scene['a'],'b':scene['b'],
            **{k:float(scene[k]) for k in ['focal','exposure','speed','brightness','noise','texture_phase']}}
    for k in ['camera','translation_error','rotation_error','light']:
        config.update({f'{k}_{i}':float(x) for i,x in enumerate(scene[k])})
    return rows,config

def emit(frame,name):
    if not isinstance(frame,pd.DataFrame):frame=pd.DataFrame(frame)
    if VERIFY:
        old=pd.read_csv(OUT/name);ignore=['cpu_s'] if 'cpu_s' in frame else []
        pd.testing.assert_frame_equal(frame.drop(columns=ignore).reset_index(drop=True),old.drop(columns=ignore).reset_index(drop=True),check_dtype=False,check_exact=False,rtol=1e-12,atol=1e-10)
    else:frame.to_csv(OUT/name,index=False)

def analyse(frame):
    cards=[];summary=[]
    for variant in VARIANTS:
        calibration=frame[(frame.phase=='calibration')&(frame.variant==variant)].sort_values('seed')
        test=frame[(frame.phase=='test')&(frame.variant==variant)].sort_values('seed')
        for request,spec in REQUESTS.items():
            k=int(event(calibration,spec).sum());n=len(calibration)
            upper=1. if k==n else float(beta.isf(SPEC['confidence_error']/SPEC['family_K'],k+1,n-k))
            cards.append({'variant':variant,'request':request,'k':k,'n':n,'upper':upper,'test_failures':int(event(test,spec).sum()),'test_n':len(test),'authorized':upper<=SPEC['allowance']})
        summary.append({'variant':variant,'test_inputs':len(test),'median_gsd_mm':float(test.gsd_m.median()*1000),
                        'median_blur_px':float(test.blur_px.median()),'mean_coverage':float(test.coverage.mean()),
                        'median_reprojection_px':float(test.reprojection_px.median()),
                        'p95_reprojection_px':float(test.reprojection_px.quantile(.95)),
                        'median_association_mm':float(test.association_m.median()*1000),
                        'p95_association_mm':float(test.association_m.quantile(.95)*1000)})
    c=pd.DataFrame(cards).set_index(['variant','request']);plans=[]
    for variant in VARIANTS:
        for request,spec in REQUESTS.items():
            exact=c.loc[(variant,request)];old=c.loc[('baseline',request)]
            candidates=[]
            for anchor in ANCHORS:
                if not contains(REQUESTS[anchor],spec):continue
                for producer in dict.fromkeys([variant,'baseline']):
                    if producer=='baseline' and not invariant(spec,variant):continue
                    card=c.loc[(producer,anchor)]
                    if bool(card.authorized):candidates.append((float(card.upper),producer,anchor))
            if candidates:
                upper,producer,proof=min(candidates);route='reuse'
            else:
                producer,proof=variant,request;upper=float(exact.upper);route='renew' if bool(exact.authorized) else 'refuse'
            dependency_producer='baseline' if invariant(spec,variant) else variant
            dependency=c.loc[(dependency_producer,request)]
            for method,chosen,bound,status,path in [
                ('Whole-producer renewal',(variant,request),float(exact.upper),bool(exact.authorized),'renew'),
                ('Dependency-aware exact',(dependency_producer,request),float(dependency.upper),bool(dependency.authorized),'retain' if dependency_producer=='baseline' and variant!='baseline' else 'renew'),
                ('Contract plus fallback',(producer,proof),upper,upper<=SPEC['allowance'],route),
                ('Stale baseline cache',('baseline',request),float(old.upper),bool(old.authorized),'retain')]:
                plans.append({'variant':variant,'request':request,'method':method,'authorized':status,
                              'proof_producer':chosen[0],'proof_event':chosen[1],'upper':bound,'route':path,
                              'unsupported_issuance':status and not bool(exact.authorized)})
            # Every signature-based transfer is checked against computed quantities.
            if invariant(spec,variant):
                base=frame[(frame.phase=='calibration')&(frame.variant=='baseline')].sort_values('seed')
                current=frame[(frame.phase=='calibration')&(frame.variant==variant)].sort_values('seed')
                for metric in spec:assert np.allclose(base[metric],current[metric],atol=1e-10,rtol=1e-12)
    p=pd.DataFrame(plans);cost=[]
    for method,g in p.groupby('method',sort=False):
        admitted=g[g.authorized]
        proof=admitted[['proof_producer','proof_event']].drop_duplicates()
        cost.append({'method':method,'supported_contexts':len(admitted),'contexts':len(g),
                     'unique_selected_proofs':len(proof),'selected_record_evaluations':len(proof)*SPEC['calibration_inputs'],
                     'unsupported_issuances':int(g.unsupported_issuance.sum())})
    match=p.pivot(index=['variant','request'],columns='method',values='authorized')
    assert match['Contract plus fallback'].eq(match['Whole-producer renewal']).all()
    assert match['Dependency-aware exact'].eq(match['Whole-producer renewal']).all()
    refresh=[]
    for variant in VARIANTS[1:]:
        for request,spec in REQUESTS.items():
            unchanged=invariant(spec,variant)
            optical=set(spec)<=set(['gsd_m','blur_px'])
            refresh.append({'variant':variant,'request':request,'whole_producer_runs':SPEC['calibration_inputs'],
                            'dependency_pipeline_runs':0 if unchanged or optical else SPEC['calibration_inputs'],
                            'dependency_optical_runs':SPEC['calibration_inputs'] if optical and not unchanged else 0,
                            'dependency_reuses':SPEC['calibration_inputs'] if unchanged else 0})
    emit(cards,'risk_cards.csv');emit(summary,'test_summary.csv');emit(plans,'plans.csv');emit(cost,'proof_cost.csv');emit(refresh,'refresh_ledger.csv')
    return {'cards':len(cards),'contexts':48,'cost':cost,'cold_single_request_refresh':{
        'cases':len(refresh),'whole_pipeline_runs':sum(x['whole_producer_runs'] for x in refresh),
        'dependency_pipeline_runs':sum(x['dependency_pipeline_runs'] for x in refresh),
        'dependency_optical_runs':sum(x['dependency_optical_runs'] for x in refresh),
        'retained_inputs':sum(x['dependency_reuses'] for x in refresh)}}

def main():
    global VERIFY
    parser=argparse.ArgumentParser();parser.add_argument('--verify',action='store_true');parser.add_argument('--workers',type=int,default=2);args=parser.parse_args();VERIFY=args.verify
    for name,value in json.loads((ROOT/'freeze.json').read_text())['files'].items():assert sha(ROOT/name)==value,name
    gallery=[];families=set()
    for i in range(SPEC['test_inputs']):
        seed=SPEC['test_seed_start']+i;family=draw(seed)['family']
        if family not in families:gallery.append(seed);families.add(family)
        if len(families)==3:break
    jobs=[(phase,start+i,start+i in gallery) for phase,start,n in [('calibration',SPEC['calibration_seed_start'],SPEC['calibration_inputs']),('test',SPEC['test_seed_start'],SPEC['test_inputs'])] for i in range(n)]
    rows=[];configs=[]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for i,(r,c) in enumerate(pool.map(worker,jobs,chunksize=1)):
            rows.extend(r);configs.append(c)
            if (i+1)%48==0:print('CAD_SURFACE_SCENES',i+1,len(jobs),flush=True)
    emit(rows,'observations.csv');emit(configs,'configurations.csv')
    result={'status':'PASS','independent_scenes':len(jobs),'producer_executions':len(rows),
            'calibration_inputs':SPEC['calibration_inputs'],'test_inputs':SPEC['test_inputs'],
            'gallery_seeds':gallery,**analyse(pd.DataFrame(rows))}
    if VERIFY:assert result==json.loads((OUT/'results.json').read_text())
    else:(OUT/'results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
