"""Build a complete source/data delivery below GitHub's file-size limit.

Run after study execution and document generation finish. --output-dir permits
a complete dry run without modifying the published delivery or source tree.
"""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
import shutil
import tempfile
import zipfile
from restore_data import sha256_file, validate_relative
from verify_package import verify_delivery

DEFAULT_ROOT = Path(__file__).resolve().parents[1]
SOURCE_NAME = "A20_AEI_Complete_Source.zip"
DATA_PREFIX = "A20_AEI_Data_"
GENERATED = {"MANIFEST.json", "DELIVERY_INDEX.json", "DELIVERY.md"}
EXCLUDED = {".aux", ".out", ".bbl", ".blg", ".pyc", ".toc", ".lof", ".lot"}
COMPILED_PDFS = {"A20_AEI_Manuscript.pdf", "Supplement.pdf", "paper/main.pdf", "paper/supplement.pdf"}
# Original pixels/meshes/arrays stay complete in data volumes. Scripts,
# protocols, JSON/CSV results and publication PDFs remain in Source.
BULK_SUFFIXES = {".png", ".jpg", ".jpeg", ".npz", ".npy", ".exr", ".blend",
    ".ply", ".stl", ".obj", ".glb", ".gltf", ".tif", ".tiff", ".hdr",
    ".bmp", ".webp", ".pcd", ".las", ".laz", ".h5", ".hdf5"}

def payload(path: Path, root: Path) -> bool:
    relative = path.relative_to(root)
    if path.is_symlink():
        raise ValueError(f"Source symlinks are not packaged: {relative}")
    if not path.is_file() or "__pycache__" in relative.parts or path.suffix.lower() in EXCLUDED:
        return False
    if relative.as_posix() in GENERATED | COMPILED_PDFS:
        return False
    if path.suffix.lower() == ".log" and "studies" not in relative.parts:
        return False
    if relative.parent.as_posix() == "paper/figures/visual" and path.suffix.lower() in {".png", ".svg"}:
        return False
    return True

def json_bytes(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode("utf-8")

def zip_info(member: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(member, date_time=(1980, 1, 1, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.create_system = 3
    info.external_attr = 0o100644 << 16
    return info

def write_file(zipped: zipfile.ZipFile, path: Path, relative: str) -> None:
    with path.open("rb") as source, zipped.open(zip_info("manuscript/" + relative), "w", force_zip64=True) as output:
        shutil.copyfileobj(source, output, length=1024 * 1024)

def partition_data(paths: list[Path], root: Path, limit: int) -> list[list[Path]]:
    """Conservative raw-DEFLATE bound; final archive sizes are also checked."""
    groups, group, size = [], [], 128
    for path in paths:
        length = path.stat().st_size
        member_length = len(("manuscript/" + path.relative_to(root).as_posix()).encode("utf-8"))
        bound = length + math.ceil(max(length, 1) / 16383) * 5 + 2048 + 2 * member_length
        if bound + 128 >= limit:
            raise ValueError(f"One data file exceeds the volume limit; split the research output explicitly: {path}")
        if group and size + bound >= limit:
            groups.append(group)
            group, size = [], 128
        group.append(path)
        size += bound
    if group:
        groups.append(group)
    return groups

def build_delivery(root: Path, output_dir: Path, limit_mib: float = 90) -> dict:
    root, output_dir = root.resolve(), output_dir.resolve()
    if output_dir == root or root in output_dir.parents:
        raise ValueError("--output-dir must be outside the manuscript source tree")
    if not 0 < limit_mib < 100:
        raise ValueError("--limit-mib must be greater than zero and less than 100")
    limit = int(limit_mib * 1024**2)
    files = [p for p in sorted(root.rglob("*")) if payload(p, root)]
    if not files:
        raise ValueError("No manuscript payload files found")
    records = {}
    for path in files:
        name = path.relative_to(root).as_posix()
        validate_relative(name)
        records[name] = {"sha256": sha256_file(path), "size": path.stat().st_size, "archive": SOURCE_NAME}
    bulk = [p for p in files if p.suffix.lower() in BULK_SUFFIXES]
    groups = partition_data(bulk, root, limit)
    output_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".a20-package-", dir=output_dir) as scratch_name:
        scratch, archives = Path(scratch_name), {}
        for number, group in enumerate(groups, 1):
            name = f"{DATA_PREFIX}{number:03d}.zip"
            archive = scratch / name
            with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=True) as zipped:
                for path in group:
                    relative = path.relative_to(root).as_posix()
                    write_file(zipped, path, relative)
                    records[relative]["archive"] = name
            if archive.stat().st_size >= limit:
                raise ValueError(f"Data archive exceeds size limit: {name}")
            archives[name] = {"sha256": sha256_file(archive), "size": archive.stat().st_size}
        manifest = {name: record["sha256"] for name, record in records.items()}
        index = {"schema": "a20-delivery-v1", "source_archive": SOURCE_NAME,
                 "archive_limit_bytes": limit, "data_archives": archives, "files": records}
        instructions = """# Complete source and original research data

Download `A20_AEI_Complete_Source.zip` and every `A20_AEI_Data_*.zip`
listed in `DELIVERY_INDEX.json` into the same directory. Extract the Source ZIP;
keep the data ZIP files unchanged. From the extracted `manuscript` directory:

```sh
python reporting/restore_data.py --archive-dir ..
python reporting/verify_package.py --source ../A20_AEI_Complete_Source.zip --data-dir .. --restored-root .
```

If the ZIP files are elsewhere, replace `..` with their directory. Restoration
verifies each archive and every payload hash, refuses unsafe paths and links,
and skips already correct files. It refuses to overwrite changed files unless
`--overwrite` is explicitly supplied. Run restoration before numerical study
reproduction or figure regeneration. Publication figure PDFs are in Source.

`MANIFEST.json` contains SHA256 hashes for every delivered research/source
payload, across Source and all data volumes. `DELIVERY_INDEX.json` maps each
payload to exactly one archive and records data archive hashes and sizes.
These generated inventory files do not hash themselves. All original files
remain unchanged in the research working tree. The archive set is complete only
when every data volume listed in the index is present; no network is used by
restoration or verification. Compiled article PDFs are supplied separately.
LaTeX intermediates, bytecode and reproducible presentation previews are
excluded under the documented packaging policy.
"""
        generated = {"MANIFEST.json": json_bytes(manifest), "DELIVERY_INDEX.json": json_bytes(index),
                     "DELIVERY.md": instructions.encode("utf-8")}
        source = scratch / SOURCE_NAME
        with zipfile.ZipFile(source, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=True) as zipped:
            for path in files:
                relative = path.relative_to(root).as_posix()
                if records[relative]["archive"] == SOURCE_NAME:
                    write_file(zipped, path, relative)
            for name, content in generated.items():
                zipped.writestr(zip_info("manuscript/" + name), content)
        if source.stat().st_size >= limit:
            raise ValueError(f"Source ZIP is {source.stat().st_size / 1024**2:.2f} MiB, above {limit_mib:g} MiB; move additional original binary data into BULK_SUFFIXES without removing code/results")
        # Reject concurrent source changes instead of publishing a mixed snapshot.
        verification = verify_delivery(source, scratch, restored_root=root, allow_unlisted=True)
        final_names = {p.relative_to(root).as_posix() for p in root.rglob("*") if payload(p, root)}
        if final_names != set(records):
            raise ValueError("Source payload set changed during packaging; wait for study execution to finish")
        names = [SOURCE_NAME] + list(archives)
        summary = {"status": "PASS", "files": len(records), "source_files": len(records) - len(bulk),
                   "data_files": len(bulk), "verification": verification,
                   "archives": {name: {"bytes": (scratch / name).stat().st_size,
                                        "sha256": sha256_file(scratch / name)} for name in names}}
        for name in names:
            (scratch / name).replace(output_dir / name)
        # A dry run must not mutate source inventories either.
        if output_dir == root.parent:
            for name, content in generated.items():
                (root / name).write_bytes(content)
        summary["obsolete_data_archives"] = sorted(p.name for p in output_dir.glob(DATA_PREFIX + "*.zip") if p.name not in archives)
        return summary

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--limit-mib", type=float, default=90)
    args = parser.parse_args()
    print(json.dumps(build_delivery(args.root, args.output_dir or args.root.parent, args.limit_mib), indent=2))

if __name__ == "__main__":
    main()
