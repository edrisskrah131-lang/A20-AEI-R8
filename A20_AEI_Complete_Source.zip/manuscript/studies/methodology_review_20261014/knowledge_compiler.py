"""Typed request grammar and metamodel for the reference evidence interface."""
from dataclasses import dataclass
from types import MappingProxyType
import math
from event_semantics import Atom,Event,METRICS

RELATIONS=MappingProxyType({
 'requires':('Request','Event'),'commits':('Plan','Request'),
 'selects':('Plan','Policy'),'bounds':('Card','Event'),
 'supports':('Card','Plan'),'derivedFrom':('Card','Producer'),
 'produces':('Producer','Quantity'),'dependsOn':('Quantity','Provider'),
 'uses':('Receipt','SourceVersion'),'records':('Receipt','Plan'),
 'revises':('SourceVersion','SourceVersion')})

@dataclass(frozen=True)
class CompiledRequest:
    population:str
    service:str
    allowance:float
    event:Event
    dependencies:tuple

def compile_request(spec,dependency_spec):
    """R ::= (population, service, allowance, all(interval ...)).

    interval ::= {metric, unit, lower?, upper?}. Bounds convert to the
    registered base dimension, repeated intervals intersect, contradictory
    intervals fail, and canonical field order determines event identity.
    """
    if not spec.get('population') or not spec.get('service'):raise ValueError('Missing population/service')
    delta=spec.get('allowance')
    if isinstance(delta,bool) or not isinstance(delta,(int,float)) or not math.isfinite(delta) or not 0<delta<1:raise ValueError('Invalid risk allowance')
    atoms=spec.get('all')
    if not isinstance(atoms,list) or not atoms:raise ValueError('Empty predicate conjunction')
    merged={}
    for expr in atoms:
        atom=Atom.quantity(expr['metric'],expr['unit'],expr.get('lower'),expr.get('upper'))
        lo=-math.inf if atom.lower is None else atom.lower
        hi=math.inf if atom.upper is None else atom.upper
        old=merged.get(atom.metric,(-math.inf,math.inf));merged[atom.metric]=(max(lo,old[0]),min(hi,old[1]))
    event=Event(tuple(Atom(m,None if not math.isfinite(lo) else lo,None if not math.isfinite(hi) else hi) for m,(lo,hi) in merged.items()))
    providers=tuple(sorted({p for atom in event.atoms for p in dependency_spec[atom.metric]}))
    return CompiledRequest(spec['population'],spec['service'],float(delta),event,providers)

def validate_model(nodes,edges):
    for relation,left,right in edges:
        expected=RELATIONS[relation]
        actual=(nodes[left]['type'],nodes[right]['type'])
        if actual!=expected:raise ValueError('Relation domain/range mismatch')
        if relation=='revises':
            new,old=nodes[left],nodes[right]
            if new['source_key']!=old['source_key'] or new['sequence']<=old['sequence']:raise ValueError('Invalid source revision order')
    return True

def verify_compiler(requirements):
    units={'length':'m','pixel':'px','time':'s','ratio':'ratio'}
    checked=0
    for task in requirements.TASKS:
        for variant in requirements.VARIANTS:
            expected=requirements.requirement(task,variant)
            d={'population':'nominal','service':'relaxed','allowance':.15,
               'all':[{'metric':a.metric,'unit':units[METRICS[a.metric]],'lower':a.lower,'upper':a.upper} for a in expected.atoms]}
            actual=compile_request(d,requirements.DEPENDENCIES)
            assert actual.event.identity==expected.identity
            assert set(actual.dependencies)=={p for a in expected.atoms for p in requirements.DEPENDENCIES[a.metric]}
            checked+=1
    mm=compile_request({'population':'nominal','service':'relaxed','allowance':.15,'all':[{'metric':'association_m','unit':'mm','upper':100}]},requirements.DEPENDENCIES)
    assert mm.event.atoms[0].upper==.1
    rejected=0
    for expr in [
       [{'metric':'association_m','unit':'px','upper':10}],
       [{'metric':'coverage','unit':'ratio','lower':True}],
       [{'metric':'association_m','unit':'m','lower':.2,'upper':.1}],
       [{'metric':'not_a_metric','unit':'m','upper':.1}]]:
        try:compile_request({'population':'nominal','service':'relaxed','allowance':.15,'all':expr},requirements.DEPENDENCIES)
        except (ValueError,KeyError):rejected+=1
    assert rejected==4
    n={x:{'type':t} for x,t in [('R','Request'),('E','Event'),('P','Plan'),('pi','Policy'),('A','Card'),('prod','Producer'),('q','Quantity'),('f','Provider'),('r','Receipt')]}
    n['v1']={'type':'SourceVersion','source_key':'s','sequence':1};n['v2']={'type':'SourceVersion','source_key':'s','sequence':2}
    edges=[('requires','R','E'),('commits','P','R'),('selects','P','pi'),('bounds','A','E'),
       ('supports','A','P'),('derivedFrom','A','prod'),('produces','prod','q'),('dependsOn','q','f'),
       ('uses','r','v2'),('records','r','P'),('revises','v2','v1')]
    assert validate_model(n,edges)
    for bad in [[('supports','R','P')],[('revises','v1','v2')]]:
        try:validate_model(n,bad)
        except ValueError:continue
        raise AssertionError('Invalid metamodel relation accepted')
    return {'task_variant_roundtrips':checked,'invalid_quantity_specs_rejected':rejected,
       'unit_conversion_checks':1,'relation_signatures':len(RELATIONS),'metamodel_type_and_revision_checks':'PASS'}
