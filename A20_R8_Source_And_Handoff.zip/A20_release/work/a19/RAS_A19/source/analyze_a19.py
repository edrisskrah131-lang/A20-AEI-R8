"""Readout of the declared audit controls; no model fitting or test selection."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1]
LABEL={'always_skip':'Skip','always_strict':'Strict','always_tempered':'Tempered','always_converged':'Converged',
       'always_full':'Full','cascade_sc':'Cascade S--C','cascade_cf':'Cascade C--F','joint':'Reuse-DP',
       'joint_nocache':'Fixed-policy no-cache','full_4s':'Full / 4 s','coarse':'Coarse','fixed':'Fixed'}

def sources():
    d=pd.read_csv(R/'data/control_snapshots.csv')
    a=pd.read_csv(R/'data/confirmation_replay.csv').query('price==.3 and ratio==1 and method=="joint"').copy()
    a['nominal_feasible']=True
    d=pd.concat([d,a[d.columns]],ignore_index=True)
    s=d.groupby(['mesh','method'],as_index=False).agg(pose_loss=('pose_loss','mean'),cpu_ms=('cpu_ms','mean'),
        loss=('loss','mean'),nominal_feasible=('nominal_feasible','mean'),probes=('probes','mean'))
    s.to_csv(R/'data/control_snapshot_summary.csv',index=False)
    contrasts=[];rng=np.random.default_rng(190110)
    for mesh in ['B767','C172']:
        dm=d.query('mesh==@mesh')
        for metric in ['pose_loss','loss','cpu_ms']:
            w=dm.pivot(index='seed',columns='method',values=metric)
            ids=rng.integers(0,len(w),(4000,len(w)))
            for method in ['always_converged','cascade_sc','cascade_cf','joint_nocache']:
                v=(w.joint-w[method]).to_numpy();ci=np.quantile(v[ids].mean(1),[.025,.975])
                contrasts.append(dict(mesh=mesh,metric=metric,comparator=method,difference=float(v.mean()),low=ci[0],high=ci[1]))
    pd.DataFrame(contrasts).to_csv(R/'data/control_snapshot_contrasts.csv',index=False)
    rows=[]
    for mesh in ['B767','C172']:
        for method in ['always_skip','always_strict','always_tempered','always_converged','always_full','cascade_sc','joint','cascade_cf','joint_nocache']:
            r=s.query('mesh==@mesh and method==@method').iloc[0]
            rows.append(f'{mesh} & {LABEL[method]} & {r.pose_loss*1000:.3f} & {r.cpu_ms:.3f} & {r.loss*1000:.3f} & {100*r.nominal_feasible:.1f} \\\\')
        rows.append('\\midrule')
    (R/'tables/controls_sources.tex').write_text('\n'.join(rows[:-1])+'\n')
    metrics={}
    for mesh in ['B767','C172']:
        w=s.query('mesh==@mesh').set_index('method');j=w.loc['joint'];nc=w.loc['joint_nocache'];c=w.loc['always_converged']
        metrics[mesh]=dict(frozen_source_cpu_reduction_pct=100*(1-j.cpu_ms/nc.cpu_ms),
            saved_source_ms=nc.cpu_ms-j.cpu_ms,source_risk_increase_vs_converged_pct=100*(j.loss/c.loss-1),
            source_pose_increase_vs_converged_pct=100*(j.pose_loss/c.pose_loss-1),
            joint_pose=j.pose_loss,converged_pose=c.pose_loss,joint_risk=j.loss,converged_risk=c.loss,
            joint_cpu_ms=j.cpu_ms,converged_cpu_ms=c.cpu_ms)
    (R/'data/control_headlines.json').write_text(json.dumps(metrics,indent=2));print('SOURCE',json.dumps(metrics,indent=2))

def missions():
    fresh=pd.read_csv(R/'data/control_missions.csv');assert len(fresh)==30
    base=pd.read_csv(R/'data/mission_results.csv').query('ratio==1').copy()
    rows=[]
    for mesh in ['B767','C172']:
        for rep in range(3):
            b=base.query('mesh==@mesh and replicate==@rep').set_index('method')
            for method,alias in [('always_full','full'),('joint','joint'),('fixed','fixed'),('coarse','coarse')]:
                x=b.loc[alias].to_dict();x.update(mesh=mesh,replicate=rep,method=method,source='A18 original run',infeasible_reservations=0);rows.append(x)
            alias_method='always_converged' if mesh=='B767' else 'always_strict'
            x=b.loc['coarse'].to_dict();x.update(mesh=mesh,replicate=rep,method=alias_method,source='Equivalent archived dispatch',infeasible_reservations=0);rows.append(x)
            if mesh=='C172':
                x=b.loc['joint'].to_dict();x.update(mesh=mesh,replicate=rep,method='cascade_sc',source='Equivalent archived dispatch',infeasible_reservations=0);rows.append(x)
    d=pd.concat([pd.DataFrame(rows),fresh.assign(source='A19 new run')],ignore_index=True)
    d.to_csv(R/'data/complete_control_missions.csv',index=False)
    table=[]
    for mesh in ['B767','C172']:
        order=['always_strict','always_tempered','always_converged','always_full','full_4s','joint','cascade_cf','joint_nocache']
        for method in order:
            z=d.query('mesh==@mesh and method==@method');r=z.mean(numeric_only=True)
            table.append(f'{mesh} & {LABEL[method]} & {r.rmse_m*100:.3f} & {z.rmse_m.min()*100:.3f}--{z.rmse_m.max()*100:.3f} & {r.cpu_s:.3f} & {int(z.infeasible_reservations.sum())} \\\\')
        table.append('\\midrule')
    (R/'tables/controls_missions.tex').write_text('\n'.join(table[:-1])+'\n')
    summary=d.groupby(['mesh','method'],as_index=False).agg(rmse_m=('rmse_m','mean'),cpu_s=('cpu_s','mean'),
        p95_m=('p95_m','mean'),overruns=('overruns','sum'),infeasible_reservations=('infeasible_reservations','sum'))
    summary.to_csv(R/'data/control_mission_summary.csv',index=False)
    metrics=json.loads((R/'data/control_headlines.json').read_text())
    for mesh in ['B767','C172']:
        z=summary.query('mesh==@mesh').set_index('method');j=z.loc['joint'];nc=z.loc['joint_nocache'];f4=z.loc['full_4s'];conv=z.loc['always_converged']
        matches=fresh.query('mesh==@mesh and method=="joint_nocache"')
        metrics[mesh].update(nocache_cpu_s=float(nc.cpu_s),joint_cpu_s=float(j.cpu_s),
            mission_reuse_cpu_reduction_pct=float(100*(1-j.cpu_s/nc.cpu_s)),
            nocache_paths_match=bool(matches.same_decision_paths.all()),
            max_nocache_trace_difference=float(matches.max_trace_error_difference.max()),
            full4_rmse_cm=float(f4.rmse_m*100),full4_cpu_s=float(f4.cpu_s),
            joint_rmse_cm=float(j.rmse_m*100),converged_rmse_cm=float(conv.rmse_m*100),converged_cpu_s=float(conv.cpu_s))
    (R/'data/control_headlines.json').write_text(json.dumps(metrics,indent=2));print('MISSIONS',json.dumps(metrics,indent=2))

if __name__=='__main__':
    sources()
    p=R/'data/control_missions.csv'
    if p.exists() and len(pd.read_csv(p))==30:missions()
