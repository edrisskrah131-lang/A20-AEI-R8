"""Closed-loop, physical-coordinate paired transitions.

No truth is available to predict(). A covariance descriptor conditions the
neighbourhood; unlike A9, it does not rescale empirical errors by a new prior.
"""
import numpy as np
import json
from pathlib import Path
from scipy.spatial import cKDTree
from .core import ACTIONS, psd

def encode(x,P):
    return np.r_[x,np.log(np.maximum(np.diag(P),1e-12))]

class ClosedLoopRisk:
    def __init__(self,path,k=48,use_cov=True,exclude=None):
        z=np.load(path);mask=np.ones(len(z['x']),bool) if exclude is None else z['group']!=exclude
        self.x=z['x'][mask];self.P=z['P'][mask];self.action=z['action'][mask];self.outcome=z['outcome'][mask];self.paired=z['paired'][mask];self.cost=z['cost'][mask];self.k=k;self.use_cov=use_cov
        af=Path(path).with_name('shrinkage.json');self.alpha=json.loads(af.read_text()) if af.exists() and exclude is None else {}
        feat=np.array([encode(x,p) if use_cov else x for x,p in zip(self.x,self.P)])
        self.mu=feat.mean(0);self.sd=np.maximum(feat.std(0),.1)
        self.indices={a:np.flatnonzero(self.action==a) for a in ACTIONS[1:]}
        self.trees={a:cKDTree((feat[ids]-self.mu)/self.sd) for a,ids in self.indices.items()}
        # Fixed physical scales regularize the dimensionless regression.
        self.scale=np.r_[np.full(3,.05),np.full(3,.006),np.full(3,.0015),np.full(3,.00015),np.full(3,.025),np.full(3,.001)]
    def neighbours(self,x,P,action):
        feat=encode(x,P) if self.use_cov else x
        dist,local=self.trees[action].query((feat-self.mu)/self.sd,k=min(self.k,len(self.indices[action])))
        ids=self.indices[action][np.atleast_1d(local)];d=np.atleast_1d(dist);w=np.exp(-d*d/max(d[-1],.1)**2);w/=w.sum()
        return ids,w
    def moments(self,x,P,action):
        ids,w=self.neighbours(x,P,action);u=self.paired[ids,:18];v=self.paired[ids,18:]
        probs=np.array([w[self.outcome[ids]==i].sum() for i in range(3)])
        ms=np.einsum('n,ni,nj->ij',w,u,u);mp=np.einsum('n,ni,nj->ij',w,v,v)
        alpha=self.alpha.get(action,1.);mp=(1-alpha)*ms+alpha*mp
        return ms,mp,probs,ids,w
    def predict(self,x,P,action,k=None):
        ms,mp,probs,ids,w=self.moments(x,P,action);u=self.paired[ids,:18];v=self.paired[ids,18:]
        alpha=self.alpha.get(action,1.)
        if alpha<1:
            v=np.concatenate([v,u]);u=np.concatenate([u,u]);w=np.r_[alpha*w,(1-alpha)*w]
        mu=w@u;mv=w@v
        U=(u-mu)/self.scale;V=(v-mv)/self.scale
        C=np.einsum('n,ni,nj->ij',w,U,U);D=np.einsum('n,ni,nj->ij',w,V,U)
        # Ridge toward identity models a no-change action when local evidence is weak.
        Aw=(D+.05*np.eye(18))@np.linalg.inv(C+.05*np.eye(18));A=Aw*self.scale[:,None]/self.scale[None,:];b=mv-A@mu
        residual=(v-mv)-(u-mu)@A.T;R=psd(np.einsum('n,ni,nj->ij',w,residual,residual));Cs=psd(np.einsum('n,ni,nj->ij',w,u-mu,u-mu))
        return psd(ms),psd(mp),probs,float(np.quantile(self.cost[ids],.95)),A,b,R,mu,Cs
