"""A second, independently specified airframe, excluded from all forecast fitting."""
import numpy as np, json
from scipy.spatial import ConvexHull
from r8_protocol import D,A19,sha

def build():
    folder=D/'geometry'; folder.mkdir(exist_ok=True)
    if (folder/'manifest.json').exists(): return
    vertices=[]; faces=[]; names=[]
    def ellipsoid(c,r,nu=48,nv=64):
        base=len(vertices)
        for i in range(nu):
            u=np.pi*(i+.5)/nu
            for j in range(nv):
                v=2*np.pi*j/nv
                vertices.append(np.asarray(c)+np.asarray(r)*[np.cos(u),np.sin(u)*np.cos(v),np.sin(u)*np.sin(v)])
        for i in range(nu-1):
            for j in range(nv):
                a=base+i*nv+j; b=base+i*nv+(j+1)%nv; cc=a+nv; dd=b+nv
                faces.extend([[a,b,cc],[b,dd,cc]]); names.extend(['metal','metal'])
        for i in [0,nu-1]:
            for j in range(1,nv-1):
                f=[base+i*nv,base+i*nv+j,base+i*nv+j+1]
                faces.append(f[::-1] if i==0 else f); names.append('metal')
    def solid(points):
        p=np.asarray(points,float); base=len(vertices);vertices.extend(p)
        for f in ConvexHull(p).simplices:
            t=p[f]
            if np.cross(t[1]-t[0],t[2]-t[0])@(t.mean(0)-p.mean(0))<0: f=f[::-1]
            faces.append((f+base).tolist());names.append('metal')
    ellipsoid([0,0,3.1],[18.4,2.15,2.15])
    for sign in [-1,1]:
        solid([[x,sign*y,z] for x,y in [(5,1.4),(-3,1.4),(-7.8,16.7),(-4.2,16.7)] for z in [3.5,3.75]])
        solid([[x,sign*y,z] for x,y in [(-13.1,1.3),(-17.1,1.3),(-17.1,6.7),(-14.4,6.7)] for z in [3.9,4.12]])
        ellipsoid([1.2,sign*6.9,2.5],[2.8,.9,.85],24,48)
    solid([[-12.7,y,3.3] for y in [-.16,.16]]+[[-17.4,y,3.3] for y in [-.16,.16]]+[[-16.7,y,9.4] for y in [-.16,.16]]+[[-15.2,y,9.4] for y in [-.16,.16]])
    v=np.asarray(vertices);f=np.asarray(faces,np.int32)
    def save(vv,p):
        t=vv[f];nn=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);aa=np.linalg.norm(nn,axis=1)/2;nn/=np.maximum(2*aa[:,None],1e-15)
        np.savez_compressed(p,vertices=vv,faces=f,normals=nn,area=aa,names=np.asarray(names))
    t=v[f];norm=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);area=np.linalg.norm(norm,axis=1)/2;norm/=np.maximum(2*area[:,None],1e-15)
    vn=np.zeros_like(v)
    for j in range(3):np.add.at(vn,f[:,j],norm*area[:,None])
    vn/=np.maximum(np.linalg.norm(vn,axis=1)[:,None],1e-12)
    for level,delta in enumerate([0,.012,.03,.06]):
        warp=delta*(np.sin(v[:,0]*.29)+.55*np.cos(v[:,1]*.37))
        save(v+warp[:,None]*vn,folder/f'world_discrepancy_{level}.npz')
    theta=np.arange(19800)*.1*2*np.pi/600
    pos=np.c_[23*np.cos(theta),20*np.sin(theta),np.ones(len(theta))*.85]
    yaw=np.unwrap(np.arctan2(-pos[:,1],-pos[:,0]))
    np.savez_compressed(folder/'route.npz',pose=np.c_[pos,np.zeros((len(theta),2)),yaw])
    for m in ['B767','C172']:
        z=np.load(A19/f'meshes/{m}/world_discrepancy_0.npz',allow_pickle=True)
        vv=z['vertices'];ff=z['faces'];nn=z['normals'];aa=z['area'];normal=np.zeros_like(vv)
        for j in range(3):np.add.at(normal,ff[:,j],nn*aa[:,None])
        normal/=np.maximum(np.linalg.norm(normal,axis=1)[:,None],1e-12)
        warped=vv+.06*(np.sin(vv[:,0]*.29)+.55*np.cos(vv[:,1]*.37))[:,None]*normal
        tt=warped[ff];newn=np.cross(tt[:,1]-tt[:,0],tt[:,2]-tt[:,0]);newa=np.linalg.norm(newn,axis=1)/2;newn/=np.maximum(2*newa[:,None],1e-15)
        np.savez_compressed(folder/f'{m}_world_discrepancy_3.npz',vertices=warped,faces=ff,normals=newn,area=newa,names=z['names'])
    (folder/'manifest.json').write_text(json.dumps({'name':'UnfittedAirframe','source':'explicit procedural ellipsoids and finite-thickness convex components; no measured CAD',
        'excluded_from_all_fitting':True,'source_sha256':sha(__file__),'files':{p.name:sha(p) for p in folder.glob('*.npz')}},indent=2))

def geometry(mesh,level=0):
    if mesh=='UnfittedAirframe':return D/'geometry'/f'world_discrepancy_{level}.npz'
    if level==3:return D/'geometry'/f'{mesh}_world_discrepancy_3.npz'
    return A19/f'meshes/{mesh}/world_discrepancy_{level}.npz'

def route(mesh):
    return D/'geometry/route.npz' if mesh=='UnfittedAirframe' else A19/f'meshes/{mesh}/route.npz'

if __name__=='__main__':build()
