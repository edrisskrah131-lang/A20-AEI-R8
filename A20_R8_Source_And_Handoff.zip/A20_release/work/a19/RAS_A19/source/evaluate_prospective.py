"""Train/validation/test separation for independently generated geometric queries."""
from pathlib import Path
import json,pickle,itertools,hashlib
from time import process_time_ns,perf_counter
import numpy as np
import pandas as pd
from soft_posterior import SoftPlanner
from prospective import ROOT,ACTIONS,MESHES,PRICE

QUANTUM=.00001
FIDELITIES=[.5,.65,.8,.95,1.]
RATIOS=[1.,1.25,1.5]
METHODS=['coarse','full','fixed','myopic','reserve','joint','hard_joint','hard_fixed']

def build(train,mesh,ctx,ratio,method,rho,profile):
    tr=[r for r in train if r['mesh']==mesh and r['context']==ctx]
    Y=np.asarray([r['losses'] for r in tr]);X=np.asarray([r['scores'] for r in tr])
    thresholds=np.median(X,axis=0)
    c=np.asarray(profile[mesh]['execution_units']);q=np.asarray(profile[mesh]['query_units'])
    budget=int(np.floor(max(c)*ratio))
    p=SoftPlanner(Y,(X>thresholds).astype(int),c,budget,q,PRICE*QUANTUM,
                  reliability=rho,reserve_full=method=='reserve',myopic=method=='myopic')
    p.solve(p.root)
    subset=p.fixed_subset()[1] if method in ['fixed','hard_fixed'] else None
    # Export only decisions that are reachable under the selected query policy.
    table={}
    def visit(state):
        if state in table:return
        v,decision=p.solve(state);table[state]=decision
        if decision[0]=='query':
            for bit in [0,1]:
                child=list(state);child[decision[1]]=bit;child=tuple(child)
                if p.masses(child).sum()>0:visit(child)
    visit(p.root)
    fixed_actions={}
    if subset is not None:
        for bits in itertools.product([0,1],repeat=len(subset)):
            state=[-1]*4
            for qj,z in zip(subset,bits):state[qj]=z
            state=tuple(state)
            belief=state if p.masses(state).sum()>0 else p.root
            fixed_actions[bits]=p.stop(belief,spent=p.spent(state))[1]
    fallback={}
    for state,decision in table.items():
        if decision[0]=='query':
            spent=p.spent(state)+p.query_costs[decision[1]]
            fallback[state]=p.stop(state,spent=spent)[1]
    return dict(table=table,thresholds=thresholds,subset=subset,fixed_actions=fixed_actions,
                fallback=fallback,coarse=p.stop(p.root)[1],budget=budget,
                costs=c,query_costs=q,rho=rho,model_risk=p.solve(p.root)[0])

def dispatch(model,method,callback):
    if method=='full':return 4,[]
    if method=='coarse':return int(model['coarse']),[]
    if model['subset'] is not None:
        path=list(model['subset']);bits=tuple(int(callback(q)>model['thresholds'][q]) for q in path)
        return int(model['fixed_actions'][bits]),path
    state=(-1,)*4;path=[]
    while True:
        kind,i=model['table'][state]
        if kind=='stop':return int(i),path
        path.append(i);child=list(state);child[i]=int(callback(i)>model['thresholds'][i]);child=tuple(child)
        if child not in model['table']:return int(model['fallback'][state]),path
        state=child

def main():
    raw=[json.loads(s) for s in (ROOT/'data/prospective_cases.jsonl').read_text().splitlines()]
    assert len(raw)==1200 and len({r['seed'] for r in raw})==1200
    train=[r for r in raw if r['split']=='train'];val=[r for r in raw if r['split']=='validation']
    test=[r for r in raw if r['split']=='test']
    profile={}
    for mesh in MESHES:
        tr=[r for r in train if r['mesh']==mesh]
        cs=np.asarray([r['cpu'] for r in tr]);qs=np.asarray([r['query_cpu'] for r in tr])
        # 20 us per query includes the small table traversal and binary comparison.
        c=np.ceil(1.5*np.quantile(cs,.99,axis=0)/QUANTUM).astype(int)
        q=np.maximum(1,np.ceil((1.5*np.quantile(qs,.99,axis=0)+.00002)/QUANTUM).astype(int))
        profile[mesh]=dict(execution_units=c.tolist(),query_units=q.tolist(),
                          execution_p50_ms=(1000*np.median(cs,axis=0)).tolist(),
                          query_p50_ms=(1000*np.median(qs,axis=0)).tolist(),
                          quantum_s=QUANTUM)
    (ROOT/'data/runtime_profile.json').write_text(json.dumps(profile,indent=2))
    models={};selection=[];rows=[];start=perf_counter()
    for mesh,ctx,ratio,method in itertools.product(MESHES,range(3),RATIOS,METHODS):
        vs=[r for r in val if r['mesh']==mesh and r['context']==ctx]
        grid=[1.] if method.startswith('hard') else [.5] if method in ['coarse','full'] else FIDELITIES
        candidates=[]
        for rho in grid:
            mod=build(train,mesh,ctx,ratio,method,rho,profile)
            values=[]
            for r in vs:
                a,path=dispatch(mod,method,lambda q:r['scores'][q])
                values.append(r['losses'][a]+PRICE*sum(r['query_cpu'][q] for q in path))
            candidates.append((float(np.mean(values)),rho,mod))
        best=min(x[0] for x in candidates);loss,rho,mod=next(x for x in candidates if x[0]<=best+1e-12)
        models[(mesh,ctx,ratio,method)]=mod
        selection.append(dict(mesh=mesh,context=ctx,ratio=ratio,method=method,rho=rho,
                              validation_loss=loss,grid_loss=[(x[1],x[0]) for x in candidates],
                              model_risk=mod['model_risk']))
        for r in test:
            if r['mesh']!=mesh or r['context']!=ctx:continue
            t=process_time_ns();a,path=dispatch(mod,method,lambda q:r['scores'][q]);lookup=(process_time_ns()-t)*1e-9
            qcpu=sum(r['query_cpu'][q] for q in path);cpu=r['cpu'][a]+qcpu+lookup
            reserved=sum(mod['query_costs'][q] for q in path)+mod['costs'][a]
            assert reserved<=mod['budget']
            oracle=float(min(r['losses']))
            rows.append(dict(seed=r['seed'],mesh=mesh,level=r['level'],noise=r['noise'],context=ctx,
                             ratio=ratio,method=method,action=ACTIONS[a],queries=len(path),path=str(path),
                             loss=r['losses'][a]+PRICE*(qcpu+lookup),registration_cpu_ms=1000*r['cpu'][a],
                             query_cpu_ms=qcpu*1000,lookup_cpu_ms=lookup*1000,cpu_ms=cpu*1000,
                             budget_ms=mod['budget']*QUANTUM*1000,overrun=cpu>mod['budget']*QUANTUM,
                             oracle_loss=oracle,instant_m=r['instant'][a],rho=rho))
    df=pd.DataFrame(rows);df.to_csv(ROOT/'data/prospective_replay.csv',index=False)
    (ROOT/'data/model_selection.json').write_text(json.dumps(selection,indent=2))
    # Pickles are local model artifacts generated from this source, never untrusted input.
    with (ROOT/'data/compiled_models.pkl').open('wb') as f:pickle.dump(models,f)
    summary=df.groupby(['mesh','ratio','method'],as_index=False).agg(loss=('loss','mean'),
       cpu_ms=('cpu_ms','mean'),query_cpu_ms=('query_cpu_ms','mean'),queries=('queries','mean'),
       overruns=('overrun','sum'),instant_m=('instant_m','mean'),oracle=('oracle_loss','mean'))
    summary.to_csv(ROOT/'data/prospective_summary.csv',index=False)
    # Paired source bootstrap. Individual simulated sources have independent RNG seeds.
    rng=np.random.default_rng(180002);contrasts=[]
    for mesh,ratio in itertools.product(MESHES,RATIOS):
        d=df[(df.mesh==mesh)&(df.ratio==ratio)].pivot(index='seed',columns='method',values='loss')
        for baseline in ['full','coarse','fixed','myopic','reserve','hard_fixed']:
            delta=(d['joint']-d[baseline]).to_numpy();boot=delta[rng.integers(0,len(delta),(4000,len(delta)))].mean(axis=1)
            contrasts.append(dict(mesh=mesh,ratio=ratio,baseline=baseline,n=len(delta),
                                  paired_difference=float(delta.mean()),ci_low=float(np.quantile(boot,.025)),
                                  ci_high=float(np.quantile(boot,.975)),source_wins=int((delta<0).sum())))
    pd.DataFrame(contrasts).to_csv(ROOT/'data/paired_contrasts.csv',index=False)
    print(summary.to_string(index=False));print('COMPILE AND EVALUATE',round(perf_counter()-start,2),'s')
    print('OUTPUT',len(df),'decisions from',len(test),'independent test sources',flush=True)

if __name__=='__main__':main()
