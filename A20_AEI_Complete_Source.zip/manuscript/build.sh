#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")/paper"
pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error supplement.tex
pdflatex -interaction=nonstopmode -halt-on-error supplement.tex
pdflatex -interaction=nonstopmode -halt-on-error supplement.tex
cp main.pdf ../A20_AEI_Manuscript.pdf
cp supplement.pdf ../Supplement.pdf
