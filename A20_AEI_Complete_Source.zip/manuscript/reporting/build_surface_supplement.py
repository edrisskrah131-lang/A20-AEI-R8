"""Render the complete independent surface benchmark from executed outputs."""
from pathlib import Path
import json
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
STUDY=ROOT/'studies/cad_surface_20261014'
OUT=STUDY/'outputs'
spec=json.loads((STUDY/'protocol.json').read_text())
cards=pd.read_csv(OUT/'risk_cards.csv')
summary=pd.read_csv(OUT/'test_summary.csv')
obs=pd.read_csv(OUT/'observations.csv')
configs=pd.read_csv(OUT/'configurations.csv')
ledger=pd.read_csv(OUT/'refresh_ledger.csv')
names={'baseline':'Baseline','focal':r'Focal +15\%','exposure':r'Exposure +50\%',
       'wide_roi':'Wide ROI','lighting':'Lower light','decoder':'Decoder shift'}
requests={'optical':'Optical','optical_relaxed':'Optical relaxed','acquisition':'Acquisition',
 'acquisition_relaxed':'Acquisition relaxed','association':'Association','association_relaxed':'Association relaxed',
 'complete':'Complete','complete_relaxed':'Complete relaxed'}
parts=[r'''\section{Controlled regular-grid CAD-surface benchmark}\label{supp:surface}
\subsection{Scene generation and independent inputs}
The controlled regular-grid study uses an analytic surface producer, separate from the earlier diagnostic-fiducial producer. It draws 384 complete scenes, with 192 calibration and 192 test inputs. The two seed ranges begin at 202615100 and 202616100. Every scene executes the baseline and five registered interventions, giving 2,304 producer/input evaluations. The scene, rather than an individual pixel or fastener, is the statistical sampling unit. Shared-input comparisons are paired; the six producer configurations are not six independent samples.

Each input independently draws one of three equally probable geometry families. The surface is $z=(a x^2+b y^2)/2$: $(a,b)=(0,0)$ for a plane, $(1/R_1,0)$ for single curvature, and $(1/R_1,1/R_2)$ for double curvature. Radii are $R_1\sim\mathcal U(2.5,5)$ m and $R_2\sim\mathcal U(4,8)$ m. Camera coordinates have $x\sim\mathcal U(-0.2,0.2)$ m, $y\sim\mathcal U(-0.1,0.1)$ m and $z\sim\mathcal U(0.7,1.15)$ m; the optical axis points toward the patch origin. CAD addresses form a $7\times5$ grid with 35-mm spacing. Fastener heads have 2.5-mm radius, with a narrow bright surrounding rim. Panel seams are located in the same CAD coordinates.

Uniform draws set focal length to 1,200--1,600 pixels, exposure to 3--7 ms, tangential motion to 0.06--0.18 m/s, brightness to 0.85--1.15 and Gaussian intensity-noise standard deviation to 1.5--3.0. The independent light direction, texture phase and camera pose determine the ray/surface image. A diffuse term, specular exponent 36, two brushed-texture sinusoids and CAD-defined seams determine intensity. Horizontal Gaussian exposure filtering uses the median predicted blur divided by $\sqrt{12}$; the vertical scale is 0.18 pixel. The random noise stream is common for paired configurations of the same raster size.

Development used eight pilots and an earlier 384-input, prior-only surface evaluation with distinct seed ranges beginning at 202611100 and 202612100. That evaluation informed the inclusion of pixel-based pose refinement. Its inputs are excluded from the controlled calibration and test sets. The final model, request family and seed specification are preserved by the benchmark hash file.
''',r'\begin{table}[!htbp]\centering\small\caption{Independent scene counts by geometry family.}\begin{tabular}{@{}lrr@{}}\toprule Family & Calibration & Test\\\midrule']
for i,label in enumerate(['Planar','Singly curved','Doubly curved']):
    parts.append(f'{label} & {len(configs.query("phase==\'calibration\' and family==@i"))} & {len(configs.query("phase==\'test\' and family==@i"))}'+r'\\')
parts += [r'\bottomrule\end{tabular}\end{table}',r'''\subsection{Pixel extraction, pose refinement and quality scores}
The decoder reads RGB pixels without CAD coordinates. Local contrast is the difference between a Gaussian-smoothed grayscale image and that image. Connected components above contrast 18 and with area 5--240 pixels supply intensity-weighted centers. Predicted CAD positions from the pose prior are subsequently assigned to these centers by minimum-cost bipartite matching with a 30-pixel gate.

The prior translation perturbation is isotropic normal with 3-mm component standard deviation. With probability 0.02, an independent normal perturbation of 5-mm component standard deviation is added. Rotation-vector errors have 0.001-rad component standard deviation. At least six matches trigger nonlinear refinement of six pose parameters. SciPy least-squares applies a componentwise Huber loss with transition 2 to normalized pixel, translation and rotation residuals. Their scales are 0.5 pixel, 3 mm and 0.001 rad. The numerical solver uses at most 60 function evaluations and $10^{-9}$ stopping tolerances. The protocol's Gaussian-prior descriptor refers to prior sampling; the implemented objective robustifies both observation and prior residuals.

Ground truth is accessed after matching and estimation to label quality. Correct-address coverage uses a half-spacing gate around the physical projected address. Reprojection and mapping quantities take the maximum over those correctly addressed matches within one scene. Mapping casts rays at the true physical image locations through the estimated pose and intersects the CAD surface. An empty correct-match set has infinite reprojection and mapping quantities; low coverage is independently included in acquisition or association requests. The reported medians and percentiles then summarize these per-scene maxima. They do not summarize all fasteners as independent observations.

The decoder intervention adds 12 pixels to decoded horizontal coordinates before matching and refinement. It represents a changed coordinate convention. It alters the fitted mapping while leaving the rendered observation and optical sampling unchanged. The model retains exact CAD geometry, an ideal perspective camera and prescribed surface appearance; no lens distortion, deformation or physical defect labels enter the numerical scores.
''',r'''\subsection{Requests and calibration family}
The eight requests are compiled through the retained unit-aware request compiler. Millimetres are converted to metres, pixels remain dimensionless image coordinates, and coverage is a ratio. Calibration uses one scene-level union failure for each request. All 48 producer/request events retain allocation $\alpha=0.05/48$, including events whose cards are not needed by a particular renewal route.

\begin{table}[!htbp]\centering\small\caption{Complete request specifications. A dash denotes an omitted quantity.}\begin{tabular}{@{}lrrrrr@{}}\toprule
Request & GSD (mm/px) & Blur (px) & Coverage & Residual (px) & Mapping (mm)\\\midrule''']
for q,s in spec['requests'].items():
    cells=[]
    for metric in ['gsd_m','blur_px','coverage','reprojection_px','association_m']:
        if metric not in s:cells.append('--');continue
        lo,hi=s[metric];value=lo if metric=='coverage' else hi
        cells.append(f'{value*(1000 if metric in ["gsd_m","association_m"] else 1):g}')
    parts.append(requests[q]+' & '+' & '.join(cells)+r'\\')
parts += [r'''\bottomrule\end{tabular}\end{table}

Coverage is a lower bound; the other entries are upper bounds. Complete requests combine acquisition and association at the same strictness. Four strict events constitute the initial anchors. The complete risk-card catalogue follows. Test failures are descriptive held-out outcomes and are not used to construct the bounds.

\begin{longtable}{@{}llrrrrl@{}}
\caption{All 48 controlled-study risk cards and held-out outcomes.}\label{supp:surface-cards}\\
\toprule Producer & Request & $k$ & $n$ & $U$ & Test failures & Decision\\\midrule\endfirsthead
\toprule Producer & Request & $k$ & $n$ & $U$ & Test failures & Decision\\\midrule\endhead
\bottomrule\endfoot''']
for r in cards.itertuples():
    parts.append(f'{names[r.variant]} & {requests[r.request]} & {r.k} & {r.n} & {r.upper:.6f} & {r.test_failures}/{r.test_n} & '+('Admit' if r.authorized else 'Refuse')+r'\\')
parts += [r'\end{longtable}',r'''\subsection{Complete numerical and computational results}
\begin{table}[!htbp]\centering\small\caption{Held-out per-scene quality. Each producer has 192 inputs. GSD and blur are medians; coverage is a mean; residual and mapping entries are medians.}\begin{tabular}{@{}lrrrrr@{}}\toprule
Producer & GSD (mm/px) & Blur (px) & Coverage & Residual (px) & Mapping (mm)\\\midrule''']
for r in summary.itertuples():
    parts.append(f'{names[r.variant]} & {r.median_gsd_mm:.3f} & {r.median_blur_px:.3f} & {r.mean_coverage:.5f} & {r.median_reprojection_px:.3f} & {r.median_association_mm:.3f}'+r'\\')
parts += [r'\bottomrule\end{tabular}\end{table}',r'''\begin{table}[!htbp]\centering\small\caption{Held-out tail errors and complete-pipeline CPU medians. CPU includes rendering, extraction, estimation and offline scoring; it is distinct from online component timing.}\begin{tabular}{@{}lrrr@{}}\toprule
Producer & Residual p95 (px) & Mapping p95 (mm) & CPU median (ms)\\\midrule''']
for r in summary.itertuples():
    t=obs.query('phase=="test" and variant==@r.variant').cpu_s.median()*1000
    parts.append(f'{names[r.variant]} & {r.p95_reprojection_px:.3f} & {r.p95_association_mm:.3f} & {t:.3f}'+r'\\')
parts += [r'\bottomrule\end{tabular}\end{table}',r'''\paragraph{Catalogue construction}
The three fair methods receive identical stored quantities. Each cache computes an event bound once for an eligible producer/event identity and counts every constructed card, including refusals. Whole-producer renewal constructs 48 cards; dependency-aware exact renewal constructs 42; containment with exact fallback constructs 25. All admit the same 44 contexts. Their record evaluations are 9,216, 8,064 and 4,800. A record visit is one scene-level event evaluation, not a new rendering or an individual fastener evaluation. Median process CPU is measured across 11 complete catalogue builds, with records already loaded. Re-execution retains the first timing archive and independently checks decisions and work counts.

The contract constructs strict anchor cards before evaluating requests. If no applicable anchor satisfies the allowance, it builds the exact-event card. The four additional relaxed-event fallbacks occur for acquisition and complete service under exposure change, and association and complete service under decoder change. Cards required for failed strict requests remain in the construction count. The stale-cache control uses baseline cards for all updates and issues four statements unsupported by the fresh catalogue.

\paragraph{Cold source-renewal ledger}
The cold workload consists of five updates times eight independently initialized requests. Each case has a 192-input renewal block. It is a logical work ledger evaluated from the registered dependency projection, rather than a measured sum of elapsed times. It does not assume that a batched catalogue rerenders shared quantities separately for every request. The whole-producer method counts 7,680 full pipelines. Both dependency-aware methods count 5,760 full pipelines, 768 optical-only evaluations and 1,152 retained inputs. An executable optical-only implementation independently reproduces GSD and blur for all 1,152 calibration/configuration combinations to tolerance $10^{-10}$.

\begin{table}[!htbp]\centering\small\caption{Cold source-renewal work aggregated by update. Eight requests and 192 inputs per update.}\begin{tabular}{@{}lrrrr@{}}\toprule
Update & Whole pipelines & Selected pipelines & Optical only & Retained inputs\\\midrule''']
for variant,g in ledger.groupby('variant',sort=False):
    parts.append(names[variant]+' & '+' & '.join(f'{int(g[c].sum()):,}' for c in ['whole_producer_runs','dependency_pipeline_runs','dependency_optical_runs','dependency_reuses'])+r'\\')
parts += [r'''\bottomrule\end{tabular}\end{table}
\paragraph{Reproduction and provenance}
The directory \texttt{studies/cad\_surface\_20261014} contains the producer, input specification, hash file, sampling and execution driver, complete observations, configurations, risk cards, request plans and work ledgers. Nine compressed image records retain actual rendered pixels and derived centers. Gallery seeds 202616100, 202616104 and 202616108 are the first test input in each family. The full independent rerun compares numerical observations and image records; only machine-dependent CPU fields are excluded from equality. All primary graphics are generated from those saved outputs. The study uses Python 3.12, NumPy, SciPy and Linux on an AMD EPYC 9V74 host, with two workers and one numerical thread per worker.
''']
(ROOT/'paper/sections/cad_surface_supplement.tex').write_text('\n\n'.join(parts)+'\n')
print('Built complete surface supplement:',len(cards),'cards')
