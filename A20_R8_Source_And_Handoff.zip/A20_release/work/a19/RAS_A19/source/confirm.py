from pathlib import Path
import json,pickle,hashlib,itertools
import numpy as np
import pandas as pd
from prospective import ROOT,MESHES,LEVELS,PRICE,Mesh,make_case,dataset_design
from reuse import realized

def freeze():
    cases=[dict(r,split='confirmation',seed=r['seed']+900000) for r in dataset_design() if r['split']=='test']
    p=ROOT/'protocol_confirmation.json'
    d=dict(cases=cases,methods=['full','coarse','fixed','myopic','reserve','joint','no_reuse'],
           prices=[.003,.03,.3],primary_price=.3,ratios=[1.,1.25,1.5],primary_ratio=1.,
           development='All original A18 cases are development history; confirmation uses a disjoint seed family.',
           method_sha256=hashlib.sha256((ROOT/'source/reuse.py').read_bytes()).hexdigest(),
           model_sha256=hashlib.sha256((ROOT/'data/reuse_models.pkl').read_bytes()).hexdigest(),
           generator_sha256=hashlib.sha256((ROOT/'source/prospective.py').read_bytes()).hexdigest())
    if p.exists():assert json.loads(p.read_text())==d
    else:p.write_text(json.dumps(d,indent=2))
    return d

def main():
    p=freeze();out=ROOT/'data/confirmation_cases.jsonl';meshes={};routes={}
    for mesh in MESHES:
        routes[mesh]=np.load(ROOT/f'meshes/{mesh}/route.npz')['pose']
        for level in LEVELS:meshes[(mesh,level)]=Mesh(ROOT/f'meshes/{mesh}/world_discrepancy_{level}.npz')
    done={json.loads(l)['seed'] for l in out.read_text().splitlines()} if out.exists() else set()
    with out.open('a') as f:
        for i,c in enumerate(p['cases']):
            if c['seed'] in done:continue
            r=make_case(c,meshes,routes);f.write(json.dumps(r)+'\n');f.flush()
            if (i+1)%40==0:print('CONFIRM',i+1,'/ 480',flush=True)
    rows=[json.loads(l) for l in out.read_text().splitlines()];assert len(rows)==480
    models=pickle.load(open(ROOT/'data/reuse_models.pkl','rb'));records=[]
    for r,ratio,price,method in itertools.product(rows,p['ratios'],p['prices'],p['methods']):
        m=models[(r['mesh'],r['context'],ratio,price,method)]
        loss,a,path,cpu=realized(r,m,method)
        pose=r['losses'][a]-PRICE*r['cpu'][a]
        reserved=sum(m['costs'][q+1] for q in path)
        if a-1 not in path or not m['reuse']:reserved+=m['costs'][a]
        assert reserved<=m['budget']
        oracle=min(r['losses'][j]-PRICE*r['cpu'][j]+price*r['cpu'][j] for j in range(5))
        records.append(dict(seed=r['seed'],mesh=r['mesh'],level=r['level'],noise=r['noise'],context=r['context'],
            ratio=ratio,price=price,method=method,action=a,path=str(path),probes=len(path),
            loss=loss,pose_loss=pose,cpu_ms=cpu*1000,instant_m=r['instant'][a],
            oracle_loss=oracle,overrun=cpu>m['budget']*.00001,rho=m['rho']))
    df=pd.DataFrame(records);df.to_csv(ROOT/'data/confirmation_replay.csv',index=False)
    summary=df.groupby(['mesh','ratio','price','method'],as_index=False).agg(loss=('loss','mean'),
        pose_loss=('pose_loss','mean'),cpu_ms=('cpu_ms','mean'),instant_m=('instant_m','mean'),
        probes=('probes','mean'),overruns=('overrun','sum'),oracle=('oracle_loss','mean'))
    summary.to_csv(ROOT/'data/confirmation_summary.csv',index=False)
    rng=np.random.default_rng(18731);contrasts=[]
    for mesh,ratio,price in itertools.product(MESHES,p['ratios'],p['prices']):
        dat=df[(df.mesh==mesh)&(df.ratio==ratio)&(df.price==price)]
        for metric in ['loss','pose_loss','cpu_ms']:
            wide=dat.pivot(index='seed',columns='method',values=metric)
            ids=rng.integers(0,len(wide),(4000,len(wide)))
            for baseline in ['full','coarse','fixed','myopic','reserve','no_reuse']:
                delta=(wide.joint-wide[baseline]).to_numpy();bs=delta[ids].mean(axis=1)
                contrasts.append(dict(mesh=mesh,ratio=ratio,price=price,metric=metric,baseline=baseline,
                    difference=float(delta.mean()),low=float(np.quantile(bs,.025)),high=float(np.quantile(bs,.975))))
    pd.DataFrame(contrasts).to_csv(ROOT/'data/confirmation_contrasts.csv',index=False)
    print(summary.query('ratio == 1.0 and price == .3').to_string(index=False),flush=True)

if __name__=='__main__':main()
