# Fixed first-scene decision and allowance sensitivity

Run `python manuscript/studies/decision_case_20261018/scriptrun.py` and then
`python manuscript/studies/decision_case_20261018/independent_check.py` from the
repository root. Both commands write only this directory. Original lifecycle
records, requests, source code, and figures are not modified or regenerated.

## Selection and interpretation

The example is the smallest held-out seed, **202619100**, selected without
conditioning on any outcome. The baseline and exposure-change images both pass
all eight defined quality events. The exposure producer nevertheless loses
population support for strict complete service. This deliberately keeps the
observed quality of one image separate from the calibration statement about a
producer operating on the specified scene population.

Exposure increases by 50%. GSD is unchanged because its requested provider
projection excludes exposure. The optical request also constrains blur, so its
whole evidence card **must be renewed**. There is no standalone GSD card in the
48-event family, and this analysis does not introduce one. The relaxed complete
request uses exact fallback because the strict complete anchor is inadmissible.
Restoring the original producer restores population compatibility; output
attachment recovery is assessed separately in
`../validated_recovery_20261018/outputs/example_trace.json`.

`case.json` records original scene quantities in report units, all exact-event
calibration/test evidence, actual contract routes, the population decision
sequence, and the executed source repair traces. `attachment_case_trace.csv`
contains the 13 protocol steps for strict complete, relaxed complete, and
optical requests under the stale-producer-output fault, all on the same seed.
The repair study supplies these traces and its source JSON hash is recorded.

In those executed traces, authenticated repair returns the exposure output to
an active state at revision 2 of the original binding, preserving capture and
predecessor provenance. Relaxed complete and optical statements can issue;
strict complete remains statistically inadmissible under that exposure
producer. The population-only restoration branch instead refers to restoring
the original producer's compatibility. These are distinct operations. Strong
authoritative snapshot and event-sourced implementations agree with the
contract on the source repair trace. Duplicate repair is refused without
invalidating a successfully restored binding.

## Allowance and threshold meaning

The allowance 0.15 is an illustrative maximum population frequency of failure
of the defined image-quality event. It is not a missed-defect rate, accident
probability, certification requirement, or industrial-standard acceptance
criterion. Thresholds were retained from `cad_surface_20261014/protocol.json`
before the lifecycle population was sampled. No industrial-standard rationale
is inferred from this reuse. Task-specific deployment would require a justified
quality requirement, population definition, and calibration data.

`request_thresholds.csv` contains all eight requests. GSD is expressed as
millimetres of surface sampling per image pixel; the request compiler stores
the corresponding single-pixel footprint in metres. Blur and reprojection use
pixels, correct-address coverage uses percent, and maximum image-to-CAD mapping
error uses millimetres. An empty cell is an unconstrained quantity. Coverage and
mapping error use offline scene ground truth; they are not available as direct
runtime oracle measurements. The current request thresholds therefore define
the evaluated image-quality tasks, not a defect-recognition system.

## Fixed-family allowance sensitivity

The five allowances are 0.02, 0.05, 0.10, 0.15, and 0.20. Each call executes the
original `construct(..., allowance=...)` implementation on the same 256 complete
calibration inputs and six producers. Every call uses the same 48-event
confidence allocation, alpha = 0.05/48. Changing the acceptance allowance does
not create another event and does not require a new family allocation. The
simultaneous event bounds can be compared to every allowance on this grid.

`sensitivity.csv` reports support, constructed cards, and calibration-record
evaluations for all four complete methods. `sensitivity_routes.csv` preserves
every decision and selected proof. All methods have identical support at each
allowance. Costs include refused requests and failed anchors. These are
evidence-evaluation counts, not new runtime measurements or image-stage costs.

## Independent held-out family assessment

`event_validation.csv` evaluates all 48 pre-specified producer/request events
on all 256 held-out scenes, without issuance filtering. Its `test_upper` is a
one-sided Clopper–Pearson bound using the separate held-out family's allocation
0.05/48. `validation_summary.json` reports the maximum held-out bound among
calibration-admitted events and sensitivity summaries.

Calibration and held-out validation each have a simultaneous 95% family
statement. The two statements are not automatically one joint 95% statement.
The held-out assessment does not change the calibration plans, thresholds,
producers, or population definition. It describes the same planned programs;
it does not estimate a conditional failure rate among monitor-issued outputs.

## Verification and provenance

`provenance.json` hashes the immutable input records and specifications.
`independent_check.py` imports neither the evidence implementation nor its
failure/containment functions. It recounts failures directly from raw CSV
values and request intervals, inverts the beta CDF independently, checks the
binomial tail equation, reconstructs containment work counts, verifies report
units, checks the fixed first seed, verifies input hashes, and cross-checks the
repair trace against population decisions, same-binding recovery, predecessor
digests, and failed-repair state preservation. It does not replace the recovery
study's independent state-machine check. Its output is `independent_check.json`.
