"""Source-grouped reporting, paired intervals, and vector publication figures."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from scipy.stats import beta
from checkpoint import ROOT
D=ROOT/'data';F=ROOT/'figures';F.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,
 'axes.spines.right':False,'pdf.fonttype':42,'savefig.bbox':'tight','axes.labelsize':9})
rows=[json.loads(l) for l in (D/'episodes.jsonl').read_text().splitlines()]
frame=pd.read_csv(D/'policy_episode_results.csv');ab=pd.read_csv(D/'checkpoint_ablations.csv')
cal=pd.read_csv(D/'risk_calibration.csv');freeze=json.loads((D/'frozen_policies.json').read_text())
selection=json.loads((D/'policy_selection.json').read_text());mult=10.
chosen=next(s for s in selection if s['runtime_multiplier']==mult and s['delta']==.15 and s['family']=='learned')['policy']
controls=['fixed_1','fixed_2','fixed_4','residual','final','all_release',chosen]
names={'fixed_1':'Fixed 1','fixed_2':'Fixed 2','fixed_4':'Fixed 4','residual':'Residual stop',
       'final':'Checkpoint final','all_release':'Publish all','native_final':'Native final',chosen:'RAVC-Loc'}
colors={'fixed_1':'#999999','fixed_2':'#9B59B6','fixed_4':'#2A9D8F','residual':'#B58900',
        'final':'#264653','all_release':'#457B9D',chosen:'#D55E00','native_final':'#222222'}
conf=frame[(frame.phase=='confirmation')&(frame.runtime_multiplier==mult)].copy()
stress=frame[(frame.phase=='stress')&(frame.runtime_multiplier==mult)].copy()
step=freeze['independent_motion_step_cpu_s'];native=[]
for phase in ['confirmation','stress']:
 for r in [r for r in rows if r['phase']==phase]:
  cpu=r['reference_cpu_s'];tick=max(1,int(np.ceil((.05+mult*cpu)/.1)));e=np.asarray(r['error']);rr=np.asarray(r['rotation_error'])
  accepted=r['trace'][-1]['accepted'];replay_steps=tick if accepted and tick<=40 else 0
  pe=e[0].copy();re=rr[0].copy()
  if tick<=40:pe[tick:]=e[-1,tick:];re[tick:]=rr[-1,tick:]
  native.append(dict(seed=r['seed'],phase=phase,mesh=r['mesh'],policy='native_final',runtime_multiplier=mult,
   solver_cpu_s=cpu,decision_cpu_s=0.,propagation_cpu_s=40*step,replay_cpu_s=replay_steps*step,
   cpu_total_s=cpu+(40+replay_steps)*step,integrated_position_mse_m2s=float(np.sum(pe[1:]**2)*.1),
   exposure_0p5_m2s=float(np.sum(pe[1:6]**2)*.1),episode_rmse_m=float(np.sqrt(np.mean(pe[5:]**2))),
   failure=int(np.any(pe[5:]>.1)),provenance='NATIVE_SOLVER_PAIRED_DIAGNOSTIC'))
native=pd.DataFrame(native);native.to_csv(D/'native_solver_diagnostic.csv',index=False)
conf=pd.concat([conf,native[native.phase=='confirmation']],ignore_index=True)
stress=pd.concat([stress,native[native.phase=='stress']],ignore_index=True)

def table(g):
 return dict(n=len(g),mean_cpu_ms=float(g.cpu_total_s.mean()*1000),mean_rmse_cm=float(g.episode_rmse_m.mean()*100),
    integrated_mse_1e3=float(g.integrated_position_mse_m2s.mean()*1000),early_exposure_1e3=float(g.exposure_0p5_m2s.mean()*1000),
    events=int(g.failure.sum()),event_rate=float(g.failure.mean()),decision_us=float(g.decision_cpu_s.mean()*1e6))
report={'policy':chosen,'confirmation':{p:table(g) for p,g in conf.groupby('policy')},
        'stress':{p:table(g) for p,g in stress.groupby('policy')},
        'ablations':{p:table(g) for p,g in ab[ab.runtime_multiplier==mult].groupby('ablation')}}
rng=np.random.default_rng(202610113);boot=rng.integers(0,240,(20000,240));intervals={}
q=conf[conf.policy==chosen].set_index('seed').sort_index()
for p in ['fixed_2','fixed_4','final','native_final']:
 b=conf[conf.policy==p].set_index('seed').sort_index();assert np.array_equal(q.index,b.index)
 for metric in ['cpu_total_s','integrated_position_mse_m2s','exposure_0p5_m2s','failure']:
  x=q[metric].to_numpy();y=b[metric].to_numpy();diff=x-y;vals=diff[boot].mean(1)
  ratios=1-x[boot].mean(1)/y[boot].mean(1) if metric!='failure' else vals
  intervals[p+'_'+metric]=dict(difference=float(diff.mean()),ci95=np.quantile(vals,[.025,.975]).tolist(),
      reduction=float(1-x.mean()/y.mean()) if metric!='failure' else float(diff.mean()),
      reduction_ci95=np.quantile(ratios,[.025,.975]).tolist())
report['paired_intervals']=intervals
for a in [1.,10.]:
 ac=ab[ab.runtime_multiplier==a]
 if len(ac):report[f'load_{a:g}_ablations']={p:table(g) for p,g in ac.groupby('ablation')}
pred=np.load(D/'prediction_confirmation.npz');P=pred['prediction'];Y=pred['target']
report['predictor']=dict(checkpoint_brier=float(np.mean((P[:,2]-Y[:,2])**2)),
    final_brier=float(np.mean((P[:,3]-Y[:,3])**2)),validation_scores=freeze['validation_scores'])

# Exact diagram of one source/version relationship, drawn as vector geometry.
fig,ax=plt.subplots(figsize=(7.0,2.85));ax.set_xlim(0,10);ax.set_ylim(0,3);ax.axis('off')
def box(x,y,w,label,color):
 p=FancyBboxPatch((x,y),w,.5,boxstyle='round,pad=.06',facecolor=color,edgecolor='#333333',linewidth=.7);ax.add_patch(p);ax.text(x+w/2,y+.25,label,ha='center',va='center',fontsize=8)
box(.1,2.3,1.55,'Source prior\n(immutable)','#E5E5E5')
for x,label in [(2.4,'Iteration 1'),(4.6,'Iteration 2'),(6.8,'Iteration 4')]:box(x,2.3,1.35,label,'#DCEEF3')
for x0,x1 in [(1.65,2.4),(3.75,4.6),(5.95,6.8)]:ax.annotate('',(x1,2.55),(x0,2.55),arrowprops={'arrowstyle':'->','lw':1})
ax.text(8.4,2.55,'Stop / resume',va='center',fontsize=7)
box(2.25,1.2,1.65,'Version 1\nsource candidate','#F8E1CE');box(4.45,1.2,1.65,'Version 2\nsource candidate','#F8E1CE')
for x in [3.05,5.25]:ax.annotate('',(x,1.77),(x,2.3),arrowprops={'arrowstyle':'->','lw':1})
box(2.6,.15,4.2,'Live estimate\nReplace source version + replay motion','#E0EDDE')
for x in [3.05,5.25]:ax.annotate('',(x,.73),(x,1.2),arrowprops={'arrowstyle':'->','lw':1})
ax.text(.3,.9,'Same scan\nSame source prior',fontsize=8,va='center');ax.text(7.25,1.4,'One retained solver state\nNo repeated likelihood fusion',fontsize=8,va='center')
fig.savefig(F/'checkpoint_interface.pdf');plt.close(fig)

fig,axes=plt.subplots(1,2,figsize=(7.0,2.75))
for a,ax in zip([1.,10.],axes):
 g=frame[(frame.phase=='confirmation')&(frame.runtime_multiplier==a)]
 for p in controls:
  z=g[g.policy==p];ax.scatter(z.cpu_total_s.mean()*1000,z.integrated_position_mse_m2s.mean()*1000,
                            c=colors[p],s=32 if p!=chosen else 65,marker='*' if p==chosen else 'o',label=names[p])
 ax.set_title(f'(a) Load {a:g}' if a==1. else '(b) Load 10');ax.set_xlabel('Total estimator CPU per episode (ms)')
 ax.grid(alpha=.2);ax.set_xlim(5,14.8);ax.set_ylim(7,23)
axes[0].set_ylabel('Mean position-error integral ($10^{-3}$ m$^2$s)')
handles,labels=axes[1].get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',ncol=4,fontsize=7,frameon=False)
fig.tight_layout(rect=(0,.17,1,1));fig.savefig(F/'episode_frontier.pdf');plt.close(fig)

fig,axes=plt.subplots(1,2,figsize=(7.0,2.7))
c=cal[cal.runtime_multiplier==10.]
for p in controls:
 z=c[c.policy==p].iloc[0];x=names[p];axes[0].plot([z.failure_rate,z.upper_risk],[x,x],c=colors[p],lw=2);axes[0].scatter([z.failure_rate,z.upper_risk],[x,x],c=colors[p],s=[24,15])
axes[0].axvline(.15,color='black',ls='--',lw=.8);axes[0].set_xlabel('Calibration event rate and simultaneous upper bound');axes[0].set_title('(a) 160 independent episodes');axes[0].grid(axis='x',alpha=.2)
labels=['Selected','Hold publication','Continue'];g=ab[ab.runtime_multiplier==10.]
for i,p in enumerate(['selected','hold_publication','continue_to_completion']):
 z=g[g.ablation==p];axes[1].bar(i,z.exposure_0p5_m2s.mean()*1000,color=['#D55E00','#999999','#457B9D'][i],width=.6)
axes[1].set_xticks(range(3),labels,rotation=15);axes[1].set_ylabel('First 0.5 s exposure ($10^{-3}$ m$^2$s)');axes[1].set_title('(b) Delivery/depth interventions');fig.tight_layout();fig.savefig(F/'risk_and_delivery.pdf');plt.close(fig)

# Publication benefit increases with delivery separation: selected policies only;
# this sensitivity is diagnostic and is not an added calibration family.
fig,axes=plt.subplots(1,2,figsize=(7.0,2.7))
phase=frame[(frame.phase=='confirmation')&(frame.runtime_multiplier==10.)]
for mesh,ax in zip(['B767','C172'],axes):
 g=phase[phase.mesh==mesh]
 for p in [chosen,'fixed_2','fixed_4','final']:
  z=g[g.policy==p];ax.scatter(z.cpu_total_s.mean()*1000,z.episode_rmse_m.mean()*100,c=colors[p],s=48,marker='*' if p==chosen else 'o',label=names[p])
 ax.set_title(mesh);ax.set_xlabel('Total estimator CPU (ms)');ax.grid(alpha=.2)
axes[0].set_ylabel('Mean episode position RMSE (cm)');axes[1].legend(fontsize=7,loc='best');fig.tight_layout();fig.savefig(F/'geometry_tradeoff.pdf');plt.close(fig)

# Conditional deployment envelope; these are computed reference values.
anchor={'B767':.03181,'C172':.02541};env=[]
for mesh,s0 in anchor.items():
 for sm,lag in [(.01,.05),(.02,.15),(.03,.35)]:
  val=np.sqrt(s0*s0+sm*sm+.000048*lag+(np.sqrt(3)*.0015*lag)**2)
  env.append(dict(mesh=mesh,anchor_rmse_cm=s0*100,extra_map_rms_cm=sm*100,delivery_delay_ms=lag*1000,
     predicted_rmse_cm=val*100,provenance='CONDITIONAL_ANALYTIC_REFERENCE_NOT_MEASURED'))
pd.DataFrame(env).to_csv(D/'deployment_envelope.csv',index=False);report['deployment_envelope']=env

if '--episodes' not in sys.argv and (D/'route_results.csv').exists():
 routes=pd.read_csv(D/'route_results.csv')
 if (D/'native_route_results.csv').exists():routes=pd.concat([routes,pd.read_csv(D/'native_route_results.csv')],ignore_index=True)
 report['route_run_count']=len(routes);report['routes']={mesh:{p:dict(runs=len(g),mean_rmse_cm=float(g.rmse_m.mean()*100),
    mean_cpu_s=float(g.cpu_s.mean()),mean_registration_cpu_s=float(g.correction_cpu_s.mean()),
    mean_replay_cpu_s=float(g.replay_cpu_s.mean()),mean_decision_us=float(g.mean_decision_us.mean()),
    max_position_cm=float(g.max_m.max()*100),route_events=int(g.route_event_after_5s.sum()))
    for p,g in q.groupby('method')} for mesh,q in routes.groupby('mesh')}
 fig,axes=plt.subplots(1,2,figsize=(7.0,2.7))
 for mesh,ax in zip(['B767','C172'],axes):
  for p,color,label in [('selected','#D55E00','RAVC-Loc'),('calibrated_baseline','#9B59B6','Fixed 2'),('fixed_4','#2A9D8F','Fixed 4'),('native_final','#222222','Native final'),('final','#264653','Checkpoint final')]:
   q=routes[(routes.mesh==mesh)&(routes.method==p)]
   if len(q):
    ax.scatter(q.cpu_s,q.rmse_m*100,c=color,alpha=.45,s=13)
    ax.scatter(q.cpu_s.mean(),q.rmse_m.mean()*100,c=color,s=48,marker='*' if p=='selected' else 'o',label=label)
  ax.set_title(mesh+' complete routes');ax.set_xlabel('Measured total estimator CPU (s)');ax.grid(alpha=.2)
 axes[0].set_ylabel('Mean route position RMSE (cm)');axes[1].legend(fontsize=6.7);fig.tight_layout();fig.savefig(F/'route_tradeoff.pdf');plt.close(fig)
(D/'manuscript_numbers.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k in ['policy','paired_intervals','routes','ablations','predictor']},indent=2))
