"""Fresh rendering of fixed first test scenes; no outcome-based source selection."""
from pathlib import Path
import argparse,json,subprocess,tempfile
import numpy as np
from PIL import Image
ROOT=Path(__file__).parent
(ROOT/'reproduction.json').unlink(missing_ok=True)
P=argparse.ArgumentParser();P.add_argument('--out',type=Path,default=Path('/tmp/a20-inspection-challenge-reproduction'));args=P.parse_args();args.out.mkdir(parents=True,exist_ok=True)
# Every invocation writes into a new child directory: no stale successful output
# can satisfy a failed Blender invocation or be mistaken for a fresh render.
args.out=Path(tempfile.mkdtemp(prefix='fresh-',dir=args.out))
protocol=json.loads((ROOT/'protocol.json').read_text());first={}
for source in protocol['test_sources']:first.setdefault(source['family'],source)
records=[]
for family,source in first.items():
 seed=source['seed'];conditions=['nominal','occlusion'] if family==3 else ['nominal']
 command=['/usr/bin/blender','-b','-t','4','--python-exit-code','1','--python',str(ROOT/'render.py'),'--','--seed',str(seed),'--family',str(family),'--split','test','--out',str(args.out),'--samples','32','--threads','4','--variants',','.join(conditions)]
 with (args.out/(str(seed)+'.log')).open('w') as f:subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=True)
 old=json.loads((ROOT/'test'/(str(seed)+'.json')).read_text());new=json.loads((args.out/(str(seed)+'.json')).read_text())
 for key in ('cad','actual','missing','translation_error','rotation_error'):assert np.array_equal(old[key],new[key]),(seed,key)
 oldmesh=np.load(ROOT/'test'/old['surface_mesh_file']);newmesh=np.load(args.out/new['surface_mesh_file'])
 for key in ('vertices','faces'):assert np.array_equal(oldmesh[key],newmesh[key])
 for condition in conditions:
  a=old['variants'][condition];b=new['variants'][condition]
  for key in ('camera','rotation','focal','blender_projected_pixels','visible'):assert np.array_equal(a[key],b[key]),(seed,condition,key)
  oldpixels=np.asarray(Image.open(ROOT/'test'/a['filename']));newpixels=np.asarray(Image.open(args.out/b['filename']));assert np.array_equal(oldpixels,newpixels),(seed,condition,int(np.max(np.abs(oldpixels.astype(int)-newpixels))))
  records.append(dict(seed=seed,family=family,condition=condition,max_pixel_difference=0,mesh_and_camera_exact=True))
result={'status':'PASS','selection':'first test scene of every family, nominal; first family3 occlusion','rerendered_images':len(records),'records':records,'PNG_container_scope':'Decoded pixels and mesh/camera arrays exactly reproduce. Container dates/timing fields vary.'}
(ROOT/'reproduction.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
