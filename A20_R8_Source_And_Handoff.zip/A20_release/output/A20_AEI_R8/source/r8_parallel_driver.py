"""Resource-bounded orchestration of unchanged frozen numerical entry points.

All inputs are generated sequentially after F1 and its attachment binding.
Evaluation phases have disjoint outputs. Route tasks are statically partitioned
after the protocol's seeded shuffle. A route input provider hydrates NPZ arrays
before the original online timer, so offline archive decompression is excluded
as required by the protocol; the numerical arrays/entry points are unchanged.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import argparse,json,subprocess,sys,time
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
from r8_protocol import ROOT,D,PROTOCOL,sha
from r8_preconfirmation_gate import gate
from r8_evaluate import assert_freeze

def invoke(name,args):
    logs=D/'logs';logs.mkdir(exist_ok=True);start=datetime.now(timezone.utc).isoformat();t=time.perf_counter()
    print('R8_PARALLEL_START',name,start,flush=True)
    with (logs/(name+'.log')).open('a') as f:rc=subprocess.call([sys.executable,str(ROOT/'source'/args[0]),*args[1:]],stdout=f,stderr=subprocess.STDOUT,cwd=ROOT)
    result={'stage':name,'started_utc':start,'ended_utc':datetime.now(timezone.utc).isoformat(),'wall_s':time.perf_counter()-t,
        'exit_code':rc,'command':args,'orchestrator_sha256':sha(__file__)}
    print('R8_PARALLEL_END',name,rc,round(result['wall_s'],1),flush=True)
    if rc:raise RuntimeError(name+' failed; retained log identifies the error')
    return result

def append(records):
    with (D/'parallel_execution_ledger.jsonl').open('a') as f:
        for r in records:f.write(json.dumps(r)+'\n')

def route_worker(index,count):
    import numpy as np,pandas as pd
    from collections import OrderedDict
    from rcp.sensor import Mesh
    from r8_routes import VARIANTS,run
    from r8_service import load_models
    from r8_geometry import geometry
    from r8_policy import policies
    from r8_contracts import Registry
    from r8_evaluate import runtime_bindings
    assert_freeze();start=time.process_time_ns();models=load_models();clock=json.loads((D/'clock_profile.json').read_text())
    ps={p['id']:p for p in policies()};reg=Registry(json.loads((D/'event_cards.json').read_text()),runtime_bindings())
    cal=pd.read_csv(D/'calibration.csv');table={(r.profile,r.service,r.policy):r.score_m2s for r in cal[cal.event=='trajectory'].itertuples()}
    maps={m:Mesh(geometry(m)).prior for m in PROTOCOL['route_design']['geometries']}
    startup=(time.process_time_ns()-start)*1e-9
    tasks=[(m,c,r,v) for m in PROTOCOL['route_design']['geometries'] for c in PROTOCOL['route_design']['conditions'] for r in range(4) for v in VARIANTS]
    np.random.default_rng(PROTOCOL['statistics']['seed']).shuffle(tasks);tasks=tasks[index::count]
    original=np.load;cache=OrderedDict();read_cpu=0.;loads=0
    def hydrated(path,*args,**kwargs):
        nonlocal read_cpu,loads
        if Path(path).name!='inputs.npz':return original(path,*args,**kwargs)
        key=str(path)
        if key not in cache:
            t=time.process_time_ns()
            with original(path,*args,**kwargs) as z:cache[key]={k:z[k] for k in z.files}
            read_cpu+=(time.process_time_ns()-t)*1e-9;loads+=1
            while len(cache)>2:cache.popitem(last=False)
        cache.move_to_end(key);return cache[key]
    records=[]
    try:
        np.load=hydrated
        for m,c,r,v in tasks:
            folder=D/'routes'/f'{m}_{c}_{r}';manifest=json.loads((folder/'inputs_manifest.json').read_text())
            assert manifest['input_sha256']==sha(folder/'inputs.npz')
            records.append(run(folder,m,c,r,v,models,maps[m],clock,reg,table,ps))
    finally:np.load=original
    pd.DataFrame(records).to_csv(D/f'route_results_worker_{index}.csv',index=False)
    (D/f'route_worker_{index}.json').write_text(json.dumps({'worker':index,'workers':count,'executions':len(records),
        'startup_cpu_s':startup,'offline_archive_cpu_s':read_cpu,'offline_archive_loads':loads,
        'frozen_executor_sha256':sha(ROOT/'source/r8_routes.py'),'input_provider_sha256':sha(__file__),
        'boundary':'all arrays hydrate before frozen online_start; online array copies and service work are still timed',
        'F1_sha256':sha(D/'selection_freeze.json')},indent=2))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--generate',action='store_true');ap.add_argument('--evaluate',action='store_true')
    ap.add_argument('--routes',action='store_true');ap.add_argument('--route-worker',type=int);ap.add_argument('--workers',type=int,default=4);a=ap.parse_args()
    if a.route_worker is not None:route_worker(a.route_worker,a.workers);return
    assert 1<=a.workers<=4
    phases=[p for p in PROTOCOL['blocks'] if not p.endswith('calibration')]
    if a.generate:
        gate();records=[]
        for phase in phases:records.append(invoke(phase+'_collect',['r8_collect.py','--block',phase]))
        records.append(invoke('route_inputs',['r8_routes.py','--collect']));append(records)
    if a.evaluate:
        with ThreadPoolExecutor(max_workers=a.workers) as pool:
            futures=[pool.submit(invoke,p+'_evaluate',['r8_evaluate.py','--phase',p]) for p in phases]
            records=[f.result() for f in as_completed(futures)]
        append(records)
    if a.routes:
        with ThreadPoolExecutor(max_workers=a.workers) as pool:
            futures=[pool.submit(invoke,f'route_worker_{i}',['r8_parallel_driver.py','--route-worker',str(i),'--workers',str(a.workers)]) for i in range(a.workers)]
            records=[f.result() for f in as_completed(futures)]
        append(records)
        import pandas as pd
        frame=pd.concat([pd.read_csv(D/f'route_results_worker_{i}.csv') for i in range(a.workers)],ignore_index=True)
        assert len(frame)==432 and not frame.duplicated(['mesh','condition','rep','variant']).any()
        frame.sort_values(['mesh','condition','rep','variant']).to_csv(D/'route_results.csv',index=False)
    print('R8_PARALLEL_DRIVER_DONE',flush=True)
if __name__=='__main__':main()
