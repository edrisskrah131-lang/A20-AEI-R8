"""Audit A19's controls against frozen raw records and compute failure diagnostics.

No fitting, simulation, timing measurement or result modification occurs here.
Run audit_artifacts.py first for the inherited evidence inventory.
"""
from pathlib import Path
import hashlib, itertools, json, pickle
import numpy as np
import pandas as pd
from reuse import realized
from prospective import PRICE
R=Path(__file__).resolve().parents[1]
read=lambda p:json.loads((R/p).read_text())
p=read('protocol_controls_A19.json')
for key,path in [('source_sha256','source/controls_a19.py'),('model_sha256','data/reuse_models.pkl')]:
    assert p[key]==hashlib.sha256((R/path).read_bytes()).hexdigest(),key
models=pickle.load(open(R/'data/reuse_models.pkl','rb'))
src=[json.loads(x) for x in (R/'data/confirmation_cases.jsonl').read_text().splitlines()]
d=pd.read_csv(R/'data/control_snapshots.csv')
assert len(d)==480*8 and d.groupby(['mesh','seed']).size().eq(8).all()
assert np.allclose(d.loss,d.pose_loss+.3*d.cpu_ms/1000)
identity=[]
for row in src:
    m=models[(row['mesh'],row['context'],1.,.3,'joint')]
    _,a,path,cpu=realized(row,m,'joint')
    z=d[(d.seed==row['seed']) & (d.method=='joint_nocache')].iloc[0]
    saved=row['cpu'][a] if a-1 in path else 0.
    assert np.isclose(z.cpu_ms/1000-cpu,saved,atol=1e-12)
    assert z.action==a and np.isclose(z.pose_loss,row['losses'][a]-PRICE*row['cpu'][a])
    reserved=sum(m['costs'][q+1] for q in path)
    won=reserved+(0 if a-1 in path else m['costs'][a])
    woff=reserved+m['costs'][a]
    assert won<=m['budget'] and bool(z.nominal_feasible)==(woff<=m['budget'])
    identity.append(dict(mesh=row['mesh'],seed=row['seed'],selected_action=a,
        selected_cached=a-1 in path,avoided_cpu_ms=saved*1000,
        reserved_with_cache=won,reserved_without_cache=woff,
        feasible_without_cache=bool(woff<=m['budget'])))
pd.DataFrame(identity).to_csv(R/'data/reuse_identity_checks.csv',index=False)
new=pd.read_csv(R/'data/control_missions.csv');old=pd.read_csv(R/'data/mission_results.csv')
assert len(new)==30 and len(old)==48
assert new[['mesh','replicate','method']].duplicated().sum()==0
assert set(zip(new.mesh,new.replicate,new.method))=={(t['case']['mesh'],t['case']['replicate'],t['mode']) for t in p['tasks']}
assert new.duration_s.eq(1980.).all()
maxerr=0.;maxpos=0.;repeated={};newjobs=0
for r in new.to_dict('records'):
    folder=f"{r['mesh']}_mission{r['replicate']}"
    path=R/'data/controls'/folder/(r['method']+'.json')
    obj=json.loads(path.read_text());jobs=obj['jobs'];record=obj['result']
    trace=np.load(path.with_suffix('.npz'))['trace'];assert trace.shape==(19800,6)
    assert np.isfinite(trace).all() and np.isclose(np.sqrt(np.mean(trace[:,4]**2)),r['rmse_m'])
    assert np.isclose(r['cpu_s'],r['propagation_cpu_s']+r['correction_cpu_s']+r['replay_cpu_s'])
    assert np.isclose(r['correction_cpu_s'],sum(j['cpu_s'] for j in jobs))
    assert r['calls']==len(jobs)==(494 if r['method']=='full_4s' else 989)
    assert r['overruns']==sum(j['overrun'] for j in jobs)
    assert r['infeasible_reservations']==sum(not j['nominal_feasible'] for j in jobs)
    newjobs+=len(jobs)
    for j in jobs:
        m=models[(r['mesh'],j['context'],1.,.3,'joint')]
        cache={q+1 for q in j['path']}
        reserved=sum(m['costs'][a] for a in cache)
        reserved+=m['costs'][j['action']] if j['action'] not in cache or j['recomputed'] else 0
        assert np.isclose(reserved*1e-5,j['reserved_s'])
        assert j['nominal_feasible']==(reserved<=m['budget'])
        assert j['cache_hit']==(j['action'] in cache and not j['recomputed'])
    if r['method']=='joint_nocache':
        original=read(f'data/missions/{folder}/joint_r1.json')
        ot=np.load(R/f'data/missions/{folder}/joint_r1.npz')['trace']
        assert len(original['jobs'])==len(jobs)
        for a,b in zip(original['jobs'],jobs):
            assert all(a[k]==b[k] for k in ['frame','action','path','accepted','delivery_frame'])
        assert np.allclose(trace[:,4:],ot[:,4:],rtol=0,atol=2e-15)
        assert np.array_equal(trace[:,1:4],ot[:,1:4])
        maxerr=max(maxerr,float(np.max(np.abs(trace[:,4:]-ot[:,4:]))))
        maxpos=max(maxpos,float(np.max(np.abs(trace[:,1:4]-ot[:,1:4]))))
        repeated[r['mesh']]=repeated.get(r['mesh'],0)+sum(j['recomputed'] for j in jobs)
    else:
        assert not any(j['recomputed'] for j in jobs)

# Check the aliases from actual dispatches, not from similar aggregate metrics.
for mesh in ['B767','C172']:
    for rep in range(3):
        base=f'data/missions/{mesh}_mission{rep}'
        co=read(base+'/coarse_r1.json')['jobs'];jo=read(base+'/joint_r1.json')['jobs']
        assert all(j['path']==[] and j['action']==(3 if mesh=='B767' else 1) for j in co)
        if mesh=='B767':
            assert all(j['path']==[] and j['action']==3 for j in jo)
            assert np.array_equal(np.load(R/(base+'/coarse_r1.npz'))['trace'],np.load(R/(base+'/joint_r1.npz'))['trace'])
        else:
            assert all(j['path']==[0] and j['action'] in [1,3] for j in jo)
            assert all(j['accepted'] for j in jo if j['action']==1)

failures=[]
for mesh in ['B767','C172']:
    for rep in range(3):
        for method in ['always_strict','always_tempered']:
            folder=f'{mesh}_mission{rep}'
            path=R/'data/controls'/folder/(method+'.json')
            if not path.exists():path=R/'data/missions'/folder/'coarse_r1.json'
            obj=json.loads(path.read_text());jobs=obj['jobs'];trace=np.load(path.with_suffix('.npz'))['trace']
            longest=max((sum(1 for _ in g) for flag,g in itertools.groupby(j['accepted'] for j in jobs) if not flag),default=0)
            failures.append(dict(mesh=mesh,replicate=rep,method=method,rmse_cm=obj['result']['rmse_m']*100,
                accepted=sum(j['accepted'] for j in jobs),correction_opportunities=len(jobs),
                longest_rejection_interval_s=2*longest,fraction_position_error_above_10cm=float(np.mean(trace[:,4]>.1))))
pd.DataFrame(failures).to_csv(R/'data/rejection_diagnostics.csv',index=False)
out=dict(status='PASS',additional_actual_runs=len(new),total_actual_runs=len(old)+len(new),
    unique_mission_inputs=6,simulated_controller_hours=float((new.duration_s.sum()+old.duration_s.sum())/3600),
    new_correction_decisions=newjobs,total_correction_decisions=int(newjobs+old.calls.sum()),
    source_cache_identity_checks=len(identity),source_infeasible_without_cache={mesh:sum(not r['feasible_without_cache'] for r in identity if r['mesh']==mesh) for mesh in ['B767','C172']},
    cache_intervention_pairs=6,avoided_repeated_calls_by_aircraft=repeated,
    cache_error_trace_max_difference=maxerr,cache_world_position_trace_max_difference=maxpos,
    new_actual_cpu_budget_overruns=int(new.overruns.sum()),all_actual_cpu_budget_overruns=int(new.overruns.sum()+old.overruns.sum()),
    new_infeasible_requested_reservations=int(new.infeasible_reservations.sum()),
    frozen_control_source_and_model='hashes match',dispatch_aliases='pass',new_metric_and_cost_ledgers='pass',
    note='Supplemental controls were specified after inspecting the primary comparison; no model was refit.')
(R/'qa/evidence_audit_A19.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
