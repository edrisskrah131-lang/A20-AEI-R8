"""Create a stable source release, then verify every included member's hash."""
from pathlib import Path
import zipfile,hashlib,json,sys
ROOT=Path(__file__).resolve().parents[1]
PREFIX='A20_release/output/A20_AEI_R4/'
TOP=['main.tex','supplement.tex','main.bbl','references.bib','elsarticle.cls','elsarticle-num.bst',
     'README.md','requirements-R4.txt','ENVIRONMENT.json','Highlights.txt','Cover_Letter.txt','AUTHOR_DECLARATIONS.md',
     'RECOVERY_PROVENANCE.md','REVISION_REPORT_CN.md','AI_ASSISTANCE_RECORD.md']
def selected():
    members=[ROOT/n for n in TOP]
    for folder in ['source','sections','figures','data']:
        members += [p for p in (ROOT/folder).rglob('*') if p.is_file()
              and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.log','.aux']
              and not (p.parent in [ROOT/'figures/r6',ROOT/'figures/r7'] and
                  (p.suffix in ['.png','.tiff'] or p.name=='simulation_views.svg'))]
    members += [p for p in (ROOT/'preserved').iterdir() if p.is_file()]
    members += [p for p in (ROOT/'preserved/lost_R4_audited_text').rglob('*') if p.is_file()]
    for folder in ['reconstruction_pilot','reconstruction_pilot_2']:
        members += [p for p in (ROOT/'preserved'/folder).rglob('*') if p.is_file()
              and (p.name in ['freeze.json','protocol.json','collection_manifest.json'] or p.suffix=='.md')]
    members += [p for p in (ROOT/'qa').iterdir() if p.is_file() and p.suffix in ['.md','.json']]
    return sorted(set(members),key=lambda p:p.relative_to(ROOT).as_posix())
def main():
    destination=Path(sys.argv[1]).resolve();destination.parent.mkdir(parents=True,exist_ok=True)
    files=selected()
    assert all(p.is_file() for p in files)
    entries={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    (ROOT/'FILE_SHA256.json').write_text(json.dumps(entries,indent=2,sort_keys=True))
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
        for p in files:z.write(p,PREFIX+p.relative_to(ROOT).as_posix())
        z.write(ROOT/'FILE_SHA256.json',PREFIX+'FILE_SHA256.json')
    with zipfile.ZipFile(destination) as z:
        assert z.testzip() is None
        manifest=json.loads(z.read(PREFIX+'FILE_SHA256.json'))
        assert set(z.namelist())=={PREFIX+n for n in manifest}|{PREFIX+'FILE_SHA256.json'}
        for n,expected in manifest.items():
            h=hashlib.sha256()
            with z.open(PREFIX+n) as f:
                for block in iter(lambda:f.read(1<<20),b''):h.update(block)
            assert h.hexdigest()==expected,n
    report={'status':'PASS','members':len(files)+1,'manifest_hashes':len(entries),
       'archive_bytes':destination.stat().st_size,'archive_sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),
       'prefix':PREFIX,'excluded':'QA page renders, caches, working logs, incomplete pilot raw inputs; compiled current papers are delivered separately; redundant R6/R7 PNG/TIFF/scene SVG exports are in the companion figure bundle and regenerable from included code/originals',
       'contains_original_archives':True}
    destination.with_suffix('.audit.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report),flush=True)
if __name__=='__main__':main()
