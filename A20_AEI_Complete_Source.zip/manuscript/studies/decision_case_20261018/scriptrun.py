"""Reproduce the fixed-input decision example and allowance sensitivity.

Only this study directory is written. The image experiment remains immutable.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
import numpy as np
import pandas as pd
from scipy.stats import beta

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "lifecycle_20261018"
sys.path.insert(0, str(SOURCE))
import evidence

ALLOWANCES = (0.02, 0.05, 0.10, 0.15, 0.20)
SPEC = json.loads((SOURCE / "protocol.json").read_text())
K = SPEC["family_K"]
ALPHA = SPEC["confidence_error"] / K
METRIC_UNITS = {
    "gsd_m": ("gsd_mm_per_pixel", 1000.0),
    "blur_px": ("blur_px", 1.0),
    "coverage": ("correct_address_coverage_percent", 100.0),
    "reprojection_px": ("reprojection_px", 1.0),
    "association_m": ("mapping_error_mm", 1000.0),
}


def dump(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def main():
    frame = pd.read_csv(SOURCE / "outputs/observations.csv")
    groups = {
        variant: group.sort_values("seed")
        for variant, group in frame[frame.phase == "calibration"].groupby("variant")
    }
    for group in groups.values():
        assert len(group) == SPEC["calibration_inputs"] == 256
        assert group.seed.nunique() == 256
    costs, route_rows, plans_at_default = [], [], None
    direct_cards = None
    for allowance in ALLOWANCES:
        answer_vectors = []
        for method in evidence.METHODS:
            cost, plans, cards = evidence.construct(
                groups, method, alpha=ALPHA, allowance=allowance
            )
            costs.append(dict(allowance=allowance, **cost))
            route_rows.extend(dict(allowance=allowance, method=method, **p) for p in plans)
            answer_vectors.append([p["authorized"] for p in plans])
            if allowance == SPEC["allowance"]:
                if method == "Contract + fallback":
                    plans_at_default = plans
                elif method == "Whole renewal":
                    direct_cards = cards
        assert all(v == answer_vectors[0] for v in answer_vectors)
    cost_frame = pd.DataFrame(costs)
    cost_frame.to_csv(ROOT / "sensitivity.csv", index=False)
    pd.DataFrame(route_rows).to_csv(ROOT / "sensitivity_routes.csv", index=False)

    validation_rows = []
    assert direct_cards is not None
    for card in direct_cards:
        test = frame[(frame.phase == "test") & (frame.variant == card["variant"])]
        n = len(test)
        assert n == SPEC["test_inputs"] == 256
        test_k = int(evidence.failures(test, card["request"]).sum())
        test_upper = 1.0 if test_k == n else float(beta.isf(ALPHA, test_k + 1, n - test_k))
        validation_rows.append({
            "variant": card["variant"], "request": card["request"],
            "calibration_n": card["n"], "calibration_failures": card["k"],
            "calibration_upper": card["upper"],
            "calibration_admitted_at_015": card["upper"] <= 0.15,
            "test_n": n, "test_failures": test_k, "test_upper": test_upper,
        })
    validation = pd.DataFrame(validation_rows)
    validation.to_csv(ROOT / "event_validation.csv", index=False)
    selected = validation[validation.calibration_admitted_at_015]
    assert len(selected) == 41
    assert (selected.test_upper <= 0.15).all()
    validation_summary = {
        "family_K": K, "confidence_error": SPEC["confidence_error"], "alpha": ALPHA,
        "test_n_per_event": 256, "calibration_selected_at_015": len(selected),
        "selected_test_upper_max": float(selected.test_upper.max()),
        "selected_max_test_failures": int(selected.test_failures.max()),
        "selected_all_test_upper_at_most_015": bool((selected.test_upper <= 0.15).all()),
        "maximum_rows": selected.loc[selected.test_upper == selected.test_upper.max(),
                                      ["variant", "request", "test_failures"]].to_dict("records"),
        "support_by_allowance": [
            {"allowance": allowance,
             "calibration_supported": int((validation.calibration_upper <= allowance).sum()),
             "test_upper_at_most_allowance": int((validation.test_upper <= allowance).sum()),
             "calibration_selected_with_test_upper_at_most_allowance": int(
                 ((validation.calibration_upper <= allowance) &
                  (validation.test_upper <= allowance)).sum())}
            for allowance in ALLOWANCES
        ],
        "interpretation": (
            "Independent held-out event evaluation covers every one of the same 48 pre-specified "
            "producer/request programs on all 256 test scenes. No issuance filtering is used. "
            "The held-out confidence family is assessed separately from the calibration family; "
            "two 95% family statements do not imply one joint 95% statement."
        ),
    }
    dump("validation_summary.json", validation_summary)

    thresholds = []
    for name, intervals in evidence.REQUESTS.items():
        row = {"request": name}
        for metric, column, bound, scale in [
            ("gsd_m", "gsd_upper_mm_per_pixel", 1, 1000.0),
            ("blur_px", "blur_upper_px", 1, 1.0),
            ("coverage", "coverage_lower_percent", 0, 100.0),
            ("reprojection_px", "reprojection_upper_px", 1, 1.0),
            ("association_m", "mapping_upper_mm", 1, 1000.0),
        ]:
            value = intervals.get(metric, (None, None))[bound]
            row[column] = None if value is None else value * scale
        thresholds.append(row)
    pd.DataFrame(thresholds).to_csv(ROOT / "request_thresholds.csv", index=False)

    seed = int(frame.loc[frame.phase == "test", "seed"].min())
    assert seed == SPEC["test_seed_start"]
    first = frame[(frame.phase == "test") & (frame.seed == seed)]
    plan_lookup = {(p["variant"], p["request"]): p for p in plans_at_default}
    exact_lookup = {(p["variant"], p["request"]): p for p in validation_rows}
    variants = {}
    for variant in ("baseline", "exposure"):
        sample = first[first.variant == variant]
        assert len(sample) == 1
        values = sample.iloc[0]
        requests = {}
        for request in evidence.REQUESTS:
            requests[request] = {
                "instance_passes": not bool(evidence.failures(sample, request)[0]),
                "exact_event_evidence": exact_lookup[variant, request],
                "contract_route": plan_lookup[variant, request],
            }
        variants[variant] = {
            "scene_layout_index": int(values.layout), "surface_family_index": int(values.family),
            "values_in_report_units": {
                out_name: float(values[metric]) * scale
                for metric, (out_name, scale) in METRIC_UNITS.items()
            },
            "matched_targets": int(values.matched_targets),
            "planned_targets": int(values.planned_targets),
            "requests": requests,
        }
    assert variants["baseline"]["values_in_report_units"]["gsd_mm_per_pixel"] == \
        variants["exposure"]["values_in_report_units"]["gsd_mm_per_pixel"]
    assert all(r["instance_passes"] for v in variants.values() for r in v["requests"].values())
    assert plan_lookup["baseline", "complete"]["authorized"]
    assert not plan_lookup["exposure", "complete"]["authorized"]
    assert plan_lookup["exposure", "complete_relaxed"]["authorized"]
    assert plan_lookup["exposure", "complete_relaxed"]["route"] == "exact"
    assert evidence.projection("baseline", "optical") != evidence.projection("exposure", "optical")

    recovery_path = ROOT.parent / "validated_recovery_20261018/outputs/example_trace.json"
    recovery = json.loads(recovery_path.read_text())
    assert recovery["seed"] == seed
    trace_columns = ("seed", "request", "fault", "step", "revision", "state",
                     "attached_seed", "attached_variant", "numerical_origin_valid",
                     "risk_authorized", "expected_issue", "quarantine_repair",
                     "authoritative_snapshot", "event_sourced", "permanent_latch", "repair_accepted")
    compact_traces = {}
    for request in ("complete", "complete_relaxed", "optical"):
        trace = recovery["examples"][request + "/stale_producer_output"]["trace"]
        assert len(trace) == 13
        for step in trace:
            for method in ("quarantine_repair", "authoritative_snapshot", "event_sourced"):
                assert step[method] == step["expected_issue"]
            # Check that the executed attachment example uses the same immutable image values.
            attached = first[first.variant == step["attached_variant"]].iloc[0]
            assert step["attached_seed"] == seed
            for metric in METRIC_UNITS:
                assert np.isclose(step["attached_offline_scores"][metric], attached[metric], atol=1e-13)
        compact_traces[request] = [{column: step[column] for column in trace_columns} for step in trace]
    pd.DataFrame([row for trace in compact_traces.values() for row in trace]).to_csv(
        ROOT / "attachment_case_trace.csv", index=False)

    case = {
        "selection": {"rule": "Smallest seed in the entire held-out test split, before inspecting outcomes.",
                      "seed": seed, "phase": "test", "outcome_selection": False},
        "allowance": SPEC["allowance"], "family_K": K, "alpha": ALPHA,
        "variants": variants,
        "exposure_change": {
            "multiplier": 1.5,
            "unchanged_quantity": "GSD; its requested provider projection excludes exposure.",
            "optical_card_retained": False,
            "optical_card_reason": "Both optical requests also constrain blur, whose provider projection includes exposure.",
            "standalone_gsd_card_constructed": False,
            "strict_complete_instance_failure": False,
            "strict_complete_population_admission": False,
            "relaxed_complete_population_admission": True,
            "relaxed_complete_route": "exact",
        },
        "population_decision_sequence": [
            {"stage": "baseline", "producer": "baseline", "strict_complete_admitted": True,
             "relaxed_complete_admitted": True},
            {"stage": "exposure +50%", "producer": "exposure", "strict_complete_admitted": False,
             "relaxed_complete_admitted": True},
            {"stage": "original producer restored", "producer": "baseline", "strict_complete_admitted": True,
             "relaxed_complete_admitted": True},
        ],
        "interpretation": (
            "The selected image passes every defined quality event before and after the exposure change. "
            "Strict complete-service evidence is nevertheless unavailable for the exposure producer "
            "because its population calibration bound exceeds the allowance. A bound U concerns the "
            "specified producer/event over the specified scene population; it is not a deterministic "
            "safety assertion for this single image. Restoring population compatibility alone does not "
            "resolve an invalid output attachment; source repair is evaluated in the separate validated-recovery study."
        ),
        "allowance_meaning": (
            "Delta=0.15 is an illustrative permitted population frequency of the defined image-quality "
            "failure event. It is not a missed-defect probability, accident probability, safety certification "
            "criterion, or claimed industrial-standard threshold. The request thresholds were retained "
            "from the earlier controlled study without tuning on this population."
        ),
        "validated_recovery": {
            "trace_source": "../validated_recovery_20261018/outputs/example_trace.json",
            "source_sha256": hashlib.sha256(recovery_path.read_bytes()).hexdigest(),
            "selection_rule": "Same first held-out seed; stale-producer-output fault for all three displayed requests.",
            "traces": compact_traces,
            "interpretation": (
                "A wrong attachment quarantines the original binding. Correct-value retry, source rename, "
                "and invalid repair requests do not restore issuance. An authenticated monotonic repair "
                "to revision 2 restores the same binding with the exposure producer. Relaxed complete "
                "service and optical evidence can then issue; strict complete service still cannot issue "
                "because its exposure-population calibration bound remains too large. The authoritative "
                "snapshot, event-sourced implementation, and quarantine/repair contract make the same "
                "decisions. A duplicate repair command is rejected without poisoning a successfully repaired binding."
            ),
        },
    }
    dump("case.json", case)

    inputs = [SOURCE / "outputs/observations.csv", SOURCE / "outputs/compiled_requests.json",
              SOURCE / "protocol.json", SOURCE / "evidence.py", SOURCE / "imaging.py",
              ROOT.parent / "cad_surface_20261014/protocol.json", recovery_path]
    dump("provenance.json", {"inputs": {
        str(p.relative_to(ROOT.parent)): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs
    }, "image_data_regenerated": False, "new_event_family_created": False,
        "allowance_grid": list(ALLOWANCES), "family_K": K})
    print(json.dumps({"first_seed": seed, "support": validation_summary["support_by_allowance"],
                      "heldout_max_upper": validation_summary["selected_test_upper_max"]}, indent=2))


if __name__ == "__main__":
    main()
