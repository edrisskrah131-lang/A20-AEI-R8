"""Reserve planning only when the complete solver remains affordable.

The gate is an admission condition under a frozen timing table, not a bound
on measured wall latency or a guarantee about estimation error.
"""
from .core import Planner
from .cached_rollout import CachedRolloutPlanner

class SupportPlanner:
    def __init__(self,model,profile,costs,lam=.003):
        self.costs=costs;self.options=[];self.active=None;self.selected=None
        common=dict(costs=costs,lam=lam,overhead_rate=profile['common']['propagation_rate'])
        for mode,steps in [('cached_rollout',4),('cached8',2),('exact',1)]:
            reserve=profile[mode]['greedy_decision_cost' if steps==1 else 'rcp_decision_cost']
            planner=Planner(model,'greedy',decision_cost=reserve,**common) if steps==1 else CachedRolloutPlanner(model,'rcp',decision_cost=reserve,planning_steps=steps,**common)
            self.options.append((mode,steps,reserve,planner))
    def reserve(self,tokens):
        self.active=None;self.selected=None
        for mode,steps,reserve,planner in self.options:
            if reserve+self.costs['full']<=tokens:
                self.active=planner;self.selected=(mode,steps,reserve)
                return reserve
        return None
    def choose(self,inp,features,J,future=None):
        if inp.age>=12.:
            return ('full' if self.costs['full']<=inp.tokens else 'skip'),{'reason':'common_cadence_floor','horizon_s':0}
        assert self.active is not None
        action,diag=self.active.choose(inp,features,J,future)
        diag.update(reason='support_preserving',horizon_s=4*self.selected[1],planning_mode=self.selected[0],reserved_decision_cpu=self.selected[2],reserved_full_cpu=self.costs['full'])
        return action,diag
