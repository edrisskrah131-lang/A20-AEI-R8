"""Vector figures rebuilt solely from final frozen records."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from r4_protocol import ROOT,D
F=ROOT/'figures/r4';F.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
COL={'KG1':'#b44728','Fixed2':'#507ba5','Fixed4':'#647886','Final':'#6a536f','FlatCART':'#87aab8','FlatRF':'#72a085','ContractRF':'#236b50','KG1_no_deadline':'#607b98'}
PH=['nominal_confirmation','difficult_confirmation','geometry_confirmation','shift_confirmation']
LABEL=['Nominal','Difficult priors','Unfitted geometry','Shifted noise / prior']
def save(fig,name):
    fig.savefig(F/f'{name}.pdf',bbox_inches='tight');fig.savefig(F/f'{name}.png',dpi=180,bbox_inches='tight');plt.close(fig)
def main():
    fig,ax=plt.subplots(figsize=(7.0,2.8));ax.set(xlim=(0,10),ylim=(0,4));ax.axis('off')
    boxes=[(.1,2.5,2.1,1.0,'Scan + sealed prior\nObserved quality / work'),(2.6,2.5,2.0,1.0,'Profile + time rules\nAdmissible caps'),(5.0,2.5,2.0,1.0,'Outcome forecasts\nPublish / continue / stop'),(7.4,2.5,2.4,1.0,'Source replacement\nCausal motion replay'),(.1,.4,2.1,1.0,'Frozen policy / forecast\nMixture + event card'),(3.1,.4,3.0,1.0,'Match source, profile, event,\nservice and requested allowance'),(7.0,.4,2.8,1.0,'Applicable population bound\nor provisional / refused')]
    for x,y,w,h,t in boxes:
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.04',facecolor='#f1f5f7',edgecolor='#506d7c',lw=.9));ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=7.4)
    for a,b in [((2.2,3),(2.6,3)),((4.6,3),(5,3)),((7,3),(7.4,3)),((2.2,.9),(3.1,.9)),((6.1,.9),(7,.9)),((8.6,2.5),(8.6,1.4))]:ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'->','color':'#536979','lw':1.1})
    ax.text(.02,3.85,'Numerical execution',fontweight='bold',fontsize=8);ax.text(.02,1.8,'Separate statistical statement service',fontweight='bold',fontsize=8)
    save(fig,'contracts')
    s=pd.read_csv(D/'summary.csv');s=s[s.load==20]
    ps=list(COL)[:-1];fig,axs=plt.subplots(2,2,figsize=(7.0,4.8))
    marks={'KG1':'*','Fixed2':'s','Fixed4':'s','Final':'D','FlatCART':'o','FlatRF':'o','ContractRF':'*'}
    for ax,phase,label in zip(axs.flat,PH,LABEL):
        for p in ps:
            r=s[(s.phase==phase)&(s.policy==p)].iloc[0];ax.scatter(r.cpu_ms,r.loss*1000,c=COL[p],marker=marks[p],s=60 if p in ['KG1','ContractRF'] else 30,label=p)
        ax.set_title(label,loc='left');ax.set_xlabel('Charged numerical CPU (ms)');ax.set_ylabel('Position-loss integral (10⁻³ m² s)');ax.grid(alpha=.2)
    h,l=axs[0,0].get_legend_handles_labels();fig.legend(h,l,ncol=4,loc='lower center',bbox_to_anchor=(.5,-.02),frameon=False);fig.tight_layout(rect=(0,.1,1,1));save(fig,'frontier')
    inf=pd.read_csv(D/'influence.csv').set_index('phase').loc[PH];fig,axs=plt.subplots(1,2,figsize=(7.0,2.9));x=np.arange(4);w=.26
    full=[1-s[(s.phase==p)&(s.policy=='KG1')].iloc[0].loss/s[(s.phase==p)&(s.policy=='Fixed2')].iloc[0].loss for p in PH]
    for off,v,l,c in [(-w,full,'All samples','#b44728'),(0,inf.gain_excluding_top_two,'Remove two largest gains','#507ba5'),(w,inf.tail_improvement,'Largest 5% loss mean','#72a085')]:axs[0].bar(x+off,np.asarray(v)*100,w,label=l,color=c)
    axs[0].set_ylabel('Improvement vs Fixed2 (%)');axs[0].set_xticks(x,['Nominal','Difficult','Geometry','Shift']);axs[0].legend(frameon=False,fontsize=6.6);axs[0].grid(axis='y',alpha=.2)
    gains=pd.read_csv(D/'policy_results.csv');gains=gains[(gains.load==20)&(gains.phase=='difficult_confirmation')];a=gains[gains.policy=='KG1'].set_index('seed').loss_m2s;b=gains[gains.policy=='Fixed2'].set_index('seed').loss_m2s
    delta=(b-a).sort_values().to_numpy();axs[1].plot(np.arange(1,len(delta)+1),delta*1000,color='#b44728',lw=1);axs[1].axhline(0,color='#82909c',lw=.8);axs[1].set_xlabel('Paired episode rank');axs[1].set_ylabel('Fixed2 − KG1 loss (10⁻³ m² s)');axs[1].set_title('Difficult mixture: individual effects',fontsize=8,loc='left');fig.tight_layout();save(fig,'influence')
    stress=pd.read_csv(D/'service_stress_summary.csv');q=stress[stress.phase=='nominal_confirmation'];fig,axs=plt.subplots(1,3,figsize=(7.0,2.7))
    for p in ['KG1','KG1_no_deadline','Fixed2']:
        v=q[q.policy==p].sort_values('load')
        for ax,col,scale in zip(axs,['cpu_ms','loss','success'],[1,1000,100/640]):ax.plot(v.load,v[col]*scale,'o-',color=COL[p],label=p,ms=3)
    for ax,label in zip(axs,['Numerical CPU (ms)','Loss (10⁻³ m² s)','Successful pose requests (%)']):ax.set_xlabel('Additional declared load');ax.set_ylabel(label);ax.grid(alpha=.2);ax.set_xticks([40,60])
    axs[0].legend(frameon=False,fontsize=6.6);fig.tight_layout();save(fig,'workload')
    r=pd.read_csv(D/'route_results.csv');order=['Fixed2','KG1','FlatRF','ContractRF','Fixed4','Final'];q=r.groupby('policy').mean(numeric_only=True).loc[order]
    fig,axs=plt.subplots(1,3,figsize=(7.0,2.8));x=np.arange(len(order))
    for ax,col,scale,label in zip(axs,['cpu_s','rmse_cm','capture_success'],[1,1,100/299],['CPU per 600-s route (s)','Route RMSE (cm)','Successful pose requests (%)']):
        ax.bar(x,q[col]*scale,color=[COL[p] for p in order]);ax.set_xticks(x,order,rotation=55,ha='right',fontsize=6.5);ax.set_ylabel(label);ax.grid(axis='y',alpha=.2)
    fig.tight_layout();save(fig,'routes')
    print('R4_FIGURES_COMPLETE',flush=True)
if __name__=='__main__':main()
