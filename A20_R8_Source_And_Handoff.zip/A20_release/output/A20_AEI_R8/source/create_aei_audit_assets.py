"""Create an AEI decision-semantic vector figure and stratum table from stored results.
No new simulation: all measurements are grouped from the original A20 confirm table.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

ROOT=Path(__file__).resolve().parents[1]
figdir=ROOT/'figures'; figdir.mkdir(exist_ok=True)

# Vector decision-semantics diagram: readable at single-column journal width.
fig,ax=plt.subplots(figsize=(6.6,4.0))
ax.set_xlim(0,6.6);ax.set_ylim(0,4.0);ax.axis('off')
blue='#224B73';gold='#996324';grey='#596B7E'

def box(x,y,w,h,title,desc,color=blue):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.055,rounding_size=0.105',
        facecolor='#F4F7FA' if color==blue else '#FDF8EE',edgecolor=color,lw=1.15))
    ax.text(x+w/2,y+h-.22,title,fontsize=10.3,fontweight='bold',ha='center',va='center',color=color)
    ax.plot([x+.12,x+w-.12],[y+h-.41]*2,color=color,lw=.6,alpha=.3)
    ax.text(x+w/2,y+.37,desc,fontsize=9.7,linespacing=1.28,ha='center',va='center',color='#24384B')

def arrow(x1,y1,x2,y2):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=12,lw=1.2,color=grey))

box(.18,2.73,3.00,1.02,'ENGINEERING CONTEXT',
    'Airframe identity / source prior\nSource lineage / task risk')
box(3.42,2.73,3.00,1.02,'CHECKPOINT EVIDENCE',
    'Geometric information / residuals\nInliers / progress / runtime')
box(1.27,1.45,4.06,.92,'EXPLICIT DECISION SEMANTICS',
    'Validity and risk rules\nPredicted benefit versus work',gold)
box(.18,.16,3.00,.94,'DELIVERY ACTIONS',
    'Publish / stop / continue\nRollback and replay')
box(3.42,.16,3.00,.94,'REPRODUCIBLE AUDIT',
    'Version trace / CPU ledger\nEpisode-risk certificate')
arrow(1.68,2.68,2.55,2.44)
arrow(4.92,2.68,4.05,2.44)
arrow(2.55,1.39,1.68,1.16)
arrow(4.05,1.39,4.92,1.16)
fig.savefig(figdir/'engineering_decision_knowledge.pdf',bbox_inches='tight',pad_inches=.12)
fig.savefig(figdir/'engineering_decision_knowledge.png',dpi=220,bbox_inches='tight',pad_inches=.12)
plt.close(fig)

# Context table reconstructed by pairing policy results on the same seed.
pd.set_option('display.float_format',lambda x:f'{x:.6f}')
d=pd.read_csv(ROOT/'data/policy_episode_results.csv')
d=d[(d.phase=='confirmation')&(d.runtime_multiplier==10)]
a=d[d.policy=='learned_p1_r0.3'].set_index('seed'); b=d[d.policy=='fixed_2'].set_index('seed')
assert len(a)==len(b)==240 and set(a.index)==set(b.index)
joined=a.copy();joined['fixed_loss']=b.loc[a.index,'integrated_position_mse_m2s']
joined['improvement']=joined['fixed_loss']-joined['integrated_position_mse_m2s']
joined['continued']=joined.stop_iteration.gt(2)
summ=joined.groupby('sd',sort=True).agg(n=('continued','size'),extended=('continued','sum'),frac=('continued','mean'),cpu=('cpu_total_s','mean'),gain=('improvement','mean'))
assert sum(summ.n)==240 and summ.extended.sum()==15
lines=[
 '\\begin{table}[t]\\centering\\small',
 '\\caption{Retrospective prior-uncertainty decision audit on 240 independent confirmation episodes at load factor 10. Improvement is Fixed~2 minus selected policy in integrated position loss; all strata are descriptive, not separately calibrated.}\\label{tab:context-audit}',
 '\\begin{tabular}{@{}rrrrr@{}}\\toprule',
 'Prior SD (cm) & Episodes & Deeper than 2 & Selected CPU (ms) & Loss gain ($10^{-3}$ m$^2$s)\\\\\\midrule'
]
for sd,row in summ.iterrows():
 lines.append(f"{sd*100:.1f} & {int(row['n'])} & {int(row['extended'])}/{int(row['n'])} ({row['frac']*100:.1f}\\%) & {row['cpu']*1000:.2f} & {row['gain']*1000:.3f} \\\\")
lines.extend(['\\bottomrule\\end{tabular}','\\end{table}'])
(ROOT/'sections/context_audit_table.tex').write_text('\n'.join(lines)+'\n')
(ROOT/'data/aei_context_strata.csv').write_text(summ.reset_index().to_csv(index=False))
print(summ.to_string())
