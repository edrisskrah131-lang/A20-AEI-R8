"""Recompute selected outputs without the stage cache and compare archived values."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import json
import numpy as np,pandas as pd
from imaging import *
ROOT=Path(__file__).parent

def check(job):
 seed,variant,expected=job;s=draw(seed);c=configuration(variant)
 # Explicit direct pipeline, independent of Pipeline.get/key and cache traversal.
 g=geometry(s,c);rad=radiance(s,c,g);rgb=sensor(s,c,rad);dec=decode(rgb,c['decoder']);values,im=fit(s,c,dec);values.update({k:v for k,v in optical(s,c).items() if k!='gsds'})
 error=max(abs(values[k]-expected[k]) for k in QUANTITIES if np.isfinite(values[k]) and np.isfinite(expected[k]))
 for k in QUANTITIES:assert np.isclose(values[k],expected[k],atol=1e-9,rtol=1e-10), (seed,variant,k,values[k],expected[k])
 return error
if __name__=='__main__':
 ob=pd.read_csv(ROOT/'outputs/observations.csv');g=ob.query('phase=="test" and variant=="baseline"');seeds=[]
 for layout in range(4):seeds+=g.query('layout==@layout').sort_values('seed').head(8).seed.tolist()
 selected=ob[(ob.phase=='test')&ob.seed.isin(seeds)];jobs=[(int(r.seed),r.variant,{k:float(getattr(r,k)) for k in QUANTITIES}) for r in selected.itertuples()]
 with ProcessPoolExecutor(2) as pool:errors=list(pool.map(check,jobs,chunksize=1))
 result=dict(status='PASS',independent_inputs=len(seeds),cold_producer_runs=len(jobs),max_quantity_error=max(errors));(ROOT/'outputs/cold_cache_equivalence.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
