"""Rerun A19 confirmation and all 78 controllers with archived frozen models.

The destination must be new. Training records, models, mission inputs and common
initialization are retained. Every confirmation callback and all 78 controller
runs are executed again; the policy is not refitted.
"""
import argparse, json, os, platform, shutil, subprocess, sys
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('destination',type=Path)
p.add_argument('--prepare-only',action='store_true',help='stage a fresh run without executing simulations')
a=p.parse_args();src=Path(__file__).resolve().parents[1];dst=a.destination.resolve()
if dst.exists():raise SystemExit('Destination must not already exist.')
dst.mkdir(parents=True)
for folder in ['source','meshes','assets']:
    shutil.copytree(src/folder,dst/folder,ignore=shutil.ignore_patterns('__pycache__'))
for name in ['requirements.txt','protocol_missions.json','protocol_confirmation.json','protocol_controls_A19.json']:
    shutil.copy2(src/name,dst/name)
for folder in ['data','figures','qa','tables']:(dst/folder).mkdir()
for name in ['prospective_cases.jsonl','reuse_models.pkl','reuse_selection.json','runtime_profile.json','environment.json']:
    shutil.copy2(src/'data'/name,dst/'data'/name)
for folder in (src/'data/missions').iterdir():
    target=dst/'data/missions'/folder.name;target.mkdir(parents=True)
    for name in ['inputs.npz','manifest.json','initial.npz']:shutil.copy2(folder/name,target/name)
(dst/'data/rerun_environment.json').write_text(json.dumps(dict(python=sys.version,platform=platform.platform(),
    processor=platform.processor(),scope='Frozen models and input files; newly executed confirmation and all controllers'),indent=2))
(dst/'README_RERUN.txt').write_text('New measurements with archived frozen models. No published manuscript or result was copied.\n'
    'If an alias or cache-trace assertion fails, timing changed delivery or execution; inspect fresh logs before using alias tables.\n'
    'CPU comparisons must use fresh results together. Published percentages do not automatically apply.\n')
if a.prepare_only:
    print('Prepared fresh run directory:',dst)
    raise SystemExit(0)
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
subprocess.run(['g++','-O3','-shared','-std=c++17','-fPIC','source/rcp/bvh.cpp','-o','source/rcp/libbvh.so'],cwd=dst,check=True)
scripts=['confirm.py','missions.py','controls_a19.py','verify_reuse.py','audit_artifacts.py','audit_a19.py',
         'figures_a18.py','analyze_a19.py','figures_a19.py']
for script in scripts:
    subprocess.run([sys.executable,'source/'+script],cwd=dst,env=env,check=True)
print('Fresh result directory:',dst)
print('Interpret CPU and accuracy from the new records; the manuscript describes the archived run.')
