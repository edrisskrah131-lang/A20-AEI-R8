"""One-time F0 freeze. Refuses an already-observed final sample."""
import json,platform,sys,subprocess
from datetime import datetime,timezone
from importlib.metadata import version
from r8_protocol import ROOT,D,A19,PROTOCOL,sha,digest
from r8_policy import policies
from r8_geometry import geometry,route
import train,prospective

def freeze():
    target=D/'freeze.json'
    if target.exists():raise RuntimeError('F0 already exists; do not overwrite it')
    if (D/'episodes.jsonl').exists() or any((D/'episode_inputs').glob('*.npz')):raise RuntimeError('final observations precede F0')
    preflight=json.loads((ROOT/'qa/r8/preflight.json').read_text());assert preflight['status']=='PASS'
    for name,h in preflight['method_sha256'].items():assert sha(ROOT/'source'/name)==h,('preflight method changed',name)
    methods=['r8_protocol','r8_collect','r8_geometry','r8_policy','r8_service','r8_contracts','r8_clock','r8_evaluate','r8_routes','r8_verify','r8_freeze']
    component_files=[ROOT/'source'/f'{n}.py' for n in methods]
    component_files += [ROOT/'source'/n for n in ['checkpoint.py','r4_sensor.py','r4_policy.py']]
    component_files += [__import__('pathlib').Path(m.__file__) for m in [train,prospective]]
    component_files += list((A19/'source/rcp').glob('*.py'))
    component_files += list((A19/'source/rcp').glob('*.so'))
    component_files += [geometry(m,l) for m in ['B767','C172','UnfittedAirframe'] for l in range(4)]
    component_files += [route(m) for m in ['B767','C172','UnfittedAirframe']]
    component_files += [ROOT/'data/r4_final/cart_forecast.npz',ROOT/'data/r4_final/rf_forecast.npz',ROOT/'data/checkpoint_model.npz',ROOT/'data/r4_final/freeze.json']
    components={str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(__import__('os').path.relpath(p,ROOT)):sha(p) for p in component_files}
    # Preserved assets are hashed independently, rather than edited or replayed
    # into the new study's calibration denominator.
    retained=[p for folder in ['preserved','figures/r7/hardware_originals','figures/r6/simulation_originals'] for p in (ROOT/folder).rglob('*') if p.is_file()]
    preservation={str(p.relative_to(ROOT)):sha(p) for p in sorted(retained)}
    (ROOT/'qa/r8/preserved_assets_manifest.json').write_text(json.dumps(preservation,indent=2))
    env={'python':sys.version,'platform':platform.platform(),'packages':{n:version(n) for n in ['numpy','scipy','pandas','matplotlib','scikit-learn']},
        'threading':'OPENBLAS_NUM_THREADS=1; OMP_NUM_THREADS=1','hardware':subprocess.check_output(['lscpu'],text=True),
        'native_clock':'time.process_time_ns; measured host CPU, not an embedded platform benchmark'}
    (D/'environment.json').write_text(json.dumps(env,indent=2))
    record={'version':'R8-F0-method-and-service-profile','utc':datetime.now(timezone.utc).isoformat(),'protocol_sha256':sha(D/'protocol.json'),
        'collector_sha256':sha(ROOT/'source/r8_collect.py'),'clock_sha256':sha(D/'clock_profile.json'),'components':components,
        'policies':policies(),'K':528,'pilot_seeds_excluded':list(range(8200000,8200048)),
        'preflight_sha256':sha(ROOT/'qa/r8/preflight.json'),'retained_assets_manifest_sha256':sha(ROOT/'qa/r8/preserved_assets_manifest.json'),
        'final_input_files_at_freeze':0,'selection_rule':'calibration only; all F1 plans fixed before confirmation generation',
        'interpretation':'prospective new study after previous-study inspection; local signed hashes establish consistency, not an external preregistration'}
    target.write_text(json.dumps(record,indent=2,allow_nan=False))
    print('R8_F0_FROZEN',record['utc'],len(components),'components',len(preservation),'retained assets',flush=True)

if __name__=='__main__':freeze()
