"""Execute frozen task plans on confirmation sources; no model/plan fitting.

The underlying numerical prefix is shared exactly as in the controlled policy
experiment. Dispatch, producer witnessing, replay, active-version checks and
the two independent validators actually execute. Request contexts and all
choices were sealed by F1 before these inputs were generated.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import json,time,argparse
import numpy as np,pandas as pd
from r8_protocol import ROOT,D,PROTOCOL,sha
from r8_evaluate import assert_freeze,runtime_bindings,relevant_bindings
from r8_contracts import Registry,dispatch,procedural_dispatch
from r8_policy import policies
from r8_service import load_models,prediction_cache,controlled
from r8_claim_layer import execute_with_claims

def execute():
    assert_freeze();f=json.loads((D/'selection_freeze.json').read_text())
    amendment=json.loads((D/'claim_layer_freeze.json').read_text())
    for p,h in amendment['components'].items():assert sha(ROOT/p)==h
    for key,p in [('F0_sha256','freeze.json'),('protocol_sha256','protocol.json'),('clock_sha256','clock_profile.json')]:assert amendment[key]==sha(D/p)
    assert amendment['audit_sha256']==sha(ROOT/'qa/r8/claim_layer_audit.json')
    bound=json.loads((D/'attachment_selection_binding.json').read_text())
    assert bound['F1_sha256']==sha(D/'selection_freeze.json') and bound['amendment_sha256']==sha(D/'claim_layer_freeze.json')
    for p,h in f['files'].items():assert sha(D/p)==h
    plans=[p for p in json.loads((D/'selection_plans.json').read_text()) if p['request']['allowance']==.15]
    assert len(plans)==32
    runtime=runtime_bindings();cards=json.loads((D/'event_cards.json').read_text());fullreg=Registry(cards,runtime);flatreg=Registry(cards,runtime)
    cal=pd.read_csv(D/'calibration.csv');table={(r.profile,r.service,r.policy):r.score_m2s for r in cal[cal.event=='trajectory'].itertuples()}
    models=load_models();ps={p['id']:p for p in policies()};services={s['id']:s for s in PROTOCOL['services']}
    for phase,profile in [('nominal_confirmation','nominal'),('geometry_confirmation','unfitted')]:
        rows=[json.loads(x) for x in (D/'episodes.jsonl').read_text().splitlines() if json.loads(x)['phase']==phase]
        assert len(rows)==2048;rows.sort(key=lambda x:x['seed']);requests=[p for p in plans if p['request']['profile']==profile]
        folder=D/'integrated'/phase;folder.mkdir(parents=True,exist_ok=True)
        for chunk in range(32):
            out=folder/f'chunk_{chunk:03d}.csv.gz';manifest=folder/f'chunk_{chunk:03d}.json'
            if out.exists() and manifest.exists():
                m=json.loads(manifest.read_text());assert sha(out)==m['sha256']
                assert m['F1_sha256']==sha(D/'selection_freeze.json') and m['executor_driver_sha256']==sha(__file__)
                assert m['claim_layer_freeze_sha256']==sha(D/'claim_layer_freeze.json')
                assert m['binding_sha256']==sha(D/'attachment_selection_binding.json')
                continue
            records=[]
            for r in rows[chunk*64:(chunk+1)*64]:
                # All dispatches run on fixed requests before source arrays are
                # opened; the policy choices are checked against the F1 plans.
                dispatched=[]
                for frozen in requests:
                    req=frozen['request'];a=dispatch(fullreg,table,req,list(ps));b=procedural_dispatch(flatreg.cards,table,req,list(ps),runtime)
                    assert (a['status'],a['policy'])==(b['status'],b['policy'])==(frozen['Full']['status'],frozen['Full']['policy'])
                    dispatched.append((req,a,b))
                # Archive decompression is offline data access, outside service
                # timing. Online source/state array copies remain inside it.
                with np.load(D/'episode_inputs'/f"{r['seed']}.npz") as archive:z={k:archive[k] for k in archive.files}
                cache=prediction_cache(r,models)
                for req,a,b in dispatched:
                    pair=[];service=services[req['service']]
                    for variant,plan,reg,manual in [('Full',a,fullreg,False),('TaskAwareFlatValidated',b,flatreg,True)]:
                        policy=ps[plan['policy'] or 'KG1'];binding=relevant_bindings(runtime,profile,service,policy)
                        result=execute_with_claims(r,z,policy,cache,clock,service,binding,plan,reg,manual)
                        result['source_claims']=json.dumps(result['source_claims'],separators=(',',':'))
                        result.update(variant=variant,task=req['task'],allowance=req['allowance'],admission=plan['status'],
                            chosen_policy=plan['policy'],dispatch_cpu_s=plan['cpu_s'],eligible_policies=len(plan.get('eligible',[])))
                        result['native_charged_cpu_s']+=plan['cpu_s'];pair.append(result);records.append(result)
                    for key in ['work_s','loss_m2s','trajectory_failure','observation_failure','union_failure','capture_success','stop_iteration']:
                        assert pair[0][key]==pair[1][key],('wrapper changes event trace',r['seed'],req,key)
                    assert json.loads(pair[0]['trace'])==json.loads(pair[1]['trace'])
            temp=out.with_suffix('.tmp');pd.DataFrame(records).to_csv(temp,index=False,compression='gzip');temp.replace(out)
            manifest.write_text(json.dumps({'phase':phase,'seeds':[r['seed'] for r in rows[chunk*64:(chunk+1)*64]],'rows':len(records),
                'sha256':sha(out),'F1_sha256':sha(D/'selection_freeze.json'),'executor_driver_sha256':sha(__file__),
                'claim_layer_freeze_sha256':sha(D/'claim_layer_freeze.json'),
                'binding_sha256':sha(D/'attachment_selection_binding.json'),
                'unit':'shared confirmation input; repeated task/method execution is paired, not a new independent input'},indent=2))
            print('R8_INTEGRATED_CONFIRMATION',phase,chunk+1,32,flush=True)
    print('R8_INTEGRATED_COMPLETE',131072,'executions on',4096,'inputs',flush=True)

if __name__=='__main__':
    clock=json.loads((D/'clock_profile.json').read_text());execute()
